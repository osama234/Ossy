<?php
	class checks_controller extends controller
	{
		function __construct() {
            parent::__construct();
        }
        
        function index($params=null) {
			return(true);
		}
		
		
		public function rccheck($act='',$id='')
		
		{ $this->vars['act']=$act;
		 
		  if($act=='add' and isset($_POST['rccheck']))
		   {
		   
		   $rccheck=$_POST['rccheck'];
		 
		   $sql = $this->mydb->sql_insert('rcchecks',$rccheck);
		   $this->mydb->execute($sql,$rccheck);
		   
		   $dtl['rc_id'] = $this->mydb->insert_id();
						$dtl['rc_userid'] = $this->user['user_id'];
						$dtl['dtl_islast'] = 1;
						$dtl['dtl_time'] = time();
						$dtl['rc_notes'] = $_POST['dtl']['rc_notes'];
					   $sql2 = $this->mydb->sql_insert('rcchecks_dtl', $dtl);
						
		  if($this->mydb->execute($sql2, $dtl))
		   {
		   SetMessage('تم حفظ الطلب بنجاح','success');
		   redirect('checks/rccheck');
		    }
			
		   
		   }elseif($act=='update' and $id){
				
				   if(isset($_POST['rccheck']))
				  {
				     
						    $rccheck=$_POST['rccheck'];
					
						  
						  
		               $rc_rtl=array('rc_id'=>$id,'rc_notes'=>$rccheck['req_desc'],'rc_userid'=>$this->user['user_id'],'dtl_time'=>time(),'dtl_islast'=>1);
					     
						 
				       if(isset($rccheck['rc_status']))
					    { $rc_rtl['rc_status']=$rccheck['rc_status'];
					     unset($rccheck['rc_status']);
						 }
					  $this->update_dtl('rcchecks_dtl','dtl_islast',array('rc_id'=>$id));
					  
		               $sql = $this->mydb->sql_update('rcchecks',$rccheck,array('id'=>$id));
					    $sql2 = $this->mydb->sql_insert('rcchecks_dtl',$rc_rtl);
		              if($this->mydb->execute($sql,$rccheck) and $this->mydb->execute($sql2,$rc_rtl))
		                 { SetMessage('تم حفظ التعديلات بنجاح','success');
		                    redirect('checks/rccheck');
		                  }
						  
				  }
				    
				       $q = $this->mydb->execute('SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (id=rc_id) where dtl_islast =1 and id=:id',array('id'=>$id));
				         while ($row = $this->mydb->fetch_assoc($q)) {
					     $this->vars['rccheck'] = $row;
						 	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck']['rc_status']);
				         }
				  }	 
		    else {
				$sql = 'SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (id=rc_id) where dtl_islast =1 and (rc_status=0 or rc_status=-1 or rc_status=7)';
				$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row;
				}}
		
		
		
		
		
		}
		
		
		public function auditinfo($act='',$id='')
		{
		$this->vars['act']=$act;
		  if($act=='add' and isset($_POST['rccheck']))
				  {
				       $rccheck=$_POST['rccheck'];
		               $rc_dtl=array('rc_id'=>$id,'rc_notes'=>$rccheck['req_desc'],'rc_userid'=>$this->user['user_id'],'dtl_time'=>time(),'dtl_islast'=>1);
					  $this->update_dtl('rcchecks_dtl','dtl_islast',array('rc_id'=>$id));
					  
		               $sql = $this->mydb->sql_update('rcchecks',$rccheck,array('id'=>$id));
					    $sql2 = $this->mydb->sql_insert('rcchecks_dtl',$rc_dtl);
		              if($this->mydb->execute($sql,$rccheck) and $this->mydb->execute($sql2,$rc_dtl))
		                 { SetMessage('تم حفظ التعديلات بنجاح','success');
		                    redirect('checks/rccheck');
		                  }
						  
				}elseif($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
						 
					  $dtl=$_POST['dtl'];
					 $dtl['rc_userid']=$this->user['user_id'];
					 $dtl['rc_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('rcchecks_dtl','dtl_islast',array('rc_id'=>$id));
					   $sql = $this->mydb->sql_insert('rcchecks_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم اعتماد فحص البيانات','success');
		                    redirect('checks/auditinfo');
							
							
							}
					  }
			    
                  $q = $this->mydb->execute(' SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (id=rc_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rc_status']);
				  
				  }else {$sql = 'SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (rcchecks_dtl.rc_id=rcchecks.id) where dtl_islast =1 and ( rc_status=0 or rc_status=8 or rc_status=9 )';
				$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row;
				}}
		
		}
		
		
		
		
		
		
		public function auditing($act='' , $id='')
		 {
		         	$this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rc_userid']=$this->user['user_id'];
					 $dtl['rc_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('rcchecks_dtl','dtl_islast',array('rc_id'=>$id));
					   $sql = $this->mydb->sql_insert('rcchecks_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم التدقيق بنجاح','success');
		                    redirect('checks/auditing');
							
							
							}
					  }
			    
                  $q = $this->mydb->execute(' SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (id=rc_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rc_status']);
				  
				  }


  			 else{$sql = 'SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (rcchecks_dtl.rc_id=rcchecks.id) where dtl_islast =1 and rc_status=1 '; $this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row;
				}
		        }
		 
		 
		 }
		 
		 public function approval($act='',$id='')
		 
		 { 
		   
		   
		   	$this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rc_userid']=$this->user['user_id'];
					 $dtl['rc_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('rcchecks_dtl','dtl_islast',array('rc_id'=>$id));
					   $sql = $this->mydb->sql_insert('rcchecks_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم حفظ الإجراء بنجاح','success');
		                    redirect('checks/approval');
							
							
							}
					  }
			    
                  $q = $this->mydb->execute(' SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (id=rc_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rc_status']);
				  
				  }


  			 else{ $sql = 'SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (rcchecks_dtl.rc_id=rcchecks.id) where dtl_islast =1 and rc_status=2  ';$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row; 
				}
		        }
		 
		 
		 
		 
		 
		  }
		  
		  public function records($act='',$id='')
		  {
		   	$this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rc_userid']=$this->user['user_id'];
					 $dtl['rc_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('rcchecks_dtl','dtl_islast',array('rc_id'=>$id));
					   $sql = $this->mydb->sql_insert('rcchecks_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم حفظ الإجراء بنجاح','success');
		                    redirect('checks/records');
							
							
							}
					  } 
			    
                  $q = $this->mydb->execute(' SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (id=rc_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rc_status']);
				  
				  }


  			 else{ $sql = 'SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (rcchecks_dtl.rc_id=rcchecks.id) where dtl_islast =1 and (rc_status=3 or rc_status=-3) ';$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row; 
				}
		        }
             
		  
		  }
		  
		  public function executive($act='',$id='')
		  {
		  $this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rc_userid']=$this->user['user_id'];
					 $dtl['rc_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('rcchecks_dtl','dtl_islast',array('rc_id'=>$id));
					   $sql = $this->mydb->sql_insert('rcchecks_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم حفظ الإجراء بنجاح','success');
		                    redirect('checks/executive');
							
							
							}
					  }
			    
                  $q = $this->mydb->execute(' SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (id=rc_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rc_status']);
				  
				  }


  			 else{ $sql = 'SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (rcchecks_dtl.rc_id=rcchecks.id) where dtl_islast =1 and (rc_status=4  or rc_status=5 or rc_status=-4)';$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row; 
				}
		        }
		  
		  }
		  
		  
		  public function wcheck($act='',$id='')
		  
		  {
		   $this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rc_userid']=$this->user['user_id'];
					 $dtl['rc_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('rcchecks_dtl','dtl_islast',array('rc_id'=>$id));
					   $sql = $this->mydb->sql_insert('rcchecks_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم حفظ الإجراء بنجاح','success');
		                    redirect('checks/wcheck');
							
							
							}
					  }
			    
                  $q = $this->mydb->execute(' SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (id=rc_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rc_status']);
				  
				  }


  			 else{ $sql = 'SELECT * FROM rcchecks INNER JOIN rcchecks_dtl ON (rcchecks_dtl.rc_id=rcchecks.id) where dtl_islast =1 and rc_status=6 ';$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row; 
				}
		        }
		  
		  
		  
		  }
		  
		  
		  
		  
		  
		  
		  
		public function update_dtl($table='',$field='',$where)
		{
		   $sql= $this->mydb->sql_update($table,array($field=>0),$where);
		   if($this->mydb->execute($sql))
		   return true;
		   else
		   return false;
		}
		
			
		private function getLastProcess($status) {
			switch (abs($status)) {
				case 0: return 'تسجيل طلب صرف شيك';
				case 1: return 'فحص طلبات صرف الشيك';
				case 2: return 'تدقيق طلبات صرف الشيك';
				case 3: return 'اعتماد مبدئي للطلب';
				case 4: return 'اعداد محضر صرف مالي';
				case 5: return 'اعداد محضر صرف مالي';
				case 6: return 'اعتماد محضر صرف مالي';
				case 7: return 'تحرير شيك الصرف';
				case 8: return 'استلام الشيك';
				case 9: return 'اغلاق الطلب';
				
			}
		}
		}
		
		
