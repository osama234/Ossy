		<?php  if (isset($rccheck_dtl )){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($rccheck_dtl['rc_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ArDate('d/m/Y', $rccheck_dtl['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$rccheck_dtl['rc_notes']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th width="20%">رقم التسلسل</th>
					<td><?=$rccheck_dtl['id']?></td>
				</tr>
				<tr>
					<th width="20%">اسم المستفيد</th>
					<td><?=$rccheck_dtl['recipient_name']?></td>
				</tr>
				<tr>
					<th width="20%">جهة المستفيد</th>
					<td><?=$rccheck_dtl['recipient_d']?></td>
				</tr>
				<tr>
					<th width="20%">قيمة العهدة</th>
					<td><?=$rccheck_dtl['c_amount']?></td>
				</tr>
				<tr>
					<th width="20%">تاريخ طلب الصرف</th>
					<td><?=$rccheck_dtl['rec_date']?></td>
				</tr>
				<tr>
					<th width="20%">اسم المشروع</th>
					<td><?=GetProjectsLabel($rccheck_dtl['proj_name'])?></td>
				</tr>				
				<tr>
					<th width="20%">ملاحظات المشروع</th>
					<td><?=$rccheck_dtl['projectnote']?></td>
				</tr>
				<tr>
					<th width="20%">مبررات الصرف</th>
					<td><?=$rccheck_dtl['reason']?></td>
				</tr>				
				<tr>
					<th width="20%">ملاحظات</th>
					<td><?=$rccheck_dtl['req_desc']?></td>
				</tr>
			</table>
		</div>
		<?php if($rccheck_dtl['rc_status']!=9){ ?>
		<form action="<?=base_url()?>checks/auditinfo/show/<?=$rccheck_dtl['rc_id']?>" method="post" data-toggle="validator" role="form"  enctype="multipart/form-data">
			<div class="panel panel-primary">
			  
				<div class="panel-heading">الإجراء المتخذ</div>
				<table class="table">
					<tr>
						<th width="20%">القرار</th>
					<?php if($rccheck_dtl['rc_status']==0){ ?>
						<td>
							<input type="radio" name="dtl[rc_status]" id="rc_status1" value="1" /><label for="dtl_status1">يوجد رصيد</label>
							<input type="radio" name="dtl[rc_status]" id="rc_status2" value="-1" /><label for="dtl_status2">ﻻ يوجد رصيد</label>
							</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[rc_notes]" rows="3" class="form-control"></textarea></td>
					</tr>
					<?php }else{ ?>
					<td>
					<input type="radio" name="dtl[rc_status]" id="rc_status1" value="9" /><label for="dtl_status1">تسجيل</label>
					
					</td>
					<?php } ?>
					<tr>
						<th></th>
						<td>
							<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
							<a href="#" class="btn btn-warning print_btn">طباعة</a>
						</td>
					</tr>
				</table>
			</div>
		</form>
		<?php }?>
<?php } else{?>
			<div class="panel panel-primary">
			<div class="panel-heading">طلبات صرف الشيكات المسجلة</div>
			<table class="table">
				<tr>
                    <th>اسم المستفيد</th>
                    <th>جهة المستفيد</th>
                    <th>المبلغ</th>
                    <th>اسم المشروع</th>
					 <th>حالة الطلب</th>
                    <th>إجراءات</th>
                </tr>
			<?php if(isset($rccheck)) foreach($rccheck as $row ) { ?>
				<tr <?=($row['rc_status']==8 ? ' class="success"':($row['rc_status']==9 ? 'class="danger"' :'') )?>>
					<td><?=$row['recipient_name']?></td>
					<td><?=$row['recipient_d']?></td>
					<td><?=$row['c_amount']?></td>
					<td><?=GetProjectsLabel($row['proj_name'])?></td>
					<td><?=($row['rc_status']==8 ? 'تم استلام الشيك' :($row['rc_status']==9 ? 'تم إغلاق الطلب': 'جديد')  )?></td>
					<td><a href="<?=base_url()?>checks/auditinfo/show/<?=$row['id']?>" class="btn btn-primary">عرض</a></td>
				</tr>
             <? }?> </table></div> 
			 <a href="#" class="btn btn-warning print_btn">طباعة</a><br/><?=$paging?>
			 </div>
<?php } ?>
