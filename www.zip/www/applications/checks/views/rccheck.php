		<?php  if($act=='add'){?>
			<div class="panel panel-primary">
				<div class="panel-heading">الشيكات</div>
				<div class="panel-body">
					<h2>تسجيل طلب صرف شيك</h2>
					<form action="<?=base_url() ?>checks/rccheck/add" method="post" data-toggle="validator" role="form">
						<div class="form-group">
							<label for="rccheck[recipient_name]" class="control-label">اسم المستفيد :</label>
							<input type="text" name="rccheck[recipient_name]" value="" id="rccheck[recipient_name]"  class="form-control"  required="true" />
						</div>
						<div class="form-group ">
							<label for="rccheck[recipient_d]" class="control-label">جهة المستفيد : </label>
							<input type="text" name="rccheck[recipient_d]" value="" id="rccheck[recipient_d]"  class="form-control" required="true" />
						</div>
<div class="form-group">
					<label for="rccheck[c_amount]" class="control-label">القيمة</label>
					<input type="text" name="rccheck[c_amount]"  id="rccheck[c_amount]"  class="form-control oneone" value="0"  required="true" />
				</div>
				<div class="form-group">
					<label for="d_mount_t" class="control-label">المبلغ كتابة</label>
					 
						<input type="text" name="donate[d_mount_t]" value="<?=$donation['d_mount_t'] ?>" id="d_mount_t"  class="form-control" required="true" />
					 
				</div>
						<div class="form-group">
							<label for="rccheck[rec_date]" class="control-label">تاريخ تقديم طلب الصرف</label>
							<input type="text" name="rccheck[rec_date]" value="" id="rccheck[rec_date]"  class="form-control datepicker" required="true" />
						</div>
						<div class="form-group">
							<label for="rccheck[proj_name]" class="control-label">اسم المشروع</label>
							<select  class="form-control" name="rccheck[proj_name]">
		                		<option></option>
		                		<?=GetProjects() ?>
		                	</select>
						</div>
						<div class="form-group">
					<label for="rccheck[projectnote]" class="control-label">ملاحظات المشروع</label>
					<textarea  id="rccheck[req_desc]" name="rccheck[projectnote]" class="form-control" ></textarea>
				</div>
			
						<div class="form-group">
							<label for="rccheck[req_desc]" class="control-label">ملاحظات</label>
						<textarea  id="rccheck[req_desc]" name="rccheck[req_desc]" class="form-control"></textarea>
						</div>
						<div class="form-group ">
							<input type="submit" value="حفظ وإعتماد" class="btn btn-primary btn-md ">
							 <a href="#" class="btn btn-warning btn-md ">طباعة</a>
						</div>
					</form>
				</div>
			</div>
							<script type="text/javascript" language="javascript">
				 
			$('.oneone').change(function(){
				
				$.ajax('<?=base_url() ?>numbers.php?val=' + $('.oneone').val()).done(function( html ) {
					$('#d_mount_t').val(html);
				});
			});
		</script>
		<?}elseif($act=='update'){ ?>
			<div class="panel panel-primary">
				<div class="panel-heading">العملية السابقة</div>
				<table class="table">
					<tr>
						<th width="20%">اسم العملية</th>
						<td><?=$lastProcess ?></td>
					</tr>
					<tr>
						<th>العملية بواسطة</th>
						<td><?=GetUserById($rccheck['rc_userid'], 'user_name') ?></td>
					</tr>
					<tr>
						<th>تاريخ العملية</th>
						<td><?=ArDate('d/m/Y', $rccheck['dtl_time']) ?></td>
					</tr>
					<tr>
						<th>الملاحظات</th>
						<td><?=$rccheck['rc_notes'] ?></td>
					</tr>
				</table>
			</div>
			
			<div class="panel panel-primary">
				<div class="panel-heading">الشيكات</div>
				<div class="panel-body">
			<form action="<?=base_url() ?>checks/rccheck/update/<?=$rccheck['id'] ?>" method="post" data-toggle="validator" role="form">
			
				<div class="form-group">
					<label for="rccheck[recipient_name]" class="control-label" >اسم المستفيد :</label>
					<input type="text" name="rccheck[recipient_name]"  id="rccheck[recipient_name]" value="<?=$rccheck['recipient_name'] ?>"   class="form-control"  required="true" />
				</div>
				<div class="form-group ">
				
					<label for="rccheck[recipient_d]" class="control-label" >جهة المستفيد : </label>
					<input type="text" name="rccheck[recipient_d]"  id="rccheck[recipient_d]"  class="form-control" required="true" value="<?=$rccheck['recipient_d'] ?>" />
				</div>
				<div class="form-group">
					<label for="rccheck[c_amount]" class="control-label">القيمة</label>
					<input type="text" name="rccheck[c_amount]"  id="rccheck[c_amount]"  class="form-control oneone" value="<?=$rccheck['c_amount'] ?>"  required="true" />
				</div>
				<div class="form-group">
					<label for="d_mount_t" class="control-label">المبلغ كتابة</label>
					 
						<input type="text" name="donate[d_mount_t]" value="<?=$donation['d_mount_t'] ?>" id="d_mount_t"  class="form-control" required="true" />
					 
				</div>
				<div class="form-group">
					<label for="rccheck[rec_date]" class="control-label">تاريخ تقديم طلب الصرف</label>
					<input type="text" name="rccheck[rec_date]" id="rccheck[rec_date]"  class="form-control" required="true" value="<?=$rccheck['rec_date'] ?>"  required="true"/>
				</div>
				<div class="form-group">
					<label for="rccheck[proj_name]" class="control-label">اسم المشروع</label>
					<select  class="form-control" name="rccheck[proj_name]">
                		<option></option>
                		<?=GetProjects($rccheck['proj_name']) ?>
                	</select>
				</div>
				
				<?php if($rccheck['rc_status'] <= 0){?>
				<div class="form-group">
					<label for="rccheck[req_desc]" class="control-label">ملاحظات المشروع</label>
					<textarea  id="rccheck[req_desc]" name="rccheck[projectnote]" class="form-control" ><?=  $rccheck['projectnote']   ?></textarea>
				</div>	<div class="form-group">
					<label for="rccheck[reason]" class="control-label">مبررات الصرف</label>
					<input type="text" name="rccheck[reason]"  id="rccheck[reason]"  class="form-control" value="<?=  $rccheck['reason']   ?>" />
				</div><div class="form-group">
					<label for="rccheck[req_desc]" class="control-label">ملاحظات</label>
					<textarea  id="rccheck[req_desc]" name="rccheck[req_desc]" class="form-control" ><?=  $rccheck['req_desc']   ?></textarea>
				</div>
				<?}else{ ?>
				<input type="radio" name="rccheck[rc_status]" id="rc_status1" value="8" /><label for="dtl_status1">استلام</label>
				<?} ?>			
				<div class="form-group ">	
					<input type="submit" value="حفظ وإعتماد" class="btn btn-primary btn-md ">
					<a href="#" class="btn btn-warning print_btn">طباعة</a>
				</div>
            </form>
				</div>
						<script type="text/javascript" language="javascript">
				$.ajax('<?=base_url() ?>numbers.php?val=' + $('.oneone').val()).done(function( html ) {
					$('#d_mount_t').val(html);
				});
			$('.oneone').change(function(){
				
				$.ajax('<?=base_url() ?>numbers.php?val=' + $('.oneone').val()).done(function( html ) {
					$('#d_mount_t').val(html);
				});
			});
		</script>
		<?}else{ ?>
			<div class="panel panel-primary">
				<div class="panel-heading">طلبات صرف الشيكات المسجلة</div>
				<table class="table">
					<tr>
	                    <th>اسم المستفيد</th>
	                    <th>جهة المستفيد</th>
	                    <th>المبلغ</th>
	                    <th>اسم المشروع</th>
				        <th>حالة الطلب</th>
	                    <th>إجراءات</th>
	                </tr>
					<?php if(isset($rccheck)) foreach($rccheck as $row ) { ?>
			 		<tr <?=($row['rc_status'] < 0 ? ' class="danger"' : ($row['rc_status'] == 7 ? ' class="success"' : '')) ?>>                    
						<td><?=$row['recipient_name'] ?></td>
						<td><?=$row['recipient_d'] ?></td>
						<td><?=$row['c_amount'] ?></td>
						<td><?=GetProjectsLabel($row['proj_name']) ?></td>
						<td><?=($row['rc_status'] < 0 ? 'يوجد ملاحظات' : ($row['rc_status'] == 7 ? 'بإنتظار الإستلام' : 'جديد')) ?></td>
						<?php if($row['rc_status'] <= 0){?>
						<td><a href="<?=base_url() ?>checks/rccheck/update/<?=$row['id'] ?>" class="btn btn-warning">تحديث</a></td>
						<?php }else{ ?>
						<td><a href="<?=base_url() ?>checks/rccheck/update/<?=$row['id'] ?>" class="btn btn-success">عرض و استلام</a></td>
						<?php } ?>				 
					</tr>
                    <?php } ?>
				</table>
			</div>
            	<a href="<?=base_url() ?>checks/rccheck/add" class="btn btn-success">تسجيل طلب جديد</a>
				<a href="#" class="btn btn-warning print_btn">طباعة</a>
            	<?=$paging ?><br/>
			</div>
		<?php } ?>
