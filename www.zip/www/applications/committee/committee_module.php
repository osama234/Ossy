<?php

class committee_controller extends controller
{
    function __construct()
    {
        parent::__construct();
    }

    function index($params = null)
    {
        return (true);
    }

    private function addBeneficiary($beneficiary, $residence, $phones, $family)
    {
        // insert beneficiary main info
        if (!empty($beneficiary)) {
            $beneficiary['b_userid'] = $this->user['user_id'];
            $beneficiary['b_lastchange'] = time();
            $beneficiary['b_account_no'] = 'SA' . $beneficiary['b_account_no'];
            $_SESSION['beneficiary'] = $beneficiary;
        }
        // insert residence info
        $this->vars['wives'] = $_POST['wives'];
        if (!empty($residence)) {
            if (!empty($_SESSION['beneficiary'])) {
                $sql = $this->mydb->sql_insert('mcw_committee.beneficiaries', $_SESSION['beneficiary']);
                $this->mydb->execute($sql, $_SESSION['beneficiary']);
                $bid = $this->mydb->insert_id();
				if ($bid == 0) {
					setMessage('رقم الهوية مسجل مسبقاً.', 'error');
					unset($_SESSION['beneficiary']);
					Redirect('committee/beneficiaries/add');
				}
                $this->vars['bid'] = $residence['r_bid'] = $bid;
                $this->vars['wives'] = $_SESSION['beneficiary']['b_wives'];
                unset($_SESSION['beneficiary']);
                $residence['r_no'] = 1;
            }
            if (empty($residence['r_rent'])) unset($residence['r_rent']);
            $residence['r_userid'] = $this->user['user_id'];
            $residence['r_lastchange'] = time();
            $sql = $this->mydb->sql_insert('mcw_committee.residences', $residence, +1);
            $this->mydb->execute($sql, $residence);
            $this->vars['bid'] = $residence['r_bid'];
            $this->vars['bno'] = ((int)intval($residence['r_no'])) + 1;
        }

        // insert phones
        if (!empty($phones)) {
            $phone['p_bid'] = $this->vars['bid'];
            $phone['p_userid'] = $this->user['user_id'];
            $phone['p_time'] = time();
			$phone['p_no'] = $residence['r_no'];
            foreach ($phones['p_number'] as $key => $v) {
                $phone['p_number'] = $phones['p_number'][$key];
                $phone['p_name'] = $phones['p_name'][$key];
                $sql = $this->mydb->sql_insert('mcw_committee.phones', $phone);
                $this->mydb->execute($sql);
            }
        }
        if (!empty($family)) {
            $family['f_bid'] = $this->vars['bid'];
            $family['data'] = serialize($family['data']);
            $family['lastchange'] = time();
			$family['f_no'] = $residence['r_no'];
            $family['userid'] = $this->user['user_id'];
            $sql = $this->mydb->sql_insert('mcw_committee.family', $family);
            $this->mydb->execute($sql, $family);
        }
        if (isset($this->vars['wives']) and $this->vars['bno'] > $this->vars['wives']) {
            SetMessage('تمت إضافة البيانات بنجاح', 'success');
            Redirect('committee/beneficiaries/show/' . $this->vars['bid']);
        }
    }

	
    private function show($id, $part)
    {
        if (!$part) {
            $part = 1;
        }
        $query = $this->mydb->execute('SELECT r_no, r_wife_name FROM mcw_committee.residences WHERE r_bid=:id',
            array('id' => $id));
        while ($row = $this->mydb->fetch_assoc($query)) {
            $this->vars['family_buttons'][] = $row;
        }
        $this->vars['beneficiary'] = $this->mydb->fetch_assoc($this->mydb->execute(
            'SELECT * FROM mcw_committee.beneficiaries
									 INNER JOIN mcw_committee.residences ON (r_bid=b_id AND r_no=:no)
									 LEFT JOIN mcw_committee.class ON (c_bid=b_id AND c_no=:no)
									 WHERE b_id=:id', array('id' => $id, 'no' => $part)));
        $q = $this->mydb->execute('SELECT * FROM mcw_committee.phones WHERE p_bid=:id AND p_no=:no',
            array('id' => $id, 'no' => $part));
        while ($row = $this->mydb->fetch_assoc($q)) {
            $this->vars['phones'][] = $row;
        }
        $this->vars['family'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mcw_committee.family WHERE f_bid=:id AND f_no=:no',
            array('id' => $id, 'no' => $part)));
        if ($this->vars['family']) {
            $this->vars['family']['data'] = unserialize($this->vars['family']['data']);
        }
        $q = $this->mydb->execute('SELECT * FROM mcw_committee.patients WHERE s_bid=:id AND s_no=:no',
            array('id' => $id, 'no' => $part));
        while ($row = $this->mydb->fetch_assoc($q)) {
            $this->vars['patients'][] = $row;
        }
        $q = $this->mydb->execute('SELECT * FROM mcw_committee.incomes WHERE i_bid=:id', array('id' => $id));
        while ($row = $this->mydb->fetch_assoc($q)) {
            $this->vars['incomes'][] = $row;
        }
        $sql = 'SELECT *  FROM mcw_committee.distribute_dtl INNER JOIN mcw_committee.distribute ON dtl_pid=d_id WHERE dtl_bid = :id';
        $q = $this->mydb->execute($sql, array('id' => $part));
        while ($row = $this->mydb->fetch_assoc($q)) {
            $this->vars['disbursed'][] = $row;
        }
    }

    private function deletePatients($id, $no)
    {
        $item = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mcw_committee.patients WHERE s_id=:id', array('id' => $id)));
        $this->mydb->execute('DELETE FROM mcw_committee.patients WHERE s_id=:id', array('id' => $id));
        SetMessage('تم حذف البيانات بنجاح', 'success');
        Redirect('committee/beneficiaries/edit/sicks/' . $item['s_bid'] . '/' . $no);
    }
	
    private function editPatients($id, $no)
    {
        if (isset($_POST['patients'])) {
            foreach ($_POST['patients']['s_name'] as $key => $v) {
                $patient['s_name'] = $_POST['patients']['s_name'][$key];
                $patient['s_relation'] = $_POST['patients']['s_relation'][$key];
                $patient['s_type'] = $_POST['patients']['s_type'][$key];
                $patient['s_report'] = $_POST['patients']['s_report'][$key];
                $patient['s_needs'] = $_POST['patients']['s_needs'][$key];
                $patient['s_bid'] = $id;
                $patient['s_no'] = $no;
                $patient['s_userid'] = $this->user['user_id'];
                $patient['s_time'] = time();
                $sql = $this->mydb->sql_insert('mcw_committee.patients', $patient);
                $this->mydb->execute($sql);
            }
            SetMessage('تمت إضافة البيانات بنجاح', 'success');
        }
        $q = $this->mydb->execute('SELECT * FROM mcw_committee.patients WHERE s_bid=:id AND s_no=:no',
            array('id' => $id, 'no' => $no));
        while ($row = $this->mydb->fetch_assoc($q)) {
            $this->vars['patients'][] = $row;
        }
        $this->vars['bid'] = $id;
        $this->vars['bno'] = $no;
    }

    private function deleteIncomes($id)
    {
        $item = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mcw_committee.incomes WHERE i_id=:id',
            array('id' => $id)));
        $this->mydb->execute('DELETE FROM mcw_committee.incomes WHERE i_id=:id', array('id' => $id));
        SetMessage('تم حذف البيانات بنجاح', 'success');
        Redirect('committee/beneficiaries/edit/incomes/' . $item['i_bid']);
    }

    private function editIncomes($id)
    {
        if (isset($_POST['incomes'])) {


            foreach ($_POST['incomes']['i_source'] as $key => $v) {
                $income['i_source'] = $_POST['incomes']['i_source'][$key];
                $income['i_info'] = $_POST['incomes']['i_info'][$key];
                $income['i_count'] = $_POST['incomes']['i_count'][$key];
                $income['i_date'] = $_POST['incomes']['i_date'][$key];
                $income['i_mount'] = $_POST['incomes']['i_mount'][$key];
                $income['i_no'] = $_POST['incomes']['i_no'][$key];
                $income['i_percent'] = $_POST['incomes']['i_percent'][$key];
                $income['i_bid'] = $id;
                $income['i_userid'] = $this->user['user_id'];
                $income['i_time'] = time();
                $sql = $this->mydb->sql_insert('mcw_committee.incomes', $income);
                $this->mydb->execute($sql);
            }
            SetMessage('تمت إضافة البيانات بنجاح', 'success');
        }
        if (isset($_POST['b_installment'])) {
            $_POST['id'] = $id;
            $this->mydb->execute('UPDATE mcw_committee.beneficiaries SET b_installment=:b_installment WHERE b_id=:id',
                $_POST);
            SetMessage('تم حفظ البيانات بنجاح', 'success');
        }
        $q = $this->mydb->execute('SELECT * FROM mcw_committee.incomes WHERE i_bid=:id', array('id' => $id));
        while ($row = $this->mydb->fetch_assoc($q)) {
            $this->vars['incomes'][] = $row;
        }
        $this->vars['bid'] = $id;
        $b = $this->mydb->fetch_assoc($this->mydb->execute('SELECT b_installment FROM mcw_committee.beneficiaries WHERE b_id=:id',
            array('id' => $id)));
        $this->vars['b_installment'] = $b['b_installment'];
        // get families
        $sql = 'SELECT * FROM mcw_committee.residences WHERE r_bid=:id';
        $query = $this->mydb->execute($sql, array('id' => $id));
        while ($row = $this->mydb->fetch_assoc($query)) {
            $this->vars['families'][] = $row;
        }
    }


    private function editPhones($id, $no)
    {
        if (isset($_POST['phones'])) {
            foreach ($_POST['phones']['p_no'] as $key => $v) {
                $phone['p_no'] = $_POST['phones']['p_no'][$key];
                $phone['p_number'] = $_POST['phones']['p_number'][$key];
                $phone['p_name'] = $_POST['phones']['p_name'][$key];
                $phone['p_bid'] = $id;
                $phone['p_userid'] = $this->user['user_id'];
                $phone['p_time'] = time();
                $sql = $this->mydb->sql_insert('mcw_committee.phones', $phone);
                $this->mydb->execute($sql);
            }
            SetMessage('تمت إضافة أرقام الهواتف بنجاح', 'success');
        }
        $q = $this->mydb->execute('SELECT * FROM mcw_committee.phones WHERE p_bid=:id AND p_no=:no',
            array('id' => $id, 'no' => $no));
        while ($row = $this->mydb->fetch_assoc($q)) {
            $this->vars['phones'][] = $row;
        }
        $this->vars['bid'] = $id;
        $this->vars['bno'] = $no;
    }

    private function deletePhone($id, $no)
    {
        $item = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mcw_committee.phones WHERE p_id=:id',
            array('id' => $id)));
        $this->mydb->execute('DELETE FROM mcw_committee.phones WHERE p_id=:id', array('id' => $id));
        SetMessage('تم حذف الرقم بنجاح', 'success');
        Redirect('committee/beneficiaries/edit/phones/' . $item['p_bid'] . '/' . $no);
    }

    private function editFamily($id, $no)
    {
        if (isset($_POST['family'])) {
            $family = $_POST['family'];
            $family['f_bid'] = $id;
            $family['data'] = serialize($family['data']);
            $family['lastchange'] = time();
            $family['userid'] = $this->user['user_id'];
            $sql = $this->mydb->sql_update('mcw_committee.family', $family, array('f_bid' => $id, 'f_no' => $no));
            $this->mydb->execute($sql, $family);
            SetMessage('تم حفظ البيانات بنجاح', 'success');
        }
        $this->vars['bid'] = $id;
        $this->vars['bno'] = $no;
        $this->vars['family'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mcw_committee.family WHERE f_bid=:id AND f_no=:no',
            array('id' => $id, 'no' => $no)));
        $this->vars['family']['data'] = unserialize($this->vars['family']['data']);
    }

    function beneficiaries($act = '', $id = 0, $part = 0, $no = 0)
    {
		if ($act == 'cancel') {
			unset($_SESSION['beneficiary']);
			redirect('committee/beneficiaries');
			exit(0);
		}
        if (!is_numeric($id) and !empty($part)) {
            $x = $part;
            $part = $id;
            $id = $x;
        }
		        if ($act == 'add_plus') {
            if (isset($_POST['residence'])) {
                $this->addBeneficiary(null, $_POST['residence'], $_POST['phones'], $_POST['family']);
            }else{
				$this->vars['bid'] = $id;
				
				
				$info = $this->mydb->fetch_assoc($this->mydb->execute('SELECT count(*) AS count FROM mcw_committee.residences WHERE r_bid=:id', array('id' => $id)));
				
				$this->vars['bno'] = $info['count'] +1;
				
			}
				}
        if ($act == 'add') {
            if (isset($_POST['beneficiary']) || isset($_POST['residence'])) {
                $this->addBeneficiary($_POST['beneficiary'], $_POST['residence'], $_POST['phones'], $_POST['family']);
            }
        } elseif ($id and $act == 'show') {
            $this->show($id, $part);
		}elseif($id && $act == 'delsup' && $part){
			$params = array('id' => $id ,'no' =>$part);
			$this->mydb->execute('DELETE FROM mcw_committee.residences WHERE r_bid=:id AND r_no=:no', $params);
			$this->mydb->execute('DELETE FROM mcw_committee.phones WHERE p_bid=:id AND p_no=:no', $params);
			$this->mydb->execute('DELETE FROM mcw_committee.family WHERE f_bid=:id AND f_no=:no', $params);
			$this->mydb->execute('DELETE FROM mcw_committee.incomes WHERE i_bid=:id AND i_no=:no', $params);
			
			
			
        } elseif ($id && $act == 'delete' && !strcmp($part, 'phones')) {
            $this->deletePhone($id, $no);
        } elseif ($id && $act == 'edit' && !strcmp($part, 'phones')) {
            $this->editPhones($id, $no);
        } elseif ($id && $act == 'edit' && !strcmp($part, 'sicks')) {
            $this->editPatients($id, $no);
        } elseif ($id && $act == 'delete' && !strcmp($part, 'sicks')) {
            $this->deletePatients($id);
        } elseif ($id && $act == 'edit' && !strcmp($part, 'incomes')) {
            $this->editIncomes($id);
        } elseif ($id && $act == 'delete' && !strcmp($part, 'incomes')) {
            $this->deleteIncomes($id);
        } elseif ($id && $act == 'edit' && !strcmp($part, 'family')) {
            $this->editFamily($id, $no);
        } elseif ($id && $act == 'need') {
            if (isset($_POST['class'])) {
                $class = $_POST['class'];
                $class['c_bid'] = $id;
                $class['c_no'] = $part;
                $class['c_userid'] = $this->user['user_id'];
                $class['c_time'] = time();
                $this->mydb->execute('DELETE FROM mcw_committee.class WHERE c_bid=:id AND c_no=:no',
                    array('id' => $id, 'no' => $part));
                $this->mydb->execute($this->mydb->sql_insert('mcw_committee.class', $class), $class);
            }
            $this->vars['bid'] = $id;
            $this->vars['bno'] = $part;
            $this->vars['class'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mcw_committee.class WHERE c_bid=:id AND c_no=:no',
                array('id' => $id, 'no' => $part)));
        } elseif ($id && $act == 'info') {
            if (isset($_POST['info'])) {
                $info['info_bid'] = $id;
                $info['info_text'] = $_POST['info']['info_text'];
                $info['info_userid'] = $this->user['user_id'];
                $info['info_time'] = time();
                $this->mydb->execute($this->mydb->sql_insert('mcw_committee.info', $info));
            }
            $this->vars['bid'] = $id;
            $query = $this->mydb->execute('SELECT * FROM mcw_committee.info WHERE info_bid=:id', array('id' => $id));
            while ($row = $this->mydb->fetch_assoc($query)) {
                $this->vars['info'][] = $row;
            }
        } elseif ($id && $act == 'edit' && !strcmp($part, 'resd')) {
            if (isset($_POST['residence'])) {
                $residence = $_POST['residence'];


                $residence['r_userid'] = $this->user['user_id'];
                $residence['r_lastchange'] = time();
                $sql = $this->mydb->sql_update('mcw_committee.residences', $residence,
                    array('r_bid' => $id, 'r_no' => $no));
                $this->mydb->execute($sql, $residence);
            }
            $this->vars['residence'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mcw_committee.residences WHERE r_bid=:id AND r_no=:no',
                array('id' => $id, 'no' => $no)));
        } elseif ($id and $act == 'edit') {
            if (isset($_POST['beneficiary'])) {
                $beneficiary = $_POST['beneficiary'];
                $beneficiary['b_userid'] = $this->user['user_id'];
                $beneficiary['b_lastchange'] = time();
                $sql = $this->mydb->sql_update('mcw_committee.beneficiaries', $beneficiary, array('b_id' => $id));
                $this->mydb->execute($sql, $beneficiary);
            }
            $this->vars['beneficiary'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mcw_committee.beneficiaries WHERE b_id=:id',
                array('id' => $id)));
        } else {
            if ($_POST['filter']) {
                $_SESSION['filter'] = $_POST['filter'];
            }
            $sql = 'SELECT * FROM mcw_committee.beneficiaries
					INNER JOIN mcw_committee.residences ON r_bid=b_id
					LEFT JOIN mcw_committee.phones ON (p_bid=b_id AND p_no=r_no) ';
            if (!empty($_SESSION['filter']['search'])) {
                $where[] = $_SESSION['filter']['field'] . ' LIKE :search';
            }
            if (!empty($_SESSION['filter']['b_status'])) {
                $where[] = 'b_status=:b_status';
            }
            if (!empty($where)) {
                $sql .= ' WHERE ' . implode(' AND ', $where);
                $filter = array(
                    'search' => '%' . trim($_SESSION['filter']['search']) . '%',
                    'b_status' => $_SESSION['filter']['b_status']
                );
            }
            $sql .= ' GROUP BY b_id';
            $q = $this->mydb->execute($sql, $filter);
			echo mysql_error();
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['beneficiaries'][] = $row;
            }
        }
    }

    public function disbursed($act = '', $id = 0)
    {
        if ($act = 'edit' and $id) {
            if (isset($_POST['dtl_received'])) {
                foreach ($_POST['dtl_received'] as $key => $value) {
                    $dtl['dtl_id'] = $key;
                    $dtl['dtl_received'] = (int)$value;
                    $dtl['dtl_lastchange'] = time();
                    $dtl['dtl_user'] = $this->user['user_id'];
                    $this->mydb->execute($this->mydb->sql_update('mcw_committee.distribute_dtl', $dtl,
                        array('dtl_id' => $key)));
                }
            }
            $sql = 'SELECT * FROM mcw_committee.distribute_dtl INNER JOIN mcw_committee.beneficiaries ON dtl_bid=b_id INNER JOIN mcw_committee.distribute ON dtl_pid=d_id WHERE d_id=:id';
            $query = $this->mydb->execute($sql, array('id' => $id));
            while ($row = $this->mydb->fetch_assoc($query)) {
                $q = $this->mydb->execute('SELECT * FROM mcw_committee.phones WHERE p_bid=:b_id LIMIT 2', $row);
                while ($r = $this->mydb->fetch_assoc($q)) {
                    $row['phones'][] = $r['p_no'];
                }
                $this->vars['items'][] = $row;
            }
            $this->vars['id'] = $id;
        } else {
            $sql = 'SELECT a.*, COUNT(b.dtl_id) AS count FROM mcw_committee.distribute a LEFT JOIN mcw_committee.distribute_dtl b ON dtl_pid=d_id GROUP BY d_id';
            $query = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($query)) {
                $this->vars['items'][] = $row;
            }
        }
    }

    public function distribute($act = '', $id = 0)
    {
        if ($act == 'add') {
            $distribute['d_type'] = $_POST['d_type'];
            $distribute['d_count_no'] = $_POST['d_count_no'];
            $distribute['d_user'] = $this->user['user_id'];
            $distribute['d_date'] = time();
            $this->mydb->execute($this->mydb->sql_insert('mcw_committee.distribute', $distribute));
            $dtl['dtl_pid'] = $this->mydb->insert_id();
            $dtl['dtl_lastchange'] = time();
            $dtl['dtl_user'] = $this->user['user_id'];
            foreach ($_POST['d_bid'] as $key => $value) {
                $dtl['dtl_bid'] = $key;
                $dtl['dtl_count'] = (int)$_POST['d_count'][$key];
                $dtl['dtl_count_no'] = $_POST['d_count_no'][$key];
                $dtl['dtl_received'] = (int)$_POST['d_received'][$key];
                $this->mydb->execute($this->mydb->sql_insert('mcw_committee.distribute_dtl', $dtl));
            }
            SetMessage('تم حفظ البيانات بنجاح', 'success');
        } else {
            if (isset($_POST['filter'])) {
                $date = ArMktime($_POST['filter']['d_date']);
                $sql = 'SELECT * FROM mcw_committee.beneficiaries
							INNER JOIN mcw_committee.residences ON r_bid=b_id WHERE b_id NOT IN (
								SELECT b_id FROM mcw_committee.beneficiaries 
								LEFT JOIN mcw_committee.distribute_dtl ON (dtl_bid=b_id AND dtl_received=1)
								INNER JOIN mcw_committee.distribute ON dtl_pid=d_id 
								WHERE d_date > ' . $date . '
								AND d_type = ' . $_POST['filter']['d_type'] . ')
							LIMIT ' . $_POST['filter']['limit'];
                $query = $this->mydb->execute($sql);
                while ($row = $this->mydb->fetch_assoc($query)) {
                    $this->vars['families'][] = $row;
                }
                $this->vars['type'] = $_POST['filter']['d_type'];
            }
            if (isset($_POST['user'])) {
                foreach ($_POST['user'] as $key => $value) {
                    $beneficiaries[] = $key;
                }
                $beneficiaries = implode(',', $beneficiaries);
                $sql = 'SELECT * FROM mcw_committee.beneficiaries INNER JOIN mcw_committee.residences ON r_bid=b_id WHERE b_id IN (' . $beneficiaries . ')';
                $query = $this->mydb->execute($sql);
                while ($row = $this->mydb->fetch_assoc($query)) {
                    $q = $this->mydb->execute('SELECT * FROM mcw_committee.phones WHERE p_bid=:r_id LIMIT 2', $row);
                    while ($r = $this->mydb->fetch_assoc($q)) {
                        $row['phones'][] = $r['p_number'];
                    }
                    $this->vars['families'][] = $row;
                }
                if (count($this->vars['families'])) {
                    $this->vars['save'] = true;
                    $this->vars['type'] = $_POST['d_type'];
                }
            }
        }
    }

    function reports($act = '', $id = 0)
    {
        if ($act == 'show') {
            $sql = 'SELECT * FROM mcw_committee.beneficiaries A INNER JOIN mcw_committee.residences B ON B.r_bid=A.b_id';
            if ($_POST['limit']) {
                $sql .= ' LIMIT ' . $_POST['limit'];
            }
            $sql . ' GROUP BY A.b_id';
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {


                $row['class'] = 0;

                $sum = getNetIncomes($beneficiary['b_id'],
                        $beneficiary['r_no']) + getFamilyIncomes($beneficiary['b_id'], $beneficiary['r_no']);
                $family = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mcw_committee.family WHERE f_bid=:id AND f_no=:no',
                    array('id' => $id, 'no' => $part)));
                if ($family) {
                    $family['data'] = unserialize($family['data']);
                }
                $total = ($sum * 12) - $beneficiary['r_rent'] - ($beneficiary['b_installment'] * 12);
                $ind = round(($total / $class) / 12, 2);
                $row['class'] = beneficiaryClass($ind);


                $this->vars['users'][] = $row;
            }
        }

    }

}


// helper functions

function getMainIncomes($bid)
{
    $db = $GLOBALS['my_db'];
    $sum = 0;
    $sql = 'SELECT * FROM mcw_committee.incomes WHERE i_bid = :bid AND i_no = 0';
    $query = $db->execute($sql, array('bid' => $bid));
    while ($row = $db->fetch_assoc($query)) {
        $sum += (int)$row['i_mount'];
    }
    return $sum;
}

function getNetIncomes($bid, $rno)
{
    $db = $GLOBALS['my_db'];
    $incomes = getMainIncomes($bid);
    $count = $uncount = 0;

    $sql = 'SELECT * FROM mcw_committee.family WHERE f_bid = :bid';
    $query = $db->execute($sql, array('bid' => $bid));
    while ($row = $db->fetch_assoc($query)) {
        if ($row['f_no'] == $rno) {
            $count = $row['unemployed'];
        } else {
            $uncount += $row['unemployed'];
        }
    }
    $incomes = $incomes / ($count + $uncount);
    return $incomes * $count;
}

function getNetnumber($bid, $rno) {
		$db = $GLOBALS['my_db'];
		$m=0;

		
		$sql = 'SELECT * FROM mcw_committee.family WHERE f_bid = :bid';
		$query = $db->execute($sql, array('bid' => $bid));
		while ($row = $db->fetch_assoc($query)) {
		$m += $row['employed'] + $row['unemployed']+1 ;

		
		
		}
		
		return $m ;
		
	}
	function cancel()
	{
	unset($_SESSION['beneficiary']);
	
		
	}

function getFamilyIncomes($bid, $rno)
{
    $db = $GLOBALS['my_db'];
    $sum = 0;
    $sql = 'SELECT * FROM mcw_committee.incomes WHERE i_bid = :bid AND i_no = :rno';
    $query = $db->execute($sql, array('bid' => $bid, 'rno' => $rno));
    while ($row = $db->fetch_assoc($query)) {
        $percent = ($row['i_percent'] < 100) ? $row['i_percent'] / 100 : 1;
        $sum += $row['i_mount'] * $percent;
    }
    return $sum;
}

function beneficiaryClass($num)
{
    if ($num < 100) {
        return 1;
    } elseif ($num < 200) {
        return 2;
    } elseif ($num < 300) {
        return 3;
    } elseif ($num < 400) {
        return 4;
    } elseif ($num < 500) {
        return 5;
    } elseif ($num < 600) {
        return 6;
    } elseif ($num < 700) {
        return 7;
    } elseif ($num < 800) {
        return 8;
    }
    return 'x';
}

function numberfamily($numm)
{
    if ($numm < 5) {
        return 400;
    } elseif ($numm < 8) {
        return 700;
    } elseif ($numm < 13) {
        return 1000;
    } elseif ($numm < 30) {
        return 1200;
    }
    return 'x';
}

?>