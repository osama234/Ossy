<br />
<form action="<?=base_url()?>committee/beneficiaries" method="post" role="form" class="form-horizontal">
	<div class="form-group">
		<label for="b_name" class="control-label col-sm-1">بحث</label>
		<div class="col-sm-3">
			<input type="text" name="filter[search]" id="search" value="<?=$_SESSION['filter']['search']?>" placeholder="رقم الملف/اسم المستفيد/اسم الزوجة/رقم الهوية/رقم الجوال " class="form-control" />
		</div>
		<div class="col-sm-2">
			<select name="filter[field]" id="field" class="form-control">
				<option value="b_name">اسم المستفيد</option>
				<option value="r_wife_name">اسم الزوجة</option>
				<option value="p_number">رقم الجوال</option>
				<option value="b_idno">رقم هوية المستفيد</option>
				<option value="r_idno">رقم هوية الزوجة</option>
				<option value="b_id">رقم الملف</option>
			</select>
		</div>
		<label for="b_status" class="control-label col-sm-2">حالة الأسرة</label>
		<div class="col-sm-2">
			<select name="filter[b_status]" id="b_status" class="form-control">
				<option></option>
				<?=GetOptions('user_status', $_SESSION['filter']['b_status'])?>
			</select>
		</div>
		<input type="submit" class="btn btn-primary" value="عرض النتائج" />
	</div>
</form>
<div class="panel panel-primary">
	<div class="panel-heading">المستفيدين</div>
	<table class="table">
		<tr>
            <th>رقم الملف</th>
            <th>اسم المستفيد</th>
            <th>الحي</th>
            <th>حالة الأسرة</th>
			<th>حالة الملف</th>
            <th></th>
        </tr>
        <?php if (isset($beneficiaries) and count($beneficiaries)){ ?>
        <?php foreach ($beneficiaries as $row){ ?>
        <tr>
            <td><?=$row['b_id']?></td>
            <td><?=$row['b_name']?></td>
            <td><?=$row['r_dist']?></td>
            <td><?=GetOptionsLabel('user_status', $row['b_status'])?></td>
            <td><span><?=GetOptionsLabel('file_status', $row['b_file']) ?></td>
			<td><a href="<?=base_url()?>committee/beneficiaries/show/<?=$row['b_id']?>" class="btn btn-primary pull-right">عرض</a></td>
        </tr>
        <?php } ?>
        <?php } else { ?>
        <tr><td colspan="4">لا توجد بيانات حالياً</td></tr>
        <?php } ?>
    </table>
</div>
<a href="<?=base_url()?>committee/beneficiaries/add" class="btn btn-success">إضافة مستفيد جديد</a>
<a href="#" class="btn btn-warning print_btn">طباعة</a>
<br /><?=$paging?>