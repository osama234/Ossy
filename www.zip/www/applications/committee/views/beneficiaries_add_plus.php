<h2 align="center">نظام اللجنة الاجتماعية</h2>
<?php if (empty($wives)) {?>
<form action="<?= base_url() ?>committee/beneficiaries/add_plus" method="post" role="form" data-toggle="novalidator" class="form-horizontal">
    <input type="hidden" name="wives" value="<?= $wives ?>" />
    <input type="hidden" name="residence[r_bid]" value="<?= $bid ?>" />
    <input type="hidden" name="residence[r_no]" value="<?= $bno ?>" />
    <div class="panel panel-primary">
        <div class="panel-heading">سكن المستفيد</div>
        <div class="panel-body">
            <div class="form-group">
                <label for="b_wife_name" class="control-label col-sm-2">اسم الزوجة التي تسكن في هذا المنزل</label>
                <div class="col-sm-4">
                    <input type="text" name="residence[r_wife_name]" id="r_wife_name" class="form-control"/>
                </div>

				<div class="input-group">
                    <input type="checkbox" name="residence[r_dead]" value="1" />		
                    <label for="text" class="control">متوفيه</label>
					</div>
                <label for="r_dist" class="control-label col-sm-2">الحي</label>
                <div class="col-sm-4">
                    <select name="residence[r_dist]" id="r_dist" class="form-control" required>
                        <option></option>
                        <?= GetOptions('street') ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="r_sponsor" class="control-label col-sm-2">كفالة المستفيد</label>
                <div class="col-sm-4">
                    <input type="radio" name="residence[r_spons]" id="r_spons1" value="0"> <label
                        for="r_spons1">مكفول</label>
                    <input type="radio" name="residence[r_spons]" id="r_spons2" value="1"> <label for="r_spons2">غير
                        مكفول</label>
                </div>
                <div class="kafeel">
                    <label for="r_name" class="control-label col-sm-2" id="r_name_label">اسم الكافل</label>
                    <div class="col-sm-4">
                        <input type="text" name="residence[r_sponsor]" id="r_sponsor"
                               value="<?= $residence['r_sponsor'] ?>" class="form-control"/>
                    </div>
                </div>

            </div>
            <div class="form-group kafeel">
                <label for="r_sponsor" class="control-label col-sm-2">تاريخ بداية الكفالة</label>
                <div class="col-sm-4">
                    <input type="date" name="residence[r_date]" id="r_date" value="<?= $residence['r_date'] ?>"
                           class="form-control datepicker"/>
                </div>
                <label for="r_sponsor" class="control-label col-sm-2">تاريخ انتهاء الكفالة</label>
                <div class="col-sm-4">
                    <input type="date" name="residence[r_date_end]" id="r_date" value="<?= $residence['r_date_end'] ?>"
                           class="form-control datepicker"/>
                </div>
            </div>
            <div class="form-group">
                <label for="r_idno" class="control-label col-sm-2">رقم الهوية</label>
                <div class="col-sm-4">
                    <input type="text" name="residence[r_idno]" id="r_idno" class="form-control" maxlength="10"
                           required/>
                </div>
            </div>
            <div class="form-group">
                <label for="r_street" class="control-label col-sm-2">اسم الشارع</label>
                <div class="col-sm-4">
                    <input type="text" name="residence[r_street]" id="r_street" class="form-control" required/>
                </div>
                <label for="r_number" class="control-label col-sm-2">رقم المنزل</label>
                <div class="col-sm-4">
                    <input type="text" name="residence[r_number]" id="r_number" class="form-control" required/>
                </div>
            </div>

            <div class="form-group">
                <label for="r_type" class="control-label col-sm-2">نوع السكن</label>
                <div class="col-sm-2">
                    <select name="residence[r_type]" id="r_type" class="form-control" required="true">
                        <option></option>
                        <?= GetOptions('residence_type') ?>
                    </select>
                </div>
                <div class="col-sm-2">
                    <input type="radio" name="residence[r_owned]" id="r_owned1" value="1"/> <label
                        for="r_owned1">ملك</label>
                    <input type="radio" name="residence[r_owned]" id="r_owned2" value="0"/> <label
                        for="r_owned2">مستأجر</label>
                </div>
                <label for="r_rent" class="control-label col-sm-2" id="r_rent_label">الإيجار السنوي</label>
                <div class="col-sm-4">
                    <input type="text" name="residence[r_rent]" id="r_rent" value="<?= $residence['r_rent'] ?>"
                           class="form-control"/>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-2">احداثيات المنزل</label>
                <div class="col-sm-9">
                    <label for="r_lat" class="control-label col-sm-1">E</label>
                    <div class="col-sm-5">
                        <input type="text" name="residence[r_lat]" id="r_lat" class="form-control"/>
                    </div>
                    <label for="r_long" class="control-label col-sm-1">N</label>
                    <div class="col-sm-5">
                        <input type="text" name="residence[r_long]" id="r_long" class="form-control"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br/>
    <div class="panel panel-primary">
        <div class="panel-heading">هواتف المستفيد</div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-9">
                <table id="rows">
                    <tr>
                        <th>رقم الهاتف</th>
                        <th>صاحب الرقم</th>
                    </tr>
                    <tr>
                        <td><input type="text" required="true" class="form-control" maxlength="10"
                                   name="phones[p_number][]"></td>
                        <td><input type="text" required="true" class="form-control" name="phones[p_name][]"></td>
                    </tr>
                </table>
                <button class="btn btn-success" type="button" id="add_row">إضافة</button>
            </div>
        </div>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">
            <span>أفراد الأسرة الذين يسكنون في المنزل</span>
        </div>
        <br/>
        <table class="table">
            <caption>أولاد المستفيد</caption>
            <tr>
                <th>المرحلة الدراسية</th>
                <th>عدد الأبناء</th>
                <th>عدد البنات</th>
            </tr>
            <tr>
                <td>صغار لم يدرسوا</td>
                <td><input type="tel" value="<?= (int)$family['data'][0]['m'] ?>" name="family[data][0][m]" id="f0m"
                           class="family"/></td>
                <td><input type="tel" value="<?= (int)$family['data'][0]['f'] ?>" name="family[data][0][f]" id="f0f"
                           class="family"/></td>
            </tr>
            <tr>
                <td>الابتدائي</td>
                <td><input type="tel" value="<?= (int)$family['data'][1]['m'] ?>" name="family[data][1][m]" id="f1m"
                           class="family"/></td>
                <td><input type="tel" value="<?= (int)$family['data'][1]['f'] ?>" name="family[data][1][f]" id="f1f"
                           class="family"/></td>
            </tr>
            <tr>
                <td>المتوسط</td>
                <td><input type="tel" value="<?= (int)$family['data'][2]['m'] ?>" name="family[data][2][m]" id="f2m"
                           class="family"/></td>
                <td><input type="tel" value="<?= (int)$family['data'][2]['f'] ?>" name="family[data][2][f]" id="f2f"
                           class="family"/></td>
            </tr>
            <tr>
                <td>لثانوي</td>
                <td><input type="tel" value="<?= (int)$family['data'][3]['m'] ?>" name="family[data][3][m]" id="f3m"
                           class="family"/></td>
                <td><input type="tel" value="<?= (int)$family['data'][3]['f'] ?>" name="family[data][3][f]" id="f3f"
                           class="family"/></td>
            </tr>
            <tr>
                <td>الجامعي</td>
                <td><input type="tel" value="<?= (int)$family['data'][4]['m'] ?>" name="family[data][4][m]" id="f4m"
                           class="family"/></td>
                <td><input type="tel" value="<?= (int)$family['data'][4]['f'] ?>" name="family[data][4][f]" id="f4f"
                           class="family"/></td>
            </tr>
            <tr>
                <td>عاطل</td>
                <td><input type="tel" value="<?= (int)$family['data'][5]['m'] ?>" name="family[data][5][m]" id="f5m"
                           class="family"/></td>
                <td><input type="tel" value="<?= (int)$family['data'][5]['f'] ?>" name="family[data][5][f]" id="f5f"
                           class="family"/></td>
            </tr>
            <tr>
                <td>موظف</td>
                <td><input type="tel" value="<?= (int)$family['data'][6]['m'] ?>" name="family[data][6][m]" id="f6m"
                           class="family"/></td>
                <td><input type="tel" value="<?= (int)$family['data'][6]['f'] ?>" name="family[data][6][f]" id="f6f"
                           class="family"/></td>
            </tr>
            <tr>
                <td>المجموع</td>
                <td><input type="tel" id="sumfm" disabled="true"/></td>
                <td><input type="tel" id="sumff" disabled="true"/></td>
            </tr>
        </table>
        <br/>
        <table class="table">
            <caption>أقارب المستفيد</caption>
            <tr>
                <th>المرحلة الدراسية</th>
                <th>اسم القريب</th>
                <th>نوع القرابة</th>
                <th>العدد</th>
                <th>ملاحظة</th>
            </tr>
            <tr>
                <td>صغار لم يدرسوا</td>
                <td><input type="text" name="family[data][0][name]" value="<?= $family['data'][0]['name'] ?>"/></td>
                <td><input type="text" name="family[data][0][type]" value="<?= $family['data'][0]['type'] ?>"/></td>
                <td><input type="tel" name="family[data][0][count]" value="<?= (int)$family['data'][0]['count'] ?>"
                           id="r0" class="family"/></td>
                <td><input type="text" name="family[data][0][note]" value="<?= $family['data'][0]['note'] ?>"/></td>
            </tr>
            <tr>
                <td>الابتدائي</td>
                <td><input type="text" name="family[data][1][name]" value="<?= $family['data'][1]['name'] ?>"/></td>
                <td><input type="text" name="family[data][1][type]" value="<?= $family['data'][1]['type'] ?>"/></td>
                <td><input type="tel" name="family[data][1][count]" value="<?= (int)$family['data'][1]['count'] ?>"
                           name="" id="r1" class="family"/></td>
                <td><input type="text" name="family[data][1][note]" value="<?= $family['data'][1]['note'] ?>"/></td>
            </tr>
            <tr>
                <td>المتوسط</td>
                <td><input type="text" name="family[data][2][name]" value="<?= $family['data'][2]['name'] ?>"/></td>
                <td><input type="text" name="family[data][2][type]" value="<?= $family['data'][2]['type'] ?>"/></td>
                <td><input type="tel" name="family[data][2][count]" value="<?= (int)$family['data'][2]['count'] ?>"
                           name="" id="r2" class="family"/></td>
                <td><input type="text" name="family[data][2][note]" value="<?= $family['data'][2]['note'] ?>"/></td>
            </tr>
            <tr>
                <td>لثانوي</td>
                <td><input type="text" name="family[data][3][name]" value="<?= $family['data'][3]['name'] ?>"/></td>
                <td><input type="text" name="family[data][3][type]" value="<?= $family['data'][3]['type'] ?>"/></td>
                <td><input type="tel" name="family[data][3][count]" value="<?= (int)$family['data'][3]['count'] ?>"
                           name="" id="r3" class="family"/></td>
                <td><input type="text" name="family[data][3][note]" value="<?= $family['data'][3]['note'] ?>"/></td>
            </tr>
            <tr>
                <td>الجامعي</td>
                <td><input type="text" name="family[data][4][name]" value="<?= $family['data'][4]['name'] ?>"/></td>
                <td><input type="text" name="family[data][4][type]" value="<?= $family['data'][4]['type'] ?>"/></td>
                <td><input type="tel" name="family[data][4][count]" value="<?= (int)$family['data'][4]['count'] ?>"
                           name="" id="r4" class="family"/></td>
                <td><input type="text" name="family[data][4][note]" value="<?= $family['data'][4]['note'] ?>"/></td>
            </tr>
            <tr>
                <td>عاطل</td>
                <td><input type="text" name="family[data][5][name]" value="<?= $family['data'][5]['name'] ?>"/></td>
                <td><input type="text" name="family[data][5][type]" value="<?= $family['data'][5]['type'] ?>"/></td>
                <td><input type="tel" name="family[data][5][count]" value="<?= (int)$family['data'][5]['count'] ?>"
                           name="" id="r5" class="family"/></td>
                <td><input type="text" name="family[data][5][note]" value="<?= $family['data'][5]['note'] ?>"/></td>
            </tr>
            <tr>
                <td>موظف</td>
                <td><input type="text" name="family[data][6][name]" value="<?= $family['data'][6]['name'] ?>"/></td>
                <td><input type="text" name="family[data][6][type]" value="<?= $family['data'][6]['type'] ?>"/></td>
                <td><input type="tel" name="family[data][6][count]" value="<?= (int)$family['data'][6]['count'] ?>"
                           name="" id="r6" class="family"/></td>
                <td><input type="text" name="family[data][6][note]" value="<?= $family['data'][6]['note'] ?>"/></td>
            </tr>
            <tr>
                <td>المجموع</td>
                <td></td>
                <td></td>
                <td><input type="tel" id="sumr"/></td>
                <td></td>
            </tr>
        </table>
        <br/>
        <div class="form-group">
            <label for="b_name" class="control-label col-sm-3">إجمالي عدد أفراد الأسرة من غير الموظفين</label>
            <div class="col-sm-4">
                <input type="text" name="family[unemployed]" id="sumue" class="form-control"/>
            </div>
        </div>
        <div class="form-group">
            <label for="b_name" class="control-label col-sm-3">الموظفين</label>
            <div class="col-sm-4">
                <input type="text" name="family[employed]" id="sume" class="form-control"/>
            </div>
        </div>
        <div class="form-group">
            <label for="b_name" class="control-label col-sm-3">المجموع</label>
            <div class="col-sm-4">
                <input type="text" name="" id="sum" class="form-control"/>
            </div>
        </div>
    </div>
    <input type="submit" class="btn btn-primary btn-md" value="التالي"/>
	<?php if(isset($_SESSION['beneficiary']))  {?>

	 <a href="<?= base_url('committee/beneficiaries/cancel') ?>" class="btn btn-danger">الغاء</a>

<?php }?>	
</form>
<?php } ?>
<script type="text/javascript">
    function resdType() {
        if ($("input[name='residence[r_spons]']:checked").val() == 1) {
            $('.kafeel').hide();
        } else {
            $('.kafeel').show();
        }
        if ($("input[name='residence[r_owned]']:checked").val() == 1) {
            $('#r_rent_label').hide();
            $('#r_rent').hide();
        } else {
            $('#r_rent_label').show();
            $('#r_rent').show();
        }
    }
    resdType();
    $('input[type=radio]').click(function () {
        resdType()
    });
    $('#add_row').click(function () {
        $('#rows tbody').append('<tr><td><input type="text" name="phones[p_number][]" class="form-control" required="true" /></td>' +
            '<td><input type="text" name="phones[p_name][]" class="form-control" /></td><td><a herf="#" class="btn btn-danger delete">X</a></td><td></td></tr>');
        $('.delete').off('click');
        $('.delete').click(function () {
            if (confirm('هل انت متأكد؟')) {
                $(this).parent().parent().remove();
            }
        });
    });
    function doCalculations() {
        $('#sumfm').val(parseInt($('#f0m').val()) + parseInt($('#f1m').val()) + parseInt($('#f2m').val()) + parseInt($('#f3m').val()) + parseInt($('#f4m').val()) + parseInt($('#f5m').val()) + parseInt($('#f6m').val()));
        $('#sumff').val(parseInt($('#f0f').val()) + parseInt($('#f1f').val()) + parseInt($('#f2f').val()) + parseInt($('#f3f').val()) + parseInt($('#f4f').val()) + parseInt($('#f5f').val()) + parseInt($('#f6f').val()));
        $('#sumr').val(parseInt($('#r0').val()) + parseInt($('#r1').val()) + parseInt($('#r2').val()) + parseInt($('#r3').val()) + parseInt($('#r4').val()) + parseInt($('#r5').val()) + parseInt($('#r6').val()));

        $('#sume').val(parseInt($('#f6m').val()) + parseInt($('#f6f').val()) + parseInt($('#r6').val()));
        $('#sum').val(parseInt($('#sumfm').val()) + parseInt($('#sumff').val()) + parseInt($('#sumr').val()));
        $('#sumue').val(parseInt($('#sum').val()) - parseInt($('#sume').val()));

    }
    $('.family').change(function () {
        doCalculations();
    });
    doCalculations();
</script>
