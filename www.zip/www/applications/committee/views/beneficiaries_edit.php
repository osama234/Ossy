<h2 align="center">نظام اللجنة الاجتماعية</h2>
<form action="<?=base_url()?>committee/beneficiaries/edit/<?=$beneficiary['b_id']?>" method="post" role="form" data-toggle="novalidator" class="form-horizontal">
	<div class="panel panel-primary">
		<div class="panel-heading">البيانات الأساسية</div>
		<br />
		<div class="form-group">
			<label for="b_name" class="control-label col-sm-2">اسم المستفيد رباعياً</label>
			<div class="col-sm-4">
				<input type="text" name="beneficiary[b_name]" id="b_name" value="<?=$beneficiary['b_name']?>" class="form-control" />
			</div>
		<div class="input-group">
                    <input type="checkbox" name="beneficiary[b_dead]" value="1" />		
                    <label for="text" class="control">متوفي</label>
					</div>
						<label for="b_idno" class="control-label col-sm-2">رقم الهوية</label>
			<div class="col-sm-3">
				<input type="text" name="beneficiary[b_idno]" id="b_idno" value="<?=$beneficiary['b_idno']?>" class="form-control" />
			</div>
</div>
				
		<div class="form-group">
			<label for="b_natid" class="control-label col-sm-2">الجنسية</label>
			<div class="col-sm-4">
				<select name="beneficiary[b_natid]" id="b_natid" class="form-control" required="true">
					<option></option>
					<?=GetOptions('nationality', $beneficiary['b_natid'])?>
				</select>
			</div>
			<label for="b_file" class="control-label col-sm-2">حالة الملف</label>
			<div class="col-sm-3">
				<select name="beneficiary[b_file]" id="b_file" class="form-control" >
					<option></option>
					<?=GetOptions('file_status', $beneficiary['b_file'])?>
				</select>
			</div>
		</div>		
		<div class="form-group">
			<label for="b_status" class="control-label col-sm-2">حالة الأسرة</label>
			<div class="col-sm-4">
				<select name="beneficiary[b_status]" id="b_status" class="form-control" required="true">
					<option></option>
					<?=GetOptions('user_status', $beneficiary['b_status'])?>
				</select>
			</div>
			<label for="b_wives" class="control-label col-sm-2">عدد الزوجات</label>
			<div class="col-sm-3">
				<input type="text" name="beneficiary[b_wives]" id="b_wives" value="<?=$beneficiary['b_wives']?>" class="form-control" />
			</div>
		</div>
		
		<div class="form-group">
		<label for="b_bank_name" class="control-label col-sm-2">اسم البنك</label>
			<div class="col-sm-4">
				<select name="beneficiary[b_bank_name]" id="b_bank_name" class="form-control" required="true">
					<option></option>
					<?=GetOptions('bank_name', $beneficiary['b_bank_name'])?>
				</select>
			</div>
			<label for="b_account_no" style="text-align: left;" class="control-label col-sm-2">رقم حساب المستفيد</label>
			<div class="col-sm-3">
				<input type="text" name="beneficiary[b_account_no]" id="b_account_no" value="<?=$beneficiary['b_account_no']?>" class="form-control" maxlength="22" required/>
				<div class="input-group-addon">SA</div>
			</div>
		</div>
				
	</div>
	<input type="submit" class="btn btn-primary btn-md" value="حفظ البيانات" />
	<a href="<?=base_url()?>committee/beneficiaries/show/<?=$beneficiary['b_id']?>" class="btn btn-warning">عودة</a>
</form>
