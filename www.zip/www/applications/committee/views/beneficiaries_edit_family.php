<form action="<?=base_url()?>committee/beneficiaries/edit/family/<?=$bid?>/<?=$bno?>" method="post" role="form" data-toggle="validator" class="form-horizontal">
<div class="panel panel-primary">
	<div class="panel-heading">
		<span>أفراد الأسرة الذين يسكنون في المنزل</span>
	</div>
	<br />
	<table class="table">
		<caption>أولاد المستفيد</caption>
		<tr>
			<th>المرحلة الدراسية</th>
			<th>عدد الأبناء</th>
			<th>عدد البنات</th>
		</tr>
		<tr>
			<td>صغار لم يدرسوا</td>
			<td><input type="tel" value="<?=(int) $family['data'][0]['m']?>" name="family[data][0][m]" id="f0m" class="family" /></td>
			<td><input type="tel" value="<?=(int) $family['data'][0]['f']?>" name="family[data][0][f]" id="f0f" class="family" /></td>
		</tr>
		<tr>
			<td>الابتدائي</td>
			<td><input type="tel" value="<?=(int) $family['data'][1]['m']?>" name="family[data][1][m]" id="f1m" class="family" /></td>
			<td><input type="tel" value="<?=(int) $family['data'][1]['f']?>" name="family[data][1][f]" id="f1f" class="family" /></td>
		</tr>
		<tr>
			<td>المتوسط</td>
			<td><input type="tel" value="<?=(int) $family['data'][2]['m']?>" name="family[data][2][m]" id="f2m" class="family" /></td>
			<td><input type="tel" value="<?=(int) $family['data'][2]['f']?>" name="family[data][2][f]" id="f2f" class="family" /></td>
		</tr>
		<tr>
			<td>لثانوي</td>
			<td><input type="tel" value="<?=(int) $family['data'][3]['m']?>" name="family[data][3][m]" id="f3m" class="family" /></td>
			<td><input type="tel" value="<?=(int) $family['data'][3]['f']?>" name="family[data][3][f]" id="f3f" class="family" /></td>
		</tr>
		<tr>
			<td>الجامعي</td>
			<td><input type="tel" value="<?=(int) $family['data'][4]['m']?>" name="family[data][4][m]" id="f4m" class="family" /></td>
			<td><input type="tel" value="<?=(int) $family['data'][4]['f']?>" name="family[data][4][f]" id="f4f" class="family" /></td>
		</tr>
		<tr>
			<td>عاطل</td>
			<td><input type="tel" value="<?=(int) $family['data'][5]['m']?>" name="family[data][5][m]" id="f5m" class="family" /></td>
			<td><input type="tel" value="<?=(int) $family['data'][5]['f']?>" name="family[data][5][f]" id="f5f" class="family" /></td>
		</tr>
		<tr>
			<td>موظف</td>
			<td><input type="tel" value="<?=(int) $family['data'][6]['m']?>" name="family[data][6][m]" id="f6m" class="family" /></td>
			<td><input type="tel" value="<?=(int) $family['data'][6]['f']?>" name="family[data][6][f]" id="f6f" class="family" /></td>
		</tr>
		<tr>
			<td>المجموع</td>
			<td><input type="tel" id="sumfm" disabled="true" /></td>
			<td><input type="tel" id="sumff" disabled="true" /></td>
		</tr>
	</table>
	<br />
	<table class="table">
		<caption>أقارب المستفيد</caption>
		<tr>
			<th>المرحلة الدراسية</th>
			<th>اسم القريب</th>
			<th>نوع القرابة</th>
			<th>العدد</th>
			<th>ملاحظة</th>
		</tr>
		<tr>
			<td>صغار لم يدرسوا</td>
			<td><input type="text" name="family[data][0][name]" value="<?=$family['data'][0]['name']?>" /></td>
			<td><input type="text" name="family[data][0][type]" value="<?=$family['data'][0]['type']?>" /></td>
			<td><input type="tel" name="family[data][0][count]" value="<?=(int) $family['data'][0]['count']?>" name="family['data'][1]['count']" id="r0" class="family" /></td>
			<td><input type="text" name="family[data][0][note]" value="<?=$family['data'][0]['note']?>" /></td>
		</tr>
		<tr>
			<td>الابتدائي</td>
			<td><input type="text" name="family[data][1][name]" value="<?=$family['data'][1]['name']?>" /></td>
			<td><input type="text" name="family[data][1][type]" value="<?=$family['data'][1]['type']?>" /></td>
			<td><input type="tel" name="family[data][1][count]" value="<?=(int) $family['data'][1]['count']?>" name="family['data'][1]['count']" id="r1" class="family" /></td>
			<td><input type="text" name="family[data][1][note]" value="<?=$family['data'][1]['note']?>" /></td>
		</tr>
		<tr>
			<td>المتوسط</td>
			<td><input type="text" name="family[data][2][name]" value="<?=$family['data'][2]['name']?>" /></td>
			<td><input type="text" name="family[data][2][type]" value="<?=$family['data'][2]['type']?>" /></td>
			<td><input type="tel" name="family[data][2][count]" value="<?=(int) $family['data'][2]['count']?>" name="family['data'][2]['count']" id="r2" class="family" /></td>
			<td><input type="text" name="family[data][2][note]" value="<?=$family['data'][2]['note']?>" /></td>
		</tr>
		<tr>
			<td>لثانوي</td>
			<td><input type="text" name="family[data][3][name]" value="<?=$family['data'][3]['name']?>" /></td>
			<td><input type="text" name="family[data][3][type]" value="<?=$family['data'][3]['type']?>" /></td>
			<td><input type="tel" name="family[data][3][count]" value="<?=(int) $family['data'][3]['count']?>" name="family['data'][3]['count']" id="r3" class="family" /></td>
			<td><input type="text" name="family[data][3][note]" value="<?=$family['data'][3]['note']?>" /></td>
		</tr>
		<tr>
			<td>الجامعي</td>
			<td><input type="text" name="family[data][4][name]" value="<?=$family['data'][4]['name']?>" /></td>
			<td><input type="text" name="family[data][4][type]" value="<?=$family['data'][4]['type']?>" /></td>
			<td><input type="tel" name="family[data][4][count]" value="<?=(int) $family['data'][4]['count']?>" name="family['data'][4]['count']" id="r4" class="family" /></td>
			<td><input type="text" name="family[data][4][note]" value="<?=$family['data'][4]['note']?>" /></td>
		</tr>
		<tr>
			<td>عاطل</td>
			<td><input type="text" name="family[data][5][name]" value="<?=$family['data'][5]['name']?>" /></td>
			<td><input type="text" name="family[data][5][type]" value="<?=$family['data'][5]['type']?>" /></td>
			<td><input type="tel" name="family[data][5][count]" value="<?=(int) $family['data'][5]['count']?>" name="family['data'][5]['count']" id="r5" class="family" /></td>
			<td><input type="text" name="family[data][5][note]" value="<?=$family['data'][5]['note']?>" /></td>
		</tr>
		<tr>
			<td>موظف</td>
			<td><input type="text" name="family[data][6][name]" value="<?=$family['data'][6]['name']?>" /></td>
			<td><input type="text" name="family[data][6][type]" value="<?=$family['data'][6]['type']?>" /></td>
			<td><input type="tel"  name="family[data][6][count]" value="<?=(int) $family['data'][6]['count']?>" name="family['data'][6]['count']" id="r6" class="family" /></td>
			<td><input type="text" name="family[data][6][note]" value="<?=$family['data'][6]['note']?>" /></td>
		</tr>
		<tr>
			<td>المجموع</td>
			<td></td>
			<td></td>
			<td><input type="tel" id="sumr" /></td>
			<td></td>
		</tr>
	</table>
	<br />
	<div class="form-group">
		<label for="b_name" class="control-label col-sm-3">إجمالي عدد أفراد الأسرة من غير الموظفين</label>
		<div class="col-sm-4">
			<input type="text" name="family[unemployed]" id="sumue" class="form-control" />
		</div>
	</div>
	<div class="form-group">
		<label for="b_name" class="control-label col-sm-3">الموظفين</label>
		<div class="col-sm-4">
			<input type="text" name="family[employed]" id="sume" class="form-control" />
		</div>
	</div>
	<div class="form-group">
		<label for="b_name" class="control-label col-sm-3">المجموع</label>
		<div class="col-sm-4">
			<input type="text" name="" id="sum" class="form-control" />
		</div>
	</div>
</div>

	
<input type="submit" class="btn btn-success" value="حفظ البيانات" />
<a href="<?=base_url()?>committee/beneficiaries/show/<?=$bid?>/<?=$bno?>" class="btn btn-warning">عودة</a>
<a href="#" class="btn btn-primary print_btn">طباعة</a>
</form>

<script type="text/javascript">
	
	function doCalculations() {
		$('#sumfm').val(parseInt($('#f0m').val()) + parseInt($('#f1m').val()) + parseInt($('#f2m').val()) + parseInt($('#f3m').val()) + parseInt($('#f4m').val()) + parseInt($('#f5m').val()) + parseInt($('#f6m').val()));
		$('#sumff').val(parseInt($('#f0f').val()) + parseInt($('#f1f').val()) + parseInt($('#f2f').val()) + parseInt($('#f3f').val()) + parseInt($('#f4f').val()) + parseInt($('#f5f').val()) + parseInt($('#f6f').val()));
		$('#sumr').val(parseInt($('#r0').val()) + parseInt($('#r1').val()) + parseInt($('#r2').val()) + parseInt($('#r3').val()) + parseInt($('#r4').val()) + parseInt($('#r5').val()) + parseInt($('#r6').val()));
		
		$('#sume').val(parseInt($('#f6m').val()) + parseInt($('#f6f').val()) + parseInt($('#r6').val()));
		$('#sum').val(parseInt($('#sumfm').val()) + parseInt($('#sumff').val()) + parseInt($('#sumr').val()));
		$('#sumue').val(parseInt($('#sum').val()) - parseInt($('#sume').val()));
		
	}
	
	$('.family').change(function(){
		doCalculations();
	});
	
	doCalculations();
</script>