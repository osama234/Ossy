<form action="<?= base_url() ?>committee/beneficiaries/edit/incomes/<?= $bid ?>/<?=$bno?>" method="post" role="form" data-toggle="novalidator" class="form-horizontal">
    <div class="panel panel-primary">
        <div class="panel-heading">دخل المستفيد</div>
        <div class="panel-body">
            <strong>دخل رب الأسرة</strong>
            <table class="table" id="table-0">
                <tr>
                    <th>جهة الدخل</th>
                    <th>مصدر المعلومة</th>
                    <th></th>
                    <th>مقدار الدخل الشهري</th>
                </tr>
                <?php foreach ($incomes as $row) { ?>
                <?php if ($row['i_no'] == 0) { ?>
                    <tr>
                        <td><?= GetOptionsLabel('income_source', $row['i_source']) ?> <?= $row['i_count'] ? $row['i_count'] . ' رأس' : '' ?></td>
                        <td><?= GetOptionsLabel('income_info', $row['i_info']) ?></td>
                        <td><?= $row['s_type'] ?></td>
                        <td><?= getMount($row); $sum+=getMount($row) ?></td>
                        <td><?= $row['s_report'] ?></td>
                        <td><?= ArDate('Y/m/d', $row['s_time']) ?></td>
                        <td><a href="<?= base_url() ?>committee/beneficiaries/delete/incomes/<?= $row['i_id'] ?>" class="btn btn-danger">حذف</a></td>
                    </tr>
				<?php } ?>
				<?php } ?>
                <th colspan="3">المجموع</th>
                <th><?= $sum ?></th>
                <th colspan="4"></th>
            </table>
            <button class="btn btn-success add_row" type="button" id="add_row-0">إضافة</button>
	        <div class="form-group">
	            <label for="" class="control-label col-sm-2">أقساط شهرية</label>
	            <div class="col-sm-9">
	                <input type="tel" name="b_installment" id="b_installment" value="<?= $b_installment ?>" class="form-control" />
	            </div>
	        </div>
	        
	        <?php foreach ($families as $row){ ?>
	        <hr />
	        <strong>دخل أسرة <?=$row['r_wife_name']?></strong>
            <table class="table" id="table-<?=$row['r_no']?>">
                <tr>
                    <th>جهة الدخل</th>
                    <th>مصدر المعلومة</th>
                    <th></th>
                    <th>مقدار الدخل الشهري</th>
                    <th>النسبة المحتسبة%</th>
                </tr>
                <?php $sum = 0; foreach ($incomes as $r) { ?>
                <?php if ($r['i_no'] == $row['r_no']) { ?>
                    <tr>
                        <td><?= GetOptionsLabel('income_source', $r['i_source']) ?> <?= $r['i_count'] ? $r['i_count'] . ' رأس' : '' ?></td>
                        <td><?= GetOptionsLabel('income_info', $r['i_info']) ?></td>
                        <td><?= $r['s_type'] ?></td>
                        <td><?= getMount($r); ?></td>
                        <td>(<?= $r['i_percent'] ?>%) <?=getMount($r)*$r['i_percent']/20; $sum+= getMount($r)*$r['i_percent']/20?></td>
                        <td><?= $r['s_report'] ?></td>
                        <td><?= ArDate('Y/m/d', $r['s_time']) ?></td>
                        <td><a href="<?= base_url() ?>committee/beneficiaries/delete/incomes/<?= $r['i_id'] ?>" class="btn btn-danger">حذف</a></td>
                    </tr>
				<?php } ?>
				<?php } ?>
                <th colspan="4">المجموع</th>
                <th><?= $sum ?></th>
                <th colspan="4"></th>
            </table>
            <button class="btn btn-success add_row" type="button" id="add_row-<?=$row['r_no']?>">إضافة</button><br /><br />
	        <?php } ?>
        </div>
    </div>
    <input type="submit" class="btn btn-primary" value="حفظ البيانات" />
    <a href="<?= base_url() ?>committee/beneficiaries/show/<?= $bid ?>" class="btn btn-warning">عودة</a>
</form>



<script type="text/javascript">
    $('.add_row').click(function () {
    
    	var number = $(this).attr('id').split('-')[1];
    	var target = '#table-' + number + ' tbody';
        var html = '<tr><td><select class="form-control source" name="incomes[i_source][]"><?= str_replace("\n", '', GetOptions('income_source')) ?></select></td>' +
                '<td><select class="form-control" name="incomes[i_info][]"><?= str_replace("\n", '', GetOptions('income_info')) ?></select></td>' +
                '<td><input type="text" name="incomes[i_count][]" class="form-control hidden counter" placeholder="عدد الرؤوس" />' +
                '<input type="hidden" name="incomes[i_no][]" value="' + number + '" />'+
                '<input type="text" name="incomes[i_date][]" class="form-control datepicker hidden" placeholder="تاريخ ثبوت التملك" /></td>' +
                '<td><input type="text" name="incomes[i_mount][]" class="form-control" /></td>';
        if (parseInt(number) == 0) {
	        html += '<input type="hidden" name="incomes[i_percent][]" value="100" /></tr>';
        } else {
	        html += '<td><input type="text" name="incomes[i_percent][]" class="form-control" value="100" /></td></tr>'
        }
        
        $(target).append(html);

        $('.datepicker').calendarsPicker({calendar: $.calendars.instance('ummalqura', 'ar'), onClose: function () {
                $(this).parent().parent().removeClass('has-error');
            }});

        $('.counter').change(function () {
            var type = $(this).parent().parent().children().eq(0).children().val();
            if (type == 7) {
                type = 1;
            } else if (type == 8) {
                type = 10;
            }
            var val = parseInt($(this).val()) * 5 * type;
            $(this).parent().parent().children().eq(3).children().val(val);
        });
        $('.source').on('change', function () {
            if ($(this).val() == 7 || $(this).val() == 8) {
                $(this).parent().parent().children().eq(2).children().removeClass('hidden');
                $(this).parent().parent().children().eq(3).children().prop('readonly', true);
            } else {
                $(this).parent().parent().children().eq(2).children().addClass('hidden');
                $(this).parent().parent().children().eq(3).children().prop('readonly', false);
                $(this).parent().parent().children().eq(3).children().val('');
            }
        });
    });


</script>

<?php
function getMount($row) {
    if ($row['i_source'] == 7)
        return $row['i_count'] * 5;
    if ($row['i_source'] == 8)
        return $row['i_count'] * 50;
    return $row['i_mount'];
}
?>