<form action="<?=base_url()?>committee/beneficiaries/edit/phones/<?=$bid?>/<?=$bno?>" method="post" role="form" data-toggle="novalidator" class="form-horizontal">
	<div class="panel panel-primary">
		<div class="panel-heading">هواتف المستفيد</div>
		<div class="form-group">
			<div class="col-sm-offset-2 col-sm-9">
				<table class="table" id="rows">
					<tr>
						<th>رقم الهاتف</th>
						<th>صاحب الرقم</th>
					</tr>
					<?php foreach ($phones as $row){ ?>
					<tr>
						<td><?=$row['p_number']?></td>
						<td><?=$row['p_name']?></td>
						<td><a href="<?=base_url()?>committee/beneficiaries/delete/phones/<?=$row['p_id']?>/<?=$bno?>" class="btn btn-danger">حذف</a></td>
						
					</tr>
					<?php } ?>
				</table>
				<button class="btn btn-success" type="button" id="add_row">إضافة</button>
				
			</div>
		</div>
	</div>
	<input type="submit" class="btn btn-primary" value="حفظ البيانات" />
	<a href="<?=base_url()?>committee/beneficiaries/show/<?=$bid?>/<?=$bno?>" class="btn btn-warning">عودة</a>
</form>

<script type="text/javascript">
	$('#add_row').click(function(){
		$('#rows tbody').append('<tr><td><input type="text" name="phones[p_number][]" class="form-control" required="true" /><input type="hidden" name="phones[p_no][]" value="<?=$bno?>" /></td>'+
				'<td><input type="text" name="phones[p_name][]" class="form-control" /></td><td><a herf="#" class="btn btn-danger delete">X</a></td><td></td></tr>');
	$('.delete').off('click');
	$('.delete').click(function(){
		if (confirm('هل انت متأكد؟')){
			$(this).parent().parent().remove();
		}
	});
	});
</script>