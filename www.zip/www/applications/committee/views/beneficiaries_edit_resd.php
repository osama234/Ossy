<h2 align="center">نظام اللجنة الاجتماعية</h2>
<form action="<?=base_url()?>committee/beneficiaries/edit/resd/<?=$residence['r_bid']?>/<?=$residence['r_no']?>" method="post" role="form" data-toggle="novalidator" class="form-horizontal">
	<div class="panel panel-primary">
		<div class="panel-heading">سكن المستفيد</div>
		<div class="panel-body">
			<div class="form-group">
				<label for="b_wife_name" class="control-label col-sm-2">اسم الزوجة التي تسكن في هذا المنزل</label>
				<div class="col-sm-4">
					<input type="text" name="residence[r_wife_name]" id="r_wife_name" value="<?=$residence['r_wife_name']?>" class="form-control" />
				</div>
			<div class="input-group">
                    <input type="checkbox" name="residence[r_dead]" value="1" />		
                    <label for="text" class="control">متوفيه</label>
					</div>
				<label for="r_dist" class="control-label col-sm-2">الحي</label>
				<div class="col-sm-4">
						<select name="residence[r_dist]" id="r_dist" class="form-control" >
					<option></option>
					<?=GetOptions('street',$residence{'r_dist'})?>
					</select>
				</div>
			</div>
			<div class="form-group">
			<label for="r_sponsor" class="control-label col-sm-2">كفالة المستفيد</label>
			<div class="col-sm-4">
				<input type="radio" name="residence[r_spons]" id="r_spons1" value="0"> <label for="r_spons1">مكفول</label>
				<input type="radio" name="residence[r_spons]" id="r_spons2" value="1"> <label for="r_spons2">غير مكفول</label>
				</div>
				<div class="kafeel">
				<label for="r_name" class="control-label col-sm-2" id="r_name_label">اسم الكافل</label>
			<div class="col-sm-4">
				<input type="text" name="residence[r_sponsor]" id="r_sponsor" value="<?=$residence['r_sponsor']?>" class="form-control" />
			</div>
			</div>
			
		</div>
		<div class="form-group kafeel">
		 <label for="r_sponsor" class="control-label col-sm-2">تاريخ بداية الكفالة</label>
                <div class="col-sm-4">
                <input type="date" name="residence[r_date]" id="r_date" value="<?=$residence['r_date']?>" class="form-control datepicker" />
                </div>				
				 <label for="r_sponsor" class="control-label col-sm-2">تاريخ انتهاء الكفالة</label>
                <div class="col-sm-4">
                <input type="date" name="residence[r_date_end]" id="r_date" value="<?=$residence['r_date_end']?>" class="form-control datepicker" />
                </div>
		</div>	
				<div class="form-group">
				<label for="r_idno" class="control-label col-sm-2">رقم الهوية</label>
				<div class="col-sm-4">
				<input type="text" name="residence[r_idno]" id="r_idno" value="<?=$residence['r_idno']?>" class="form-control" />
			</div>
			</div>
			<div class="form-group">
				<label for="r_street" class="control-label col-sm-2">اسم الشارع</label>
				<div class="col-sm-4">
					<input type="text" name="residence[r_street]" id="r_street" value="<?=$residence['r_street']?>" class="form-control" />
				</div>
				<label for="r_no" class="control-label col-sm-2">رقم المنزل</label>
				<div class="col-sm-4">
					<input type="text" name="residence[r_no]" id="r_no" value="<?=$residence['r_no']?>" class="form-control" />
				</div>
			</div>
			
			<div class="form-group">
				<label for="r_type" class="control-label col-sm-2">نوع السكن</label>
				<div class="col-sm-2">
					<select name="residence[r_type]" id="r_type" class="form-control" required="true">
						<option></option>
						<?=GetOptions('residence_type', $residence['r_type'])?>
					</select>
				</div>
				<div class="col-sm-2">
					<input type="radio" name="residence[r_owned]" id="r_owned1" value="1"<?=($residence['r_owned'] == 1 ? ' checked="true"':'')?> /> <label for="r_owned1">ملك</label>
					<input type="radio" name="residence[r_owned]" id="r_owned2" value="0"<?=($residence['r_owned'] == 0 ? ' checked="true"':'')?> /> <label for="r_owned2">مستأجر</label>
				</div>
				<label for="r_rent" class="control-label col-sm-2" id="r_rent_label">الإيجار السنوي</label>
				<div class="col-sm-4">
					<input type="text" name="residence[r_rent]" id="r_rent" value="<?=$residence['r_rent']?>" class="form-control" />
				</div>
			</div>
			
			<div class="form-group">
			<label class="control-label col-sm-2">احداثيات المنزل</label>
			<div class="col-sm-10">
				<label for="r_lat" class="control-label col-sm-1">E</label>
				<div class="col-sm-5">
					<input type="text" name="residence[r_lat]" id="r_lat" value="<?=$residence['r_lat']?>" class="form-control" />
				</div>
				<label for="r_long" class="control-label col-sm-1">N</label>
				<div class="col-sm-5">
					<input type="text" name="residence[r_long]" id="r_long" value="<?=$residence['r_long']?>" class="form-control" />
				</div>
			</div>
		</div>
		</div>
	</div>
	
	<input type="submit" class="btn btn-primary btn-md" value="حفظ وإعتماد" />
	<a href="<?=base_url()?>committee/beneficiaries/show/<?=$residence['r_bid']?>/<?=$residence['r_no']?>" class="btn btn-warning">عودة</a>
</form>

<script type="text/javascript">	
  function resdType() {
        if ($("input[name='residence[r_spons]']:checked").val() == 1) {
            $('.kafeel').hide();
        } else {
            $('.kafeel').show();
        }
        if ($("input[name='residence[r_owned]']:checked").val() == 0) {
            $('#r_rent_label').hide();
            $('#r_rent').hide();
        } else {
            $('#r_rent_label').show();
            $('#r_rent').show();
        }
    }
    resdType();
    $('input[type=radio]').click(function () {
        resdType()
    });
</script>