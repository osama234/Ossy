<form action="<?=base_url()?>committee/beneficiaries/edit/sicks/<?=$bid?>/<?=$bno?>" method="post" role="form" data-toggle="novalidator" class="form-horizontal">
	<div class="panel panel-primary">
		<div class="panel-heading">المرضى من أفراد الأسرة</div>
		<div class="form-group">
			<div class="col-sm-offset-1 col-sm-11">
				<table class="table" id="rows">
					<tr>
						<th>اسم المريض</th>
						<th>قرابته بصاحب الملف</th>
						<th>نوع المرض</th>
						<th>احتياجاته</th>
						<th>هل بوجد تقرير</th>
						<th>تاريخ التعديل</th>
					</tr>
					<?php foreach ($patients as $row){ ?>
					<tr>
						<td><?=$row['s_name']?></td>
						<td><?=$row['s_relation']?></td>
						<td><?=$row['s_type']?></td>
						<td><?=$row['s_needs']?></td>
						<td><?=$row['s_report']?></td>
						<td><?=ArDate('Y/m/d', $row['s_time'])?></td>
						<td><a href="<?=base_url()?>committee/beneficiaries/delete/sicks/<?=$row['s_id']?>/<?=$bno?>" class="btn btn-danger">حذف</a></td>
					</tr>
					<?php } ?>
				</table>
				<button class="btn btn-success" type="button" id="add_row">إضافة</button>
			</div>
		</div>
	</div>
	<input type="submit" class="btn btn-primary" value="حفظ البيانات" />
	<a href="<?=base_url()?>committee/beneficiaries/show/<?=$bid?>/<?=$bno?>" class="btn btn-warning">عودة</a>
</form>

<script type="text/javascript">
	$('#add_row').click(function(){
		$('#rows tbody').append('<tr><td><input type="text" name="patients[s_name][]" class="form-control" required="true" /></td>'+
						'<td><input type="text" name="patients[s_relation][]" class="form-control" /></td>'+
						'<td><input type="text" name="patients[s_type][]" class="form-control" /></td>'+
						'<td><input type="text" name="patients[s_needs][]" class="form-control" /></td>'+
						'<td><input type="text" name="patients[s_report][]" class="form-control" /></td><td></td></tr>');
	});
</script>