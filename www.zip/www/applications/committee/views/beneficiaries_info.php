	<h2 align="center">نظام اللجنة الاجتماعية</h2>
	<div class="panel panel-primary">
		<div class="panel-heading">معلومات عامة عن الأسرة</div>
		<div class="panel-body">
			
			<?php foreach ($info as $row){ ?>
			<div class="panel panel-default">
				<div class="panel-body"><?=nl2br($row['info_text'])?></div>
				<div class="panel-footer">أضيف في <?=ArDate('Y/m/d h:ia')?> بواسطة <?=GetUserById($row['info_userid'], 'user_name')?></div>
			</div>
			<?php } ?>
			
			<form action="<?=base_url()?>committee/beneficiaries/info/<?=$bid?>" method="post" role="form" data-toggle="novalidator" class="">
				<div class="form-group">
					<label for="b_name" class="control-label">إضافة معلومات</label>
					<textarea name="info[info_text]" class="form-control" rows="5"></textarea>
				</div>
				<input type="submit" class="btn btn-primary btn-md" value="حفظ البيانات" />
				<a href="<?=base_url()?>committee/beneficiaries/show/<?=$bid?>" class="btn btn-warning">عودة</a>
			</form>
		</div>
	</div>
	<br />

