	<h2 align="center">نظام اللجنة الاجتماعية</h2>
	<form action="<?=base_url()?>committee/beneficiaries/need/<?=$bid?>/<?=$bno?>" method="post" role="form" data-toggle="novalidator"  class="form-horizontal">
		<div class="panel panel-primary">
			<div class="panel-heading">فئة المستفيد ومدى حاجته</div>
			<div class="panel-body">
					<div class="form-group">
						<label class="control-label col-sm-4">رأي الباحث المباشر مع المستفيد في مدى حاجته</label>
						<div class="col-sm-4">
							<input type="radio" name="class[c_need]" value="1" <?=$class['c_need'] == 1 ? 'checked="true"':'' ?> id="very" /><label for="very">شديدة</label>
							<input type="radio" name="class[c_need]" value="2" <?=$class['c_need'] == 2 ? 'checked="true"':'' ?>id="medium" /><label for="medium">متوسطة</label>
							<input type="radio" name="class[c_need]" value="3" <?=$class['c_need'] == 3 ? 'checked="true"':'' ?>id="low" /><label for="low">ضعيفة</label>
						</div>
					</div>
					<div class="form-group">
						<label for="b_class" class="control-label col-sm-4">فئة المستفيد</label>
						<div class="col-sm-4">
							<input type="text" name="class[c_class]" id="b_class" value="<?=$class['c_class']?>" class="form-control" />
						</div>
					</div>
			</div>
			<div class="panel-footer">آخر تحديث في <?=ArDate('Y/m/d h:ia', $class['c_time'])?> بواسطة <?=GetUserById($class['c_userid'], 'user_name')?></div>
		</div>
		<input type="submit" class="btn btn-primary btn-md" value="حفظ البيانات" />
		<a href="<?=base_url()?>committee/beneficiaries/show/<?=$bid?>/<?=$bno?>" class="btn btn-warning">عودة</a>
	</form>
