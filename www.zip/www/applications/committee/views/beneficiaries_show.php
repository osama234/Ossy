<h2 align="center">نظام اللجنة الاجتماعية</h2>
<form role="form" class="form-horizontal">
    <?php foreach ($family_buttons as $row){ ?>
    	<?php if ($row['r_no'] == $beneficiary['r_no']){ ?>
    	<a href="#" class="btn btn-default"><?=$row['r_wife_name']?></a>
		<?php } else { ?>
    	<a href="<?=base_url()?>committee/beneficiaries/show/<?=$beneficiary['b_id']?>/<?=$row['r_no']?>" class="btn btn-primary"><?=$row['r_wife_name']?></a>
		<?php } ?>
    <?php } ?>
	<a href="<?= base_url() ?>committee/beneficiaries/add_plus/<?= $beneficiary['r_bid'] ?> " class="btn btn-primary pull-right">إضافة زوجة +</a>
    <br />
    <br />
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h4 class="pull-left">البيانات الأساسية</h4>
            <a href="<?= base_url() ?>committee/beneficiaries/edit/<?= $beneficiary['b_id'] ?>" class="btn btn-warning pull-right">تعديل</a>
            <div class="clearfix"></div>
        </div>
        <div class="panel-body">
            <div class="form-group">
                <label for="b_name" class="control-label col-sm-2">اسم المستفيد رباعياً</label>
                <div class="col-sm-4">
                    <?= $beneficiary['b_name'] ?>
                </div>
                <label for="b_id" class="control-label col-sm-2">رقم ملف المستفيد</label>
                <div class="col-sm-4">
                    <?= $beneficiary['b_id'] ?>
                </div>
            </div>

            <div class="form-group">
                <label for="b_idno" class="control-label col-sm-2">رقم الهوية</label>
                <div class="col-sm-4">
                    <?= $beneficiary['b_idno'] ?>
                </div>
                <label for="b_natid" class="control-label col-sm-2">الجنسية</label>
                <div class="col-sm-4">
                    <?= GetOptionsLabel('nationality', $beneficiary['b_natid']) ?>
                </div>
            </div>

            <div class="form-group">
                <label for="b_status" class="control-label col-sm-2">حالة الأسرة</label>
                <div class="col-sm-4">
                    <?= GetOptionsLabel('user_status', $beneficiary['b_status']) ?>
                </div>
                <label for="b_wives" class="control-label col-sm-2">عدد الزوجات</label>
                <div class="col-sm-4">
                    <?= $beneficiary['b_wives'] ?>
                </div>
            </div>

            <div class="form-group">
                <label for="b_wives" class="control-label col-sm-2">رقم حساب المستفيد</label>
                <div class="col-sm-4">
                    <?= $beneficiary['b_account_no'] ?>
                </div>
			   </div>
			<div class="form-group">
				<label for="b_bank_name" class="control-label col-sm-2">اسم البنك</label>
			<div class="col-sm-4">							
					<?=GetOptionslabel('bank_name', $beneficiary['b_bank_name'])?>				
			</div>
			                <label for="b_file" class="control-label col-sm-2">حالة الملف</label>
                <div class="col-sm-4">
                    <?= GetOptionsLabel('file_status', $beneficiary['b_file']) ?>
                </div>
            </div>
		</div>       						
			
		
        <div class="panel-footer">
            <span>آخر تعديل في: <?= ArDate('Y/m/d h:ia', $beneficiary['b_lastchange']) ?> بواسطة <?= GetUserById($beneficiary['b_userid'], 'user_name') ?></span>
        </div>
    </div>

    <div class="panel panel-primary">
        <div class="panel-heading">
            <h4 class="pull-left">سكن المستفيد</h4>
            <a href="<?= base_url() ?>committee/beneficiaries/edit/resd/<?= $beneficiary['r_bid'] ?>/<?= $beneficiary['r_no'] ?>" class="btn btn-warning pull-right">تعديل</a>
            <div class="clearfix"></div>
        </div>
        <div class="panel-body">
            <div class="form-group">
                <label for="b_wife_name" class="control-label col-sm-2">اسم الزوجة التي تسكن في هذا المنزل</label>
                <div class="col-sm-4">
                    <?= $beneficiary['r_wife_name'] ?>
                </div>
                <label for="r_dist" class="control-label col-sm-2">الحي</label>
                <div class="col-sm-4">
                    <?= $beneficiary['r_dist'] ?>
                </div>
			</div>
				<div class="form-group">
							<label for="r_sponsor" class="control-label col-sm-2">كفالة المستفيد</label>
			<div class="col-sm-4">			 
				
				 <?= $beneficiary['r_spons'] == 0 ? "مكفول" : "غير مكفول" ?>
			</div>
			 <label for="r_idno" class="control-label col-sm-2">رقم الهوية</label>
                <div class="col-sm-4">
                    <?= $beneficiary['r_idno'] ?>
                </div>			
			</div>
			<div class="form-group kafeel">
			  <label for="r_sponsor" class="control-label col-sm-2">اسم الكافل</label>
                <div class="col-sm-4">
                    <?= $beneficiary['r_sponsor'] ?>
                </div>
				</div>
          
	
			<div class="form-group kafeel">
				 <label for="r_sponsor" class="control-label col-sm-2">تاريخ الكفالة</label>
                <div class="col-sm-4">
                    <?= $beneficiary['r_date'] ?>
					</div>
						 <label for="r_sponsor" class="control-label col-sm-2">تاريخ الكفالة</label>
                <div class="col-sm-4">
                    <?= $beneficiary['r_date_end'] ?>
                </div>
			</div>	
            <div class="form-group">
                <label for="r_street" class="control-label col-sm-2">اسم الشارع</label>
                <div class="col-sm-4">
                    <?= $beneficiary['r_street'] ?>
                </div>
                <label for="r_no" class="control-label col-sm-2">رقم المنزل</label>
                <div class="col-sm-4">
                    <?= $beneficiary['r_no'] ?>
                </div>
            </div>

            <div class="form-group">
                <label for="r_type" class="control-label col-sm-2">نوع السكن</label>
                <div class="col-sm-2">
                    <?= GetOptionsLabel('residence_type', $beneficiary['r_type']) ?>
                </div>
                <div class="col-sm-2">
                    <?= $beneficiary['r_owned'] == 1 ? "ملك" : "مستأجر" ?>
                </div>
                <label for="r_rent" class="control-label col-sm-2">الإيجار السنوي</label>
                <div class="col-sm-4">
                    <?= $beneficiary['r_rent'] ?>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">احداثيات المنزل</label>
                <div class="col-sm-10">
                    <label for="r_lat" class="control-label col-sm-1">E</label>
                    <div class="col-sm-4">
                        <?= $beneficiary['r_lat'] ?>
                    </div>
                    <label for="r_long" class="control-label col-sm-1">N</label>
                    <div class="col-sm-4">
                        <?= $beneficiary['r_long'] ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel-footer">
            <span>آخر تعديل في: <?= ArDate('Y/m/d h:ia', $beneficiary['r_lastchange']) ?> <?= GetUserById($beneficiary['b_userid'], 'user_name') ?>
			</span>
        </div>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h4 class="pull-left">هواتف المستفيد</h4>
            <a href="<?= base_url() ?>committee/beneficiaries/edit/phones/<?= $beneficiary['b_id'] ?>/<?=$beneficiary['r_no']?>" class="btn btn-warning pull-right">تعديل</a>
            <div class="clearfix"></div>
        </div>
        <div class="panel-body">
            <table class="table">
                <tr>
                    <th>رقم الهاتف</th>
                    <th>صاحب الرقم</th>
                    <th>تاريخ الإضافة</th>
                </tr>
                <?php foreach ($phones as $row) { ?>
                    <tr>
                        <td><?= $row['p_number'] ?></td>
                        <td><?= $row['p_name'] ?></td>
                        <td><?= ArDate('Y/m/d', $row['p_time']) ?></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>

    <div class="panel panel-primary">
        <div class="panel-heading">
            <h4 class="pull-left">أفراد الأسرة الذين يسكنون في المنزل</h4>
            <a href="<?= base_url() ?>committee/beneficiaries/edit/family/<?= $beneficiary['b_id'] ?>/<?= $beneficiary['r_no'] ?>" class="btn btn-warning pull-right">تعديل</a>
            <div class="clearfix"></div>
        </div>
        <?php if ($family) { ?>
            <div class="panel-body">
                <table class="table">
                    <tr>
                        <th colspan="3">أولاد المستفيد</th>
                        <th colspan="4">أقارب المستفيد</th>
                    </tr>
                    <tr>
                        <th>المرحلة الدراسية</th>
                        <th>عدد الأبناء</th>
                        <th>عدد البنات</th>
                        <th>اسم القريب</th>
                        <th>نوع القرابة</th>
                        <th>العدد</th>
                        <th>ملاحظة</th>
                    </tr>
                    <tr>
                        <td>صغار لم يدرسوا</td>
                        <td><?= (int) $family['data'][0]['m'] ?></td>
                        <td><?= (int) $family['data'][0]['f'] ?></td>
                        <td><?= $family['data'][0]['name'] ?></td>
                        <td><?= $family['data'][0]['type'] ?></td>
                        <td><?= (int) $family['data'][0]['count'] ?></td>
                        <td><?= $family['data'][0]['note'] ?></td>
                    </tr>
                    <tr>
                        <td>الابتدائي</td>
                        <td><?= (int) $family['data'][1]['m'] ?></td>
                        <td><?= (int) $family['data'][1]['f'] ?></td>
                        <td><?= $family['data'][1]['name'] ?></td>
                        <td><?= $family['data'][1]['type'] ?></td>
                        <td><?= (int) $family['data'][1]['count'] ?></td>
                        <td><?= $family['data'][1]['note'] ?></td>
                    </tr>
                    <tr>
                        <td>المتوسط</td>
                        <td><?= (int) $family['data'][2]['m'] ?></td>
                        <td><?= (int) $family['data'][2]['f'] ?></td>
                        <td><?= $family['data'][2]['name'] ?></td>
                        <td><?= $family['data'][2]['type'] ?></td>
                        <td><?= (int) $family['data'][2]['count'] ?></td>
                        <td><?= $family['data'][2]['note'] ?></td>
                    </tr>
                    <tr>
                        <td>لثانوي</td>
                        <td><?= (int) $family['data'][3]['m'] ?></td>
                        <td><?= (int) $family['data'][3]['f'] ?></td>
                        <td><?= $family['data'][3]['name'] ?></td>
                        <td><?= $family['data'][3]['type'] ?></td>
                        <td><?= (int) $family['data'][3]['count'] ?></td>
                        <td><?= $family['data'][3]['note'] ?></td>
                    </tr>
                    <tr>
                        <td>الجامعي</td>
                        <td><?= (int) $family['data'][4]['m'] ?></td>
                        <td><?= (int) $family['data'][4]['f'] ?></td>
                        <td><?= $family['data'][4]['name'] ?></td>
                        <td><?= $family['data'][4]['type'] ?></td>
                        <td><?= (int) $family['data'][4]['count'] ?></td>
                        <td><?= $family['data'][4]['note'] ?></td>
                    </tr>
                    <tr>
                        <td>عاطل</td>
                        <td><?= (int) $family['data'][5]['m'] ?></td>
                        <td><?= (int) $family['data'][5]['f'] ?></td>
                        <td><?= $family['data'][5]['name'] ?></td>
                        <td><?= $family['data'][5]['type'] ?></td>
                        <td><?= (int) $family['data'][5]['count'] ?></td>
                        <td><?= $family['data'][5]['note'] ?></td>
                    </tr>
                    <tr>
                        <td>موظف</td>
                        <td><?= (int) $family['data'][6]['m'] ?></td>
                        <td><?= (int) $family['data'][6]['f'] ?></td>
                        <td><?= $family['data'][6]['name'] ?></td>
                        <td><?= $family['data'][6]['type'] ?></td>
                        <td><?= (int) $family['data'][6]['count'] ?></td>
                        <td><?= $family['data'][6]['note'] ?></td>
                    </tr>
                </table>
                <div class="form-group">
                    <label for="b_name" class="control-label col-sm-4">إجمالي عدد أفراد الأسرة من غير الموظفين</label>
                    <div class="col-sm-1">
                        <?= $family['unemployed']  ?>
                    </div>
                    <label for="b_name" class="control-label col-sm-2">الموظفين</label>
                    <div class="col-sm-1">
                        <?= $family['employed'] ?>
                    </div>
                    <label for="b_name" class="control-label col-sm-2">المجموع</label>
                    <div class="col-sm-1">
                        <?= $family['unemployed'] + $family['employed']  ?>
                    </div>
                </div>
            </div>
            <div class="panel-footer">آخر تحديث في <?= ArDate('Y/m/d h:ia', $family['lastchange']) ?> بواسطة <?= GetUserById($family['userid'], 'user_name') ?></div>
        <?php } ?>
    </div>

    <div class="panel panel-primary">
        <div class="panel-heading">
            <h4 class="pull-left">المرضى من أفراد الأسرة</h4>
            <a href="<?= base_url() ?>committee/beneficiaries/edit/sicks/<?= $beneficiary['b_id'] ?>/<?= $beneficiary['r_no'] ?>" class="btn btn-warning pull-right">تعديل</a>
            <div class="clearfix"></div>
        </div>
        <?php if ($patients) { ?>
            <div class="panel-body">
                <table class="table" id="rows">
                    <tr>
                        <th>اسم المريض</th>
                        <th>قرابته بصاحب الملف</th>
                        <th>نوع المرض</th>
                        <th>احتياجاته</th>
                        <th>هل بوجد تقرير</th>
                        <th>تاريخ التعديل</th>
                    </tr>
                    <?php foreach ($patients as $row) { ?>
                        <tr>
                            <td><?= $row['s_name'] ?></td>
                            <td><?= $row['s_relation'] ?></td>
                            <td><?= $row['s_type'] ?></td>
                            <td><?= $row['s_needs'] ?></td>
                            <td><?= $row['s_report'] ?></td>
                            <td><?= ArDate('Y/m/d', $row['s_time']) ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </div>
        <?php } ?>
    </div>

    <div class="panel panel-primary">
        <div class="panel-heading">
            <h4 class="pull-left">دخل المستفيد</h4>
            <a href="<?= base_url() ?>committee/beneficiaries/edit/incomes/<?=$beneficiary['b_id']?>/<?= $beneficiary['r_no'] ?>" class="btn btn-warning pull-right">تعديل</a>
            <div class="clearfix"></div>
        </div>
        <?php if ($incomes) { ?>
            <div class="panel-body">
                <table class="table" id="rows">
                    <tr>
                        <th>جهة الدخل</th>
                        <th>مصدر المعلومة</th>
                        <th>مقدار الدخل الشهري</th>
                        <th>تاريخ ثبوت الملكية</th>
                        <th>تاريخ الإدخال</th>
                    </tr>
                    <?php foreach ($incomes as $row) { ?>
                    <?php if ($row['i_no'] == $beneficiary['r_no'] || $row['i_no'] == 0) { ?>
                        <tr>
                            <td><?= GetOptionsLabel('income_source', $row['i_source']) ?> <?= $row['i_count'] ? $row['i_count'] . ' رأس' : '' ?></td>
                            <td><?= GetOptionsLabel('income_info', $row['i_info']) ?></td>
                            <?php if ($row['i_percent'] < 100) { ?>
                            <td><?= getMount($row); $sum+=getMount($row)*$row['i_percent']/100 ?> * <?=$row['i_percent']?>% = <?=getMount($row)*$row['i_percent']/100?></td>
                            <?php } else { ?>
                            <td><?= getMount($row); $sum+=getMount($row) ?></td>
                            <?php } ?>
                            <td><?= $row['i_date'] ?></td>
                            <td><?= ArDate('Y/m/d', $row['s_time']) ?></td>
                        </tr>
					<?php } ?>
                    <?php } ?>
                    <th colspan="2">المجموع</th>
                    <th><?= $sum ?></th>
                    <th colspan="4"></th>
                </table>
                
                <table class="table">
                	<tr>
                		<th>دخل رب الأسرة</th>
                		<td><?=getMainIncomes($beneficiary['b_id'])?></td>
                	</tr>
                	<tr>
                		<th>دخل رب الأسرة المخصص لهذه الأسرة</th>
                		<td><?=getNetIncomes($beneficiary['b_id'], $beneficiary['r_no'])?></td>
                	</tr>
                	<tr>
                		<th>دخل آخر للأسرة</th>
                		<td><?=getFamilyIncomes($beneficiary['b_id'], $beneficiary['r_no'])?></td>
                	</tr>
                	<tr>
                		<th>الصافي</th>
                		<td><?=getNetIncomes($beneficiary['b_id'], $beneficiary['r_no']) + getFamilyIncomes($beneficiary['b_id'], $beneficiary['r_no'])?></td>
                	</tr>
                </table>
            </div>
            <div class="panel-footer">آخر تحديث في <?= ArDate('Y/m/d h:ia', $row['i_time']) ?> بواسطة <?= GetUserById($row['i_userid'], 'user_name') ?></div>
<?php } ?>
    </div>

    <div class="panel panel-primary">
        <div class="panel-heading">متوسط دخل الفرد</div>
        <div class="panel-body">
<?php if ($incomes and $family) { ?>
                <table class="table">
                    <tr>
                        <th>مجموع الدخل السنوي</th>
                        <th>إيجار المنزل</th>
                        <th>أقساط تسحب</th>
                        <th>صافي الدخل السنوي</th>
                        <th>عدد أفراد الأسرة</th>
                        <th>متوسط دخل الفرد</th>
                        <th>الشهري</th>
						<th>فئة المستفيد</th>
						<th>فئة الصرف</th>
                    </tr>
                    <tr>
                        <td><?= $sum * 12 ?></td>
                        <td><?= $beneficiary['r_rent']  ?></td>
                        <td><?= $beneficiary['b_installment'] * 12 ?></th>
                        <td><?= $total = ($sum * 12) - $beneficiary['r_rent'] - ($beneficiary['b_installment'] * 12) ?></td>
                        <td><?= $class = getNetnumber($family['f_bid'])+1 - $beneficiary['b_dead']  - $beneficiary['r_dead']  ?></td>
                        <td><?= round($ipp = $total / $class , 2) ?></td>
                        <td><?= $ind=round($ipp / 12, 2) ?></td>
						<td><?= beneficiaryClass($ind)?></td>
						<td><?= numberfamily($class) ?></td>
                    </tr>
                </table>
            <?php } else { ?>
                <span>يرجى إدخال دخل المستفيد وأفراد أسرته</span>
<?php } ?>
        </div>
    </div>

</form>

<div class="panel panel-primary">
    <div class="panel-heading">
        <h4>الإعانات المصروفة للمستفيد</h4>
    </div>
    <table class="table">
        <tr>
            <th>م</th>
            <th>النوع</th>
            <th>العدد</th>
			<th>الكمية</th>
            <th>التاريخ</th>
            <th>الاستلام</th>
            <th>مدخل البيانات</th>
        </tr>
        <?php if (isset($disbursed) and count($disbursed)) { ?>
		<?php $i = 1; foreach ($disbursed as $row) { ?>
        <tr>
            <td><?= $i++ ?></td>
            <td><?= GetOptionsLabel('disbursed', $row['d_type']) ?></td>
            <td><?= $row['dtl_count'] ?></td>
			<td><?= $row['dtl_count_no']?></td>
            <td><?= ArDate('Y/m/d', $row['d_date']) ?></td>
            <td>
                <?= ($row['dtl_received'] == 1) ? 'تم التسليم':'' ?>
                <?= ($row['dtl_received'] == 2) ? 'لم يستلم':'' ?>
            </td>
            <td><?=GetUserById($row['d_user'], 'user_name')?></td>
        </tr>
        <?php } ?>
        <?php } else { ?>
        <tr><td colspan="4">لا توجد بيانات حالياً</td></tr>
		<?php } ?>
    </table>
</div>


<a href="<?= base_url() ?>committee/beneficiaries/info/<?= $beneficiary['b_id'] ?>" class="btn btn-primary">معلومات عامة أخرى</a>
<a href="<?= base_url() ?>committee/beneficiaries" class="btn btn-primary">عودة</a>
<a href="#" class="btn btn-warning print_btn">طباعة</a>
<a href="<?=base_url()?>committee/beneficiaries/delsup/<?=$beneficiary['r_bid']?>/<?=$beneficiary['r_no']?>" class="btn btn-danger">حذف</a>
<br />
<br />

<?php

function getMount($row) {
    if ($row['i_source'] == 7)
        return $row['i_count'] * 5;
    if ($row['i_source'] == 8)
        return $row['i_count'] * 50;
    return $row['i_mount'];
}
?>


