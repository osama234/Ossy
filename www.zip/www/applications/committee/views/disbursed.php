<div class="panel panel-primary">
	<div class="panel-heading">المشاريع الموزعة</div>
	<table class="table">
		<tr>
            <th>م</th>
            <th>النوع</th>
            <th>التاريخ</th>
            <th>عدد المستفيدين</th>
            <th></th>
        </tr>
        <?php if (isset($items) and count($items)){ ?>
        <?php $i=1; foreach ($items as $row){ ?>
		<tr>
            <td><?=$i++?></td>
            <td><?=GetOptionsLabel('disbursed', $row['d_type'])?></td>
            <td><?=ArDate('Y/m/d', $row['d_date'])?></td>
            <td><?=$row['count']?></td>
            <td><a class="btn btn-primary pull-right" href="<?=base_url()?>committee/disbursed/edit/<?=$row['d_id']?>">عرض</a></td>
        </tr>
        <?php } ?>
        <?php } else { ?>
        <tr><td colspan="4">لا توجد بيانات حالياً</td></tr>
        <?php } ?>
    </table>
</div>