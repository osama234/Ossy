<form action="<?=base_url()?>committee/disbursed/edit/<?=$id?>" method="post" role="form">
	<div class="panel panel-primary">
		<div class="panel-heading">المشاريع الموزعة</div>
		<table class="table">
			<tr>
	            <th>رقم المستفيد</th>
	            <th>اسم المستفيد</th>
	            <th>هاتف المستفيد</th>
	            <th>العدد</th>
	            <th>الاستلام</th>
	            <th></th>
	        </tr>
	        <?php if (isset($items) and count($items)){ ?>
	        <?php foreach ($items as $row){ ?>
			<tr>
	            <td><?=$row['b_id']?></td>
	            <td><?=$row['b_name']?></td>
	            <td><?=$row['phones'][0]?> <?=$row['phones'][1]?></td>
	            <td><?=$row['dtl_count']?></td>
	            <td>
	   	            <input name="dtl_received[<?=$row['dtl_id']?>]" type="radio" value="1" <?=$row['dtl_received'] == 1 ? 'checked="true"':'' ?> /> <label >تم التسليم</label>
		            <input name="dtl_received[<?=$row['dtl_id']?>]" type="radio" value="2" <?=$row['dtl_received'] == 2 ? 'checked="true"':'' ?> /> <label >لم يستلم</label>
	            </td>
	        </tr>
	        <?php } ?>
	        <?php } else { ?>
	        <tr><td colspan="4">لا توجد بيانات حالياً</td></tr>
	        <?php } ?>
	    </table>
	    <div class="panel-footer">
			<input type="submit" class="btn btn-primary btn-md" value="حفظ البيانات" />
	    </div>
	</div>
</form>