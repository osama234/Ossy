<?php if (!$save){ ?>
<form action="<?=base_url()?>committee/distribute" method="post" class="form-horizontal" role="form">
	<div class="form-group">
		<label for="d_type" class="control-label col-sm-1">توزيع</label>
		<div class="col-sm-2">
			<select name="filter[d_type]" id="d_type" class="form-control" required="true">
					<option></option>
					<?=GetOptions('disbursed', $_POST['filter']['d_type'])?>
				</select>
		</div>
		<label for="b_name" class="control-label col-sm-2">لمن لم يصرف لهم منذ</label>
		<div class="col-sm-2">
			<input type="text" name="filter[d_date]" id="d_date" class="form-control datepicker" value="<?=$_POST['filter']['d_date']?>" />
		</div>
		<label for="limit" class="control-label col-sm-1">عدد الأسر</label>
		<div class="col-sm-2">
			<input type="text" name="filter[limit]" id="limit" class="form-control" value="<?=$_POST['filter']['limit']?>" />
		</div>
		<input type="submit" class="btn btn-primary btn-md" value="عرض" />
	</div>
</form>
<?php } ?>
<?php if ($save){ ?>
<form action="<?=base_url()?>committee/distribute/add" method="post" role="form">
<div class="panel panel-primary">
	<div class="panel-heading">المستفيدين</div>
	<input name="d_type" type="hidden" value="<?=$type?>" />
	<table class="table">
		<tr>
            <th>رقم المستفيد</th>
            <th>اسم المستفيد</th>
			<th>الزوجة</th>
            <th>هاتف المستفيد</th>
            <th>العدد</th>
			<th>النوع</th>
            <th>الاستلام</th>
            <th></th>
        </tr>
        <?php if (isset($families) and count($families)){ ?>
        <?php foreach ($families as $row){ ?>
		<tr>
            <td><?=$row['b_id']?></td>
            <td><?=$row['b_name']?></td>
			<td><?= $row['r_wife_name'] ?></td>
            <td><?=$row['phones'][0]?> <?=$row['phones'][1]?></td>
            <td><input type="number" name="d_count[<?=$row['r_id']?>]" /></td>
			<td><input type="text" name="d_count_no[<?=$row['r_id']?>]"  /></td>
            <td>
				<input name="d_bid[<?=$row['r_id']?>]" type="hidden" value="<?=$row['b_id']?>" />
   	            <input name="d_received[<?=$row['r_id']?>]" type="radio" value="1" /> <label >تم التسليم</label>
	            <input name="d_received[<?=$row['r_id']?>]" type="radio" value="2" /> <label >لم يستلم</label>
            </td>
        </tr>
        <?php } ?>
        <?php } else { ?>
        <tr><td colspan="5">لا توجد بيانات حالياً</td></tr>
        <?php } ?>
    </table>
    <div class="panel-footer">
		<input type="submit" class="btn btn-primary btn-md" value="حفظ البيانات" />
    </div>
</div>
</form>
<?php } else {?>
<form action="<?=base_url()?>committee/distribute" method="post" role="form">
<div class="panel panel-primary">
	<div class="panel-heading">المستفيدين</div>
	<input name="d_type" type="hidden" value="<?=$type?>" />
	<table class="table">
		<tr>
            <th><input type="checkbox" id="checkall" /></th>
            <th>رقم المستفيد</th>
            <th>اسم المستفيد</th>
            <th>الحي</th>
            <th>حالة المستفيد</th>
            <th></th>
        </tr>
        <?php if (isset($families) and count($families)){ ?>
        <?php foreach ($families as $row){ ?>
        <tr>
            <td><input type="checkbox" name="user[<?=$row['b_id']?>]" class="checkbox" /></td>
            <td><?=$row['b_id']?></td>
            <td><?=$row['b_name']?></td>
            <td><?=$row['r_dist']?></td>
            <td><?=GetOptionsLabel('user_status', $row['b_status'])?></td>
        </tr>
        <?php } ?>
        <?php } else { ?>
        <tr><td colspan="6">لا توجد بيانات حالياً</td></tr>
        <?php } ?>
    </table>
    <div class="panel-footer">
		<input type="submit" class="btn btn-primary btn-md" value="التالي" />
    </div>
</div>
</form>
<?php } ?>

<script type="text/javascript">
	$(function(){
		$('#checkall').click(function(){
			$('.checkbox').prop("checked",$('#checkall').is(':checked'));
		});
	});
</script>