<form action="<?= base_url('committee/reports/show') ?>" method="post">
    <div class="panel panel-primary">
        <div class="panel-heading">التقارير</div>
        <div class="panel-body">
            <div class="form-group">
                <label for="title" class="control-label col-sm-4">عنوان التقرير</label>
                <div class="col-sm-4">
                    <input type="text" name="title" id="title" class="form-control" />
                </div>
            </div>
            <br />
            <br />
            <div class="form-group">
                <label for="date" class="control-label col-sm-1">من </label>
                <div class="col-sm-4">
                    <input type="date" name="" id=""  class="form-control datepicker"   />
                </div>			
                <label for="date" class="control-label col-sm-1">إلى</label>
                <div class="col-sm-4">
                    <input type="date" id="" class="form-control datepicker" >


                </div>
            </div>
            <br />
            <br />
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="panel-body">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="b_id" />		
                                        <label for="text" class="control">رقم الملف</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="b_name" />		
                                        <label for="text" class="control">الإسم</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="beneficiaryClass" />		
                                        <label for="text" class="control">فئة المستفيد</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox"  name="r_sponsor" />		
                                        <label for="text" class="control">اسم الكافل</label>
                                    </div><!-- /input-group -->
                                </div>
                            </div>

                        </div>

                        <div class="form-group">
                            <div class="row">
							  <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="unemployed" />		
                                        <label for="text" class="control">عدد الأفراد</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="p_number" />		
                                        <label for="text" class="control">رقم الإتصال</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="r_dist" />		
                                        <label for="text" class="control">الحي</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="r_wife_name" />		
                                        <label for="text" class="control">اسم الزوجة</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="b_idno" />		
                                        <label for="text" class="control">السجل المدني0</label>
                                    </div><!-- /input-group -->
                                </div>

                            </div>

                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="b_id" />		
                                        <label for="text" class="control">فئة الصرف</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="b_account_no" />		
                                        <label for="text" class="control">الحساب البنكي</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name=""/>		
                                        <label for="text" class="control">الدخل</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="r_type" />		
                                        <label for="text" class="control">نوع السكن</label> 
                                    </div><!-- /input-group -->
                                </div>
                            </div>

                        </div>

                        <div class="form-group">
                            <div class="row">
							  <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="d_type" />		
                                        <label for="text" class="control">مصروفات المستفيد</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="d_date" />		
                                        <label for="text" class="control">تاريخ</label>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group">     
                                        <input type="checkbox" name="sign" />		
                                        <label for="text" class="control">التوقيع</label>
                                    </div><!-- /input-group -->
                                </div>
                              
                            </div>

                        </div>

                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="text" class="control-label col-sm-2">العدد المطلوب للتقرير</label>
                <div class="col-sm-3">
                    <input type="text" class="form-control" name="limit" />
                </div>
                <div class="row">
                    <div class="col-sm-2">
                        <div class="input-group">     
                            <input type="checkbox" name="all" />		
                            <label for="text" class="control">الجميع</label>
                        </div><!-- /input-group -->
                    </div>
                </div>
                <input type="submit" class="btn btn-primary btn-md" value="حفظ البيانات" />
            </div>
        </div>
    </div>
</form>