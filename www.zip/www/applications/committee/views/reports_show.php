<h2 align="center">نظام اللجنة الاجتماعية</h2>

<div class="panel panel-primary">
        <div class="panel-heading">تقارير المستفيدين</div>
        <div class="panel-body">
		
		<div class="form-group">
                <h4><?= $_POST['title']  ?></h4>
				

                <table class="table table-bordered ">
				<thead>
                    <tr>
                        <?php if ($_POST['b_id']){ ?>
                        <th>رقم الملف</th>
                        <?php } ?>
                        <?php if ($_POST['b_name']){ ?>
                        <th>الاسم</th>
                        <?php } ?>
                        <?php if ($_POST['beneficiaryClass']){ ?>
                        <th>فئة المستفيد</th>
                        <?php } ?>
						 <?php if ($_POST['r_sponsor']){ ?>
						<th>اسم الكافل</th>
						 <?php } ?>
						<?php if ($_POST['unemployed']){ ?>
						<th>عدد الأفراد</th>
						<?php } ?>
						<?php if ($_POST['p_number']){ ?>
                        <th>رقم الإتصال</th>
						<?php } ?>
						<?php if ($_POST['r_dist']){ ?>
                        <th>الحي</th>
						<?php } ?>
						<?php if ($_POST['r_wife_name']){ ?>
						<th>اسم الزوجة</th>
						<?php } ?>
						<?php if ($_POST['b_idno']){ ?>
						<th>السجل المدني0</th>
						<?php } ?>
						<?php if ($_POST['class']){ ?>
						<th>فئة الصرف</th>
						<?php } ?>
						<?php if ($_POST['b_account_no']){ ?>
						<th>الحساب البنكي</th>
						<?php } ?>
						<?php if ($_POST['sum']){ ?>
						<th>الدخل</th>
						<?php } ?>
						<?php if ($_POST['r_type']){ ?>
						<th>نوع السكن</th>
						<?php } ?>
						<?php if ($_POST['d_type']){ ?>
						<th>مصروفات المستفيد</th>
						<?php } ?>
						<?php if ($_POST['d_date']){ ?>
						<th>تاريخ الصرف</th>
						<?php } ?>
						<?php if ($_POST['sign']){ ?>
						<th>التوقيع</th>
						<?php } ?>
						
                    </tr>
					</thead>
			<?php foreach ($users as $row) { ?>
			<tbody>
                    <tr>

                        <?php if ($_POST['b_id']){ ?>
                        <td><?= $row['b_id'] ?></td>
                        <?php } ?>
                        <?php if ($_POST['b_name']){ ?>
                        <td><?= $row['b_name']?></th>
                        <?php } ?>
                        <?php if ($_POST['beneficiaryClass']){ ?>
                        <td><?= $row=beneficiaryClass($ind)?></td>
                        <?php } ?>
						<?php if ($_POST['r_sponsor']){ ?>
                        <td><?= $row['r_sponsor']?></td>
						<?php } ?>
						<?php if ($_POST['p_number']){ ?>
                        <td><?= $row['p_number']?></td>
						<?php } ?>
						<?php if ($_POST['r_dist']){ ?>
                        <td><?= $row['r_dist'] ?></td>
						<?php } ?>
	                    <?php if ($_POST['r_wife_name']){ ?>
						<td><?= $row['r_wife_name'] ?></td>
						<?php } ?>
						<?php if ($_POST['b_account_no']){ ?>
						<td><?= $row['b_account_no'] ?></td>
						<?php } ?>
						<?php if ($_POST['b_idno']){ ?>
						<td><?= $row['b_idno'] ?></td>
						<?php } ?>
						<?php if ($_POST['getMainIncomes']){ ?>
						<td><?= $row=getMainIncomes($beneficiary['b_id'])?></td>
						<?php } ?>
						<?php if ($_POST['r_type']){ ?>
						<td><?= $row['r_type'] ?></td>
						<?php } ?>
						<?php if ($_POST['d_type']){ ?>
						<td><?= $row['d_type']?></td>
						<?php } ?>
						<?php if ($_POST['d_date']){ ?>
						<td><?= ArDate('Y/m/d', $row['d_date']) ?></td>
						<?php } ?>
						<?php if ($_POST['sign']){ ?>
						<td></td>
						<?php } ?>
                    </tr>
					</tbody>
					<?php } ?>
                </table>
        </div>
		</div>
    </div>