<?php
    class control_controller extends controller 
    {
        function __construct() {
            parent::__construct();
        }
        
        function index($params=null) {
        	RedirectDefault();
			return(true);
		}
        
        function user($act='', $id=0) {
			if ($act == 'add') {
				if (isset($_POST['user'])) {
					$user = $this->validate_user($_POST['user'], $act);
					if ($user) {
						$user['user_password'] = md5($user['user_password']);
						$sql = $this->mydb->sql_insert('users', $user);
						$this->mydb->execute($sql, $user);
						setMessage('User data saved!', 'success');
						redirect('control/user');
					} else {
						$this->vars['user_row'] = $_POST['user'];
					}
				}
			} elseif ($act == 'edit' and $id) {
				if (isset($_POST['user'])) {
					$user = $this->validate_user($_POST['user'], $act);
					if ($user) {
						if (!empty($user['user_password'])) {
							$user['user_password'] = md5($user['user_password']);
						} else {
							unset($user['user_password']);
						}
						$this->mydb->execute($this->mydb->sql_update('users', $user, array('user_id' => $id)), $user);
						setMessage('User data saved!', 'success');
						redirect('control/user');
					}
				}
				$this->vars['user_row'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM users WHERE user_id=:id', array('id' => $id)));
			} elseif ($act == 'delete') {
			    $this->mydb->execute('DELETE FROM users WHERE user_id=:id', array('id' => $id));
			    setMessage('تم حذف المستخدم بنجاح', 'success');
				redirect('control/user');
			} else {
			    $q = $this->mydb->execute('SELECT * FROM users');
				while ($row = $this->mydb->fetch_assoc($q)) {
				    $this->vars['users'][] = $row;
				}
			}
			return $this->vars;
		}
		
		public function perm($act='', $id=0) {
			if ($act == 'edit') {
				if (isset($_POST['perms'])) {
					//delete old permission rows
					$this->mydb->execute("DELETE FROM tree WHERE tree_type='userperm' AND tree_pid=:tree_pid", array('tree_pid'=>$id));
					// set the new permissions
					foreach ($_POST['perms'] as $key => $value) {
						Permissions::SetPerm($key, $id);
					}
					setMessage('تم تعديل صلاحيات المستخدم بنجاح', 'success');
					redirect('control/perm');
				}
				$user_row = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM users WHERE user_id=:id', array('id' => $id)));
				$this->vars['selected_user'] = $user_row;
				
				$q = $this->mydb->execute('SELECT * FROM applications WHERE app_pid=0 ORDER BY app_sort ASC');
				while ($row = $this->mydb->fetch_assoc($q)) {
					$q2 = $this->mydb->execute('SELECT * FROM applications WHERE app_pid=:app_id ORDER BY app_sort ASC', $row);
					$row['sub'] = array();
					while ($sub = $this->mydb->fetch_assoc($q2)) {
						$row['sub'][] = $sub;
					}
					$this->vars['all_apps'][] = $row;
				}
			
			} else {
				$q = $this->mydb->execute('SELECT * FROM users');
				while ($row = $this->mydb->fetch_assoc($q)) {
				    $this->vars['users'][] = $row;
				}
			}
			return $this->vars;
		}
		
		public function departments($act='', $id=0) {
			if ($act == 'add') {
				if (isset($_POST['department'])) {
					$department = $_POST['department'];
					echo $sql = $this->mydb->sql_insert('departments', $department);
					$this->mydb->execute($sql, $department);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('control/departments');

				}
			} elseif ($act == 'edit' and $id) {
				if (isset($_POST['department'])) {
					$department = $_POST['department'];
					echo $sql = $this->mydb->sql_update('departments', $department, array('d_id' => $id));
					$this->mydb->execute($sql, $department);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('control/departments');
				}
				$this->vars['department'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM departments WHERE d_id=:d_id', array('d_id' => $id)));
			} elseif ($act == 'delete' and $id) {
				$this->mydb->execute('DELETE FROM departments WHERE d_id=:d_id', array('d_id' => $id));
				setMessage('تم الحذف بنجاح', 'success');
				redirect('control/departments');
			} else {
				$q = $this->mydb->execute('SELECT departments.*, COUNT(user_id) AS count FROM departments LEFT JOIN users ON user_dept=d_id GROUP BY d_id');
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['departments'][] = $row;
				}
			}
		}
		
		private function validate_user($user_data, $act) {
		    $valid = true;
			if (!CheckInput($user_data['user_name'], 'fullname')) {
			    SetMessage('Please, enter a valid name', 'error');
			    $valid = false;
			}
			/*
			if (!CheckInput($user_data['user_mail'], 'email')) {
			    SetMessage('Please, enter a valid e-mail', 'error');
			    $valid = false;
			}
			*/
			if (!CheckInput($user_data['user_mobile'], 'mobile')) {
			    SetMessage('Please, enter a valid mobile number', 'error');
			    $valid = false;
			}
			if ($act == 'add') {
				if (!CheckInput($user_data['user_password'], 'password')) {
					SetMessage('Please, enter a valid password. It should be at least 8 characters', 'error');
					$valid = false;
				}
			} elseif (!empty($user_data['user_password']) and !CheckInput($user_data['user_password'], 'password')) {
				SetMessage('Please, enter a valid password. It should be at least 8 characters', 'error');
				$valid = false;
			} else {
				unset($user_data['user_password']);
			}

			if ($valid) {
			    return $user_data;
			} else {
			    return false;
			}
		}
	}
?>
