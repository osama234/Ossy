        <?php if (isset($department)){ ?>
            <br />
            <div class="panel panel-primary">
            <div class="panel-heading">تعديل إدارة</div>
			<form action="<?=base_url()?>control/departments/edit/<?=$department['d_id']?>" method="post" data-toggle="validator" role="form" class="form-horizontal">
				<br />
				<div class="form-group">
					<label for="user_name" class="control-label col-sm-2">الاسم</label>
					<div class="col-sm-9">
						<input type="text" name="department[d_name]" value="<?=$department['d_name']?>" id="d_name"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
    					<button type="submit" class="btn btn-primary">حفظ</button>
    				</div>
				</div>
            </form>
			</div>
        <?php } else {?>
            <div class="panel panel-primary">
            <div class="panel-heading">الإدارات</div>
            <table class="table">
                <tr>
                    <th>م</th>
                    <th>الاسم</th>
                    <th>عدد المستخدمين</th>
                    <th></th>
                </tr>
                <?php foreach ($departments as $row){ ?>
                <tr>
                    <td><?=$row['d_id']?></td>
                    <td><?=$row['d_name']?></td>
                    <td><?=$row['count']?></td>
                    <td>
                        <a href="<?=base_url()?>control/departments/edit/<?=$row['d_id']?>" class="btn btn-warning">تعديل</a>
                        <?php if ($row['count'] == 0){ ?><a href="<?=base_url()?>control/departments/delete/<?=$row['d_id']?>" class="btn btn-danger">حذف</a><?php } ?>
                    </td>
                </tr>
                <?php } ?>
            </table>
            </div>
            <div class="panel panel-primary">
            <div class="panel-heading">إضافة إدارة</div>
			<br />
			<form action="<?=base_url()?>control/departments/add" method="post" data-toggle="validator" role="form" class="form-horizontal">
				<div class="form-group">
					<label for="user_name" class="control-label col-sm-2">الاسم</label>
					<div class="col-sm-8">
						<input type="text" name="department[d_name]" id="user_name"  class="form-control" required="true" />
					</div>
					<div class="col-sm-1">
    					<button type="submit" class="btn btn-success">إضافة إدارة</button>
    				</div>
				</div>
			</form>
			</div>
        <?php } ?>
