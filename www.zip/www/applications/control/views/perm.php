        <?php if (isset($users)){ ?>
            <br />
            <div class="panel panel-primary">
            <div class="panel-heading">المستخدمين</div>
            <table class="table">
                <tr>
                    <th>م</th>
                    <th>الاسم</th>
                    <th>البريد الإلكتروني</th>
                    <th>الجوال</th>
                    <th></th>
                </tr>
                <?php foreach ($users as $row){ ?>
                <tr>
                    <td><?=$row['user_id']?></td>
                    <td><?=$row['user_name']?></td>
                    <td><?=$row['user_mail']?></td>
                    <td><?=$row['user_mobile']?></td>
                    <td>
                        <a href="<?=base_url()?>control/perm/edit/<?=$row['user_id']?>" class="btn btn-primary">الصلاحيات</a>
                    </td>
                </tr>
                <?php } ?>
            </table>
            </div>
        <?php } else {?>
        <div class="panel panel-primary">
			<div class="panel-heading">الصلاحيات</div>
				<h3><?=$selected_user['user_name']?></h3>
				<form action="<?=base_url()?>control/perm/edit/<?=$selected_user['user_id']?>" method="post">
				<?php foreach($all_apps as $app) { ?>
					<div class="app" style="padding-right: 20px; padding-left: 20px;">
						<?php if(Permissions::CheckUserPerms($selected_user['user_id'],$app['app_id'])==1) { ?>
							<input style="padding-right: 20px; padding-left: 20px;" type="checkbox" name="perms[<?=$app['app_id']?>]" class="app_checkbox" value="1" checked />
						<?php } elseif(Permissions::CheckUserPerms($selected_user['user_id'],$app['app_id'])>=2) {?>
							<input  style="padding-right: 20px; padding-left: 20px;" type="checkbox" name="perms[<?=$app['app_id']?>]" class="app_checkbox" value="1" checked disabled="disabled" />
						<?php } else { ?>
							<input  style="padding-right: 20px; padding-left: 20px;" type="checkbox" name="perms[<?=$app['app_id']?>]" class="app_checkbox" value="1" />
						<?php } ?>
						<a href="#" class="link"><?=$app['app_ar']?></a>
						<?php foreach($app['sub'] as $sub) { ?>
							<div style="padding-right: 20px; padding-left: 20px;">
								<?php if(Permissions::CheckUserPerms($selected_user['user_id'],$sub['app_id'])==1) { ?>
									<input type="checkbox" name="perms[<?=$sub['app_id']?>]" class="sub_checkbox" value="1" checked />
								<?php } elseif(Permissions::CheckUserPerms($selected_user['user_id'],$sub['app_id'])>=2) {?>
									<input type="checkbox" name="perms[<?=$sub['app_id']?>]" class="sub_checkbox" value="1" checked disabled="disabled" />
								<?php } else { ?>
									<input type="checkbox" name="perms[<?=$sub['app_id']?>]" class="sub_checkbox" value="1" />
								<?php } ?>
								<?=$sub['app_ar']?>
							</div>
						<?php } ?>
					</div>
				<?php } ?>
					<div class="form-group">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		<?php } ?>
		
<script type="text/javascript">
	$(function(){
		$(".app_checkbox").click(function(){
			$(".sub_checkbox", $(this).parent(".app")).prop('checked',$(this).prop('checked'));
		});
		$(".sub_checkbox").click(function(){
			app = $(this).parents(".app");
			$(".app_checkbox", app).prop('checked',($(".sub_checkbox:checked", app).length>0));
		});
	});
</script>
