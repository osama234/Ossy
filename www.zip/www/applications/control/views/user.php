        <?php if (isset($users)){ ?>
            <br />
            <div class="panel panel-primary">
            <div class="panel-heading">المستخدمين</div>
            <table class="table">
                <tr>
                    <th>م</th>
                    <th>الاسم</th>
                    <th>الإدارة</th>
                    <th>رقم الجوال</th>
                    <th></th>
                </tr>
                <?php foreach ($users as $row){ ?>
                <tr>
                    <td><?=$row['user_id']?></td>
                    <td><?=$row['user_name']?></td>
                    <td><?=GetDepartmentLabel($row['user_dept'])?></td>
                    <td><?=$row['user_mobile']?></td>
                    <td>
                        <a href="<?=base_url()?>control/user/edit/<?=$row['user_id']?>" class="btn btn-warning">تعديل</a>
                        <a href="<?=base_url()?>control/user/delete/<?=$row['user_id']?>" class="btn btn-danger">حذف</a>
                    </td>
                </tr>
                <?php } ?>
            </table>
            </div>
            <a href="<?=base_url()?>control/user/add" class="btn btn-success">إضافة مستخدم جديد</a>
        <?php } else {?>
            <div class="panel panel-primary">
			<?php if (isset($user_row['user_id'])){ ?>
            <div class="panel-heading">تعديل بيانات مستخدم</div>
			<form action="<?=base_url()?>control/user/edit/<?=$user_row['user_id']?>" method="post" data-toggle="validator" role="form" class="form-horizontal">
			<?php } else {?>
            <div class="panel-heading">إضافة مستخدم جديد</div>
			<form action="<?=base_url()?>control/user/add" method="post" data-toggle="validator" role="form" class="form-horizontal">
			<?php } ?>
				<br />
				<div class="form-group">
					<label for="user_name" class="control-label col-sm-2">الاسم</label>
					<div class="col-sm-9">
						<input type="text" name="user[user_name]" value="<?=$user_row['user_name']?>" id="user_name"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_idno" class="control-label col-sm-2">رقم الهوية</label>
					<div class="col-sm-9">
						<input type="text" name="user[user_idno]" value="<?=$user_row['user_idno']?>" id="user_idno"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_mobile" class="control-label col-sm-2">رقم الجوال</label>
					<div class="col-sm-9">
						<input type="text" name="user[user_mobile]" value="<?=$user_row['user_mobile']?>" id="user_mobile"  class="form-control" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_mail" class="control-label col-sm-2">البريد الالكتروني</label>
					<div class="col-sm-9">
						<input type="text" name="user[user_mail]" value="<?=$user_row['user_mail']?>" id="user_mail"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_password" class="control-label col-sm-2">كلمة المرور</label>
					<div class="col-sm-9">
						<input type="text" name="user[user_password]" id="user_password"  class="form-control" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_dept"  class="control-label col-sm-2">الإدارة</label>
					<div class="col-sm-9">
						<select name="user[user_dept]" class="form-control">
							<?=GetDepartmentOptions($user_row['user_dept'])?>
						</select>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
    					<button type="submit" class="btn btn-primary">حفظ</button>
    				</div>
				</div>
            </form>
			</div>
        <?php } ?>
