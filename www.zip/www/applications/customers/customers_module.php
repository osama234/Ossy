<?php

class customers_controller extends controller {

    function __construct() {
        parent::__construct();
    }

    function index($params = null) {
        return(true);
    }

    public function customer($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'add' and isset($_POST['customer'])) {
            $customer = $_POST['customer'];
            $sql = $this->mydb->sql_insert('customers', $customer);
            $this->mydb->execute($sql, $customer);
            $dtl['c_id'] = $this->mydb->insert_id();
            $dtl['c_userid'] = $this->user['user_id'];
            $dtl['dtl_islast'] = 1;
            $dtl['dtl_time'] = time();
            $dtl['c_notes'] = $customer['rej_desc'];
            $sql2 = $this->mydb->sql_insert('customers_dtl', $dtl);
            if ($this->mydb->execute($sql2, $dtl)) {
                SetMessage('تم حفظ البيانات بنجاح', 'success');
                redirect('customers/customer');
            } else {
                SetMessage('خطأ', 'error');
            }
        } elseif ($act == 'update' and $id) {
            if (isset($_POST['customer'])) {
                $customer = $_POST['customer'];
                $rc_rtl = array('c_id' => $id, 'c_notes' => $customer['req_desc'], 'c_userid' => $this->user['user_id'], 'dtl_time' => time(), 'dtl_islast' => 1);
                $this->update_dtl('customers_dtl', 'dtl_islast', array('c_id' => $id));
                $sql = $this->mydb->sql_update('customers', $customer, array('id' => $id));
                $sql2 = $this->mydb->sql_insert('customers_dtl', $rc_rtl);
                if ($this->mydb->execute($sql, $customer) and $this->mydb->execute($sql2, $rc_rtl)) {
                    SetMessage('تم حفظ التعديلات بنجاح', 'success');
                    redirect('customers/customer');
                }
            }
            $q = $this->mydb->execute('SELECT * FROM customers INNER JOIN customers_dtl ON (id=c_id) where dtl_islast =1 and id=:id', array('id' => $id));
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['customer'] = $row;
                $this->vars['lastProcess'] = $this->getLastProcess($this->vars['customer']['c_status']);
            }
        } else {
            $sql = 'SELECT * FROM customers INNER JOIN customers_dtl ON (id=c_id) where dtl_islast =1 and (c_status=0 or c_status=-1)';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['customer'][] = $row;
            }
        }
    }

    public function AuditCustomer($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'show' and $id != '') {
            if (isset($_POST['dtl'])) {
                $dtl = $_POST['dtl'];
                $dtl['c_userid'] = $this->user['user_id'];
                $dtl['c_id'] = $id;
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
                $this->update_dtl('customers_dtl', 'dtl_islast', array('c_id' => $id));
                $sql = $this->mydb->sql_insert('customers_dtl', $dtl);
                if ($this->mydb->execute($sql, $dtl)) {
                    SetMessage('تم حفظ الإجراء بنجاح', 'success');
                    redirect('customers/AuditCustomer');
                }
            }
            $q = $this->mydb->execute(' SELECT * FROM customers INNER JOIN customers_dtl ON (id=c_id) where id=:id and dtl_islast =1', array('id' => $id));
            $row = $this->mydb->fetch_assoc($q);
            $this->vars['customer'] = $row;
            $this->vars['lastProcess'] = $this->getLastProcess($this->vars['customer']['c_status']);
        } else {
            $sql = 'SELECT * FROM customers INNER JOIN customers_dtl ON (customers_dtl.c_id=customers.id) where dtl_islast =1 and (c_status=0 or c_status=-2) ';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['customer'][] = $row;
            }
        }
    }

    public function aproval($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'show' and $id != '') {
            if (isset($_POST['dtl'])) {
                $dtl = $_POST['dtl'];
                $dtl['c_userid'] = $this->user['user_id'];
                $dtl['c_id'] = $id;
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
                $this->update_dtl('customers_dtl', 'dtl_islast', array('c_id' => $id));
                $sql = $this->mydb->sql_insert('customers_dtl', $dtl);
                if ($this->mydb->execute($sql, $dtl)) {
                    SetMessage('تم حفظ الإجراء بنجاح', 'success');
                    redirect('customers/aproval');
                }
            }

            $q = $this->mydb->execute(' SELECT * FROM customers INNER JOIN customers_dtl ON (id=c_id) where id=:id and dtl_islast =1', array('id' => $id));
            $row = $this->mydb->fetch_assoc($q);
            $this->vars['customer'] = $row;
            $this->vars['lastProcess'] = $this->getLastProcess($this->vars['customer']['c_status']);
        } else {
            $sql = 'SELECT * FROM customers INNER JOIN customers_dtl ON (customers_dtl.c_id=customers.id) where dtl_islast =1 and c_status=1';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {

                $this->vars['customer'][] = $row;
            }
        }
    }

    public function UpdateCustomer($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'update' and $id) {
            if (isset($_POST['customer'])) {
                $customer = $_POST['customer'];
                $rc_rtl = array('c_id' => $id, 'c_status' => 0, 'c_notes' => $customer['rej_desc'], 'c_userid' => $this->user['user_id'], 'dtl_time' => time(), 'dtl_islast' => 1);
                $this->update_dtl('customers_dtl', 'dtl_islast', array('c_id' => $id));
                $sql = $this->mydb->sql_update('customers', $customer, array('id' => $id));
                $sql2 = $this->mydb->sql_insert('customers_dtl', $rc_rtl);
                if ($this->mydb->execute($sql, $customer) and $this->mydb->execute($sql2, $rc_rtl)) {
                    SetMessage('تم حفظ التعديلات بنجاح', 'success');
                    redirect('customers/UpdateCustomer');
                }
            }
            $q = $this->mydb->execute('SELECT * FROM customers INNER JOIN customers_dtl ON (id=c_id) where dtl_islast =1 and id=:id', array('id' => $id));
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['customer'] = $row;
                $this->vars['lastProcess'] = $this->getLastProcess($this->vars['customer']['c_status']);
            }
        } else {
            $sql = 'SELECT * FROM customers INNER JOIN customers_dtl ON (id=c_id) where dtl_islast =1 and c_status > 0';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {

                $this->vars['customer'][] = $row;
            }
        }
    }

    public function update_dtl($table = '', $field = '', $where) {
        $sql = $this->mydb->sql_update($table, array($field => 0), $where);
        if ($this->mydb->execute($sql))
            return true;
        else
            return false;
    }

    private function getLastProcess($status) {
        switch ($status) {
            case 0: return 'إجراء تسجيل وتحديث بيانات المستفيدين ';
            case 1: return 'تدقيق بيانات المستفيدين  ';
            case 2: return 'تحديث بيانات المستفيدين ';
            case 3: return 'اعتماد بيانات المستفيدين';
        }
    }
}
