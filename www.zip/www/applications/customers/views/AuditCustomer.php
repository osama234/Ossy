<?php if (isset($customer) and $act == 'show') { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">العملية السابقة</div>
        <table class="table">
            <tr>
                <th width="20%">اسم العملية</th>
                <td><?= $lastProcess ?></td>
            </tr>
            <tr>
                <th>العملية بواسطة</th>
                <td><?= GetUserById($customer['c_userid'], 'user_name') ?></td>
            </tr>
            <tr>
                <th>تاريخ العملية</th>
                <td><?= date('d/m/Y', $customer['dtl_time']) ?></td>
            </tr>
            <tr>
                <th>ملاحظات</th>
                <td><?= $customer['c_notes'] ?></td>
            </tr>
        </table>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">بيانات الطلب</div>
        <table class="table">
            <tr>
                <th width="20%">رقم المستفيد</th>
                <td><?= $customer['c_no'] ?></td>
            </tr>
            <tr>
                <th width="20%">اسم المستفيد</th>
                <td><?= $customer['c_name'] ?></td>
            </tr>
            <tr>
                <th width="20%">جهة المستفيد</th>
                <td><?= $customer['c_dep'] ?></td>
            </tr>
            <tr>
                <th width="20%">بيانات الاتصال</th>
                <td><?= $customer['c_contact'] ?></td>
            </tr>
            <tr>
                <th width="20%">عدد أفراد الأسرة</th>
                <td><?= $customer['c_family'] ?></td>
            </tr>

            <tr>
                <th width="20%">تاريخ طلب الصرف</th>
                <td><?= $customer['rej_date'] ?></td>
            </tr>
        </table>
    </div>
    <form action="<?= base_url() ?>customers/AuditCustomer/show/<?= $customer['c_id'] ?>" method="post" data-toggle="validator" role="form">
        <div class="panel panel-primary">
            <div class="panel-heading">الإجراء المتخذ</div>
            <table class="table">
                <tr>
                    <th width="20%">القرار</th>
                    <td>
                        <input type="radio" name="dtl[c_status]" id="c_status1" value="1" /><label for="dtl_status1">اعتماد</label>
                        <input type="radio" name="dtl[c_status]" id="c_status2" value="-1" /><label for="dtl_status2"> ملاحظات </label>
                    </td>
                </tr>
                <tr>
                    <th>ملاحظات</th>
                    <td><textarea name="dtl[c_notes]" rows="3" class="form-control" ></textarea></td>
                </tr>
                <tr>
                    <th></th>
                    <td>
                    	<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
	                    <a href="#" class="btn btn-warning print_btn">طباعة</a>
                    </td>
                </tr>
            </table>
        </div>
    </form>
<?php } else { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">المستفيدين الجدد</div>
        <table class="table">
            <tr>
                <th>رقم المستفيد</th>
                <th>اسم المستفيد</th>
                <th>جهة المستفيد</th>
                <th>عدد أفراد الأسرة</th>
                <th>حالة المستفيد</th>
                <th>إجراءات</th>
            </tr>
            <?php if(isset($customer)) foreach($customer as $row ) { ?>
            <tr <?= ($row['c_status'] < 0 ? ' class="danger"' : '') ?>>
                <td><?= $row['c_no'] ?></td>
                <td><?= $row['c_name'] ?></td>
                <td><?= $row['c_dep'] ?></td>
                <td><?= $row['c_family'] ?></td>
                <td><?= ($row['c_status'] < 0 ? 'يوجد ملاحظات' : 'جديد') ?></td>
                <td><a href="<?= base_url() ?>customers/AuditCustomer/show/<?= $row['id'] ?>" class="btn btn-primary">عرض</a></td>
            </tr>
            <?php } ?>
        </table>
    </div>
	<a href="#" class="btn btn-warning print_btn">طباعة</a><br/>
	<?=$paging?>
<?php } ?>

