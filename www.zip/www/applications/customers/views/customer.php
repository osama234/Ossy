<?php if ($act == 'add' or $act == 'update') { ?>
	<?php if ($act == 'update') { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">العملية السابقة</div>
        <table class="table">
            <tr>
                <th width="20%">اسم العملية</th>
                <td><?= $lastProcess ?></td>
            </tr>
            <tr>
                <th>العملية بواسطة</th>
                <td><?= GetUserById($customer['c_userid'], 'user_name') ?></td>
            </tr>
            <tr>
                <th>تاريخ العملية</th>
                <td><?= date('d/m/Y', $customer['dtl_time']) ?></td>
            </tr>
            <tr>
                <th>الملاحظات</th>
                <td><?= $customer['c_notes'] ?></td>
            </tr>
        </table>
    </div>
	<?php } ?>
    <div class="panel panel-primary">
        <?php if ($act == 'add') { ?>
            <div class="panel-heading">تسجيل بيانات المستفيد</div>
            <form action="<?= base_url() ?>customers/customer/add" method="post" data-toggle="validator" role="form" class="form-horizontal">
            <?php } else { ?>
                <div class="panel-heading">تحديث بيانات المستفيد</div>
                <form action="<?= base_url() ?>customers/customer/update/<?= $customer['id'] ?>" method="post" data-toggle="validator" role="form" class="form-horizontal">
                <?php } ?>
                <br />
                <div class="form-group">
                    <label for="c_no" class="control-label col-sm-2">رقم المستفيد :</label>
                    <div class="col-sm-9">
                        <input type="text" name="customer[c_no]"  id="c_no"  value="<?= $customer['c_no'] ?>" class="form-control"  required="true" />
                    </div>
                </div>
                <div class="form-group">
                    <label for="c_name" class="control-label col-sm-2">اسم المستفيد :</label>
                    <div class="col-sm-9">
                        <input type="text" name="customer[c_name]" id="c_name" value="<?= $customer['c_name'] ?>" class="form-control"  required="true" />
                    </div>
                </div>
                <div class="form-group ">

                    <label for="c_dep" class="control-label col-sm-2">جهة المستفيد : </label>
                    <div class="col-sm-9">
                        <input type="text" name="customer[c_dep]"  id="c_dep" value="<?= $customer['c_dep'] ?>"  class="form-control" required="true" />
                    </div>
                </div>
                <div class="form-group">
                    <label for="c_contact" class="control-label col-sm-2">بيانات اتصال</label>
                    <div class="col-sm-9">
                        <input type="text" name="customer[c_contact]"  id="c_contact" value="<?= $customer['c_contact'] ?> " class="form-control" />
                    </div>
                </div>
                <div class="form-group">
                    <label for="c_family" class="control-label col-sm-2">عدد أفراد الأسرة</label>
                    <div class="col-sm-9">
                        <input type="text" name="customer[c_family]"  id="c_family" value="<?= $customer['c_family'] ?> " class="form-control" />
                    </div>
                </div>
                <div class="form-group">
                    <label for="customer[rej_date]" class="control-label col-sm-2">تاريخ تسجيل المستفيد</label>
                    <div class="col-sm-9">
                        <input type="date" name="customer[rej_date]"  id="customer[rej_date]" value="<?= $customer['rej_date'] ?>" class="form-control datepicker" required="true" />
                    </div>
                </div>


                <div class="form-group">
                    <label for="customer[rej_desc]" class="control-label col-sm-2">ملاحظات</label>
                    <div class="col-sm-9">
                        <textarea  id="customer[rej_desc]" name="customer[rej_desc]" class="form-control"><?= $customer['rej_desc'] ?></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-9">
                        <input type="submit" value="حفظ وإعتماد" class="btn btn-primary btn-md ">
                        <a class="btn btn-warning print_btn" href="#">طباعة</a>
                    </div>
                </div>
            </form>
    </div>
<?php } else { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">المستفيدين الجدد</div>
        <table class="table">
            <tr>
                <th>رقم المستفيد</th>
                <th>اسم المستفيد</th>
                <th>جهة المستفيد</th>
                <th>عدد أفراد الأسرة</th>
                <th>حالة المستفيد</th>
                <th>إجراءات</th>
            </tr>
            <?php if (isset($customer)) foreach ($customer as $row) { ?>
                    <tr <?= ($row['c_status'] < 0 ? ' class="danger"' : '') ?>>
                        <td><?= $row['c_no'] ?></td>
                        <td><?= $row['c_name'] ?></td>
                        <td><?= $row['c_dep'] ?></td>
                        <td><?= $row['c_family'] ?></td>
                        <td><?= ($row['c_status'] < 0 ? 'يوجد ملاحظات' : 'جديد') ?></td>
                        <td><a href="<?= base_url() ?>customers/customer/update/<?= $row['id'] ?>" class="btn btn-warning">تعديل</a></td>
                    </tr>
                <?php } ?>
        </table>
    </div>
    <a href="<?= base_url() ?>customers/customer/add" class="btn btn-success">تسجيل مستفيد جديد</a>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>
    <?= $paging ?><br/>
    </div>
<?php } ?>
