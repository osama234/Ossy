<?php

	class goods_controller extends controller {
	    function __construct() {
	        parent::__construct();
	    }
	
	    function index($params = null) {
	        return(true);
	    }
	
	    public function request($act = '', $id = '') {
	    	if ($act == 'add') {
				if (isset($_POST['request'])) {
					$request = $_POST['request'];
					$sql = $this->mydb->sql_insert('goods', $request);
					$this->mydb->execute($sql, $request);
					$dtl['dtl_pid'] = $this->mydb->insert_id();
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$sql = $this->mydb->sql_insert('goods_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('goods/request');
				}
			} elseif ($act == 'edit') {
				if (isset($_POST['request'])) {
					$request = $_POST['request'];
					$this->mydb->execute($this->mydb->sql_update('goods', $request, array('r_id' => $id)), $request);
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$this->mydb->execute('UPDATE goods_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this->mydb->sql_insert('goods_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('goods/request');
				}
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status<=0 AND r_id=:id';
				$this->vars['request'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id)));
				$this->vars['lastProcess'] = $this->getLastProcess($this->vars['request']['dtl_status']);
			} else {
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status<=0' ;
				$this->vars['paging'] = PagingSQL($sql);
				$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['requests'][] = $row;
				}
			}
	    }
	    
	    public function counting($act='', $id=0) {
		    if ($act == 'edit' and $id) {
			    if (isset($_POST['request'])) {
			    	$request = $_POST['request'];
			    	$request['r_goods'] = serialize($_POST['data']);
					$this->mydb->execute($this->mydb->sql_update('goods', $request, array('r_id' => $id)), $request);
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_status'] = 1;
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$this->mydb->execute('UPDATE goods_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this->mydb->sql_insert('goods_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('goods/counting');
			    }
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=0 AND r_id=:id';
				$this->vars['request'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id)));			    
		    } else {
			    $sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=0' ;
				$this->vars['paging'] = PagingSQL($sql);
				$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['requests'][] = $row;
				}
		    }
	    }
	    
	    public function selecting($act='', $id=0) {
		    if ($act == 'edit' and $id) {
			    if (isset($_POST['request'])) {
			    	$request = $_POST['request'];
			    	$request['r_files'] = serialize(SaveUploadedFile('attach'));
			    	$this->mydb->execute($this->mydb->sql_update('goods', $request, array('r_id' => $id)), $request);
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_status'] = 2;
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$this->mydb->execute('UPDATE goods_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this->mydb->sql_insert('goods_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('goods/selecting');
			    }
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=1 AND r_id=:id';
				$this->vars['request'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id)));			    

		    } else {
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=1' ;
				$this->vars['paging'] = PagingSQL($sql);
				$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['requests'][] = $row;
				}
			}
	    }
	    
	    public function purshase($act='', $id=0) {
		    $status = 5;
		    if ($act == 'edit' and $id) {
			    if (isset($_POST['request'])) {
			    	$request = $_POST['request'];
			    	$request['r_bills'] = serialize(SaveUploadedFile('attach'));
			    	$this->mydb->execute($this->mydb->sql_update('goods', $request, array('r_id' => $id)), $request);
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_status'] = $status +1;
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$this->mydb->execute('UPDATE goods_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this->mydb->sql_insert('goods_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('goods/purshase');
			    }
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=:status AND r_id=:id';
				$this->vars['request'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id, 'status' => $status)));
				$this->vars['request']['r_goods'] = unserialize($this->vars['request']['r_goods']);
		    } else {
			    $sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=:status' ;
				$this->vars['paging'] = PagingSQL($sql, array('status' => $status));
				$q = $this->mydb->execute($sql, array('status' => $status));
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['requests'][] = $row;
				}
		    }
	    }
	    
	    public function distribute($act='', $id=0) {
		    $status = 8;
		    if ($act == 'edit' and $id) {
			    if (isset($_POST['request'])) {
			    	$request = $_POST['request'];
			    	$request['r_distributed'] = serialize($_POST['data']);
			    	$this->mydb->execute($this->mydb->sql_update('goods', $request, array('r_id' => $id)), $request);
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_status'] = $status +1;
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$this->mydb->execute('UPDATE goods_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this->mydb->sql_insert('goods_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('goods/distribute');
			    }
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=:status AND r_id=:id';
				$this->vars['request'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id, 'status' => $status)));
				$this->vars['request']['r_goods'] = unserialize($this->vars['request']['r_goods']);
		    } else {
			    $sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=:status' ;
				$this->vars['paging'] = PagingSQL($sql, array('status' => $status));
				$q = $this->mydb->execute($sql, array('status' => $status));
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['requests'][] = $row;
				}
		    }
	    }
	    
	    public function dist_report($act='', $id=0) {
		    $status = 9;
		    if ($act == 'edit' and $id) {
			    if (isset($_POST['request'])) {
			    	$request = $_POST['request'];
			    	$request['r_returns'] = serialize($_POST['data']);
			    	$this->mydb->execute($this->mydb->sql_update('goods', $request, array('r_id' => $id)), $request);
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_status'] = $status +1;
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$this->mydb->execute('UPDATE goods_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this->mydb->sql_insert('goods_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('goods/dist_report');
			    }
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=:status AND r_id=:id';
				$this->vars['request'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id, 'status' => $status)));
		    	$this->vars['request']['r_goods'] = unserialize($this->vars['request']['r_goods']);
		    } else {
			    $sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=:status' ;
				$this->vars['paging'] = PagingSQL($sql, array('status' => $status));
				$q = $this->mydb->execute($sql, array('status' => $status));
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['requests'][] = $row;
				}
		    }
	    }
	    
	    public function approval($act='', $id=0) {
	    	$this->status($act, $id, 2, 'approval');	    
	    }
	    public function receive($act='', $id=0) {
	    	$this->status($act, $id, 3, 'receive');	    
	    }
	    public function proceed($act='', $id=0) {
	    	$this->status($act, $id, 4, 'proceed');	    
	    }
	    public function receipt($act='', $id=0) {
	    	$this->status($act, $id, 6, 'receipt');	    
	    }
	    public function dist($act='', $id=0) {
	    	$this->status($act, $id, 7, 'dist');	    
	    }
	    public function report($act='', $id=0) {
	    	$this->status($act, $id, 10, 'report');	    
	    }
	    public function report2($act='', $id=0) {
	    	$this->status($act, $id, 11, 'report2');	    
	    }
	    public function report3($act='', $id=0) {
	    	$this->status($act, $id, 12, 'report3');	    
	    }
	    
	    public function archive($id=0) {
			if ($id) {
				$this->vars['request'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM goods WHERE r_id=:id', array('id' => $id)));
				$this->vars['request']['r_goods'] = unserialize($this->vars['request']['r_goods']);
				$this->vars['request']['r_files'] = unserialize($this->vars['request']['r_files']);
				$this->vars['request']['r_distributed'] = unserialize($this->vars['request']['r_distributed']);
				$this->vars['request']['r_returns'] = unserialize($this->vars['request']['r_returns']);
				$this->vars['request']['r_bills'] = unserialize($this->vars['request']['r_bills']);
				$this->vars['request']['r_report'] = unserialize($this->vars['request']['r_report']);
				
				$q = $this->mydb->execute('SELECT * FROM goods_dtl WHERE dtl_pid=:id ORDER BY dtl_time', array('id' => $id));
				while ($row = $this->mydb->fetch_assoc($q)) {
					$row['process'] = $this->getLastProcess($row['dtl_status']);
					$this->vars['details'][] = $row;
				}
			} else {
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) ORDER BY dtl_time';
				//PagingSQL(&$sql, $arr=array(), $limit=15)
				$this->vars['paging'] = PagingSQL($sql);
				
				$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['items'][] = $row;
				}
			}
		}
	    
	    private function status($act='', $id=0, $status, $redirect) {
		    if ($act == 'edit' and $id) {
		    	if (isset($_FILES['attach'])) {
		    		$request['r_id'] = $id;
			    	$request['r_report'] = serialize(SaveUploadedFile('attach'));
			    	$this->mydb->execute('UPDATE goods set r_report=:r_report WHERE r_id=:r_id', $request);
		    	}
			    if (isset($_POST['dtl'])) {
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_status'] = $_POST['dtl']['dtl_status'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$this->mydb->execute('UPDATE goods_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this->mydb->sql_insert('goods_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('goods/'.$redirect);
			    }
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=:status AND r_id=:id';
				$this->vars['request'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id, 'status' => $status)));
				
				$this->vars['request'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM goods WHERE r_id=:id', array('id' => $id)));
				$this->vars['request']['r_goods'] = unserialize($this->vars['request']['r_goods']);
				$this->vars['request']['r_files'] = unserialize($this->vars['request']['r_files']);
				$this->vars['request']['r_distributed'] = unserialize($this->vars['request']['r_distributed']);
				$this->vars['request']['r_returns'] = unserialize($this->vars['request']['r_returns']);
				$this->vars['request']['r_bills'] = unserialize($this->vars['request']['r_bills']);
				$this->vars['request']['r_report'] = unserialize($this->vars['request']['r_report']);
				
				
		    } else {
				$sql = 'SELECT * FROM goods INNER JOIN goods_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=:status' ;
				$this->vars['paging'] = PagingSQL($sql, array('status' => $status));
				$q = $this->mydb->execute($sql, array('status' => $status));
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['requests'][] = $row;
				}
			}
	    }
	    
	    private function getLastProcess($status) {
		    switch ($status) {
			    case 0: return 'طلب جديد';
			    case 1: return 'تحديد المستفيدين';
			    case 2: return 'ترشيح الأسر المستفيدة';
			    case 3: return 'اعتماد ترشيح الأسر والمواد';
			    case 4: return 'استلام كشوف الأسر والمواد';
			    case 5: return 'استلام كشوف تصنيف المواد';
		    }
		    return '';
	    }
	}
?>