<?php if ($request){ ?>
	<div class="panel panel-primary">
    	<div class="panel-heading">العملية السابقة</div>
		<table class="table">
			<tr>
				<th width="20%">اسم العملية</th>
				<td><?=$lastProcess?></td>
			</tr>
			<tr>
				<th>العملية بواسطة</th>
				<td><?=GetUserById($request['dtl_userid'], 'user_name')?></td>
			</tr>
			<tr>
				<th>تاريخ العملية</th>
				<td><?=date('d/m/Y', $request['dtl_time'])?></td>
			</tr>
			<tr>
				<th>ملاحظات</th>
				<td><?=$request['dtl_notes']?></td>
			</tr>
		</table>
	</div>
	<div class="panel panel-primary">
		<div class="panel-heading">صرف المشاريع العينية </div>
		<div class="panel-body">
			<br />
			<form action="<?=base_url()?>goods/counting/edit/<?=$request['r_id']?>" method="post" class="form-horizontal">
				
				<div class="form-group">
	            	<label for="h_no" class="control-label col-sm-2">اسم المشروع</label>
	                <div class="col-sm-9">
	                		<?=GetProjectsLabel((int)$request['r_project'])?>
	                </div>
				</div>
				
				<div class="form-group">
	            	<label class="control-label col-sm-2">تاريخ استحقاق الصرف</label>
	                <div class="col-sm-9">
	                	<?=$request['r_date']?>
	                </div>
				</div>
				
				<div class="form-group">
	            	<label for="r_families" class="control-label col-sm-2">عدد الأسر المستفيدة</label>
	                <div class="col-sm-9">
	                	<input required type="text" name="request[r_families]" id="r_families" value="<?=$request['r_families'] ?>" class="form-control" />
	                </div>
				</div>
				
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<table id="rows">
							<tr>
								<th>الصنف</th>
								<th>الكمية</th>
								<th>ملاحظات</th>
							</tr>
							<tr>
								<td><input type="text" required="true" class="form-control" name="data[type][]"></td>
								<td><input type="text" required="true" class="form-control" name="data[mount][]"></td>
								<td><input type="text" required="true" class="form-control" name="data[note][]"></td>
							</tr>
						</table>
						<button class="btn btn-success" type="button" id="add_row">إضافة</button>
					</div>
				</div>
				
				
				<div class="form-group">
	            	<label for="h_no" class="control-label col-sm-2">ملاحظات</label>
	                <div class="col-sm-9">
	                	<textarea name="dtl[d_notes]" id="" class="form-control"></textarea>
	                </div>
				</div>
				<div class="col-sm-offset-2">
					<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
				</div>
			</form>	
		</div>
	</div>
	
	<script type="text/javascript">
		$('#add_row').click(function(){
			$('#rows tbody').append('<tr><td><input type="text" name="data[type][]" id="p_beneficiaries" class="form-control" required="true" /></td>'+
							'<td><input type="text" name="data[mount][]" id="p_beneficiaries" class="form-control" required="true" /></td>'+
							'<td><input type="text" name="data[note][]" id="p_beneficiaries" class="form-control" /></td></tr>');
		});
	</script>
<?php } else {?>
	<div class="panel panel-primary">
		<div class="panel-heading">صرف المشاريع العينية</div>
		<table class="table">
			<tr>
                <th>م</th>
                <th>اسم المشروع</th>
                <th>تاريخ الصرف</th>
                <th></th>
            </tr>
            <?php if (isset($requests) and count($requests)){ ?>
            <?php $i=1; foreach ($requests as $row){ ?>
            <tr<?=($row['dtl_status'] < 0 ? ' class="danger"':'')?>>
                <td><?=$i++?></td>
                <td><?=GetProjectsLabel($row['r_project'])?></td>
                <td><?=$row['r_date']?></td>
                <td><a href="<?=base_url()?>goods/counting/edit/<?=$row['r_id']?>" class="btn btn-primary">عرض</a></td>
            </tr>
            <?php } ?>
            <?php } else { ?>
            <tr><td colspan="4">لا توجد بيانات حالياً</td></tr>
            <?php } ?>
        </table>
    </div>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>