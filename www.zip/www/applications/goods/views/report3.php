<?php if ($request){ ?>
	<div class="panel panel-primary">
    	<div class="panel-heading">العملية السابقة</div>
		<table class="table">
			<tr>
				<th width="20%">اسم العملية</th>
				<td><?=$lastProcess?></td>
			</tr>
			<tr>
				<th>العملية بواسطة</th>
				<td><?=GetUserById($request['dtl_userid'], 'user_name')?></td>
			</tr>
			<tr>
				<th>تاريخ العملية</th>
				<td><?=date('d/m/Y', $request['dtl_time'])?></td>
			</tr>
			<tr>
				<th>ملاحظات</th>
				<td><?=$request['dtl_notes']?></td>
			</tr>
		</table>
	</div>
	<div class="panel panel-primary">
		<div class="panel-heading">صرف المشاريع العينية </div>
		<div class="panel-body">
			<br />
			<form action="<?=base_url()?>goods/report3/edit/<?=$request['r_id']?>" method="post" class="form-horizontal" enctype="multipart/form-data">
				<div class="form-group">
	            	<label for="h_no" class="control-label col-sm-2">اسم المشروع</label>
	                <div class="col-sm-9">
	                		<?=GetProjectsLabel((int)$request['r_project'])?>
	                </div>
				</div>
				
				<div class="form-group">
	            	<label class="control-label col-sm-2">تاريخ استحقاق الصرف</label>
	                <div class="col-sm-9">
	                	<?=$request['r_date']?>
	                </div>
				</div>
				
				<div class="form-group">
	            	<label for="r_sel_families" class="control-label col-sm-2">المواد المراد صرفها</label>
	                <div class="col-sm-9">
	            <?php if (is_array($request['r_goods'])){ ?>
				<table class="table table-bordered">
					<tr class="active">
						<th>الصنف</th>
						<th>الكمية</th>
						<th>ملاحظات</th>
					</tr>
					<?php foreach ($request['r_goods']['type'] as $key=>$value){ ?>
					<tr>
						<td><?=$request['r_goods']['type'][$key]?></td>
						<td><?=$request['r_goods']['mount'][$key]?></td>
						<td><?=$request['r_goods']['note'][$key]?></td>
					</tr>
					<?php } ?>
				</table>
				<?php } ?>
	                </div>
				</div>
				
				<div class="form-group">
	            	<label for="r_sel_families" class="control-label col-sm-2">الأسر المرشحة</label>
	                <div class="col-sm-9"><?=nl2br($request['r_sel_families'])?></div>
				</div>
				
				
				<?php if (!empty($request['r_files'])){ ?>
				<div class="form-group">
	            	<label for="r_sel_families" class="control-label col-sm-2">الأسر المرشحة</label>
	            	<div class="col-sm-9">
	            	<?php foreach ($request['r_files'] as $file){ ?>
						<a href="<?=base_url($file['path'])?>"><?=$file['filename']?></a><br />
					<?php } ?>
					</div>
				</div>
				<?php } ?>
        	<?php if (!empty($request['r_purshase_date'])){ ?>
			<div class="form-group row">
            	<label for="r_purshase_date" class="control-label col-sm-2">تاريخ شراء المواد</label>
                <div class="col-sm-9">
                	<?=$request['r_purshase_date']?>
                </div>
			</div>
			<div class="form-group row">
            	<label for="r_vendor" class="control-label col-sm-2">المؤسسة التجارية</label>
                <div class="col-sm-9">
                	<?=$request['r_vendor']?>
                </div>
			</div>
			<?php } ?>
			<?php if (!empty($request['r_bills'])){ ?>
			<div class="form-group row">
            	<label for="r_sel_families" class="control-label col-sm-2">الفواتير</label>
            	<div class="col-sm-9">
            	<?php foreach ($request['r_bills'] as $file){ ?>
					<a href="<?=base_url($file['path'])?>"><?=$file['filename']?></a><br />
				<?php } ?>
				</div>
			</div>
			<?php } ?>
            
            <?php if (!empty($request['r_distributed'])){ ?>
            <div class="form-group row">
                <label for="r_sel_families" class="control-label col-sm-2">المواد المستلمة من المخزون</label>
                <div class="col-sm-9">
                    <?php if (is_array($request['r_distributed'])) { ?>
                        <table class="table table-bordered">
                            <tr class="active">
                                <th>الصنف</th>
                                <th>الكمية</th>
                                <th>ملاحظات</th>
                            </tr>
                            <?php foreach ($request['r_distributed']['type'] as $key => $value) { ?>
                                <tr>
                                    <td><?= $request['r_distributed']['type'][$key] ?></td>
                                    <td><?= $request['r_distributed']['mount'][$key] ?></td>
                                    <td><?= $request['r_distributed']['note'][$key] ?></td>
                                </tr>
                            <?php } ?>
                        </table>
                    <?php } ?>
                </div>
            </div>
            <?php } ?>
            <div class="form-group row">
				<label for="r_not_receipt" class="control-label col-sm-2">الأسر الغير متاحة</label>
				<div class="col-sm-9">
					<?=$request['r_not_receipt']?>
				</div>
			</div>
            <?php if (!empty($request['r_returns'])){ ?>
            <div class="form-group row">
                <label for="r_sel_families" class="control-label col-sm-2">الفائض</label>
                <div class="col-sm-9">
                    <?php if (is_array($request['r_returns'])) { ?>
                        <table class="table table-bordered">
                            <tr class="active">
                                <th>الصنف</th>
                                <th>الكمية</th>
                                <th>ملاحظات</th>
                            </tr>
                            <?php foreach ($request['r_returns']['type'] as $key => $value) { ?>
                                <tr>
                                    <td><?= $request['r_returns']['type'][$key] ?></td>
                                    <td><?= $request['r_returns']['mount'][$key] ?></td>
                                    <td><?= $request['r_returns']['note'][$key] ?></td>
                                </tr>
                            <?php } ?>
                        </table>
                    <?php } ?>
                </div>
            </div>
            <?php } ?>				
				<?php if (!empty($request['r_report'])){ ?>
				<div class="form-group">
	            	<label for="r_sel_families" class="control-label col-sm-2">تقرير عن المخزون</label>
	            	<div class="col-sm-9">
	            	<?php foreach ($request['r_report'] as $file){ ?>
						<a href="<?=base_url($file['path'])?>"><?=$file['filename']?></a><br />
					<?php } ?>
					</div>
				</div>
				<?php } ?>

				<div class="form-group">
	            	<label for="h_no" class="control-label col-sm-2">استلام تقرير عن المخزون</label>
	                <div class="col-sm-9">
						<input type="radio" name="dtl[dtl_status]" id="dtl_status1" value="13" required /> <label for="dtl_status1">اعتماد</label>
						<input type="radio" name="dtl[dtl_status]" id="dtl_status2" value="-11" required /> <label for="dtl_status2">ملاحظات</label>
	                </div>
				</div>
				
				<div class="form-group">
	            	<label for="h_no" class="control-label col-sm-2">ملاحظات</label>
	                <div class="col-sm-9">
	                	<textarea name="dtl[d_notes]" id="d_notes" class="form-control"></textarea>
	                </div>
				</div>
				<div class="col-sm-offset-2">
					<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
				</div>
			</form>	
		</div>
	</div>
	<script type="text/javascript">
		$('#add_btn').click(function(){
			$('#pictures').append('<input type="file" name="attach[]" />');
		});
	</script>
<?php } else { ?>
	<div class="panel panel-primary">
		<div class="panel-heading">صرف المشاريع العينية</div>
		<table class="table">
			<tr>
                <th>م</th>
                <th>اسم المشروع</th>
                <th>تاريخ الصرف</th>
                <th></th>
            </tr>
            <?php if (isset($requests) and count($requests)){ ?>
            <?php $i=1; foreach ($requests as $row){ ?>
            <tr<?=($row['dtl_status'] < 0 ? ' class="danger"':'')?>>
                <td><?=$i++?></td>
                <td><?=GetProjectsLabel($row['r_project'])?></td>
                <td><?=$row['r_date']?></td>
                <td><a href="<?=base_url()?>goods/report3/edit/<?=$row['r_id']?>" class="btn btn-primary">عرض</a></td>
            </tr>
            <?php } ?>
            <?php } else { ?>
            <tr><td colspan="4">لا توجد بيانات حالياً</td></tr>
            <?php } ?>
        </table>
    </div>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>