<?php if ($requests){ ?>
	<div class="panel panel-primary">
		<div class="panel-heading">صرف المشاريع العينية</div>
		<table class="table">
			<tr>
                <th>م</th>
                <th>اسم المشروع</th>
                <th>تاريخ الصرف</th>
                <th></th>
            </tr>
            <?php $i=1; foreach ($requests as $row){ ?>
            <tr<?=($row['dtl_status'] < 0 ? ' class="danger"':'')?>>
                <td><?=$i++?></td>
                <td><?=GetProjectsLabel($row['r_project'])?></td>
                <td><?=$row['r_date']?></td>
                <td><a href="<?=base_url()?>goods/request/edit/<?=$row['r_id']?>" class="btn btn-warning">تعديل</a></td>
            </tr>
            <?php } ?>
        </table>
    </div>
    <a href="<?=base_url()?>goods/request/add" class="btn btn-success">طلب صرف جديد</a>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } else { ?>
	<div class="panel panel-primary">
		<div class="panel-heading">صرف المشاريع العينية </div>
		<div class="panel-body">
			<br />
			<?php if ($request['r_id']){ ?>
			<form action="<?=base_url()?>goods/request/edit/<?=$request['r_id']?>" method="post" class="form-horizontal">
			<?php } else { ?>
			<form action="<?=base_url()?>goods/request/add" method="post" class="form-horizontal">
			<?php } ?>	
				<div class="form-group">
	            	<label for="h_no" class="control-label col-sm-2">اسم المشروع</label>
	                <div class="col-sm-9">
	                	<select  class="form-control" name="request[r_project]">
	                		<option></option>
	                		<?=GetProjects((int)$request['r_project'])?>
	                	</select>
	                </div>
				</div>
				
				<div class="form-group">
	            	<label for="h_no" class="control-label col-sm-2">تاريخ استحقاق الصرف</label>
	                <div class="col-sm-9">
	                	<input required type="text" name="request[r_date]" id="h_no" value="<?=$request['r_date'] ?>" class="form-control datepicker" />
	                </div>
				</div>
				
				<div class="form-group">
	            	<label for="h_no" class="control-label col-sm-2">ملاحظات</label>
	                <div class="col-sm-9">
	                	<textarea name="dtl[d_notes]" id="" class="form-control"><?=$request['dtl_notes']?></textarea>
	                </div>
				</div>
				<div class="col-sm-offset-2">
					<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
				</div>
			</form>	
		</div>
	</div>
<?php } ?>