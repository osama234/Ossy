<?php

class help_controller extends controller {

    function __construct() {
        parent::__construct();
    }

    function index($params = null) {
        redirect('help/new_request');
        return(true);
    }

    //step one
    function new_request($act = 'home', $id = 0) {
        if ($act == 'add') {
            if (isset($_POST['nr'])) {
                $help = $this->validateData($_POST['nr'], $act);
                $sql = $this->mydb->sql_insert('help_requests', $help);
                $this->mydb->execute($sql, $help);
                $dtl['dtl_pid'] = $this->mydb->insert_id();
                $dtl['dtl_userid'] = $this->user['user_id'];
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
                $dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
                $sql = $this->mydb->sql_insert('help_dtl', $dtl);
                $this->mydb->execute($sql, $dtl);
                setMessage('تم حفظ البيانات بنجاح', 'success');
                redirect('help/new_request');
            }
        } else if ($act == "edit") {
            if (isset($_POST['nr'])) {
                $help = $this->validateData($_POST['nr'], $act);
                $this->mydb->execute($this->mydb->sql_update('help_requests', $help, array('h_id' => $id)));
                $dtl['dtl_pid'] = $id;
                $dtl['dtl_userid'] = $this->user['user_id'];
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
                $dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
                $this->mydb->execute('UPDATE help_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
                $sql = $this->mydb->sql_insert('help_dtl', $dtl);
                $this->mydb->execute($sql, $dtl);
                setMessage('تم حفظ البيانات بنجاح', 'success');
                redirect('help/');
            }
            $sql = 'SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no INNER JOIN help_dtl ON (dtl_pid=h_id AND dtl_islast=1) WHERE dtl_status<=0 AND h_id=:id';
            $this->vars['help'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id)));
            $this->vars['lastProcess'] = $this->getLastProcess($this->vars['help']['dtl_status']);
        } else {
            $sql = ('SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no INNER JOIN help_dtl ON (dtl_pid=h_id AND dtl_islast=1) WHERE dtl_status<=0 or  dtl_status like "%-%" ');
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['items'][] = $row;
            }
        }
    }

    //step two
    function researcher($act = '', $id = 0) {
        $this->process($act, $id, 0, 'researcher');
    }

    //step three
    function approve_form($act = '', $id = 0) {
        $this->process($act, $id, 1, 'approve_form');
    }

    //step four
    function approve_withdraw($act = '', $id = 0) {
        $this->process($act, $id, 2, 'approve_withdraw');
    }

    public function archive($id = 0) {
        if ($id) {
            $sql = 'SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no WHERE h_id=:id';
            $this->vars['help'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id)));
            $q = $this->mydb->execute('SELECT * FROM help_dtl WHERE dtl_pid=:id ORDER BY dtl_time', array('id' => $id));
            while ($row = $this->mydb->fetch_assoc($q)) {
                $row['process'] = $this->getLastProcess($row['dtl_status']);
                $this->vars['details'][] = $row;
            }
        } else {
            $sql = ('SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no INNER JOIN help_dtl ON (dtl_pid=h_id AND dtl_islast=1) ORDER BY dtl_time');
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['helps'][] = $row;
            }
        }
    }

    private function process($act, $id, $status, $redirect) {
        if ($act == 'edit' and $id) {
            if (isset($_POST['help'])) {
	            $help = $this->validateData($_POST['help'], $act);
                $this->mydb->execute($this->mydb->sql_update('help_requests', $help, array('h_id' => $id)));
            }
            if (isset($_POST['dtl'])) {
                $dtl = $_POST['dtl'];
                $dtl['dtl_pid'] = $id;
                $dtl['dtl_userid'] = $this->user['user_id'];
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
                $this->mydb->execute('UPDATE help_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
                $sql = $this->mydb->sql_insert('help_dtl', $dtl);
                $this->mydb->execute($sql, $dtl);
                setMessage('تم حفظ البيانات بنجاح', 'success');
                redirect('help/' . $redirect);
            }
            $this->vars['help'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no INNER JOIN help_dtl ON (dtl_pid=h_id AND dtl_islast=1) WHERE dtl_status=:status AND h_id=:id', array('id' => $id, 'status' => $status)));
            $this->vars['lastProcess'] = $this->getLastProcess($this->vars['help']['dtl_status']);
        } else {
            $sql = ('SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no INNER JOIN help_dtl ON (dtl_pid=h_id AND dtl_islast=1) WHERE dtl_status=:status');
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql, array('status' => $status));
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['helps'][] = $row;
            }
        }
    }

    private function getLastProcess($status) {
        switch (abs($status)) {
            case 0: return 'تسجيل او تحديث طلب مساعدة';

            case 1: return 'اعتماد تسليم البيانات';

            case 2: return 'اعتماد النموذج';

            case 3: return 'اعتماد الصرف';
        }
    }

    private function validateData($data, $act = '') {
        return $data;
    }

}
?>
