<?php if (isset($help)){ ?>
		<div class="panel panel-primary">
        	<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم </th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($help['dtl_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=date('d/m/Y', $help['dtl_time'])?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المستفيد</th>
					<td><?=$help['h_name']?></td>
				</tr>
				<tr>
					<th width="20%">رقم الجوال</th>
					<td><?=$help['h_mobile']?></td>
				</tr>
				<tr>
					<th width="20%">نوع الطلب</th>
					<td><?=$help['h_type']?></td>
				</tr>
				<tr>
					<th>الملاحظات</th>
					<td><?=$help['dtl_notes']?></td>
				</tr>
			</table>
		</div>
		<form action="<?=base_url()?>help/approve_dataentriy/edit/<?=$help['h_id']?>" method="post" data-toggle="validator" role="form">
			<div class="panel panel-primary">
        		<div class="panel-heading">الإجراء المتخذ</div>
				<table class="table">
					<tr>
						<th>القرار</th>
						<td>
							<input type="radio" name="dtl[dtl_status]" id="dtl_status1" value="1" /><label for="dtl_status1">تدقيق</label>
							<input type="radio" name="dtl[dtl_status]" id="dtl_status2" value="-1" /><label for="dtl_status2">ملاحظات</label>
						</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[dtl_notes]" rows="3" ></textarea></td>
					</tr>
					<tr>
						<th></th>
						<td><button type="submit" class="btn btn-primary">حفظ واعتماد</button></td>
					</tr>
				</table>
			</div>
		</form>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading"> تسجيل طلب مساعدة </div>
             <table class="table">
            <tr>
                <th>نوع الطلب</th>
                <th>الاسم</th>
                <th>رقم الجوال</th>
               
            </tr>
            <?php foreach ($helps as $row) { ?>
                <tr>
                    <td><?= $row['h_type'] ?></td>
                     <td><?= $row['h_name'] ?></td>
                    <td><?= $row['h_mobile'] ?></td>
                    
                    <td><a href="<?= base_url() ?>help/approve_dataentriy/edit/<?= $row['h_id'] ?>" class="btn btn-warning">تعديل</a></td>
                </tr>
            <?php } ?>
        </table>
        </div>
        <?=$paging?><br/>
<a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
