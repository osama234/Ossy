<?php if (isset($help)) { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">العملية السابقة</div>
        <table class="table">
            <tr>
                <th width="20%">اسم </th>
                <td><?= $lastProcess ?></td>
            </tr>
            <tr>
                <th>العملية بواسطة</th>
                <td><?= GetUserById($help['dtl_userid'], 'user_name') ?></td>
            </tr>
            <tr>
                <th>تاريخ العملية</th>
                <td><?= date('d/m/Y', $help['dtl_time']) ?></td>
            </tr>
        </table>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">بيانات الطلب</div>
        <table class="table">
            <tr>
                <th width="20%">نوع  الطلب</th>
                <td><?= $help['h_type'] ?></td>
            </tr>
            <tr>
                <th>رقم المستفيد</th>
                <td>
                    <?= $help['h_no'] ?>
                    <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">عرض بيانات المستفيد</button>
                </td>
            </tr>
            <tr>
                <th>اسم المستفيد</th>
                <td><?= $help['b_name'] ?></td>
            </tr>
            <tr>
                <th>الملاحظات</th>
                <td><?= $help['dtl_notes'] ?></td>
            </tr>
        </table>
    </div>
    <form action="<?= base_url() ?>help/approve_withdraw/edit/<?= $help['h_id'] ?>" method="post" data-toggle="validator" role="form">
        <div class="panel panel-primary">
            <div class="panel-heading">الإجراء المتخذ</div>
            <table class="table">
                <tr>
                    <th width="20%">القرار</th>
                    <td>
                        <input type="radio" name="dtl[dtl_status]" id="dtl_status1" value="3" /><label for="dtl_status1">اعتماد</label>
                    </td>
                </tr>
				<tr>
					<th>الجهة الموجه لها البلاغ</th>
					<td>
						<select name="help[h_department]" id="h_department" class="form-control">
							<option></option>
							<?=GetDepartmentOptions()?>
						</select>
					</td>
				</tr>
                <tr>
                    <th></th>
                    <td><button type="submit" class="btn btn-primary">حفظ واعتماد</button></td>
                </tr>
            </table>
        </div>
    </form>

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">بيانات المستفيد</h4>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    <script>
        $("#myModal").on("show.bs.modal", function (e) {
            var link = $(e.relatedTarget);
            $(this).find(".modal-body").load('<?= base_url() ?>sheet.php?id=<?= $help['h_no'] ?>');
                });
    </script>
<?php } else { ?>
    <div class="panel panel-primary">
        <div class="panel-heading"> إعتماد الصرف</div>
        <table class="table">
            <tr>
                <th>نوع الطلب</th>
                <th>رقم المستفيد</th>
                <th>اسم المستفيد</th>
            </tr>
            <?php foreach ($helps as $row) { ?>
                <tr>
                    <td><?= $row['h_type'] ?></td>
                    <td><?= $row['b_file_no'] ?></td>
                    <td><?= $row['b_name'] ?></td>
                    <td><a href="<?= base_url() ?>help/approve_withdraw/edit/<?= $row['h_id'] ?>" class="btn btn-primary">عرض</a></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <?= $paging ?><br/>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
