<?php if (isset($items)) { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">تسجيل طلب مساعدة</div>
        <table class="table">
            <tr>
                <th>النوع </th>
                <th>رقم المستفيد</th>
                <th>اسم المستفيد</th>
            </tr>
            <?php foreach ($items as $row) { ?>
                <tr>
                    <td><?= $row['h_type'] ?></td>
                    <td><?= $row['h_no'] ?></td>
                    <td><?= $row['b_name'] ?></td>
                    <td><a href="<?= base_url() ?>help/new_request/edit/<?= $row['h_id'] ?>" class="btn btn-warning">تعديل</a></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <a href="<?= base_url() ?>help/new_request/add" class="btn btn-success">تسجيل طلب مساعدة جديد</a>
    <a href="#" class="btn btn-warning print_btn">طباعة</a><br/>
    <?= $paging ?>
<?php } else { ?>
    <?php if ($help['dtl_status'] != 0) { ?>
        <div class="panel panel-primary">
            <div class="panel-heading">العملية السابقة</div>
            <table class="table">
                <tr>
                    <th width="20%">اسم العملية</th>
                    <td><?= $lastProcess ?></td>
                </tr>
                <tr>
                    <th>العملية بواسطة</th>
                    <td><?= GetUserById($help['dtl_userid'], 'user_name') ?></td>
                </tr>
                <tr>
                    <th>تاريخ العملية</th>
                    <td><?= date('d/m/Y', $help['dtl_time']) ?></td>
                </tr>
            </table>
        </div>
    <?php } ?>
    <?php if (isset($help['h_id'])) { ?>
        <form action="/starter/help/new_request/edit/<?=$help['h_id']?>" method="post" data-toggle="validator" role="form" novalidate="true" class="form-horizontal">
        <?php } else { ?>
        <form action="/starter/help/new_request/add" method="post" data-toggle="validator" role="form" novalidate="true" class="form-horizontal">
        <?php } ?>
            <div class="panel panel-primary">
                <div class="panel-heading">تسجيل طلب مساعدة</div>
            	<br />
            	<div class="form-group">
                	<label for="h_no" class="control-label col-sm-2">رقم المستفيد</label>
                    <div class="col-sm-9">
                    	<input required type="text" name="nr[h_no]" id="h_no" value="<?= $help['h_no'] ?>" class="form-control">
                    </div>
				</div>
                <div class="form-group">
                	<label for="h_name" class="control-label col-sm-2">اسم المستفيد</label>
                    <div class="col-sm-9">
                    	<input required type="text" id="h_name" value="<?= $help['b_name'] ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="h_type" class="control-label col-sm-2">نوع المساعدة</label>
                    <div class="col-sm-9">
                    	<input required type="text" name="nr[h_type]" id="h_type" value="<?= $help['h_type'] ?>" class="form-control" required="true">
                    </div>
                </div>
                <div class="form-group">
                    <label for="h_date" class="control-label col-sm-2">تاريخ طلب المساعدة</label>
                    <div class="col-sm-9">
                    	<input required type="date" name="nr[h_date]" id="h_date" value="<?= $help['h_date'] ?>" class="form-control datepicker" required="true">
                    </div>
                </div>
                <div class="form-group">
                    <label for="d_notes" class="control-label col-sm-2">ملاحظات</label>
                    <div class="col-sm-9">
                    	<textarea name="dtl[d_notes]" id="d_notes" rows="3" class="form-control"><?= $help['dtl_notes'] ?></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-9">
                        <button type="submit" class="btn btn-primary disabled" style="pointer-events: all; cursor: pointer;">حفظ واعتماد</button>
                        <a class="btn btn-warning print_btn" href="#">طباعة</a>
                    </div>
                </div>
            </div>
        </form>
        <script type="text/javascript" src="<?=base_url()?>public/js/jquery.autocomplete.js"></script>
		<script type="text/javascript">
			$("#h_no").autocomplete('<?=base_url()?>info.php?a=user',{after:function(no,name){
				$('#h_no').val(no);
				$('#h_name').val(name);
				}
			});
		</script>
    <?php } ?>
