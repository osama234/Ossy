<?php
	class home_controller extends controller{
		function __construct() {
			parent::__construct();
		}
		
		function index($params=null) {
			if (!isset($_SESSION['current_user'])) {
				redirect('user/login');
			}
			redirect('home/desktop');
			return true;
		}
		
		function desktop() {
			$info = array(
						'moneydonation/receive' => 'SELECT COUNT(*) AS count FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status = 0',
						'moneydonation/audit' 	=> 'SELECT COUNT(*) AS count FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status = 1',
						'moneydonation/approve' => 'SELECT COUNT(*) AS count FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status = 2',
						'moneydonation/direct' 	=> 'SELECT COUNT(*) AS count FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status = 3',
						
			);
			foreach ($info as $app => $sql) {
				if (Permissions::CheckUserPerms($this->user['user_id'], Permissions::GetAppID($app))) {
					$row = $this->mydb->fetch_assoc($this->mydb->execute($sql));
					$var = str_replace('/', '_', $app);
					$this->vars[$var] = (int)$row['count'];
				}
			}
			return true;
		}
		
		function employee($part='', $act='', $id=0) {
			if ($act == 'edit' and $id) {
				if (isset($_POST['donate'])) {
					$this->mydb->execute('UPDATE money_donations SET d_status=:d_status WHERE d_id=:id', $_POST['donate'] + array('id' => $id), 1);
					die;
				}
				if (isset($_POST['help'])) {
					$this->mydb->execute('UPDATE help_requests SET h_status=:h_status WHERE h_id=:id', $_POST['help'] + array('id' => $id));
				}
				if ($part == 'donation') {
					$this->vars['donation'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM money_donations WHERE d_user=:user_id AND d_id=:id', $this->user + array('id' => $id)));
					$q = $this->mydb->execute('SELECT * FROM money_donations_dtl WHERE dtl_pid=:d_id ORDER BY dtl_time', $this->vars['donation']);
					while ($row = $this->mydb->fetch_assoc($q)) {
						$row['process'] = $this->getLastProcess($row['dtl_status']);
						$this->vars['details'][] = $row;
					}
				}
				if ($part == 'help') {
					$sql = 'SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no WHERE h_user=:user_id AND h_id=:id';
		            $this->vars['help'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, $this->user + array('id' => $id)));
		            $q = $this->mydb->execute('SELECT * FROM help_dtl WHERE dtl_pid=:id ORDER BY dtl_time', array('id' => $id));
		            while ($row = $this->mydb->fetch_assoc($q)) {
		                $row['process'] = $this->getLastProcess($row['dtl_status']);
		                $this->vars['details'][] = $row;
		            }
				}
			} else {
				$q = $this->mydb->execute('SELECT * FROM money_donations WHERE d_user=:user_id', $this->user);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['donations'][] = $row;
				}
				
				$q = $this->mydb->execute('SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no WHERE h_user=:user_id', $this->user);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['helps'][] = $row;
				}
			}
		}

		function department($part='', $act='', $id=0) {
			if ($act == 'edit' and $id) {
				if (isset($_POST['donate'])) {
					$this->mydb->execute('UPDATE money_donations SET d_user=:d_user WHERE d_id=:id', $_POST['donate'] + array('id' => $id));
				}
				if (isset($_POST['help'])) {
					$this->mydb->execute('UPDATE help_requests SET h_user=:h_user WHERE h_id=:id', $_POST['help'] + array('id' => $id));
				}
				if ($part == 'donation') {
					$this->vars['donation'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM money_donations WHERE d_department=:user_dept AND d_id=:id', $this->user + array('id' => $id)));
					$q = $this->mydb->execute('SELECT * FROM money_donations_dtl WHERE dtl_pid=:d_id ORDER BY dtl_time', $this->vars['donation']);
					while ($row = $this->mydb->fetch_assoc($q)) {
						$row['process'] = $this->getLastProcess($row['dtl_status']);
						$this->vars['details'][] = $row;
					}
				}
				if ($part == 'help') {
					$sql = 'SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no WHERE h_id=:id';
		            $this->vars['help'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id)));
		            $q = $this->mydb->execute('SELECT * FROM help_dtl WHERE dtl_pid=:id ORDER BY dtl_time', array('id' => $id));
		            while ($row = $this->mydb->fetch_assoc($q)) {
		                $row['process'] = $this->getLastProcess($row['dtl_status']);
		                $this->vars['details'][] = $row;
		            }
				}
			} else {
				$q = $this->mydb->execute('SELECT * FROM money_donations WHERE d_department=:user_dept', $this->user);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['donations'][] = $row;
				}
				
				$q = $this->mydb->execute('SELECT * FROM help_requests INNER JOIN mcw_committee.beneficiaries ON h_no=b_file_no WHERE h_department=:user_dept', $this->user);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['helps'][] = $row;
				}
			}
		}
		
		function profile() {
			if (isset($_POST['profile'])) {
				$profile = $this->validateUser($_POST['profile']);
				if ($profile) {
					$sql = $this->mydb->sql_update('users', $profile, array('user_id' => $profile['user_id']));
					$this->mydb->execute($sql, $profile);
					setMessage('تم تحديث البانات بنجاح.', 'success');
					redirect('user/profile');
				}
			}
		}
		
		private function getLastProcess($status) {
			switch (abs($status)) {
				case 0: return 'تسجيل تبرع جديد';
				case 1: return 'استلام التبرع';
				case 2: return 'تدقيق بيانات التبرع';
				case 3: return 'اعتماد التبرع';
				case 4: return 'التوجيه';
			}
		}
	}
?>
