<div class="panel panel-primary">
	<div class="panel-heading">نظرة عامة</div>
	<div class="panel-body">

	<?php if ($moneydonation_receive) {?>
	<div class="col-md-4">
		<div class="well" style="margin:10px">
			<h4 align="center">تبرعات مالية بانتظار الاستلام</h4>
			<h2 align="center"><?=$moneydonation_receive?></h2>
		</div>
	</div>
	<?php } ?>
	
	<?php if ($moneydonation_audit) {?>
	<div class="col-md-4">
		<div class="well" style="margin:10px">
			<h4 align="center">تبرعات مالية بانتظار التدقيق</h4>
			<h2 align="center"><?=$moneydonation_audit?></h2>
		</div>
	</div>
	<?php } ?>
	
	<?php if ($moneydonation_approve) {?>
	<div class="col-md-4">
		<div class="well" style="margin:10px">
			<h4 align="center">تبرعات مالية بانتظار الاعتماد</h4>
			<h2 align="center"><?=$moneydonation_approve?></h2>
		</div>
	</div>
	<?php } ?>
	
	<?php if ($moneydonation_direct) {?>
	<div class="col-md-4">
		<div class="well" style="margin:10px">
			<h4 align="center">تبرعات مالية بانتظار التوجيه</h4>
			<h2 align="center"><?=$moneydonation_direct?></h2>
		</div>
	</div>
	<?php } ?>
	</div>
</div>
