<?php if (isset($donation)) { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">حالة الإنجاز</div>
        <br />
        <form action="<?= base_url() ?>home/employee/donation/edit/<?= $donation['d_id'] ?>" method="post" data-toggle="validator" role="form" class="form-horizontal">
            <div class="form-group">
                <label for="d_status" class="control-label col-sm-2">حالة الإنجاز</label>
                <div class="col-sm-9">
                    <select name="donate[d_status]" id="d_status" class="form-control" required="true">
                        <?= GetOptions('task_status', $donation['d_status']) ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-9">
                    <button type="submit" class="btn btn-primary">تحديث</button>
                </div>
            </div>
        </form>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">بيانات التبرع</div>
        <table class="table">
            <tr>
                <th width="20%">اسم المتبرع</th>
                <td><?= $donation['d_name'] ?></td>
            </tr>
            <tr>
                <th>رقم الجوال</th>
                <td><?= $donation['d_mobile'] ?></td>
            </tr>
            <tr>
                <th>المبلغ رقماً</th>
                <td><?= $donation['d_mount_d'] ?></td>
            </tr>
            <tr>
                <th>المبلغ كتابة</th>
                <td><?= $donation['d_mount_t'] ?></td>
            </tr>
            <tr>
                <th>نوع التبرع</th>
                <td><?= GetOptionsLabel('donation_type', $donation['d_type']) ?></td>
            </tr>
            <tr>
                <th>البنك</th>
                <td><?= $donation['d_bank'] ?></td>
            </tr>
            <tr>
                <th>اسم المشروع</th>
                <td><?= GetProjectsLabel($donation['d_project']) ?></td>
            </tr>
            <tr>
                <th>الجهة الموجه لها البلاغ</th>
                <td><?= GetDepartmentLabel($donation['d_department']) ?></td>
            </tr>
        </table>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">سجل العمليات</div>
        <table class="table">
            <tr>
                <th>المستخدم</th>
                <th>العملية</th>
                <th>التاريخ</th>
                <th>الوقت</th>
                <th>ملاحظات</th>
            </tr>
            <?php foreach ($details as $row) { ?>
                <tr>
                    <td><?= GetUserById($row['dtl_userid'], 'user_name') ?></td>
                    <td><?= $row['process'] ?></td>
                    <td><?= date('d/m/Y', $row['dtl_time']) ?></td>
                    <td><?= date('h:i A', $row['dtl_time']) ?></td>
                    <td><?= $row['dtl_notes'] ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } elseif (isset($help)) { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">حالة الإنجاز</div>
        <div class="panel-body">
            <form action="<?= base_url() ?>home/employee/help/edit/<?= $help['h_id'] ?>" method="post" data-toggle="validator" role="form" class="form-horizontal">
                <div class="form-group">
                    <label for="h_status" class="control-label col-sm-2">حالة الإنجاز</label>
                    <div class="col-sm-9">
                        <select name="help[h_status]" id="h_status" class="form-control" required="true">
                            <?= GetOptions('task_status', $help['h_status']) ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-9">
                        <button type="submit" class="btn btn-primary">تحديث</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">بيانات الطلب</div>
        <table class="table">
            <tr>
                <th width="20%">رقم المستفيد</th>
                <td>
                    <?= $help['h_no'] ?>
                    <button type="button" class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#myModal">عرض بيانات المستفيد</button>
                </td>
            </tr>
            <tr>
                <th width="20%">اسم المستفيد</th>
                <td><?= $help['b_name'] ?></td>
            </tr>
            <tr>
                <th width="20%">نوع الطلب</th>
                <td><?= $help['h_type'] ?></td>
            </tr>
            <?php if ($help['h_department']) { ?>
                <tr>
                    <th width="20%">الجهة الموجه لها البلاغ</th>
                    <td><?= GetDepartmentLabel($help['h_department']) ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">سجل العمليات</div>
        <table class="table">
            <tr>
                <th>المستخدم</th>
                <th>العملية</th>
                <th>التاريخ</th>
                <th>الوقت</th>
                <th>ملاحظات</th>
            </tr>
            <?php foreach ($details as $row) { ?>
                <tr>
                    <td><?= GetUserById($row['dtl_userid'], 'user_name') ?></td>
                    <td><?= $row['process'] ?></td>
                    <td><?= ArDate('d/m/Y', $row['dtl_time']) ?></td>
                    <td><?= ArDate('h:i A', $row['dtl_time']) ?></td>
                    <td><?= $row['dtl_notes'] ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">بيانات المستفيد</h4>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    <script>
        $("#myModal").on("show.bs.modal", function (e) {
            var link = $(e.relatedTarget);
            $(this).find(".modal-body").load('<?= base_url() ?>sheet.php?id=<?= $help['h_no'] ?>');
                });
    </script>
<?php } else { ?>
    <?php if (isset($donations)) { ?>
        <div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية</div>
            <table class="table">
                <tr>
                    <th>نوع التبرع</th>
                    <th>المبلغ</th>
                    <th>المبلغ كتابة</th>
                    <th>نوع المشروع</th>
                    <th>حالة الإنجاز</th>
                    <th></th>
                </tr>
                <?php if (isset($donations) and count($donations)) { ?>
                    <?php foreach ($donations as $row) { ?>
                        <tr>
                            <td><?= GetOptionsLabel('donation_type', $row['d_type']) ?></td>
                            <td><?= $row['d_mount_d'] ?></td>
                            <td><?= $row['d_mount_t'] ?></td>
                            <td><?= GetProjectsLabel($row['d_project']) ?></td>
                            <td><?= GetOptionsLabel('task_status', $row['d_status']) ?></td>
                            <td>
                                <a href="<?= base_url() ?>home/employee/donation/edit/<?= $row['d_id'] ?>" class="btn btn-primary">عرض</a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } else { ?>
                    <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div>
        <?= $paging ?><br/>
    <?php } ?>

    <?php if (isset($helps)) { ?>
        <div class="panel panel-primary">
            <div class="panel-heading">طلبات المساعدة</div>
            <table class="table">
                <?php if (isset($helps) and count($helps)) { ?>
                    <tr>
                        <th>نوع الطلب</th>
                        <th>رقم المستفيد</th>
                        <th>اسم المستفيد</th>
                        <th>حالة الإنجاز</th>
                    </tr>
                    <?php foreach ($helps as $row) { ?>
                        <tr>
                            <td><?= $row['h_type'] ?></td>
                            <td><?= $row['h_no'] ?></td>
                            <td><?= $row['b_name'] ?></td>
                            <td><?= GetOptionsLabel('task_status', $row['h_status']) ?></td>
                            <td><a href="<?= base_url() ?>home/employee/help/edit/<?= $row['h_id'] ?>" class="btn btn-primary pull-right">عرض</a></td>
                        </tr>
                    <?php } ?>
                <?php } else { ?>
                    <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div>
    <?php } ?>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
