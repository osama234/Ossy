		<div class="panel panel-primary">
			<div class="panel-heading">الملف الشخصي</div>
			<br />
			<form action="<?=base_url()?>user/profile" method="post" data-toggle="validator" role="form" class="form-horizontal">
				<div class="form-group">
					<label for="user_name" class="control-label col-sm-2">الاسم</label>
					<div class="col-sm-9">
						<input type="text" name="user[user_name]" value="<?=$user['user_name']?>" id="user_name"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_idno" class="control-label col-sm-2">رقم الهوية</label>
					<div class="col-sm-9">
						<input type="text" name="user[user_idno]" value="<?=$user['user_idno']?>" id="user_idno"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_mobile" class="control-label col-sm-2">الجوال</label>
					<div class="col-sm-9">
						<input type="text" name="user[user_mobile]" value="<?=$user['user_mobile']?>" id="user_mobile"  class="form-control" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_mail" class="control-label col-sm-2">البريد الإلكتروني</label>
					<div class="col-sm-9">
						<input type="text" name="user[user_mail]" value="<?=$user['user_mail']?>" id="user_mail"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_password" class="control-label col-sm-2">كلمة المرور (للتغيير فقط)</label>
					<div class="col-sm-9">
						<input type="text" name="user[password1]" id="user_password"  class="form-control" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_password" class="control-label col-sm-2">تأكيد كلمة المرور</label>
					<div class="col-sm-9">
						<input type="text" name="user[password2]" id="user_password"  class="form-control" />
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ البيانات</button>
					</div>
				</div>
            </form>
		</div>