<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Bootstrap 101 Template</title>
		<link href="public/css/bootstrap.min.css" rel="stylesheet">
		<link href="public/css/bootstrap-theme.min.css" rel="stylesheet">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
			<form data-toggle="validator" role="form">
				<div class="form-group">
					<label for="inputName" class="control-label">Name</label>
					<input type="text" class="form-control" id="inputName" placeholder="Cina Saffary" required>
				</div>
				<div class="form-group">
					<label for="inputTwitter" class="control-label">Twitter</label>
					<div class="input-group">
						<span class="input-group-addon">@</span>
						<input type="text" pattern="^([_A-z0-9]){3,}$" maxlength="20" class="form-control" id="inputTwitter" placeholder="1000hz" required>
					</div>
					<span class="help-block with-errors">Up to 20 letters, numbers and underscores</span>
				</div>
				<div class="form-group">
					<label for="inputEmail" class="control-label">Email</label>
					<input type="email" class="form-control" id="inputEmail" placeholder="Email" data-error="Bruh, that email address is invalid" required>
					<div class="help-block with-errors"></div>
				</div>
				<div class="form-group">
					<label for="inputPassword" class="control-label">Password</label>
					<div class="form-group col-sm-6">
						<input type="password" data-minlength="6" class="form-control" id="inputPassword" placeholder="Password" required />
						<span class="help-block">Minimum of 6 characters</span>
					</div>
					<div class="form-group col-sm-6">
						<input type="password" class="form-control" id="inputPasswordConfirm" data-match="#inputPassword" data-match-error="Whoops, these don't match" placeholder="Confirm" required />
						<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group">
					<div class="radio">
						<label>
							<input type="radio" name="underwear" required />
							Boxers
						</label>
					</div>
					<div class="radio">
						<label>
						<input type="radio" name="underwear" required />
						Briefs
						</label>
					</div>
				</div>
				<div class="form-group">
					<div class="checkbox">
						<label>
						<input type="checkbox" id="terms" data-error="Before you wreck yourself" required>
						Check yourself
						</label>
						<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>
		</div>
		<script src="public/js/jquery.min.js"></script>
		<script src="public/js/bootstrap.min.js"></script>
		<script src="public/js/validator.js"></script>
	</body>
</html>
