				</div><!-- col-sm-9 col-md-10-->
			</div><!-- row -->
		</div><!-- container -->
		<script src="<?=base_url()?>public/js/bootstrap.min.js"></script>
		<script src="<?=base_url()?>public/js/validator.js"></script>
		<script type="text/javascript">
			if ($('.container').height() < $(window).height()) {
				$('.container').height($(window).height());
			}
			$('.datepicker').calendarsPicker({calendar: $.calendars.instance('ummalqura', 'ar'), onClose: function(){ $(this).parent().parent().removeClass('has-error'); }});
		    $(".active").parent().addClass("in");
		    $("#menu-toggle").click(function(e) {
		        e.preventDefault();
		        $("#wrapper").toggleClass("active");
		    });
		    $('.print_btn').click(function(){window.print();return(false);});
		</script>
	</body>
</html>
