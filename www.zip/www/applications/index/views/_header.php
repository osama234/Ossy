<!DOCTYPE html>
<html lang="en" dir="rtl">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>المستودع الخيري بالمجمعة</title>
		<link href="<?=base_url()?>public/css/bootstrap.min.css" rel="stylesheet">
		<link href="<?=base_url()?>public/css/bootstrap-theme.min.css" rel="stylesheet">
		<link href="<?=base_url()?>public/css/bootstrap-rtl.min.css" rel="stylesheet">
		<link href="<?=base_url()?>public/css/style.css" rel="stylesheet">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		<script src="<?=base_url()?>public/js/jquery.min.js"></script>
		<link rel="stylesheet" type="text/css" media="print" href="<?=base_url()?>public/css/print.css"/>
		
		<script type="text/javascript" src="<?=base_url()?>public/js/jquery.calendars.js"></script>
		<script type="text/javascript" src="<?=base_url()?>public/js/jquery.calendars.plus.js"></script>
		<script type="text/javascript" src="<?=base_url()?>public/js/jquery.calendars.ummalqura.js"></script>
		<script type="text/javascript" src="<?=base_url()?>public/js/jquery.calendars.ummalqura-ar.js"></script>
		<script type="text/javascript" src="<?=base_url()?>public/js/jquery.plugin.js"></script> 
		<script type="text/javascript" src="<?=base_url()?>public/js/jquery.calendars.picker.js"></script>
		<script type="text/javascript" src="<?=base_url()?>public/js/jquery.calendars.picker-ar.js"></script>
		<script type="text/javascript" src="<?=base_url()?>public/js/jquery.calendars.picker.ext.js"></script>
		<script type="text/javascript" src="<?=base_url()?>public/js/jquery.calendars.validation.js"></script>
		<link rel="stylesheet" href="<?=base_url()?>public/css/jquery.calendars.picker.css">

	</head>
	<body style="background-color: #444">
		<div class="container">
			<div class="row">
				<div class="col-sm-3 col-md-2 sidebar-nav" style="background-color: #fff">
					<img src="<?=base_url()?>public/logo.png" alt="" align="center" />
					<?php if (isset($apps)){ ?>
					<ul class="nav bs-docs-sidenav">
						<li><a data-target="#home" data-toggle="collapse" href="<?=base_url()?>user/logout">خروج</a></li>
						<li><a data-target="#home" data-toggle="collapse" href="<?=base_url()?>hr">نظام شؤون الموظفين</a></li>
					</ul>
					<ul class="nav bs-docs-sidenav">
					<?php foreach($apps as $app) { ?>
						<li><a href="javascript:void(0);"  data-toggle="collapse" data-target="#<?=$app['app_name']?>"><?=$app['app_ar']?></a>
							<ul class="nav collapse"  id="<?=$app['app_name']?>">
								<?php foreach($app['sub'] as $sub) { ?>
								<li<?=($sub['app_name']==$_params[0].'/'.$_params[1] ? ' class="active"':'')?>>
									<a href="<?=base_url()?><?=$sub['app_name']?>"><?=$sub['app_ar']?></a>
								</li>
								<? } ?>
							</ul>
						</li>
					<? } ?>
					</ul>
					<? } ?>
				</div>
				<div class="col-sm-9 col-md-10">
				<h1>المستودع الخيري بالمجمعة</h1>
				<?=ShowMessage()?>
		
