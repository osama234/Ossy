<?php
class moneydonation_controller extends controller {
	function __construct() {
		parent::__construct();
	}

	function index($params = null) {
		RedirectDefault();
		return (true);
	}

	function register($act = '', $id = 0) {
		if ($act == 'add') {
			if (isset($_POST['donate'])) {
				$donation = $this -> validateData($_POST['donate'], $act);
				$checkid = $_POST['check']['idcheck']!=''?' رقم الشيك : ' . $_POST['check']['idcheck'].' - ':' ';
				$checkdate = $_POST['check']['checkdate']!=''?' تاريخ الشيك : ' . $_POST['check']['checkdate'].' - ':' ';; 
				$donation['d_details'] = $donation['d_details'];
				if ($donation) {
					$sql = $this -> mydb -> sql_insert('money_donations', $donation);
					$this -> mydb -> execute($sql, $donation);
					$dtl['dtl_pid'] = $this -> mydb -> insert_id();
					$dtl['dtl_userid'] = $this -> user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$sql = $this -> mydb -> sql_insert('money_donations_dtl', $dtl);
					$this -> mydb -> execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('moneydonation/print2');
				}
			}
		} elseif ($act == 'edit') {
			if (isset($_POST['donate'])) {
				$donation = $this -> validateData($_POST['donate'], $act);
				if ($donation) {
					$this -> mydb -> execute($this -> mydb -> sql_update('money_donations', $donation, array('d_id' => $id)), $donation);
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this -> user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$this -> mydb -> execute('UPDATE money_donations_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this -> mydb -> sql_insert('money_donations_dtl', $dtl);
					$this -> mydb -> execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('moneydonation/register');
				}
			}
			$sql = 'SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status<=0 AND d_id=:id';
			$this -> vars['donation'] = $this -> mydb -> fetch_assoc($this -> mydb -> execute($sql, array('id' => $id)));
			$this -> vars['lastProcess'] = $this -> getLastProcess($this -> vars['donation']['dtl_status']);
		} else {
			$sql = 'SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status<=0';
			$this -> vars['paging'] = PagingSQL($sql);
			$q = $this -> mydb -> execute($sql);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['items'][] = $row;
			}
		}
	}
	
		function register2($act = '', $id = 0) {
		if ($act == 'add') {
			if (isset($_POST['donate'])) {
				$donation = $this -> validateData($_POST['donate'], $act);
				$checkid = $_POST['check']['idcheck']!=''?' رقم الشيك : ' . $_POST['check']['idcheck'].' - ':' ';
				$checkdate = $_POST['check']['checkdate']!=''?' تاريخ الشيك : ' . $_POST['check']['checkdate'].' - ':' ';; 
				$donation['d_details'] = $donation['d_details'];
				if ($donation) {
					$sql = $this -> mydb -> sql_insert('money_donations', $donation);
					$this -> mydb -> execute($sql, $donation);
					$dtl['dtl_pid'] = $this -> mydb -> insert_id();
					$dtl['dtl_userid'] = $this -> user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$sql = $this -> mydb -> sql_insert('money_donations_dtl', $dtl);
					$this -> mydb -> execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('moneydonation/print2');
				}
			}
		} elseif ($act == 'edit') {
			if (isset($_POST['donate'])) {
				$donation = $this -> validateData($_POST['donate'], $act);
				if ($donation) {
					$this -> mydb -> execute($this -> mydb -> sql_update('money_donations', $donation, array('d_id' => $id)), $donation);
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this -> user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
					$this -> mydb -> execute('UPDATE money_donations_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this -> mydb -> sql_insert('money_donations_dtl', $dtl);
					$this -> mydb -> execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('moneydonation/register');
				}
			}
			$sql = 'SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status<=0 AND d_id=:id';
			$this -> vars['donation'] = $this -> mydb -> fetch_assoc($this -> mydb -> execute($sql, array('id' => $id)));
			$this -> vars['lastProcess'] = $this -> getLastProcess($this -> vars['donation']['dtl_status']);
		} else {
			$sql = 'SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status<=0';
			$this -> vars['paging'] = PagingSQL($sql);
			$q = $this -> mydb -> execute($sql);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['items'][] = $row;
			}
		}
	}

	public function report($act = '', $id = 0) {
		if (isset($_POST['report'])) {
			$report = $_POST['report'];
			$report['start'] = ArMktime($report['start']);
			$report['end'] = ArMktime($report['end']) + 24 * 3600 - 1;
			// until the end of the day ;)
			$q = $this -> mydb -> execute('SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_status=3) WHERE d_project=:d_project AND dtl_time BETWEEN :start AND :end', $report);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['items'][] = $row;
			}
		}
	}
	
		public function report2($act = '', $id = 0) {
		if (isset($_POST['report'])) {
			$report = $_POST['report'];
			$report['start'] = ArMktime($report['start']);
			$report['end'] = ArMktime($report['end']) + 24 * 3600 - 1;
			// until the end of the day ;)
			$q = $this -> mydb -> execute('SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id) WHERE d_type=:d_type AND dtl_time BETWEEN :start AND :end', $report);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['items'][] = $row;
			}
		}
	}

	public function archive($id = 0) {
		if ($id) {
			$this -> vars['donation'] = $this -> mydb -> fetch_assoc($this -> mydb -> execute('SELECT * FROM money_donations WHERE d_id=:id', array('id' => $id)));
			$q = $this -> mydb -> execute('SELECT * FROM money_donations_dtl WHERE dtl_pid=:id ORDER BY dtl_time', array('id' => $id));
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$row['process'] = $this -> getLastProcess($row['dtl_status']);
				$this -> vars['details'][] = $row;
			}
		} else {//PagingSQL(&$sql, $arr=array(), $limit=15)
			$sql = 'SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) ORDER BY dtl_time';
			$this -> vars['paging'] = PagingSQL($sql);

			$q = $this -> mydb -> execute($sql);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['donations'][] = $row;
			}
		}
	}

	public function printing($id = 0) {
		if ($id) {
			$this -> vars['donation'] = $this -> mydb -> fetch_assoc($this -> mydb -> execute('SELECT * FROM money_donations WHERE d_id=:id', array('id' => $id)));
			$q = $this -> mydb -> execute('SELECT * FROM money_donations_dtl WHERE dtl_pid=:id ORDER BY dtl_time', array('id' => $id));
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$row['process'] = $this -> getLastProcess($row['dtl_status']);
				$this -> vars['details'][] = $row;
			}
		} else {//PagingSQL(&$sql, $arr=array(), $limit=15)
			$sql = 'SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) ORDER BY dtl_time';
			$this -> vars['paging'] = PagingSQL($sql);

			$q = $this -> mydb -> execute($sql);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['donations'][] = $row;
			}
		}
	}

	public function receive($act = '', $id = 0) {
		$this -> process($act, $id, 0, 'receive');
	}

	public function audit($act = '', $id = 0) {
		$this -> process($act, $id, 1, 'audit');
	}

	public function approve($act = '', $id = 0) {
		$this -> process($act, $id, 2, 'approve');
	}

	public function direct($act = '', $id = 0) {
		$this -> process($act, $id, 3, 'direct');
	}

	private function process($act, $id, $status, $redirect) {
		if ($act == 'edit' and $id) {
			if (isset($_POST['donate']) and !empty($_POST['donate']['d_department'])) {
				$_POST['donate']['d_id'] = $id;
				$this -> mydb -> execute('UPDATE money_donations SET d_department=:d_department WHERE d_id=:d_id', $_POST['donate']);
			}
			if (isset($_POST['dtl'])) {
				$dtl = $_POST['dtl'];
				$dtl['dtl_pid'] = $id;
				$dtl['dtl_userid'] = $this -> user['user_id'];
				$dtl['dtl_islast'] = 1;
				$dtl['dtl_time'] = time();
				$this -> mydb -> execute('UPDATE money_donations_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
				$sql = $this -> mydb -> sql_insert('money_donations_dtl', $dtl);
				$this -> mydb -> execute($sql, $dtl);
				setMessage('تم حفظ البيانات بنجاح', 'success');
				redirect('moneydonation/' . $redirect);
			}
			$this -> vars['donation'] = $this -> mydb -> fetch_assoc($this -> mydb -> execute('SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status=:status AND d_id=:id', array('id' => $id, 'status' => $status)));
			$this -> vars['lastProcess'] = $this -> getLastProcess($this -> vars['donation']['dtl_status']);
		} else {
			$sql = 'SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) WHERE dtl_status=:status';
			$this -> vars['paging'] = PagingSQL($sql,array(),30);
			$q = $this -> mydb -> execute($sql, array('status' => $status));
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['donations'][] = $row;
			}
		}
	}
	public function print2($id = 0) {
		if ($id) {
			$this -> vars['donation'] = $this -> mydb -> fetch_assoc($this -> mydb -> execute('SELECT * FROM money_donations WHERE d_id=:id', array('id' => $id)));
			$q = $this -> mydb -> execute('SELECT * FROM money_donations_dtl WHERE dtl_pid=:id ORDER BY dtl_time', array('id' => $id));
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$row['process'] = $this -> getLastProcess($row['dtl_status']);
				$this -> vars['details'][] = $row;
			}
		} else {//PagingSQL(&$sql, $arr=array(), $limit=15)
			$sql = 'SELECT * FROM money_donations LEFT JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_islast=1) ORDER BY dtl_time DESC';
			$this -> vars['paging'] = PagingSQL($sql);

			$q = $this -> mydb -> execute($sql);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['donations'][] = $row;
			}
		}
	}

	public function summary() {
		$q = $this -> mydb -> execute('SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id AND dtl_status=3)');
		while ($row = $this -> mydb -> fetch_assoc($q)) {
			if (date('d/m/Y') == date('d/m/Y', $row['dtl_time'])) {
				$this -> vars['donations'][$row['d_project']] += $row['d_mount_d'];
			}
		}
	}
	
		public function summary2() {
		$q = $this -> mydb -> execute('SELECT * FROM money_donations INNER JOIN money_donations_dtl ON (dtl_pid=d_id)');
		while ($row = $this -> mydb -> fetch_assoc($q)) {
			if (date('d/m/Y') == date('d/m/Y', $row['dtl_time'])) {
				$this -> vars['donations'][$row['d_type']] += $row['d_mount_d'];
			}
		}
	}

	private function getLastProcess($status) {
		switch (abs($status)) {
			case 0 :
				return 'تسجيل تبرع جديد';
			case 1 :
				return 'استلام التبرع';
			case 2 :
				return 'تدقيق بيانات التبرع';
			case 3 :
				return 'اعتماد التبرع';
			case 4 :
				return 'التوجيه';
		}
	}

	private function validateData($data, $act = '') {
		return $data;
	}

}
?>
