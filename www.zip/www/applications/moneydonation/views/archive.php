<?php if (isset($donation)){ ?>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات التبرع</div>
			<table class="table">
				<tr>
					<th width="20%">رقم السند</th>
					<td><?=$donation['d_id']?></td>
				</tr>
				<tr>
					<th width="20%">اسم المتبرع</th>
					<td><?=$donation['d_name']?></td>
				</tr>
				<tr>
					<th>رقم الجوال</th>
					<td><?=$donation['d_mobile']?></td>
				</tr>
				<tr>
					<th>المبلغ رقماً</th>
					<td><?=$donation['d_mount_d']?></td>
				</tr>
				<tr>
					<th>المبلغ كتابة</th>
					<td><?=$donation['d_mount_t']?></td>
				</tr>
				<tr>
					<th>طريقة الدفع</th>
					<td><?=GetOptionsLabel('donation_type', $donation['d_type'])?></td>
				</tr>
				<tr>
					<th>البنك</th>
					<td><?=$donation['d_bank']?></td>
				</tr>
				<tr>
					<th>اسم المشروع</th>
					<td><?=GetProjectsLabel($donation['d_project'])?></td>
				</tr>
				<tr>
				<th>ملاحظات</th>
					<td><?= nl2br( $donation['d_details'])?></td>
				</tr>
				<?php if ($donation['d_department']){ ?>
				<tr>
					<th>الجهة الموجه لها البلاغ</th>
					<td><?=GetDepartmentLabel($donation['d_department'])?></td>
				</tr>
				<?php } ?>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">سجل العمليات</div>
        	<table class="table">
        		<tr>
        			<th>المستخدم</th>
        			<th>العملية</th>
        			<th>التاريخ</th>
        			<th>الوقت</th>
        			<th>ملاحظات</th>
        		</tr>
        		<?php foreach ($details as $row){ ?>
        		<tr>
        			<td><?=GetUserById($row['dtl_userid'], 'user_name')?></td>
        			<td><?=$row['process']?></td>
        			<td><?=ArDate('d/m/Y', $row['dtl_time'])?></td>
        			<td><?=date('h:i A', $row['dtl_time'])?></td>
        			<td><?=$row['dtl_notes']?></td>
        		</tr>
        		<?php } ?>
        	</table>
		</div>
		<a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية</div>
            <table class="table">
                <tr>
                    <th>نوع التبرع</th>
                    <th>المبلغ</th>
                    <th>المبلغ كتابة</th>
                    <th>نوع المشروع</th>
                    <th></th>
                </tr>
                <?php if (isset($donations) and count($donations)){ ?>
                <?php foreach ($donations as $row){ ?>
                <tr>
                    <td><?=GetOptionsLabel('donation_type', $row['d_type'])?></td>
                    <td><?=$row['d_mount_d']?></td>
                    <td><?=$row['d_mount_t']?></td>
                    <td><?=GetProjectsLabel($row['d_project'])?></td>
                    <td>
                        <a href="<?=base_url()?>moneydonation/archive/<?=$row['d_id']?>" class="btn btn-primary">عرض</a>
                    </td>
                </tr>
                <?php } ?>
                <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div>
               <?=$paging?><br/>
        <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
