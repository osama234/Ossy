<?php if (isset($donation)){ ?>
		<div class="panel panel-primary">
        	<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($donation['dtl_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ArDate('d/m/Y', $donation['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$donation['dtl_notes']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات التبرع</div>
			<table class="table">
				<tr>
					<th width="20%">رقم السند</th>
					<td><?=$donation['d_id']?></td>
				</tr>
				<tr>
					<th width="20%">اسم المتبرع</th>
					<td><?=$donation['d_name']?></td>
				</tr>
				<tr>
					<th>رقم الجوال</th>
					<td><?=$donation['d_mobile']?></td>
				</tr>
				<tr>
					<th>المبلغ رقماً</th>
					<td><?=$donation['d_mount_d']?></td>
				</tr>
				<tr>
					<th>المبلغ كتابة</th>
					<td><?=$donation['d_mount_t']?></td>
				</tr>
				<tr>
					<th>طريقة الدفع</th>
					<td><?=GetOptionsLabel('donation_type', $donation['d_type'])?></td>
				</tr>
				<tr>
					<th>البنك</th>
					<td><?=$donation['d_bank']?></td>
				</tr>
				<tr>
					<th>اسم المشروع</th>
					<td><?=GetProjectsLabel($donation['d_project'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?= nl2br( $donation['d_details'])?></td>
				</tr>
			</table>
		</div>
		<form action="<?=base_url()?>moneydonation/direct/edit/<?=$donation['d_id']?>" method="post" data-toggle="validator" role="form" class="form-horizontal">
			<div class="panel panel-primary">
				<div class="panel-heading">الإجراء المتخذ</div>
				<br />
				<div class="form-group">
					<label for="dtl_notes" class="control-label col-sm-2">الجهة الموجه لها البلاغ</label>
					<div class="col-sm-9">
						<select name="donate[d_department]" id="d_department" class="form-control">
							<?=GetDepartmentOptions($donation['d_department'])?>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="dtl_status1" class="control-label col-sm-2">القرار</label>
					<div class="col-sm-9">
						<input type="radio" name="dtl[dtl_status]" id="dtl_status1" value="4" required /> <label for="dtl_status1">اعتماد</label>
						<input type="radio" name="dtl[dtl_status]" id="dtl_status2" value="-4" required /> <label for="dtl_status2">ملاحظات</label>
					</div>
				</div>
				<div class="form-group">
					<label for="dtl_notes" class="control-label col-sm-2">ملاحظات</label>
					<div class="col-sm-9">
						<textarea name="dtl[dtl_notes]" id="dtl_notes" rows="3" class="form-control"></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
						<a href="#" class="btn btn-warning print_btn">طباعة</a>
					</div>
				</div>
			</div>
		</form>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية المعتمدة</div>
            <table class="table">
                <tr>
                    <th>نوع التبرع</th>
                    <th>المبلغ</th>
                    <th>المبلغ كتابة</th>
                    <th>نوع المشروع</th>
                    <th></th>
                </tr>
                <?php if (isset($donations) and count($donations)){ ?>
                <?php foreach ($donations as $row){ ?>
                <tr>
                    <td><?=GetOptionsLabel('donation_type', $row['d_type'])?></td>
                    <td><?=$row['d_mount_d']?></td>
                    <td><?=$row['d_mount_t']?></td>
                    <td><?=GetProjectsLabel($row['d_project'])?></td>
                    <td>
                        <a href="<?=base_url()?>moneydonation/direct/edit/<?=$row['d_id']?>" class="btn btn-primary">عرض</a>
                    </td>
                </tr>
                <?php } ?>
                <?php } else { ?>
                <tr>
                	<td colspan="5">لا توجد عمليات حالياً</td>
                </tr>
                <?php } ?>
            </table>
        </div>
        <a href="#" class="btn btn-warning print_btn">طباعة</a>
        <?=$paging?><br/>
<?php } ?>
