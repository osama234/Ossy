
<?php if (isset($donation)) { ?>

    <style type="text/css">
        @media print {
            body * {
                visibility: hidden;
            }
            .report * {
                visibility: visible;
            }
            .report {
                position: relative;
                width:890px;
				height:890px:
				font-size:500px; 
            }
			
        }
    </style>
    <div class="report">
	<div class="head3">	<h3 style="position:relative;left:-600px;top:.35433070866px; font-size:25px;"'color:red;' class='reportnumber'>&nbsp;</h3>
		</div>
        <div style="position: relative;left:-600px;top:-70.89763779528px; font-size:20px;"><?= ArDate('Y/m/d', time()) ?>هـ</div>
		
		<div style="position: relative;left:-30px;top:13px; font-size:20px;"><?= $donation['d_name'] ?></div>
		<div style="position: relative;left:-600px;top:-15px; font-size:20px;"><?= $donation['d_mobile'] ?></div>
        <div style="position: relative;left:-50px;top:-20px;font-size:20px;"><?= $donation['d_mount_d'] ?>&nbsp; ( <?= $donation['d_mount_t'] ?> )</div>
		<div style="position: relative;left:-90px;top:-30px; font-size:20px;"><?= GetOptionsLabel('donation_type', $donation['d_type']) ?></div>
		<div style="position: relative;left:-500px;top:-59px; font-size:20px;"><?=$donation['d_bank'] ?>&nbsp;</div> 
		<div style="position: relative;left:-50px;top:-65px;font-size:20px;"><?= GetProjectsLabel($donation['d_project']) ?></div>
		<div style="position: relative;left:-50px;top:-55px;font-size:20px;"><?= $donation['d_details'] ?></div>
<br />


  


    </div>
    <a href="#" class="btn btn-success" onclick="window.print();
            return false;">طباعة</a> 
    <script>
        function pad(str, max) {
            str = str.toString();
            return str.length < max ? pad("0" + str, max) : str;
        }
        $('.reportnumber').html(pad(<?= $donation['d_id'] ?>
        , 5));
    </script>

<?php } else { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">التبرعات النقدية</div>
        <table class="table">
            <tr>
                <th>نوع التبرع</th>
                <th>المبلغ</th>
                <th>المبلغ كتابة</th>
				<th>رقم السند</th>
				<th>التاريخ</th>
                <th>نوع المشروع</th>
                <th></th>
            </tr>
            <?php if (isset($donations) and count($donations)) { ?>
        <?php foreach ($donations as $row) { ?>
                    <tr class="<?=ArDate('d/m/Y', $row['dtl_time'])==ArDate('d/m/Y',time())?'info':'success'?>">
                        <td><?= GetOptionsLabel('donation_type', $row['d_type']) ?></td>
                        <td><?= $row['d_mount_d'] ?></td>
                        <td><?= $row['d_mount_t'] ?></td>
						<td><?= $row['d_id']?> </td>
						<td><?=ArDate('d/m/Y', $row['dtl_time'])?></td>
                        <td><?= GetProjectsLabel($row['d_project']) ?></td>
                        <td>
                            <a href="<?= base_url() ?>moneydonation/print2/<?= $row['d_id'] ?>" class="btn btn-primary">عرض</a>
                        </td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
    <?php } ?>
        </table>
    </div>
    <?= $paging ?><br/>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>