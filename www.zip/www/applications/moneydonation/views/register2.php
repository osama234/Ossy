<?php if (isset($items)){ ?>

    <style type="text/css">
        @media print {
            body * {
                visibility: hidden;
            }
            .report * {
                visibility: visible;
            }
            .report {
                position: relative;
 
            }
			
        }
    </style>
    <div class="report">
	
		<div class="panel panel-primary">
			<div class="panel-heading">التبرعات النقدية المسجلة</div>
			<table class="table">
				<tr>
                    <th>نوع التبرع</th>
                    <th>المبلغ</th>
					<th>رقم السند</th>
					<th>التاريخ</th>
                    <th>نوع المشروع</th>
                    <th></th>
                </tr>
                <?php foreach ($items as $row){ ?>
                <tr<?=($row['dtl_status'] < 0 ? ' class="danger"':'')?>>
                    <td><?=GetOptionsLabel('donation_type', $row['d_type'])?></td>
                    <td><?=$row['d_mount_d']?></td>
					<td><?= $row['d_id']?> </td>
					<td><?=ArDate('d/m/Y', $row['dtl_time'])?></td>
                    <td><?=GetProjectsLabel($row['d_project'])?></td>
                    <td><a href="<?=base_url()?>moneydonation/register/edit/<?=$row['d_id']?>" class="btn btn-warning">تعديل</a></td>
                </tr>
                <?php } ?>
            </table>
			<br />
			<br />
			محرر سند القبض ...................................................تدقيق المحاسب ...............................................استلام أمين الصندوق <br />
			الاسم: .........................................................الاسم:.............................................................الاسم:<br />
			التوقيع:.......................................................التوقيع: ............................................................التوقيع:<br />
        </div>
		</div>
        <a href="<?=base_url()?>moneydonation/register/add" class="btn btn-success">تسجيل تبرع جديد</a>
        <a href="#" class="btn btn-warning print_btn">طباعة</a>
        <?=$paging ?><br/>
<?php } else {?>
		<?php if(isset($donation['d_id'])){ ?>
		<?php if ($donation['dtl_status'] != 0){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($donation['dtl_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ArDate('d/m/Y', $donation['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$donation['dtl_notes']?></td>
				</tr>
			</table>
		</div>
		<?php } ?>
		<form action="<?=base_url()?>moneydonation/register/edit/<?=$donation['d_id']?>" method="post" data-toggle="validator" role="form" class="form-horizontal">
			<div class="panel panel-primary">
				<div class="panel-heading">تعديل بيانات تبرع</div>
		<?php } else {?>
        <form action="<?=base_url()?>moneydonation/register/add" method="post" data-toggle="validator" role="form" class="form-horizontal">
			<div class="panel panel-primary">
				<div class="panel-heading">تسجيل تبرع جديد</div>
		<?php } ?>
				<br />
				<div class="form-group">
					<label for="user_name" class="control-label col-sm-2">اسم المتبرع</label>
					<div class="col-sm-9">
						<input type="text" name="donate[d_name]" value="<?=$donation['d_name']?>" id="d_name"  class="form-control"  required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="d_mobile" class="control-label col-sm-2">رقم الجوال</label>
					<div class="col-sm-9">
						<input type="text" name="donate[d_mobile]" value="<?=$donation['d_mobile']?>" id="d_mobile"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="d_mount_d" class="control-label col-sm-2">المبلغ رقماً</label>
					<div class="col-sm-9">
						<input type="text" name="donate[d_mount_d]" value="<?=$donation['d_mount_d']?>" id="d_mount_d"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="d_mount_t" class="control-label col-sm-2">المبلغ كتابة</label>
					<div class="col-sm-9">
						<input type="text" name="donate[d_mount_t]" value="<?=$donation['d_mount_t']?>" id="d_mount_t"  class="form-control"  />
					</div>
				</div>
				<div class="form-group">
					<label for="d_type" class="control-label col-sm-2">طريقة الدفع</label>
					<div class="col-sm-9">
						<select name="donate[d_type]" id="d_type" class="form-control">
						<?=GetOptions('donation_type', $donation['d_type'])?>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="d_bank" class="control-label col-sm-2">البنك</label>
					<div class="col-sm-9">
					<input type="text" name="donate[d_bank]" value="<?=$donation['d_bank']?>" id="d_bank" class="form-control">
					
					
											
					</div>
				</div>
				
				 
				<div class="form-group check">
					<label for="d_bank" class="control-label col-sm-2">رقم الشيك</label>
					<div class="col-sm-9">
						<input type="text" name="check[idcheck]" class="form-control" value="0" required="true"/>
					</div>
				</div>
				<div class="form-group check">
					<label for="d_bank" class="control-label col-sm-2">تاريخ الشيك</label>
					<div class="col-sm-9">
						<input type="text" name="check[checkdate]" class="form-control datepicker" value="//" required="true"/>
					</div>
				</div>
				
				<div class="form-group">
					<label for="d_project" class="control-label col-sm-2">اسم المشروع</label>
					<div class="col-sm-9">
						<select  class="form-control" name="donate[d_project]"><?=GetProjects((int ) $donation['d_project'])?></select>
					</div>
				</div>
				<div class="form-group">
					<label for="d_bank" class="control-label col-sm-2">ملاحظات</label>
					<div class="col-sm-9">
						<textarea name="donate[d_details]"  id="d_details"  class="form-control" ><?=$donation['d_details']?></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
						<a href="#" class="btn btn-warning print_btn">طباعة</a>
					</div>
				</div>
			</div>
		</form>
		
		<script type="text/javascript" language="javascript">
		$('.check').hide();
		$('#d_type').change(function(){	
				if($(this).val() == 2){
				$('.check').show();	$('.check input').prop('required',true);
				}
				else{
				$('.check').hide();	$('.check input').prop('required',false);
				}
				
		});
			$.ajax('<?=base_url()?>numbers.php?val=' + $('#d_mount_d').val()).done(function( html ) {
					$('#d_mount_t').val(html);
				});
				$('#d_mount_d').change(function(){
				$.ajax('<?=base_url()?>numbers.php?val=' + $('#d_mount_d').val()).done(function( html ) {
					$('#d_mount_t').val(html);
				});
			});
		</script>
<?php } ?>
