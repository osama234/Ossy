<form action="<?=base_url()?>moneydonation/report2" method="post" data-toggle="validator" role="form" class="form-horizontal">
	<div class="row">
		<label for="d_type" class="control-label col-sm-1">المشروع</label>
		<div class="col-sm-2">
			<select name="report[d_type]" id="d_type" class="form-control col-sm-2">
			<?=Getoptions('donation_type',@$_POST['report']['d_type'])?>
			</select>
		</div>
		<label for="" class="control-label col-sm-2">للفترة من</label>
		<div class="col-sm-2">
			<input type="text" class="form-control datepicker" id="start" value="<?=@$_POST['report']['start']?>" name="report[start]" required="true" />
		</div>
		<label for="" class="control-label col-sm-1">إلى</label>
		<div class="col-sm-2">
			<input type="text" class="form-control datepicker" id="end" value="<?=@$_POST['report']['end']?>" name="report[end]" required="true" />
		</div>
		<button type="submit" class="btn btn-primary">عرض</button>
	</div>
	<br />
</form>
<?php if (isset($_POST['report'])){ ?>
<div class="panel panel-primary">
	<div class="panel-heading">بيان ملخص العمليات اليومية لمشروع (<?=GetoptionsLabel('donation_type',@$_POST['report']['d_type'])?>)</div>
	<table class="table">
		<tr>
			<th>رقم السند</th>
			<th>الاسم</th>
			<th>رقم الهاتف</th>
			<th>المبلغ</th>
			<th>ملاحظات</th>
		</tr>
		<?php if (isset($items) and count($items)){ ?>
		<?php $sum = 0; foreach ($items as $row){?>
		<tr>
			<td><?=$row['d_id']?></td>
			<td><?=$row['d_name']?></td>
			<td><?=$row['d_mobile']?></td>
			<td><?=$row['d_mount_d']; $sum += $row['d_mount_d'] ?></td>
			<td><?=$row['dth_notes']?></td>
		</tr>
		<?php } ?>
		<tr>
			<th colspan="3">الإجمالي</th>
			<th colspan="2"><?=$sum?></th>
		</tr>
		<?php } else { ?>
		<tr><td colspan="5">لا توجد بيانات في هذه الفترة</td></tr>
		<?php } ?>
	</table>
</div>
<a href="#" class="btn btn-warning print_btn">طباعة</a>
<br />
<?php } ?>
