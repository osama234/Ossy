<div class="panel panel-primary">
    <div class="panel-heading">ملخص تبرعات اليوم</div>
    <table class="table">
	<tr>
		<th>اسم المشروع</th>
		<th>إجمالي التبرعات رقماً</th>
		<th>إجمالي التبرعات كتابة</th>
	</tr>
	<?php $sum = 0; foreach ($donations as $key => $val){ ?>
	<tr>
		<td><?=GetoptionsLabel('donation_type', $key)?></td>
		<td><?=$val; $sum += $val?></td>
		<td><?=number2string($val)?></td>
	</tr>
	<?php } ?>
	<tr>
		<th>الإجمالي</th>
		<td><?=$sum?></td>
		<td><?=number2string($sum)?></td>
	</tr>
</table>
<a href="#" class="btn btn-warning print_btn">طباعة</a>
</div>