<?php
	class mosquesmaintenance_controller extends controller
	{
		function __construct() {
            parent::__construct();
        }
        
        function index($params=null) {
			return(true);
		}
		
		function register($act='', $id=0) {
			if ($act == 'add') {
				if (isset($_POST['restoration'])) {
					$restoration = $this->validateData($_POST['restoration'], $act);
					$restoration['r_pictures'] = serialize(SaveUploadedFile('pictures'));
					if ($restoration) {
						$sql = $this->mydb->sql_insert('mosquesmaintenance', $restoration);
						$this->mydb->execute($sql, $donation);
						$dtl['dtl_pid'] = $this->mydb->insert_id();
						$dtl['dtl_userid'] = $this->user['user_id'];
						$dtl['dtl_islast'] = 1;
						$dtl['dtl_time'] = time();
						$dtl['dtl_notes'] = @$_POST['dtl']['d_notes'];
						$sql = $this->mydb->sql_insert('mosquesmaintenance_dtl', $dtl);
						$this->mydb->execute($sql, $dtl);
						setMessage('تم حفظ البيانات بنجاح', 'success');
						redirect('mosquesmaintenance/register');
					}
				}
			} elseif ($act == 'edit') {
				if (isset($_POST['restoration'])) {
					$restoration = $this->validateData($_POST['restoration'], $act);
					if ($restoration) {
						$this->mydb->execute($this->mydb->sql_update('mosquesmaintenance', $restoration, array('r_id' => $id)), $restoration);
						$dtl['dtl_pid'] = $id;
						$dtl['dtl_userid'] = $this->user['user_id'];
						$dtl['dtl_islast'] = 1;
						$dtl['dtl_time'] = time();
						$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
						$this->mydb->execute('UPDATE mosquesmaintenance_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
						$sql = $this->mydb->sql_insert('mosquesmaintenance_dtl', $dtl);
						$this->mydb->execute($sql, $dtl);
						setMessage('تم حفظ البيانات بنجاح', 'success');
						redirect('mosquesmaintenance/register');
					}
				}
				$sql = 'SELECT * FROM mosquesmaintenance INNER JOIN mosquesmaintenance_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status<=0 AND r_id=:id';
				$restoration = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id)));
				if (!empty($restoration['r_data2'])) {
					$restoration['r_data2'] = unserialize($restoration['r_data2']);
				}
				$restoration['r_data'] = unserialize($restoration['r_data']);
				$restoration['r_pictures'] = unserialize($restoration['r_pictures']);
				$this->vars['restoration'] = $restoration;
				$this->vars['lastProcess'] = $this->getLastProcess($this->vars['restoration']['dtl_status']);
			} else {
				$sql = ('SELECT * FROM mosquesmaintenance INNER JOIN mosquesmaintenance_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status<=0 AND dtl_status > -4');
				$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['items'][] = $row;
				}
			}
		}
		
		public function archive($id=0) {
			if ($id) {
				$restoration = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM mosquesmaintenance WHERE r_id=:id', array('id' => $id)));
				if (!empty($restoration['r_data2'])) {
					$restoration['r_data2'] = unserialize($restoration['r_data2']);
				}
				$restoration['r_data'] = unserialize($restoration['r_data']);
				$restoration['r_pictures'] = unserialize($restoration['r_pictures']);
				$restoration['r_pictures2'] = unserialize($restoration['r_pictures2']);
				$restoration['r_bills'] = unserialize($restoration['r_bills']);
				$this->vars['restoration'] = $restoration;
				$q = $this->mydb->execute('SELECT * FROM mosquesmaintenance_dtl WHERE dtl_pid=:id ORDER BY dtl_time', array('id' => $id));
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['details'][] = $row;
				}
			} else {
				$sql = ('SELECT * FROM mosquesmaintenance INNER JOIN mosquesmaintenance_dtl ON (dtl_pid=r_id AND dtl_islast=1) ORDER BY dtl_time');
				$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['restorations'][] = $row;
				}
			}
		}
		
		public function preview($act='', $id=0) {
			$this->process($act, $id, 0, 'preview');
		}
		
		public function approve($act='', $id=0) {
			$this->process($act, $id, 1, 'approve');
		}
		
		public function postview($act='', $id=0) {
			$this->process($act, $id, 2, 'postview');
		}
		
		public function report($act='', $id=0) {
			$this->process($act, $id, 3, 'report');
		}
		
		public function bill($act='', $id=0) {
			$this->process($act, $id, 4, 'bill');
		}
		
		private function process($act, $id, $status, $redirect) {
			if ($act == 'edit' and $id) {
				if (isset($_POST['restoration'])) {
					$restoration = $this->validateData($_POST['restoration'], $act);
					$restoration['r_pictures2'] = serialize(SaveUploadedFile('pictures2'));
					$restoration['r_bills'] = serialize(SaveUploadedFile('bills'));
					if ($restoration) {
						$sql = $this->mydb->sql_update('mosquesmaintenance', $restoration, array('r_id' => $id));
						$this->mydb->execute($sql, $donation);
					}
				}
				if (isset($_POST['dtl'])) {
					$dtl = $_POST['dtl'];
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$this->mydb->execute('UPDATE mosquesmaintenance_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this->mydb->sql_insert('mosquesmaintenance_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('mosquesmaintenance/'.$redirect);
				}
				$sql = 'SELECT * FROM mosquesmaintenance INNER JOIN mosquesmaintenance_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE r_id=:id';
				$restoration = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id, 'status' => $status)));
				if (!empty($restoration['r_data2'])) {
					$restoration['r_data2'] = unserialize($restoration['r_data2']);
				}
				$restoration['r_data'] = unserialize($restoration['r_data']);
				$restoration['r_pictures'] = unserialize($restoration['r_pictures']);
				$restoration['r_pictures2'] = unserialize($restoration['r_pictures2']);
				$restoration['r_bills'] = unserialize($restoration['r_bills']);
				$this->vars['restoration'] = $restoration;
				$this->vars['lastProcess'] = $this->getLastProcess($this->vars['donation']['dtl_status']);
			} else {
				$sql = 'SELECT * FROM mosquesmaintenance INNER JOIN mosquesmaintenance_dtl ON (dtl_pid=r_id AND dtl_islast=1) WHERE dtl_status=:status';
				if ($status == 2) {
					$sql .= ' OR dtl_status IN (-4, -5)';
				}
				$this->vars['paging'] = PagingSQL($sql); 
				$q = $this->mydb->execute($sql, array('status' => $status));
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['restorations'][] = $row;
				}
			}
		}
		
		private function getLastProcess($status) {
			switch (abs($status)) {
				case 0: return 'إعداد معاينة قبل الصيانة أو الترميم';
				case 1: return 'اعتماد بيانات المعاينة';
				case 2: return 'اعتماد أمر العمل';
				case 3: return 'إعداد معاينة بعد الصيانة أو الترميم';
				case 4: return 'اعتماد تقرير العمل';
				case 5: return 'اعتماد الفواتير';
			}
		}
		
		private function validateData($data, $act='') {
			if (isset($_POST['data'])) {
				$data['r_data'] = serialize($_POST['data']);
			}
			if (isset($_POST['data2'])) {
				$data['r_data2'] = serialize($_POST['data2']);
			}
			return $data;
		}
		
	}
?>
