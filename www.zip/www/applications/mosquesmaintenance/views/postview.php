<?php if (isset($restoration)){ ?>
		<div class="panel panel-primary">
        	<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($restoration['dtl_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ArDate('d/m/Y', $restoration['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$restoration['dtl_notes']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">طلبات ترميم وصيانة المساجد</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المستفيد</th>
					<td><?=$restoration['r_name']?></td>
				</tr>
				<tr>
					<th>رقم المستفيد</th>
					<td><?=$restoration['r_no']?></td>
				</tr>
				<tr>
					<th>المدينة</th>
					<td><?=$restoration['r_city']?></td>
				</tr>
				<tr>
					<th>الحي</th>
					<td><?=$restoration['r_dist']?></td>
				</tr>
			</table>
			<br />
			<table class="table table-bordered">
				<tr class="active">
					<th>بحاجة لصيانة</th>
					<th>عدد</th>
					<th>القيمة</th>
					<th>ملاحظات</th>
				</tr>
				<?php foreach ($restoration['r_data']['need'] as $key=>$value){ ?>
				<tr>
					<td><?=$restoration['r_data']['need'][$key]?></td>
					<td><?=$restoration['r_data']['count'][$key]?></td>
					<td><?=$restoration['r_data']['cost'][$key]?></td>
					<td><?=$restoration['r_data']['notes'][$key]?></td>
				</tr>
				<?php } ?>
			</table>
			<br />
			<table class="table">
				<?php if (!empty($restoration['r_pictures'])){ ?>
				<tr>
					<th>صور المعاينة قبل الصيانة</th>
					<td>
						<?php foreach ($restoration['r_pictures'] as $pic){ ?>
							<a href="<?=base_url($pic['path'])?>"><?=$pic['filename']?></a><br />
						<?php } ?>
					</td>
				</tr>
				<?php } ?>
				<tr>
					<th>تاريخ تسجيل المعاينة</th>
					<td><?=$restoration['r_date']?></td>
				</tr>
				<tr>
					<th>تمت المعاينة من قبل</th>
					<td><?=$restoration['r_visor']?></td>
				</tr>
			</table>
		</div>
		<form action="<?=base_url()?>mosquesmaintenance/postview/edit/<?=$restoration['r_id']?>" method="post" data-toggle="validator" role="form" class="form-horizontal" enctype="multipart/form-data">
			<div class="panel panel-primary">
        		<div class="panel-heading">الإجراء المتخذ</div>
				<br />
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<table id="rows">
							<tr>
								<th>تم صيانة</th>
								<th>عدد</th>
								<th>القيمة التقديرية</th>
								<th>ملاحظات</th>
							</tr>
							<?php if (is_array($restoration['r_data2'])){ ?>
							<?php foreach ($restoration['r_data2']['need'] as $key=>$v){ ?>
							<tr>
								<td><input type="text" name="data2[need][]" value="<?=$restoration['r_data']['need'][$key]?>" class="form-control" required="true" /></td>
								<td><input type="text" name="data2[count][]" value="<?=$restoration['r_data']['count'][$key]?>" class="form-control" required="true" /></td>
								<td><input type="text" name="data2[cost][]" value="<?=$restoration['r_data']['cost'][$key]?>" class="form-control" required="true" /></td>
								<td><input type="text" name="data2[notes][]" value="<?=$restoration['r_data']['notes'][$key]?>" class="form-control" /></td>
							</tr>
							<?php } ?>
							<?php } else {?>
							<tr>
								<td><input type="text" name="data2[need][]" class="form-control" required="true" /></td>
								<td><input type="text" name="data2[count][]" class="form-control" required="true" /></td>
								<td><input type="text" name="data2[cost][]" class="form-control" required="true" /></td>
								<td><input type="text" name="data2[notes][]" class="form-control" /></td>
							</tr>
							<?php } ?>
						</table>
						<button id="add_row" type="button" class="btn btn-success">إضافة</button>
					</div>
				</div>
				<br />
				<div class="form-group">
					<label for="user_name" class="control-label col-sm-2">التكلفة الإجمالية</label>
					<div class="col-sm-9">
						<input type="text" name="restoration[r_total]" id="r_total" value="<?=$restoration['r_total']?>" class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="pictures" class="control-label col-sm-2">إرفاق صور المعاينة بعد الصيانة</label>
					<div class="cols-sm-9" id="pictures">
						<input type="file" name="pictures2[]" /> <a href="#" id="add_btn">إضافة</a>
						<input type="file" name="pictures2[]" />
					</div>
				</div>
				<div class="form-group">
					<label for="pictures" class="control-label col-sm-2">إرفاق الفواتير</th>
					<div class="cols-sm-9" id="bills">
						<input type="file" name="bills[]" /> <a href="#" id="add_bill">إضافة</a>
						<input type="file" name="bills[]" />
					</div>
				</div>

				<div class="form-group">
					<label for="user_name" class="control-label col-sm-2">تاريخ المعاينة</label>
					<div class="col-sm-9">
						<input type="date" name="restoration[r_view_date]" id="r_view_date" value="<?=$restoration['r_view_date']?>" class="form-control datepicker" required="true" />
					</div>
				</div>
				<input type="hidden" name="dtl[dtl_status]" value="3" />
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
						<a href="#" class="btn btn-warning print_btn">طباعة</a>
					</div>
				</div>
			</div>
		</form>
		
		<script type="text/javascript">
			$('#add_row').click(function(){
				$('#rows tbody').append('<tr><td><input type="text" name="data2[need][]" class="form-control" required="true" /></td>'+
								'<td><input type="text" name="data2[count][]" class="form-control" required="true" /></td>'+
								'<td><input type="text" name="data2[cost][]" class="form-control" required="true" /></td>'+
								'<td><input type="text" name="data2[notes][]" class="form-control" /></td></tr>');
			});
			$('#add_btn').click(function(){
				$('#pictures').append('<input type="file" name="pictures2[]" />');
			});
			$('#add_bill').click(function(){
				$('#bills').append('<input type="file" name="bills[]" />');
			});
		</script>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading">طلبات ترميم وصيانة المساجد</div>
            <table class="table">
                <tr>
                    <th>اسم المستفيد</th>
                    <th>رقم المستفيد</th>
                    <th>المدينة</th>
                    <th>الحي</th>
                </tr>
                <?php if (isset($restorations) and count($restorations)){ ?>
                <?php foreach ($restorations as $row){ ?>
                <tr<?=($row['dtl_status'] < 0 ? ' class="danger"':'')?>>
                    <td><?=$row['r_name']?></td>
                    <td><?=$row['r_no']?></td>
                    <td><?=$row['r_city']?></td>
                    <td><?=$row['r_dist']?></td>
                    <td><a href="<?=base_url()?>mosquesmaintenance/postview/edit/<?=$row['r_id']?>" class="btn btn-warning">تعديل</a></td>
                </tr>
                <?php } ?>
                <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div>
        <?=$paging?><br/>
<a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
