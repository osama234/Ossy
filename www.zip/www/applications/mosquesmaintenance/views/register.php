<?php if (isset($items)){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">طلبات ترميم وصيانة المساجد</div>
			<table class="table">
				<tr>
                    <th>اسم المستفيد</th>
                    <th>رقم المستفيد</th>
                    <th>المدينة</th>
                    <th>الحي</th>
                </tr>
                <?php foreach ($items as $row){ ?>
                <tr<?=($row['dtl_status'] < 0 ? ' class="danger"':'')?>>
                    <td><?=$row['r_name']?></td>
                    <td><?=$row['r_no']?></td>
                    <td><?=$row['r_city']?></td>
                    <td><?=$row['r_dist']?></td>
                    <td><a href="<?=base_url()?>mosquesmaintenance/register/edit/<?=$row['r_id']?>" class="btn btn-warning">تعديل</a></td>
                </tr>
                <?php } ?>
            </table>
        </div>
        <a href="<?=base_url()?>mosquesmaintenance/register/add" class="btn btn-success">إعداد معاينة</a>
		<a href="#" class="btn btn-warning print_btn">طباعة</a>
        <?=$paging?><br/>
<?php } else {?>
		<?php if(isset($restoration['r_id'])){ ?>
		<?php if ($restoration['dtl_status'] != 0){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($restoration['dtl_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ArDate('d/m/Y', $restoration['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$restoration['dtl_notes']?></td>
				</tr>
			</table>
		</div>
		<?php } ?>
		<form action="<?=base_url()?>mosquesmaintenance/register/edit/<?=$restoration['r_id']?>" method="post" data-toggle="validator" role="form" class="form-horizontal" enctype="multipart/form-data">
			<div class="panel panel-primary">
				<div class="panel-heading">تعديل طلب صيانة / ترميم</div>
		<?php } else {?>
        <form action="<?=base_url()?>mosquesmaintenance/register/add" method="post" data-toggle="validator" role="form" class="form-horizontal" enctype="multipart/form-data">
			<div class="panel panel-primary">
				<div class="panel-heading">إعداد معاينة</div>
		<?php } ?>
				<br />
				<div class="form-group">
					<label for="r_name" class="control-label col-sm-2">اسم المستفيد</label>
					<div class="col-sm-9">
						<input type="text" name="restoration[r_name]" id="r_name" value="<?=$restoration['r_name']?>" class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="r_no" class="control-label col-sm-2">رقم المستفيد</label>
					<div class="col-sm-9">
						<input type="text" name="restoration[r_no]" id="r_no" value="<?=$restoration['r_no']?>" class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="r_city" class="control-label col-sm-2">المدينة</label>
					<div class="col-sm-9">
						<input type="text" name="restoration[r_city]" id="r_city" value="<?=$restoration['r_city']?>" class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="r_dist" class="control-label col-sm-2">الحي</label>
					<div class="col-sm-9">
						<input type="text" name="restoration[r_dist]" id="r_dist" value="<?=$restoration['r_dist']?>" class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<table id="rows">
							<tr>
								<th>بحاجة لصيانة</th>
								<th>عدد</th>
								<th>القيمة التقديرية</th>
								<th>ملاحظات</th>
							</tr>
							<?php if (isset($restoration['r_data'])){ ?>
							<?php foreach ($restoration['r_data']['need'] as $key=>$v){ ?>
							<tr>
								<td><input type="text" name="data[need][]" value="<?=$restoration['r_data']['need'][$key]?>" class="form-control" required="true" /></td>
								<td><input type="text" name="data[count][]" value="<?=$restoration['r_data']['count'][$key]?>" class="form-control" required="true" /></td>
								<td><input type="text" name="data[cost][]" value="<?=$restoration['r_data']['cost'][$key]?>" class="form-control" required="true" /></td>
								<td><input type="text" name="data[notes][]" value="<?=$restoration['r_data']['notes'][$key]?>" class="form-control" /></td>
							</tr>
							<?php } ?>
							<?php } else {?>
							<tr>
								<td><input type="text" name="data[need][]" class="form-control" required="true" /></td>
								<td><input type="text" name="data[count][]" class="form-control" required="true" /></td>
								<td><input type="text" name="data[cost][]" class="form-control" required="true" /></td>
								<td><input type="text" name="data[notes][]" class="form-control" /></td>
							</tr>
							<?php } ?>
						</table>
						<button id="add_row" type="button" class="btn btn-success">إضافة</button>
					</div>
				</div>
				<br />
				<?php if (!empty($restoration['r_pictures'])){ ?>
				<div class="form-group">
					<label class="control-label col-sm-2">الصور المرفقة</label>
					<div class="cols-sm-9">
						<?php foreach ($restoration['r_pictures'] as $pic){ ?>
							<a href="<?=base_url($pic['path'])?>"><?=$pic['filename']?></a><br />
						<?php } ?>
					</div>
				</div>
				<?php } ?>
				<div class="form-group">
					<label for="pictures" class="control-label col-sm-2">إرفاق صور المعاينة قبل الصيانة</label>
					<div class="cols-sm-9" id="pictures">
						<input type="file" name="pictures[]" /> <a href="#" id="add_btn">إضافة</a>
						<input type="file" name="pictures[]" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_name" class="control-label col-sm-2">تاريخ تسجيل المعاينة</label>
					<div class="col-sm-9">
						<input type="date" name="restoration[r_date]" id="p_beneficiaries" value="<?=$restoration['r_date']?>" class="form-control datepicker" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="user_name" class="control-label col-sm-2">تمت المعاينة من قبل</label>
					<div class="col-sm-9">
						<input type="text" name="restoration[r_visor]" id="p_beneficiaries" value="<?=$restoration['r_visor']?>" class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
						<a href="#" class="btn btn-warning print_btn">طباعة</a>
					</div>
				</div>
			</div>
		</form>
		<script type="text/javascript">
			$('#add_row').click(function(){
				$('#rows tbody').append('<tr><td><input type="text" name="data[need][]" id="p_beneficiaries" class="form-control" required="true" /></td>'+
								'<td><input type="text" name="data[count][]" id="p_beneficiaries" class="form-control" required="true" /></td>'+
								'<td><input type="text" name="data[cost][]" id="p_beneficiaries" class="form-control" required="true" /></td>'+
								'<td><input type="text" name="data[notes][]" id="p_beneficiaries" class="form-control" /></td></tr>');
			});
			$('#add_btn').click(function(){
				$('#pictures').append('<input type="file" name="pictures[]" />');
			});
		</script>
<?php } ?>
