<?php
class pcach_controller extends controller {
    function __construct() {
        parent::__construct();
    }

    function index($params = null) {
        return(true);
    }

    public function requestpc($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'add' and isset($_POST['requestpc'])) {
            $requestpc = $_POST['requestpc'];
            $sql = $this->mydb->sql_insert('pcach', $requestpc);
            $this->mydb->execute($sql, $requestpc);
            $dtl['p_id'] = $this->mydb->insert_id();
            $dtl['p_userid'] = $this->user['user_id'];
            $dtl['dtl_islast'] = 1;
            $dtl['dtl_time'] = time();
            $dtl['p_notes'] = $requestpc['req_desc'];
            $sql2 = $this->mydb->sql_insert('pcach_dtl', $dtl);
            if ($this->mydb->execute($sql2, $dtl)) {
                SetMessage('تم حفظ الطلب بنجاح', 'success');
                redirect('pcach/requestpc');
            } else {
                SetMessage('خطأ', 'error');
            }
        } elseif ($act == 'update' and $id) {
            if (isset($_POST['requestpc'])) {
                $requestpc = $_POST['requestpc'];
                $rc_rtl = array('p_id' => $id, 'p_notes' => $requestpc['req_desc'], 'p_userid' => $this->user['user_id'], 'dtl_time' => time(), 'dtl_islast' => 1);
                $this->update_dtl('pcach_dtl', 'dtl_islast', array('p_id' => $id));
                $sql = $this->mydb->sql_update('pcach', $requestpc, array('id' => $id));
                $sql2 = $this->mydb->sql_insert('pcach_dtl', $rc_rtl);
                if ($this->mydb->execute($sql, $requestpc) and $this->mydb->execute($sql2, $rc_rtl)) {
                    SetMessage('تم حفظ التعديلات بنجاح', 'success');
                    redirect('pcach/requestpc');
                }
            }

            $q = $this->mydb->execute('SELECT * FROM pcach INNER JOIN pcach_dtl ON (id=p_id) where dtl_islast =1 and id=:id', array('id' => $id));
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['requestpc'] = $row;
                $this->vars['lastProcess'] = $this->getLastProcess($this->vars['requestpc']['p_status']);
            }
        } else {
            $sql = 'SELECT * FROM pcach INNER JOIN pcach_dtl ON (id=p_id) where dtl_islast =1 and (p_status=0 or p_status=-1)';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {

                $this->vars['requestpc'][] = $row;
            }
        }
    }

    public function auditinfo($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'show' and $id != '') {
            if (isset($_POST['dtl'])) {
                $dtl = $_POST['dtl'];
                $dtl['p_userid'] = $this->user['user_id'];
                $dtl['p_id'] = $id;
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
                $this->update_dtl('pcach_dtl', 'dtl_islast', array('p_id' => $id));
                $sql = $this->mydb->sql_insert('pcach_dtl', $dtl);
                if ($this->mydb->execute($sql, $dtl)) {
                    SetMessage('تم حفظ الإجراء بنجاح', 'success');
                    redirect('pcach/auditinfo');
                }
            }
            $q = $this->mydb->execute(' SELECT * FROM pcach INNER JOIN pcach_dtl ON (id=p_id) where id=:id and dtl_islast =1', array('id' => $id));
            $row = $this->mydb->fetch_assoc($q);
            $this->vars['pcach_dtl'] = $row;
            $this->vars['lastProcess'] = $this->getLastProcess($this->vars['pcach_dtl']['p_status']);
        } else {
            $sql = 'SELECT * FROM pcach INNER JOIN pcach_dtl ON (pcach_dtl.p_id=pcach.id) where dtl_islast =1 and (p_status=0 or p_status=-1 )';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['pcach'][] = $row;
            }
        }
    }

    public function exchange($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'show' and $id != '') {
            if (isset($_POST['dtl'])) {
                $dtl = $_POST['dtl'];
                $dtl['p_userid'] = $this->user['user_id'];
                $dtl['p_id'] = $id;
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
                $this->update_dtl('pcach_dtl', 'dtl_islast', array('p_id' => $id));
                $sql = $this->mydb->sql_insert('pcach_dtl', $dtl);
                if ($this->mydb->execute($sql, $dtl)) {
                    SetMessage('تم حفظ الإجراء بنجاح', 'success');
                    redirect('pcach/exchange');
                }
            }
            $q = $this->mydb->execute(' SELECT * FROM pcach INNER JOIN pcach_dtl ON (id=p_id) where id=:id and dtl_islast =1', array('id' => $id));
            $row = $this->mydb->fetch_assoc($q);
            $this->vars['pcach_dtl'] = $row;
            $this->vars['lastProcess'] = $this->getLastProcess($this->vars['pcach_dtl']['p_status']);
        } else {
            $sql = 'SELECT * FROM pcach INNER JOIN pcach_dtl ON (pcach_dtl.p_id=pcach.id) where dtl_islast =1 and (p_status=1 or p_status=-2)';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['pcach'][] = $row;
            }
        }
    }

    public function Attach($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'show' and $id != '') {
            if (isset($_POST['dtl'])) {
                $dtl = $_POST['dtl'];
                $dtl['p_userid'] = $this->user['user_id'];
                $dtl['p_id'] = $id;
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
				$dtl1 = serialize($_POST['a']);
				
                $this->mydb->execute("update pcach set bills = '{$dtl1}' where id={$id}");
				$this->update_dtl('pcach_dtl', 'dtl_islast', array('p_id' => $id));
                $sql = $this->mydb->sql_insert('pcach_dtl', $dtl);
                if ($this->mydb->execute($sql, $dtl)) {
                    SetMessage('تم حفظ الإجراء بنجاح', 'success');
                    redirect('pcach/Attach');
                }
            }
            $q = $this->mydb->execute(' SELECT * FROM pcach INNER JOIN pcach_dtl ON (id=p_id) where id=:id and dtl_islast =1', array('id' => $id));
            $row = $this->mydb->fetch_assoc($q);
            $this->vars['pcach_dtl'] = $row;
            $this->vars['lastProcess'] = $this->getLastProcess($this->vars['pcach_dtl']['p_status']);
        } else {
            $sql = 'SELECT * FROM pcach INNER JOIN pcach_dtl ON (pcach_dtl.p_id=pcach.id) where dtl_islast =1 and (p_status=2 or p_status=-3)';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);

            while ($row = $this->mydb->fetch_assoc($q)) {

                $this->vars['pcach'][] = $row;
            }
        }
    }

    public function Receipt($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'show' and $id != '') {
            if (isset($_POST['dtl'])) {
                $dtl = $_POST['dtl'];
                $dtl['p_userid'] = $this->user['user_id'];
                $dtl['p_id'] = $id;
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
                $this->update_dtl('pcach_dtl', 'dtl_islast', array('p_id' => $id));
                $sql = $this->mydb->sql_insert('pcach_dtl', $dtl);
                if ($this->mydb->execute($sql, $dtl)) {
                    SetMessage('تم حفظ الإجراء', 'success');
                    redirect('pcach/Receipt');
                }
            }
            $q = $this->mydb->execute(' SELECT * FROM pcach INNER JOIN pcach_dtl ON (id=p_id) where id=:id and dtl_islast =1', array('id' => $id));
            $row = $this->mydb->fetch_assoc($q);
            $this->vars['pcach_dtl'] = $row;
            $this->vars['lastProcess'] = $this->getLastProcess($this->vars['pcach_dtl']['p_status']);
        } else {
            $sql = 'SELECT * FROM pcach INNER JOIN pcach_dtl ON (pcach_dtl.p_id=pcach.id) where dtl_islast =1 and (p_status=3 or p_status=-4)';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['pcach'][] = $row;
            }
        }
    }

    public function adjustment($act = '', $id = '') {
        $this->vars['act'] = $act;
        if ($act == 'show' and $id != '') {
            if (isset($_POST['dtl'])) {
                $dtl = $_POST['dtl'];
                $dtl['p_userid'] = $this->user['user_id'];
                $dtl['p_id'] = $id;
                $dtl['dtl_islast'] = 1;
                $dtl['dtl_time'] = time();
                $this->update_dtl('pcach_dtl', 'dtl_islast', array('p_id' => $id));
                $sql = $this->mydb->sql_insert('pcach_dtl', $dtl);
                if ($this->mydb->execute($sql, $dtl)) {
                    SetMessage('تم حفظ الإجراء', 'success');
                    redirect('pcach/adjustment');
                }
            }
            $q = $this->mydb->execute(' SELECT * FROM pcach INNER JOIN pcach_dtl ON (id=p_id) where id=:id and dtl_islast =1', array('id' => $id));
            $row = $this->mydb->fetch_assoc($q);
            $this->vars['pcach_dtl'] = $row;
            $this->vars['lastProcess'] = $this->getLastProcess($this->vars['pcach_dtl']['p_status']);
        } else {
            $sql = 'SELECT * FROM pcach INNER JOIN pcach_dtl ON (pcach_dtl.p_id=pcach.id) where dtl_islast =1 and (p_status=4 or p_status=-5 or p_status=5)';
            $this->vars['paging'] = PagingSQL($sql);
            $q = $this->mydb->execute($sql);
            while ($row = $this->mydb->fetch_assoc($q)) {
                $this->vars['pcach'][] = $row;
            }
        }
    }

    public function update_dtl($table = '', $field = '', $where) {
        $sql = $this->mydb->sql_update($table, array($field => 0), $where);
        if ($this->mydb->execute($sql))
            return true;
        else
            return false;
    }

    private function getLastProcess($status) {
        switch ($status) {
            case 0: return 'إجراء طلب صرف عهدة';
            case 1: return 'اعتماد طلب صرف عهدة ';
            case -1: return 'رفض اعتماد صرف عهدة ';
            case 2: return 'صرف العهدة';
            case -2: return 'رفض صرف العهدة';
            case 3: return 'ارفاق فواتير العهدة ';
            case -3: return 'رفض ارفاق فواتير العهدة';
            case 4: return 'استلام فواتير العهدة ';
            case -4: return 'رفض استلام فواتير العهدة ';
            case 5: return 'تسوية عند اكتمال العهدة';
            case -5: return 'رفض التسوية';
        }
    }
}
