<?php  if (isset($pcach_dtl )){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($pcach_dtl['p_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ArDate('d/m/Y', $pcach_dtl['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$pcach_dtl['p_notes']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المستفيد</th>
					<td><?=$pcach_dtl['c_name']?></td>
				</tr>
				<tr>
					<th width="20%">جهة المستفيد</th>
					<td><?=$pcach_dtl['c_dep']?></td>
				</tr>
				<tr>
					<th width="20%">قيمة العهدة</th>
					<td><?=$pcach_dtl['c_amount']?></td>
				</tr>
				<tr>
					<th width="20%">تاريخ طلب الصرف</th>
					<td><?=$pcach_dtl['req_date']?></td>
				</tr>
<!--
				<tr>
					<th width="20%">اسم المشروع</th>
					<td><?=$rccheck_dtl['proj_name']?></td>
				</tr>
				-->
				
				<tr>
					<th>
						بيان تفصيل العهد
					</th>
					<td>
						<table class=table>
								<tr>
									<th>م</th>
									<th>البيان</th>
									<th>رقم الفاتورة</th>
									<th>إسم المحل</th>
									<th>السعر</th> 									
								</tr>
							<?php
							 
							$a = unserialize( $pcach_dtl['bills'] );
							$t = 0;
							$i = 0 ;
							foreach($a['m'] as $aa) {
							print "<tr><td>{$aa}</td><td> {$a['b'][$i]}</td><td> {$a['bb'][$i]}</td><td> {$a['s'][$i]}</td><td> {$a['p'][$i]}</td></tr>";
							$i++;	$t += $a['p'][$i];
							} 
							?>
							<tr><td colspan="4">المجموع</td><td><?=$t?></td></tr>
						</table>
					</td>
				</tr>
			</table>
		</div>
		<form action="<?=base_url()?>pcach/adjustment/show/<?=$pcach_dtl['p_id']?>" method="post" data-toggle="validator" role="form">
			<div class="panel panel-primary">
				<div class="panel-heading">الإجراء المتخذ</div>
				<table class="table">
					<tr>
						<th width="20%">القرار</th>
						<td>
							<input type="radio" name="dtl[p_status]" id="p_status1" value="5" /><label for="dtl_status1">تم</label>
							<input type="radio" name="dtl[p_status]" id="p_status2" value="-5" /><label for="dtl_status2">لم يتم</label>
						</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[p_notes]" rows="3" ></textarea></td>
					</tr>
					<tr>
						<th></th>
						<td><button type="submit" class="btn btn-primary">حفظ واعتماد</button></td>
					</tr>
				</table>
			</div>
		</form>
<?php } else{?>
			<div class="panel panel-primary">
			<div class="panel-heading">طلبات صرف العهد المسجلة</div>
			<table class="table">
				<tr>
                    <th>اسم المستفيد</th>
                    <th>جهة المستفيد</th>
					 <th>الغرض</th>
                    <th>المبلغ</th>
					
                    <!--<th>اسم المشروع</th>-->
			        <th>حالة الطلب</th>
                    <th>إجراءات</th>
                </tr>
			<?
			if(isset($pcach))
			
			   foreach($pcach as $row )
                 {			?>
			 <tr <?=($row['p_status'] < 0 ? ' class="danger"':($row['p_status']==5 ? 'class="success"':''))?>>
                    
                    <td><?=$row['c_name']?></td>
                    <td><?=$row['c_dep']?></td>
					 <td><?=$row['purpose']?></td>
                    <td><?=$row['c_amount']?></td>
					 <!--<td><?=$row['proj_name']?></td>-->
					  <td><?=($row['p_status']<0 ? 'يوجد ملاحظات' :($row['p_status']==5 ? 'تمت التسوية و اكتمال العهدة' : 'تم استلام الفواتير') )?></td>
              
                 <td><a href="<?=base_url()?>pcach/adjustment/show/<?=$row['id']?>" class="btn btn-primary">عرض</a></td>
				 
                </tr>
                     		<? }?> </table></div><?=$paging?><br/><a href="#" class="btn btn-warning print_btn">طباعة</a>
                  							
			 </div><?}?>
