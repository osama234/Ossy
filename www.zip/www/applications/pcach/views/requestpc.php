




<?php if ($act == 'add') { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">العهد</div>
        <div class="panel-body">

            <h2>تسجيل طلب صرف عهدة</h2>



            <form action="<?= base_url() ?>pcach/requestpc/add" method="post" data-toggle="validator" role="form">

                <div class="form-group">
                    <label for="requestpc[c_name]" class="control-label">اسم المستفيد :</label>
                    <input type="text"   name="requestpc[c_name]" value="" id="requestpc[c_name]"  class="form-control"  required="true" />
                </div>
                <div class="form-group ">

                    <label for="requestpc[c_dep]" class="control-label">جهة المستفيد : </label>
                    <input type="text" name="requestpc[c_dep]" value="" id="requestpc[c_dep]"  class="form-control" required="true" />
                </div>
                <div class="form-group">
                    <label for="requestpc[purpose]" class="control-label">الغرض</label>
                    <input type="text" name="requestpc[purpose]" value="" id="requestpc[purpose]"  class="form-control" />
                </div>
                <div class="form-group">
                    <label for="requestpc[c_amount]" class="control-label">القيمة</label>
                    <input type="text" name="requestpc[c_amount]" value="" id="requestpc[c_amount]"  class="form-control" />
                </div>
                <div class="form-group">
                    <label for="requestpc[req_date]" class="control-label">تاريخ تقديم طلب الصرف</label>
                    <input type="date" name="requestpc[req_date]" value="" id="requestpc[req_date]"  class="form-control datepicker" required="true" />
                </div>
               <!--
                <div class="form-group">
                    <label for="requestpc[proj_name]" class="control-label">اسم المشروع</label>
                    <select  class="form-control"name="requestpc[proj_name]"><?= GetProjects() ?></select>
                </div>
-->
                <div class="form-group">
                    <label for="requestpc[req_desc]" class="control-label">ملاحظات</label>
                    <textarea  id="requestpc[req_desc]" name="requestpc[req_desc]" class="form-control"></textarea>
                </div>
                <div class="form-group ">
                    <input type="submit" value="حفظ وإعتماد" class="btn btn-primary btn-md ">
                    <a href="#" class="btn btn-primary btn-md ">طباعة</a>
                </div>
            </form>


        </div></div>


    <?}elseif($act=='update'){  ?>
    <div class="panel panel-primary">
        <div class="panel-heading">العملية السابقة</div>
        <table class="table">
            <tr>
                <th width="20%">اسم العملية</th>
                <td><?= $lastProcess ?></td>
            </tr>
            <tr>
                <th>العملية بواسطة</th>
                <td><?= GetUserById($requestpc['p_userid'], 'user_name') ?></td>
            </tr>
            <tr>
                <th>تاريخ العملية</th>
                <td><?= ArDate('d/m/Y', $requestpc['dtl_time']) ?></td>
            </tr>
            <tr>
                <th>الملاحظات</th>
                <td><?= $requestpc['p_notes'] ?></td>
            </tr>
        </table>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">العهد</div>
        <div class="panel-body">
            <form action="<?= base_url() ?>pcach/requestpc/update/<?= $requestpc['id'] ?>" method="post" data-toggle="validator" role="form">
                <div class="form-group">
                    <label for="requestpc[c_name]" class="control-label" >اسم المستفيد :</label>
                    <input type="text" name="requestpc[c_name]"  id="requestpc[c_name]" value="<?= $requestpc['c_name'] ?>"   class="form-control"  required="true" />
                </div>
                <div class="form-group ">

                    <label for="requestpc[c_dep]" class="control-label" >جهة المستفيد : </label>
                    <input type="text" name="requestpc[c_dep]"  id="requestpc[c_dep]"  class="form-control" required="true" value="<?= $requestpc['c_dep'] ?>" />
                </div>
                <div class="form-group">
                    <label for="requestpc[purpose]" class="control-label">الغرض</label>
                    <input type="text" name="requestpc[purpose]"  id="requestpc[purpose]"  class="form-control" value="<?= $requestpc['purpose'] ?>" />
                </div>
                <div class="form-group">
                    <label for="requestpc[c_amount]" class="control-label">القيمة</label>
                    <input type="text" name="requestpc[c_amount]"  id="requestpc[c_amount]"  class="form-control" value="<?= $requestpc['c_amount'] ?>" />
                </div>

                <div class="form-group">
                    <label for="requestpc[req_date]" class="control-label">تاريخ تقديم طلب الصرف</label>
                    <input type="text" name="requestpc[req_date]" id="requestpc[req_date]"  class="form-control" required="true" value="<?= $requestpc['req_date'] ?>" />
                </div><!--
                <div class="form-group">
                    <label for="requestpc[proj_name]" class="control-label">اسم المشروع</label>
                    <select  class="form-control"name="requestpc[proj_name]"><?= GetProjects((int) $requestpc['proj_name']) ?></select>
                </div>
-->
                <div class="form-group">
                    <label for="requestpc[req_desc]" class="control-label">ملاحظات</label>
                    <textarea  id="requestpc[req_desc]" name="requestpc[req_desc]" class="form-control" ><?= $requestpc['req_desc'] ?></textarea>
                </div>
                <div class="form-group ">
                    <input type="submit" value="حفظ وإعتماد" class="btn btn-primary btn-md ">

                </div>
            </form>
        </div>
        <?php }else{ ?>
        <div class="panel panel-primary">
            <div class="panel-heading">طلبات صرف العهد المسجلة</div>
            <table class="table">
                <tr>
                    <th>اسم المستفيد</th>
                    <th>جهة المستفيد</th>
                    <th>الغرض</th>
                    <th>المبلغ</th>

                    <!--<th>اسم المشروع</th>-->
                    <th>حالة الطلب</th>
                    <th>إجراءات</th>
                </tr>
                <?php if(isset($requestpc)) foreach($requestpc as $row ) {?>
                <tr <?= ($row['p_status'] < 0 ? ' class="danger"' : '') ?>>
                    <td><?= $row['c_name'] ?></td>
                    <td><?= $row['c_dep'] ?></td>
                    <td><?= $row['purpose'] ?></td>
                    <td><?= $row['c_amount'] ?></td>
                    <!--<td><?= GetProjectsLabel($row['proj_name']) ?></td>-->
                    <td><?= ($row['p_status'] < 0 ? 'يوجد ملاحظات' : 'جديد') ?></td>
                    <td><a href="<?= base_url() ?>pcach/requestpc/update/<?= $row['id'] ?>" class="btn btn-warning">تحديث</a></td>
                </tr>
                <?php } ?>
            </table>
        </div>
        <a href="<?= base_url() ?>pcach/requestpc/add" class="btn btn-success">تسجيل طلب جديد</a>
        <a href="#" class="btn btn-warning print_btn">طباعة</a><br/>
        <?= $paging ?>
    </div>
<?php } ?>
