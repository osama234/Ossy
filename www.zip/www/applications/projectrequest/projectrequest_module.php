<?php
	class projectrequest_controller extends controller
	{
		function __construct() {
            parent::__construct();
        }
        
        function index($params=null) {
			return(true);
		}
		
		function register($act='', $id=0) {
			if ($act == 'add') {
				if (isset($_POST['project'])) {
					$project = $this->validateData($_POST['project'], $act);
					if ($project) {
						$sql = $this->mydb->sql_insert('project_requests', $project);
						$this->mydb->execute($sql, $donation);
						$dtl['dtl_pid'] = $this->mydb->insert_id();
						$dtl['dtl_userid'] = $this->user['user_id'];
						$dtl['dtl_islast'] = 1;
						$dtl['dtl_time'] = time();
						$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
						$sql = $this->mydb->sql_insert('project_requests_dtl', $dtl);
						$this->mydb->execute($sql, $dtl);
						setMessage('تم حفظ البيانات بنجاح', 'success');
						redirect('projectrequest/register');
					}
				}
			} elseif ($act == 'edit') {
				if (isset($_POST['project'])) {
					$project = $this->validateData($_POST['project'], $act);
					if ($project) {
						$this->mydb->execute($this->mydb->sql_update('project_requests', $project, array('p_id' => $id)), $project);
						$dtl['dtl_pid'] = $id;
						$dtl['dtl_userid'] = $this->user['user_id'];
						$dtl['dtl_islast'] = 1;
						$dtl['dtl_time'] = time();
						$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];
						$this->mydb->execute('UPDATE project_requests_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
						$sql = $this->mydb->sql_insert('project_requests_dtl', $dtl);
						$this->mydb->execute($sql, $dtl);
						setMessage('تم حفظ البيانات بنجاح', 'success');
						redirect('projectrequest/register');
					}
				}
				$sql = 'SELECT * FROM project_requests INNER JOIN project_requests_dtl ON (dtl_pid=p_id AND dtl_islast=1) WHERE dtl_status<=0 AND p_id=:id';
				$this->vars['project'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id)));
				$this->vars['lastProcess'] = $this->getLastProcess($this->vars['project']['dtl_status']);
			} else {
				$sql =  ('SELECT * FROM project_requests INNER JOIN project_requests_dtl ON (dtl_pid=p_id AND dtl_islast=1) WHERE dtl_status<=0');
				$this->vars['paging'] = PagingSQL($sql);
				$q = $this->mydb->execute( $sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['items'][] = $row;
				}
			}
		}
		
		public function archive($id=0) {
			if ($id) {
				$this->vars['project'] = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM project_requests WHERE p_id=:id', array('id' => $id)));
				$q = $this->mydb->execute('SELECT * FROM project_requests_dtl WHERE dtl_pid=:id ORDER BY dtl_time', array('id' => $id));
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['details'][] = $row;
				}
			} else {
				$sql =  ('SELECT * FROM project_requests INNER JOIN project_requests_dtl ON (dtl_pid=p_id AND dtl_islast=1) ORDER BY dtl_time');
				$this->vars['paging'] = PagingSQL($sql);
				$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['projects'][] = $row;
				}
			}
		}
		
		public function audit($act='', $id=0) {
			$this->process($act, $id, 0, 'audit');
		}
		
		public function approve($act='', $id=0) {
			$this->process($act, $id, 1, 'approve');
		}
		
		public function direct($act='', $id=0) {
			$this->process($act, $id, 2, 'direct');
		}
		
		private function process($act, $id, $status, $redirect) {
			if ($act == 'edit' and $id) {
				if (isset($_POST['dtl'])) {
					$dtl = $_POST['dtl'];
					$dtl['dtl_pid'] = $id;
					$dtl['dtl_userid'] = $this->user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$this->mydb->execute('UPDATE project_requests_dtl SET dtl_islast=0 WHERE dtl_pid=:id', array('id' => $id));
					$sql = $this->mydb->sql_insert('project_requests_dtl', $dtl);
					$this->mydb->execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect('projectrequest/'.$redirect);
				}
				$sql = 'SELECT * FROM project_requests INNER JOIN project_requests_dtl ON (dtl_pid=p_id AND dtl_islast=1) WHERE dtl_status=:status AND p_id=:id';
				$this->vars['project'] = $this->mydb->fetch_assoc($this->mydb->execute($sql, array('id' => $id, 'status' => $status)));
				$this->vars['lastProcess'] = $this->getLastProcess($this->vars['project']['dtl_status']);
			} else {
				$sql =  ('SELECT * FROM project_requests INNER JOIN project_requests_dtl ON (dtl_pid=p_id AND dtl_islast=1) WHERE dtl_status=:status');
				$this->vars['paging'] = PagingSQL($sql);
				$q = $this->mydb->execute($sql, array('status' => $status));
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['projects'][] = $row;
				}
			}
		}
		
		private function getLastProcess($status) {
			switch (abs($status)) {
				case 0: return 'تسجيل مشروع جديد';
				case 1: return 'تدقيق بيانات المشروع';
				case 2: return 'اعتماد المشروع';
				case 3: return 'اعتماد المشروع';
			}
		}
		
		private function validateData($data, $act='') {
			$valid = true;
			if (!CheckInput($data['p_name'])) {
			    SetMessage('الرجاء إدخال اسم المشروع', 'error');
			    $valid = false;
			}
			if (!CheckInput($data['p_type'])) {
			    SetMessage('الرجاء إدخال نوع المشروع', 'error');
			    $valid = false;
			}
			if (!CheckInput($data['p_date'])) {
			    SetMessage('الرجاء إدخال تاريخ تقديم المشروع', 'error');
			    $valid = false;
			}
			if (!CheckInput($data['p_beneficiaries'])) {
			    SetMessage('الرجاء إدخال المستفيدين من المشروع', 'error');
			    $valid = false;
			}
			if (!CheckInput($data['p_description'])) {
			    SetMessage('الرجاء إدخال مقدمة عن المشروع', 'error');
			    $valid = false;
			}
			if ($valid) {
				return $data;
			} else {
				return false;
			}
		}
	}
?>
