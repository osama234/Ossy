<?php if (isset($project)){ ?>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات التبرع</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المشروع</th>
					<td><?=$project['p_name']?></td>
				</tr>
				<tr>
					<th width="20%">نوع المشروع</th>
					<td><?=$project['p_type']?></td>
				</tr>
				<tr>
					<th width="20%">تاريخ تقديم المشروع</th>
					<td><?=$project['p_date']?></td>
				</tr>
				<tr>
					<th width="20%">المستفيدين من المشروع</th>
					<td><?=$project['p_beneficiaries']?></td>
				</tr>
				<tr>
					<th width="20%">مقدمة عن المشروع</th>
					<td><?=$project['p_description']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">سجل العمليات</div>
        	<table class="table">
        		<tr>
        			<th>المستخدم</th>
        			<th>التاريخ</th>
        			<th>الوقت</th>
        			<th>ملاحظات</th>
        		</tr>
        		<?php foreach ($details as $row){ ?>
        		<tr>
        			<td><?=GetUserById($row['dtl_userid'], 'user_name')?></td>
        			<td><?=date('d/m/Y', $row['dtl_time'])?></td>
        			<td><?=date('h:i A', $row['dtl_time'])?></td>
        			<td><?=$row['dtl_notes']?></td>
        		</tr>
        		<?php } ?>
        	</table>
		</div>
		<a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية</div>
            <table class="table">
                <tr>
                    <th>اسم المشروع</th>
                    <th>نوع المشروع</th>
                    <th>المستفيدين من المشروع</th>
                    <th></th>
                </tr>
                <?php if (isset($projects) and count($projects)){ ?>
                <?php foreach ($projects as $row){ ?>
                <tr>
                    <td><?=$row['p_name']?></td>
                    <td><?=$row['p_type']?></td>
                    <td><?=$row['p_beneficiaries']?></td>
                    <td>
                        <a href="<?=base_url()?>projectrequest/archive/<?=$row['p_id']?>" class="btn btn-primary">عرض</a>
                    </td>
                </tr>
                <?php } ?>
                <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div><?=$paging?><br/>
        <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
