<?php if (isset($project)){ ?>
		<div class="panel panel-primary">
        	<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($project['dtl_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=date('d/m/Y', $project['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$project['dtl_notes']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات التبرع</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المشروع</th>
					<td><?=$project['p_name']?></td>
				</tr>
				<tr>
					<th>نوع المشروع</th>
					<td><?=$project['p_type']?></td>
				</tr>
				<tr>
					<th>تاريخ تقديم المشروع</th>
					<td><?=$project['p_date']?></td>
				</tr>
				<tr>
					<th>المستفيدين من المشروع</th>
					<td><?=$project['p_beneficiaries']?></td>
				</tr>
				<tr>
					<th>مقدمة عن المشروع</th>
					<td><?=$project['p_description']?></td>
				</tr>
			</table>
		</div>
		<form action="<?=base_url()?>projectrequest/audit/edit/<?=$project['p_id']?>" method="post" data-toggle="validator" role="form" class="form-horizontal">
			<div class="panel panel-primary">
        		<div class="panel-heading">الإجراء المتخذ</div>
				<br />
				<div class="form-group">
					<label for="dtl_status1" class="control-label col-sm-2">القرار</label>
					<div class="col-sm-9">
						<input type="radio" name="dtl[dtl_status]" id="dtl_status1" value="1" required /> <label for="dtl_status1">تدقيق</label>
						<input type="radio" name="dtl[dtl_status]" id="dtl_status2" value="-1" required /> <label for="dtl_status2">ملاحظات</label>
					</div>
				</div>
				<div class="form-group">
					<label for="dtl_notes" class="control-label col-sm-2">ملاحظات</label>
					<div class="col-sm-9">
						<textarea name="dtl[dtl_notes]" id="dtl_notes" rows="3" class="form-control"></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
						<a href="#" class="btn btn-warning print_btn">طباعة</a>
					</div>
				</div>

			</div>
		</form>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية المستلمة</div>
            <table class="table">
                <tr>
                    <th>اسم المشروع</th>
                    <th>نوع المشروع</th>
                    <th>المستفيدين من المشروع</th>
                    <th></th>
                </tr>
                <?php if (isset($projects) and count($projects)){ ?>
                <?php foreach ($projects as $row){ ?>
                <tr>
                    <td><?=$row['p_name']?></td>
                    <td><?=$row['p_type']?></td>
                    <td><?=$row['p_beneficiaries']?></td>
                    <td>
                        <a href="<?=base_url()?>projectrequest/audit/edit/<?=$row['p_id']?>" class="btn btn-primary">عرض</a>
                    </td>
                </tr>
                <?php } ?>
                <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div><?=$paging?><br/>
        <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
