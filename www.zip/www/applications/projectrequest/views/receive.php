<?php if (isset($donation)){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($donation['dtl_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=date('d/m/Y', $donation['dtl_time'])?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات التبرع</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المتبرع</th>
					<td><?=$donation['d_name']?></td>
				</tr>
				<tr>
					<th width="20%">رقم الجوال</th>
					<td><?=$donation['d_mobile']?></td>
				</tr>
				<tr>
					<th width="20%">المبلغ رقماً</th>
					<td><?=$donation['d_mount_d']?></td>
				</tr>
				<tr>
					<th width="20%">المبلغ كتابة</th>
					<td><?=$donation['d_mount_t']?></td>
				</tr>
				<tr>
					<th width="20%">نوع التبرع</th>
					<td><?=GetOptionsLabel('donation_type', $donation['d_type'])?></td>
				</tr>
				<tr>
					<th width="20%">البنك</th>
					<td><?=$donation['d_bank']?></td>
				</tr>
				<tr>
					<th width="20%">اسم المشىروع</th>
					<td><?=$donation['d_project']?></td>
				</tr>
				<tr>
					<th>الملاحظات</th>
					<td><?=$donation['dtl_notes']?></td>
				</tr>
			</table>
		</div>
		<form action="<?=base_url()?>moneydonation/receive/edit/<?=$donation['d_id']?>" method="post" data-toggle="validator" role="form">
			<div class="panel panel-primary">
				<div class="panel-heading">الإجراء المتخذ</div>
				<table class="table">
					<tr>
						<th width="20%">القرار</th>
						<td>
							<input type="radio" name="dtl[dtl_status]" id="dtl_status1" value="1" /><label for="dtl_status1">استلام</label>
							<input type="radio" name="dtl[dtl_status]" id="dtl_status2" value="-1" /><label for="dtl_status2">ملاحظات</label>
						</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[dtl_notes]" rows="3" ></textarea></td>
					</tr>
					<tr>
						<th></th>
						<td>
							<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
							<a href="#" class="btn btn-warning print_btn">طباعة</a>
						</td>
					</tr>
				</table>
			</div>
		</form>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية المسجلة</div>
            <table class="table">
                <tr>
                    <th>نوع التبرع</th>
                    <th>المبلغ</th>
                    <th>المبلغ كتابة</th>
                    <th>نوع المشروع</th>
                    <th></th>
                </tr>
                <?php if (isset($donations) and count($donations)){ ?>
                <?php foreach ($donations as $row){ ?>
                <tr>
                    <td><?=GetOptionsLabel('donation_type', $row['d_type'])?></td>
                    <td><?=$row['d_mount_d']?></td>
                    <td><?=$row['d_mount_t']?></td>
                    <td><?=$row['d_project']?></td>
                    <td>
                        <a href="<?=base_url()?>moneydonation/receive/edit/<?=$row['d_id']?>" class="btn btn-primary">عرض</a>
                    </td>
                </tr>
                <?php } ?>
                <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div><?=$paging?><br/>
        <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
