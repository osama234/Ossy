<?php if (isset($items)){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">طلبات المشاريع</div>
			<table class="table">
				<tr>
                    <th>اسم المشروع</th>
                    <th>نوع المشروع</th>
                    <th>المستفيدين من المشروع</th>
                    <th></th>
                </tr>
                <?php foreach ($items as $row){ ?>
                <tr<?=($row['dtl_status'] < 0 ? ' class="danger"':'')?>>
                    <td><?=$row['p_name']?></td>
                    <td><?=$row['p_type']?></td>
                    <td><?=$row['p_beneficiaries']?></td>
                    <td><a href="<?=base_url()?>projectrequest/register/edit/<?=$row['p_id']?>" class="btn btn-warning">تعديل</a></td>
                </tr>
                <?php } ?>
            </table>
        </div>
        <a href="<?=base_url()?>projectrequest/register/add" class="btn btn-success">تسجيل مشروع جديد</a>
        <?=$paging?><br/>
        <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } else {?>
		<?php if(isset($project['p_id'])){ ?>
		<?php if ($project['dtl_status'] != 0){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($project['dtl_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=date('d/m/Y', $project['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$project['dtl_notes']?></td>
				</tr>
			</table>
		</div>
		<?php } ?>
		<form action="<?=base_url()?>projectrequest/register/edit/<?=$project['p_id']?>" method="post" data-toggle="validator" role="form" class="form-horizontal">
			<div class="panel panel-primary">
				<div class="panel-heading">تعديل بيانات مشروع</div>
		<?php } else {?>
        <form action="<?=base_url()?>projectrequest/register/add" method="post" data-toggle="validator" role="form" class="form-horizontal">
			<div class="panel panel-primary">
				<div class="panel-heading">تسجيل مشروع جديد</div>
		<?php } ?>
				<br />
				<div class="form-group">
					<label for="p_name" class="control-label col-sm-2">اسم المشروع</label>
					<div class="col-sm-9">
						<input type="text" name="project[p_name]" value="<?=$project['p_name']?>" id="p_name"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="p_type" class="control-label col-sm-2">نوع المشروع</label>
					<div class="col-sm-9">
						<input type="text" name="project[p_type]" value="<?=$project['p_type']?>" id="p_type"  class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="p_date" class="control-label col-sm-2">تاريخ تقديم المشروع</label>
					<div class="col-sm-9">
						<input type="date" name="project[p_date]" value="<?=$project['p_date']?>" id="p_date"  class="form-control datepicker" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="p_beneficiaries" class="control-label col-sm-2">المستفيدين من المشروع</label>
					<div class="col-sm-9">
						<input type="text" name="project[p_beneficiaries]" value="<?=$project['p_beneficiaries']?>" id="p_beneficiaries"  class="form-control" required="true" />
					</div>
				</div>
				
				<div class="form-group">
					<label for="p_description" class="control-label col-sm-2">مقدمة عن المشروع</label>
					<div class="col-sm-9">
						<textarea name="project[p_description]" id="p_description" rows="3" class="form-control" required="true"><?=$project['p_description']?></textarea>
					</div>
				</div><div class="form-group">
					<label for="dtl_notes" class="control-label col-sm-2">ملاحظات</label>
					<div class="col-sm-9">
						<textarea name="dtl[d_notes]" id="d_notes" rows="3" class="form-control" ><?=$project['dtl_notes']?></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
						<a href="#" class="btn btn-warning print_btn">طباعة</a>
					</div>
				</div>
			</div>
		</form>
<?php } ?>

<script type="text/javascript">
<!--
$('.datepicker').calendarsPicker({calendar: $.calendars.instance('ummalqura', 'ar')});
-->
</script>
