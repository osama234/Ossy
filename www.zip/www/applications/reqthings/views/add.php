	<?php if (isset($items)){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">تسجيل طلب جديد</div>
			<table class="table">
				<tr>
                    <th>النوع</th>
                    <th>الهدف</th>
                    <th>المشروع</th> 
                </tr>
                <?php  foreach ($items as $row){ ?>
                <tr<?=($row['dtl_status'] < 0 ? ' class="danger"' : '') ?>>
                    <td><?=$row['r_kind'] ?></td>
                    <td><?=$row['r_purpose'] ?></td>
                    <td><?=$row['r_project'] ?></td> 
                    <td><a href="<?=base_url() ?>reqthings/add/edit/<?=$row['r_id'] ?>" class="btn btn-warning">تعديل</a></td>
                </tr>
                <?php } ?>
            </table>
        </div>
        <a href="<?=base_url() ?>reqthings/add/add" class="btn btn-success">تسجيل طلب جديد</a>
        <?=$paging ?><br/>
<a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } else { ?>
	<?php if(isset($reqthings['r_id'])){ ?>
		<?php if ($reqthings['dtl_islast'] > 0){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess ?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($reqthings['dtl_userid'], 'user_name') ?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=date('d/m/Y', $reqthings['dtl_time']) ?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$reqthings['dtl_notes'] ?></td>
				</tr>
			</table>
		</div>
		<?php } ?>
				<form action="<?=base_url() ?>reqthings/add/edit/<?=$reqthings['r_id'] ?>" method="post" data-toggle="validator" role="form" class="form-horizontal" enctype="multipart/form-data">
			<div class="panel panel-primary">
				<div class="panel-heading">تسجيل طلب جديد</div>
		<?php } else { ?>
        <form action="<?=base_url() ?>reqthings/add/add" method="post" data-toggle="validator" role="form" class="form-horizontal" enctype="multipart/form-data">
			<div class="panel panel-primary">
				<div class="panel-heading">تسجيل طلب جديد</div>
		<?php } ?>
				<br />
				<div class="form-group">
					<label for="r_name" class="control-label col-sm-2">نوع المواد</label>
					<div class="col-sm-9">
						<input type="text" required="true" name="reqthings[r_kind]" id="r_kind" value="<?=$reqthings['r_kind'] ?>" class="form-control" required="true" />
					</div>
				</div>				  
								<div class="form-group">
					<label for="r_name" class="control-label col-sm-2">كمية المواد / عددها</label>
					<div class="col-sm-9">
						<input type="text" required="true" name="reqthings[r_amount]" id="r_mount" value="<?=$reqthings['r_amount'] ?>" class="form-control" required="true" />
					</div>
				</div>
								<div class="form-group">
					<label for="r_name" class="control-label col-sm-2">اسم المشروع</label>
					<div class="col-sm-9">
						<select  class="form-control"name='reqthings[r_project]'><?=GetProjects((int )$used['r_project']) ?></select>
					</div>
				</div>
								<div class="form-group">
					<label for="r_name" class="control-label col-sm-2">الغرض من الطلب</label>
					<div class="col-sm-9">
						<input type="text" required="true" name="reqthings[r_purpose]" id="r_propuse" value="<?=$reqthings['r_purpose'] ?>" class="form-control" required="true" />
					</div>
				</div>
								<div class="form-group">
					<label for="r_name" class="control-label col-sm-2">القيمة الشرائية</label>
					<div class="col-sm-9">
						<input type="text" required="true" name="reqthings[r_cost]" id="r_value" value="<?=$reqthings['r_cost']>0?$reqthings['r_cost']:0 ?>" class="form-control" required="true" />
					</div>
				</div>
								<div class="form-group">
					<label for="r_name" class="control-label col-sm-2">تاريخ الشراء</label>
					<div class="col-sm-9">
						<input name="reqthings[r_date]" id="r_date" value="<?=$reqthings['r_date'] ?>" type="datetime" class="form-control datepicker" required="true"  />
					</div>
				</div> 
								<div class="form-group">
					<label for="r_name" class="control-label col-sm-2">ملاحظات</label>
					<div class="col-sm-9">
						<input type="text" name="reqthings[r_note]" id="r_note" value="<?=$reqthings['r_note'] ?>" class="form-control" />
					</div>
				</div>
			 
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
						<a href="#" class="btn btn-warning print_btn">طباعة</a>
					</div>
				</div>
			</div>
		</form>
				<?php } ?>
				
