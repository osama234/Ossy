<?php if (isset($donation)){ ?>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th width="20%">نوع المواد</th>
					<td><?=$restoration['r_kind']?></td>
				</tr>
				<tr>
					<th width="20%">كمية المواد / عددها</th>
					<td><?=$restoration['r_amount']?></td>
				</tr>
 
				<tr>
					<th width="20%">اسم المشروع</th>
					<td><?=GetProjectsLabel($restoration['r_project'])?></td>
				</tr>
				<tr>
					<th width="20%">الغرض من الطلب</th>
					<td><?=$restoration['r_purpose']?></td>
				</tr>
				<tr>
					<th width="20%">تاريخ الشراء</th>
					<td><?=$restoration['r_date']?></td>
				</tr>
				<tr>
					<th width="20%">القيمة الشرائية</th>
					<td><?=$restoration['r_cost']?></td>
				</tr>
				<tr>
					<th width="20%">الماحظات</th>
					<td><?=$restoration['r_note']?></td>
				</tr>
				
				
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">سجل العمليات</div>
        	<table class="table">
        		<tr>
        			<th>المستخدم</th>
        			<th>التاريخ</th>
        			<th>الوقت</th>
        			<th>ملاحظات</th>
        		</tr>
        		<?php foreach ($details as $row){ ?>
        		<tr>
        			<td><?=GetUserById($row['dtl_userid'], 'user_name')?></td>
        			<td><?=date('d/m/Y', $row['dtl_time'])?></td>
        			<td><?=date('h:i A', $row['dtl_time'])?></td>
        			<td><?=$row['dtl_notes']?></td>
        		</tr>
        		<?php } ?>
        	</table>
		</div>
		<a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية</div>
            <table class="table">
                <tr>
                    <th>نوع المواد</th>
                    <th>الكمية</th>  
                    <th>اسم المشروع</th>
                    <th></th> 
                </tr>
                <?php if (isset($donations) and count($donations)){ ?>
                <?php foreach ($donations as $row){ ?>
                <tr>
                    <td><?=$row['r_kind']?></td>
                    <td><?=$row['r_amount']?></td>  
              		<td><?=GetProjectsLabel($row['r_project'])?></td> 
                    <td>
                        <a href="<?=base_url()?>reqthings/archive/<?=$row['r_id']?>" class="btn btn-primary">عرض</a>
                    </td>
                </tr>
                <?php } ?>
                <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div><?=$paging?><br/>
        <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
