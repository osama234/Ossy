<?php if($act=='edit')
{?>
	<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($restoration['dtl_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ardate('d/m/Y', $restoration['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$restoration['dtl_notes']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th width="20%">نوع المواد</th>
					<td><?=$restoration['r_kind']?></td>
				</tr>
				<tr>
					<th width="20%">كمية المواد / عددها</th>
					<td><?=$restoration['r_amount']?></td>
				</tr>
 
				<tr>
					<th width="20%">اسم المشروع</th>
					<td><?=GetProjectsLabel($restoration['r_project'])?></td>
				</tr>
				<tr>
					<th width="20%">الغرض من الطلب</th>
					<td><?=$restoration['r_purpose']?></td>
				</tr>
				<tr>
					<th width="20%">تاريخ الشراء</th>
					<td><?=$restoration['r_date']?></td>
				</tr>
				<tr>
					<th width="20%">القيمة الشرائية</th>
					<td><?=$restoration['r_cost']?></td>
				</tr>
				<tr>
					<th width="20%">الماحظات</th>
					<td><?=$restoration['r_note']?></td>
				</tr>
				
				
			</table>
		</div>
		<form action="<?=base_url()?><?=$app1?>/<?=$dir?>/edit/<?=$restoration['r_id']?>" method="post" data-toggle="validator" role="form">
			<div class="panel panel-primary">
				<div class="panel-heading">إعتماد بلاغات</div>
				<table class="table">
					<tr>
						<th width="20%">القرار</th>
						<td>
							<input type="radio" name="dtl[dtl_status]" id="rt_status1" value="<?=$status+1?>" /><label for="dtl_status1">اعتماد مبدئي لطلب </label>
							<input type="radio" name="dtl[dtl_status]" id="rt_status2" value="0" /><label for="dtl_status2">ملاحظات</label>
						</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[dtl_notes]" rows="3" ></textarea></td>
					</tr>
					<tr>
						<th></th>
						<td><button type="submit" class="btn btn-primary">حفظ واعتماد</button></td>
					</tr>
				</table>
			</div>
		</form>













<?}else{?>
	<div class="panel panel-primary">
			<div class="panel-heading"><?=$appname?></div>
			<table class="table">
				<tr>
                    <th>نوع المواد</th>
                    <th>الكمية</th>  
                    <th>اسم المشروع</th>
                    <th></th>
                </tr>
			<?
			if(isset($restorations))  
			
			   foreach($restorations as $row )
                 {			?>
			 <tr>
                    
                    <td><?=$row['r_kind']?></td>
                    <td><?=$row['r_amount']?></td>  
              		<td><?=GetProjectsLabel($row['r_project'])?></td> 
                    <td><a href="<?=base_url()?><?=$app1?>/<?=$dir?>/edit/<?=$row['r_id']?>" class="btn btn-primary">عرض</a></td>
				 
             </tr>
                     		<? }?> </table></div> 
                  	
			<a href="#" class="btn btn-warning print_btn">طباعة</a><br/><?=$paging?>						
			<?}?>
