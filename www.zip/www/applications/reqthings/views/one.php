<?php if($act=='show')
{?>
	<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th wr_idth="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserByr_id($restorations_dtl['rt_userr_id'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=date('d/m/Y', $restorations_dtl['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$restorations_dtl['rt_notes']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th wr_idth="20%">نوع المواد</th>
					<td><?=$restorations_dtl['r_kind']?></td>
				</tr>
				<tr>
					<th wr_idth="20%">كمية المواد</th>
					<td><?=$restorations_dtl['r_amount']?></td>
				</tr>
 
				<tr>
					<th wr_idth="20%">اسم المشروع</th>
					<td><?=$restorations_dtl['r_project']?></td>
				</tr>
				<tr>
					<th wr_idth="20%">الغرض من الطلب</th>
					<td><?=$restorations_dtl['r_purpose']?></td>
				</tr>
				<tr>
					<th wr_idth="20%">القيمة الشرائية</th>
					<td><?=$restorations_dtl['r_cost']?></td>
				</tr>
				<tr>
					<th wr_idth="20%">تاريخ الشراء</th>
					<td><?=$restorations_dtl['r_date']?></td>
				</tr>
				<tr>
					<th wr_idth="20%">الماحظات</th>
					<td><?=$restorations_dtl['r_note']?></td>
				</tr>
				
				
			</table>
		</div>
		<form action="<?=base_url()?>reqthings/approval/show/<?=$restorations_dtl['rt_r_id']?>" method="post" data-toggle="valr_idator" role="form">
			<div class="panel panel-primary">
				<div class="panel-heading">تحديث بيانات طلب مواد</div>
				<table class="table">
					<tr>
						<th wr_idth="20%">القرار</th>
						<td>
							<input type="radio" name="dtl[rt_status]" r_id="rt_status1" value="2" /><label for="dtl_status1">اعتماد مبدئي لطلب </label>
								<input type="radio" name="dtl[rt_status]" r_id="rt_status2" value="1" /><label for="dtl_status2">ملاحظات</label>
						</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[rt_notes]" rows="3" ></textarea></td>
					</tr>
					<tr>
						<th></th>
						<td><button type="submit" class="btn btn-primary">حفظ واعتماد</button></td>
					</tr>
				</table>
			</div>
		</form>













<?}else{?>
	<div class="panel panel-primary">
			<div class="panel-heading">طلبات العهد المدققة</div>
			<table class="table">
				<tr>
                    <th>نوع المواد</th>
                    <th>اسم المشروع</th> 
			        <th>حالة الطلب</th>
                    <th>إجراءات</th>
                </tr>
			<?
			if(isset($restorations))  
			
			   foreach($restorations as $row )
                 {			?>
			 <tr <?=($row['rt_status'] < 0 ? ' class="danger"':'')?>>
                    
                    <td><?=$row['r_kind']?></td>
                    <td><?=$row['r_project']?></td> 
					  <td><?=($row['rt_status']==2 ? 'تم التدقيق':'')?></td>
              
                 <td><a href="<?=base_url()?>reqthings/approval/show/<?=$row['r_id']?>" class="btn btn-primary">عرض</a></td>
				 
                </tr>
                     		<? }?> </table></div> 
                  				<?=$paging?><br/>
<a href="#" class="btn btn-warning print_btn">طباعة</a>			
			<?}?>
