<?php if (isset($restoration)) { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">بيانات الطلب</div>
        <table class="table">
            <tr>
                <th width="20%">رقم المستفيد</th>
                <td>
                    <?= $restoration['r_no'] ?>
                    <button type="button" class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#myModal">عرض بيانات المستفيد</button>
                </td>
            </tr>
            <tr>
                <th>اسم المستفيد</th>
                <td><?= $restoration['b_name'] ?></td>
            </tr>
            <tr>
                <th>الحي</th>
                <td><?= $restoration['r_dist'] ?></td>
            </tr>
        </table>
        <br />
        <table class="table table-bordered">
            <tr class="active">
                <th>بحاجة لصيانة</th>
                <th>عدد</th>
                <th>القيمة</th>
                <th>ملاحظات</th>
            </tr>
            <?php foreach ($restoration['r_data']['need'] as $key => $value) { ?>
                <tr>
                    <td><?= $restoration['r_data']['need'][$key] ?></td>
                    <td><?= $restoration['r_data']['count'][$key] ?></td>
                    <td><?= $restoration['r_data']['cost'][$key] ?></td>
                    <td><?= $restoration['r_data']['notes'][$key] ?></td>
                </tr>
            <?php } ?>
        </table>
        <br />
        <table class="table">
            <?php if (!empty($restoration['r_pictures'])) { ?>
                <tr>
                    <th>صور المعاينة قبل الصيانة</th>
                    <td>
                        <?php foreach ($restoration['r_pictures'] as $pic) { ?>
                            <a href="<?= base_url($pic['path']) ?>"><?= $pic['filename'] ?></a><br />
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
            <tr>
                <th width="20%">تاريخ تسجيل المعاينة</th>
                <td><?= $restoration['r_date'] ?></td>
            </tr>
            <tr>
                <th>تمت المعاينة من قبل</th>
                <td><?= $restoration['r_visor'] ?></td>
            </tr>
        </table>
        <?php if (is_array($restoration['r_data2'])) { ?>
            <br />
            <table class="table table-bordered">
                <tr class="active">
                    <th>تم صيانة</th>
                    <th>عدد</th>
                    <th>القيمة</th>
                    <th>ملاحظات</th>
                </tr>
                <?php foreach ($restoration['r_data2']['need'] as $key => $value) { ?>
                    <tr>
                        <td><?= $restoration['r_data2']['need'][$key] ?></td>
                        <td><?= $restoration['r_data2']['count'][$key] ?></td>
                        <td><?= $restoration['r_data2']['cost'][$key] ?></td>
                        <td><?= $restoration['r_data2']['notes'][$key] ?></td>
                    </tr>
                <?php } ?>
            </table>
            <br />
            <table class="table">
                <?php if (!empty($restoration['r_pictures2'])) { ?>
                    <tr>
                        <th>صور المعاينة بعد الصيانة</th>
                        <td>
                            <?php foreach ($restoration['r_pictures2'] as $pic) { ?>
                                <a href="<?= base_url($pic['path']) ?>"><?= $pic['filename'] ?></a><br />
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
                <tr>
                    <th width="20%">التكلفة الإجمالية</th>
                    <td><?= $restoration['r_total'] ?></td>
                </tr>
                <tr>
                    <th>تاريخ المعاينة</th>
                    <td><?= $restoration['r_view_date'] ?></td>
                </tr>
                <?php if (!empty($restoration['r_bills'])) { ?>
                    <tr>
                        <th>صورة الفاتورة</th>
                        <td>
                            <?php foreach ($restoration['r_bills'] as $pic) { ?>
                                <a href="<?= base_url($pic['path']) ?>"><?= $pic['filename'] ?></a><br />
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        <?php } ?>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">سجل العمليات</div>
        <table class="table">
            <tr>
                <th>المستخدم</th>
                <th>التاريخ</th>
                <th>الوقت</th>
                <th>العملية</th>
                <th>ملاحظات</th>
            </tr>
            <?php foreach ($details as $row) { ?>
                <tr>
                    <td><?= GetUserById($row['dtl_userid'], 'user_name') ?></td>
                    <td><?= ArDate('d/m/Y', $row['dtl_time']) ?></td>
                    <td><?= date('h:i A', $row['dtl_time']) ?></td>
                    <td><?= $row['process'] ?></td>
                    <td><?= $row['dtl_notes'] ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">بيانات المستفيد</h4>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    <script>
        $("#myModal").on("show.bs.modal", function (e) {
            var link = $(e.relatedTarget);
            $(this).find(".modal-body").load('<?= base_url() ?>sheet.php?id=<?= $restoration['r_no'] ?>');
                });
    </script>
<?php } else { ?>
    <div class="panel panel-primary">
        <div class="panel-heading">طلبات ترميم وصيانة المنازل</div>
        <table class="table">
            <tr>
                <th>رقم المستفيد</th>
                <th>اسم المستفيد</th>
                <th>الحي</th>
            </tr>
            <?php if (isset($restorations) and count($restorations)) { ?>
                <?php foreach ($restorations as $row) { ?>
                    <tr<?= ($row['dtl_status'] < 0 ? ' class="danger"' : '') ?>>
                        <td><?= $row['r_no'] ?></td>
                        <td><?= $row['b_name'] ?></td>
                        <td><?= $row['r_dist'] ?></td>
                        <td><a href="<?= base_url() ?>restoration/archive/<?= $row['r_id'] ?>" class="btn btn-primary">عرض</a></td>
                    </tr>

                <?php } ?>
            <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
            <?php } ?>
        </table>
    </div><?= $paging ?><br/>
    <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
