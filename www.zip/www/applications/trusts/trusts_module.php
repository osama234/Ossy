<?php
	class trusts_controller extends controller
	{
		function __construct() {
            parent::__construct();
        }
        
        function index($params=null) {
			return(true);
		}
		
		
		public function rtrust($act='',$id='')
		
		{ $this->vars['act']=$act;
		 
		  if($act=='add' and isset($_POST['rtrusts']))
		   {
		   
		   $rtrusts=$_POST['rtrusts'];
		  print_r($rtrusts);
		   $sql = $this->mydb->sql_insert('trusts',$rtrusts);
		   $this->mydb->execute($sql,$rtrusts);
		   
		   $dtl['rt_id'] = $this->mydb->insert_id();
						$dtl['rt_userid'] = $this->user['user_id'];
						$dtl['dtl_islast'] = 1;
						$dtl['dtl_time'] = time();
						$dtl['rt_notes'] = $rtrusts['rt_desc'];
					   $sql2 = $this->mydb->sql_insert('trusts_dtl', $dtl);
						
		  if($this->mydb->execute($sql2, $dtl))
		   {
		   SetMessage('تم حفظ الطلب بنجاح','success');
		   redirect('trusts/rtrust');
		    }
			
		   
		   }elseif($act=='update' and $id){
				
				   if(isset($_POST['rtrusts']))
				  {
				     
						    $rtrusts=$_POST['rtrusts'];
					
						  
						  
		               $rt_rtl=array('rt_id'=>$id,'rt_notes'=>$rtrusts['rt_desc'],'rt_userid'=>$this->user['user_id'],'dtl_time'=>time(),'dtl_islast'=>1);
					     
						 
				       if(isset($rtrusts['rt_status']))
					    { $rt_rtl['rt_status']=$rtrusts['rt_status'];
					     unset($rtrusts['rt_status']);
						 }
					  $this->update_dtl('trusts_dtl','dtl_islast',array('rt_id'=>$id));
					  
		               $sql = $this->mydb->sql_update('trusts',$rtrusts,array('id'=>$id));
					    $sql2 = $this->mydb->sql_insert('trusts_dtl',$rt_rtl);
		              if($this->mydb->execute($sql,$rtrusts) and $this->mydb->execute($sql2,$rt_rtl))
		                 { SetMessage('تم حفظ التعديلات بنجاح','success');
		                    redirect('trusts/rtrust');
		                  }
						  
				  }
				    
				       $q = $this->mydb->execute('SELECT * FROM trusts INNER JOIN trusts_dtl ON (id=rt_id) where dtl_islast =1 and id=:id',array('id'=>$id));
				         while ($row = $this->mydb->fetch_assoc($q)) {
					     $this->vars['rtrusts'] = $row;
						 	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rtrusts']['rt_status']);
				         }
				  }	 
		    else {
				 $sql = 'SELECT * FROM trusts INNER JOIN trusts_dtl ON (id=rt_id) where dtl_islast =1 and (rt_status=0 or rt_status=-1 or rt_status=7)';$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['trusts'][] = $row;
				}}
		
		
		
		
		
		}
		
		
		public function auditinfo($act='',$id='')
		{
		$this->vars['act']=$act;
		  if($act=='add' and isset($_POST['rccheck']))
				  {
				       $rccheck=$_POST['rccheck'];
		               $rt_dtl=array('rt_id'=>$id,'rt_notes'=>$rccheck['rt_desc'],'rt_userid'=>$this->user['user_id'],'dtl_time'=>time(),'dtl_islast'=>1);
					  $this->update_dtl('trusts_dtl','dtl_islast',array('rt_id'=>$id));
					  
		               $sql = $this->mydb->sql_update('trusts',$rccheck,array('id'=>$id));
					    $sql2 = $this->mydb->sql_insert('trusts_dtl',$rt_dtl);
		              if($this->mydb->execute($sql,$rccheck) and $this->mydb->execute($sql2,$rt_dtl))
		                 { SetMessage('تم حفظ التعديلات بنجاح','success');
		                    redirect('trusts/rtrust');
		                  }
						  
				}elseif($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rt_userid']=$this->user['user_id'];
					 $dtl['rt_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('trusts_dtl','dtl_islast',array('rt_id'=>$id));
					   $sql = $this->mydb->sql_insert('trusts_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم حفظ الإجراء بنجاح','success');
		                    redirect('trusts/auditinfo');
							
							
							}
					  }
			    
                  $q = $this->mydb->execute(' SELECT * FROM trusts INNER JOIN trusts_dtl ON (id=rt_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rt_status']);
				  
				  }else {
				 $sql = 'SELECT * FROM trusts INNER JOIN trusts_dtl ON (trusts_dtl.rt_id=trusts.id) where dtl_islast =1 and ( rt_status=0 or rt_status=9 or rt_status=10 )';$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row;
				}}
		
		}
		
		
		
		
		
		
		public function auditing($act='' , $id='')
		 {
		         	$this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rt_userid']=$this->user['user_id'];
					 $dtl['rt_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('trusts_dtl','dtl_islast',array('rt_id'=>$id));
					   $sql = $this->mydb->sql_insert('trusts_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم التدقيق بنجاح','success');
		                    redirect('trusts/auditing');
							
							
							}
					  }
			    
                  $q = $this->mydb->execute(' SELECT * FROM trusts INNER JOIN trusts_dtl ON (id=rt_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rt_status']);
				  
				  }


  			 else{  $sql = 'SELECT * FROM trusts INNER JOIN trusts_dtl ON (trusts_dtl.rt_id=trusts.id) where dtl_islast =1 and rt_status=1 ';$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row;
				}
		        }
		 
		 
		 }
		 
		 public function approval($act='',$id='')
		 
		 { 
		   
		   
		   	$this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				  print_r($_POST['dtl']);
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl']; 
					
					 $dtl['rt_userid']=$this->user['user_id'];
					 $dtl['rt_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('trusts_dtl','dtl_islast',array('rt_id'=>$id));
					   $sql = $this->mydb->sql_insert('trusts_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم حفظ الإجراء بنجاح','success');
		                    redirect('trusts/approval');
							
							
							}
					  }
			    
                  $q = $this->mydb->execute(' SELECT * FROM trusts INNER JOIN trusts_dtl ON (id=rt_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rt_status']);
				  
				  }


  			 else{  $sql = 'SELECT * FROM trusts INNER JOIN trusts_dtl ON (trusts_dtl.rt_id=trusts.id) where dtl_islast =1 and rt_status=2  ';$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row; 
				}
		        }
		 
		 
		 
		 
		 
		  }
		  
		  public function records($act='',$id='')
		  {
		   	$this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rt_userid']=$this->user['user_id'];
					 $dtl['rt_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('trusts_dtl','dtl_islast',array('rt_id'=>$id));
					   $sql = $this->mydb->sql_insert('trusts_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم حفظ الإجراء بنجاح','success');
		                    redirect('trusts/records');
							
							
							}
					  } 
			    
                  $q = $this->mydb->execute(' SELECT * FROM trusts INNER JOIN trusts_dtl ON (id=rt_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rt_status']);
				  
				  }


  			 else{  $sql = 'SELECT * FROM trusts INNER JOIN trusts_dtl ON (trusts_dtl.rt_id=trusts.id) where dtl_islast =1 and (rt_status=3 or rt_status=-3) ';$this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row; 
				}
		        }
             
		  
		  }
		  
		  public function executive($act='',$id='')
		  {
		  $this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rt_userid']=$this->user['user_id'];
					 $dtl['rt_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('trusts_dtl','dtl_islast',array('rt_id'=>$id));
					   $sql = $this->mydb->sql_insert('trusts_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم حفظ الإجراء بنجاح','success');
		                    redirect('trusts/executive');
							
							
							}
					  }
			    
                    $q = $this->mydb->execute(' SELECT * FROM trusts INNER JOIN trusts_dtl ON (id=rt_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rt_status']);
				  
				  }


  			 else{ $sql = 'SELECT * FROM trusts INNER JOIN trusts_dtl ON (trusts_dtl.rt_id=trusts.id) where dtl_islast =1 and (rt_status=4  or rt_status=5 or rt_status=-4)'; $this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row; 
				}
		        }
		  
		  }
		  
		  
		  public function wtrust($act='',$id='')
		  
		  {
		   $this->vars['act']=$act;
				 
				 if($act=='show' and $id!='')
				{
				
				   if(isset($_POST['dtl']))
				      {
					
					  $dtl=$_POST['dtl'];
					 $dtl['rt_userid']=$this->user['user_id'];
					 $dtl['rt_id']=$id;
					 $dtl['dtl_islast']=1;
					 $dtl['dtl_time']=time();
					   $this->update_dtl('trusts_dtl','dtl_islast',array('rt_id'=>$id));
					   $sql = $this->mydb->sql_insert('trusts_dtl',$dtl);
					   
					     if($this->mydb->execute($sql,$dtl))
						    {
							SetMessage('تم حفظ الإجراء بنجاح','success');
		                    redirect('trusts/wtrust');
							
							
							}
					  }
			    
                   $q = $this->mydb->execute(' SELECT * FROM trusts INNER JOIN trusts_dtl ON (id=rt_id) where id=:id and dtl_islast =1',array('id'=>$id));    
                    $row = $this->mydb->fetch_assoc($q);
				
					$this->vars['rccheck_dtl']= $row;
				   	$this->vars['lastProcess'] = $this->getLastProcess($this->vars['rccheck_dtl']['rt_status']);
				  
				  }


  			 else{ $sql = 'SELECT * FROM trusts INNER JOIN trusts_dtl ON (trusts_dtl.rt_id=trusts.id) where dtl_islast =1 and (rt_status=6 or rt_status=8) '; $this->vars['paging'] = PagingSQL($sql);$q = $this->mydb->execute($sql);
				while ($row = $this->mydb->fetch_assoc($q)) {
					$this->vars['rccheck'][] = $row; 
				}
		        }
		  
		  
		  
		  }
		  
		  
		  
		  
		  
		  
		  
		public function update_dtl($table='',$field='',$where)
		{
		   $sql= $this->mydb->sql_update($table,array($field=>0),$where);
		   if($this->mydb->execute($sql))
		   return true;
		   else
		   return false;
		}
		
			
		private function getLastProcess($status) {
			switch (abs($status)) {
				case 0: return 'تسجيل طلب عهدة';
				case 1: return 'فحص طلب عهدة';
				case 2: return 'تدقيق طلب عهدة';
				case 3: return 'اعتماد مبدئي لطلب العهدة';
				case 4: return 'اعداد محضر صرف مالي';
				case 5: return 'اعداد محضر صرف مالي';
				case 6: return 'اعتماد محضر صرف مالي';
				case 7: return 'تحرير صرف عهدة';
				case 8: return 'استلام العهدة';
				case 9: return 'استلام نقدي';
				case 10: return 'تسجيل قيد العهدة';
				
			}
		}
		}
		
		
