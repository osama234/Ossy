<?php if($act=='show')
{?>
	<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($rccheck_dtl['rt_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=date('d/m/Y', $rccheck_dtl['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$rccheck_dtl['rt_notes']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المستفيد</th>
					<td><?=$rccheck_dtl['recipient_name']?></td>
				</tr>
				<tr>
					<th width="20%">جهة المستفيد</th>
					<td><?=$rccheck_dtl['recipient_d']?></td>
				</tr>
				<tr>
					<th width="20%">قيمة الشيك</th>
					<td><?=$rccheck_dtl['t_amount']?></td>
				</tr>
				<tr>
					<th width="20%">تاريخ طلب الصرف</th>
					<td><?=$rccheck_dtl['rt_date']?></td>
				</tr>
				<tr>
					<th width="20%">اسم المشروع</th>
					<td><?=GetProjectsLabel($rccheck_dtl['proj_name'])?></td>
				</tr>
				
				
			</table>
		</div>
		<form action="<?=base_url()?>trusts/approval/show/<?=$rccheck_dtl['rt_id']?>" method="post" data-toggle="validator" role="form">
			<div class="panel panel-primary">
				<div class="panel-heading">الإجراء المتخذ</div>
				<table class="table">
					<tr>
						<th width="20%">القرار</th>
						<td>
							<input type="radio" name="dtl[rt_status]" id="rt_status1" value="3" /><label for="dtl_status1">اعتماد مبدئي لطلب العهدة</label>
								<input type="radio" name="dtl[rt_status]" id="rt_status2" value="4" /><label for="dtl_status2">ملاحظات</label>
						</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[rt_notes]" rows="3" class="form-control" ></textarea></td>
					</tr>
					<tr>
						<th></th>
						<td><button type="submit" class="btn btn-primary">حفظ واعتماد</button></td>
					</tr>
				</table>
			</div>
		</form>













<?}else{?>
	<div class="panel panel-primary">
			<div class="panel-heading">طلبات العهد المدققة</div>
			<table class="table">
				<tr>
                    <th>اسم المستفيد</th>
                    <th>جهة المستفيد</th>
                    <th>المبلغ</th>
                    <th>اسم المشروع</th>
			        <th>حالة الطلب</th>
                    <th>إجراءات</th>
                </tr>
			<?
			if(isset($rccheck))  
			
			   foreach($rccheck as $row )
                 {			?>
			 <tr <?=($row['rt_status'] < 0 ? ' class="danger"':'')?>>
                    
                    <td><?=$row['recipient_name']?></td>
                    <td><?=$row['recipient_d']?></td>
                    <td><?=$row['t_amount']?></td>
					 <td><?=GetProjectsLabel($row['proj_name'])?></td>
					  <td><?=($row['rt_status']==2 ? 'تم التدقيق':'')?></td>
              
                 <td><a href="<?=base_url()?>trusts/approval/show/<?=$row['id']?>" class="btn btn-primary">عرض</a></td>
				 
                </tr>
                     		<? }?> </table></div><?=$paging?><br/><a href="#" class="btn btn-warning print_btn">طباعة</a>
                  							
			<?}?>
