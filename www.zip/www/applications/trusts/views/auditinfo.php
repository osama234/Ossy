<?php  if (isset($rccheck_dtl )){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($rccheck_dtl['rt_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=date('d/m/Y', $rccheck_dtl['dtl_time'])?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$rccheck_dtl['rt_notes']?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المستفيد</th>
					<td><?=$rccheck_dtl['recipient_name']?></td>
				</tr>
				<tr>
					<th width="20%">جهة المستفيد</th>
					<td><?=$rccheck_dtl['recipient_d']?></td>
				</tr>
				<tr>
					<th width="20%">قيمة العهدة</th>
					<td><?=$rccheck_dtl['t_amount']?></td>
				</tr>
				<tr>
					<th width="20%">تاريخ طلب الصرف</th>
					<td><?=$rccheck_dtl['rt_date']?></td>
				</tr>
				<tr>
					<th width="20%">اسم المشروع</th>
					<td><?=GetProjectsLabel($rccheck_dtl['proj_name'])?></td>
				</tr>
				
				
			</table>
		</div>
		<?if($rccheck_dtl['rt_status']!=10){?>
		<form action="<?=base_url()?>trusts/auditinfo/show/<?=$rccheck_dtl['rt_id']?>" method="post" data-toggle="validator" role="form">
			<div class="panel panel-primary">
			  
				<div class="panel-heading">الإجراء المتخذ</div>
				<table class="table">
					<tr>
						<th width="20%">القرار</th>
						
						<?if($rccheck_dtl['rt_status']==0){?>
						<td>
							<input type="radio" name="dtl[rt_status]" id="rt_status1" value="1" /><label for="dtl_status1">تم فحص البيانات</label>
							<input type="radio" name="dtl[rt_status]" id="rt_status2" value="-1" /><label for="dtl_status2">ملاحظات</label>
							
							</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[rt_notes]" class="form-control" rows="3" ></textarea></td>
					</tr>
					<?}elseif($rccheck_dtl['rt_status']==9){?>
					<td>
					<input type="radio" name="dtl[rt_status]" id="rt_status1" value="10" /><label for="dtl_status1">تسجيل قيد العهدة</label>
					
					</td>
					<?}else{?>
					<td>
					<input type="radio" name="dtl[rt_status]" id="rt_status1" value="9" /><label for="dtl_status1">تسجيل</label>
					
					</td>
					<?}?>

					
					<tr>
						<th></th>
						<td><button type="submit" class="btn btn-primary">حفظ واعتماد</button></td>
					</tr>
				</table>
			</div>
		</form><?}?>
<?php } else{?>
			<div class="panel panel-primary">
			<div class="panel-heading">طلبات العهد المسجلة</div>
			<table class="table">
				<tr>
                    <th>اسم المستفيد</th>
                    <th>جهة المستفيد</th>
                    <th>المبلغ</th>
                    <th>اسم المشروع</th>
					 <th>حالة الطلب</th>
                    <th>إجراءات</th>
                </tr>
			<?
			if(isset($rccheck))
			
			   foreach($rccheck as $row )
                 {			?>
				 <tr <?=($row['rt_status']==9 ? ' class="success"':($row['rt_status']==10 ? 'class="danger"' :'') )?>>
                    
                    <td><?=$row['recipient_name']?></td>
                    <td><?=$row['recipient_d']?></td>
                    <td><?=$row['t_amount']?></td>
					 <td><?=GetProjectsLabel($row['proj_name'])?></td>
					  <td><?=($row['rt_status']==9 ? 'تم الاستلام النقدي' :($row['rt_status']==10 ? 'تم إغلاق الطلب': 'جديد')  )?></td>
                    <td><a href="<?=base_url()?>trusts/auditinfo/show/<?=$row['id']?>" class="btn btn-primary">عرض</a></td>
                </tr>
                     		<? }?> </table></div><?=$paging?><br/><a href="#" class="btn btn-warning print_btn">طباعة</a>
                  							
			 </div><?}?>
