	<?php  if($act=='add'){?>
            <div class="panel panel-primary">
			  <div class="panel-heading">تسجل طلب عهدة</div>
			<div class="panel-body">
			<form action="<?=base_url()?>trusts/rtrust/add" method="post" data-toggle="validator" role="form">
			
				<div class="form-group">
					<label for="rtrusts[recipient_name]" class="control-label">اسم المستفيد :</label>
					<input type="text" name="rtrusts[recipient_name]" value="" id="rtrusts[recipient_name]"  class="form-control"  required="true" />
				</div>
				<div class="form-group ">
				
					<label for="rtrusts[recipient_d]" class="control-label">جهة المستفيد : </label>
					<input type="text" name="rtrusts[recipient_d]" value="" id="rtrusts[recipient_d]"  class="form-control" required="true" />
				</div>
				<div class="form-group">
					<label for="rtrusts[purpose]" class="control-label">الغرض</label>
					<input type="text" name="rtrusts[purpose]" value="" id="rtrusts[purpose]"  class="form-control"  required="true"/>
				</div>
				<div class="form-group">
					<label for="rtrusts[t_amount]" class="control-label">القيمة</label>
					<input type="text" name="rtrusts[t_amount]" value="" id="rtrusts[t_amount]"  class="form-control"  required="true"/>
				</div>
				<div class="form-group">
					<label for="rtrusts[rt_date]" class="control-label">تاريخ تقديم طلب العهدة</label>
					<input type="date" name="rtrusts[rt_date]" value="" id="rtrusts[rt_date]"  class="form-control datepicker" required="true" />
				</div>
				<div class="form-group">
					<label for="rtrusts[proj_name]" class="control-label">اسم المشروع</label>
					<select  class="form-control"name="donate[d_project]"><?=GetProjects((int ) $donation['d_project'])?></select>
				</div>
				
				<div class="form-group">
					<label for="rtrusts[rt_desc]" class="control-label">ملاحظات</label>
				<textarea  id="rtrusts[rt_desc]" name="rtrusts[rt_desc]" class="form-control"></textarea>
				</div>
				<div class="form-group ">
			<input type="submit" value="حفظ وإعتماد" class="btn btn-primary btn-md ">
					 <a href="#" class="btn btn-primary btn-md ">طباعة</a>
				</div>
            </form>
     

            </div></div>
           
      
			<?}elseif($act=='update'){  ?>
				<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($rtrusts['rt_userid'], 'user_name')?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=date('d/m/Y', $rtrusts['dtl_time'])?></td>
				</tr>
				<tr>
					<th>الملاحظات</th>
					<td><?=$rtrusts['rt_notes']?></td>
				</tr>
			</table>
		</div>
			
			<div class="panel panel-primary">
			  <div class="panel-heading">تعديل طلب عهدة</div>
			<div class="panel-body">
			<form action="<?=base_url()?>trusts/rtrust/update/<?=$rtrusts['id']?>" method="post" data-toggle="validator" role="form">
			
				<div class="form-group">
					<label for="rtrusts[recipient_name]" class="control-label" >اسم المستفيد :</label>
					<input type="text" name="rtrusts[recipient_name]"  id="rtrusts[recipient_name]" value="<?=$rtrusts['recipient_name']?>"   class="form-control"  required="true" />
				</div>
				<div class="form-group ">
				
					<label for="rtrusts[recipient_d]" class="control-label" >جهة المستفيد : </label>
					<input type="text" name="rtrusts[recipient_d]"  id="rtrusts[recipient_d]"  class="form-control" required="true" value="<?=$rtrusts['recipient_d']?>" />
				</div>
					<div class="form-group">
					<label for="rtrusts[purpose]" class="control-label">الغرض</label>
					<input type="text" name="rtrusts[purpose]"  id="rtrusts[purpose]"   class="form-control" value="<?=$rtrusts['purpose']?>"  required="true"/>
				</div>
				<div class="form-group">
					<label for="rtrusts[t_amount]" class="control-label">القيمة</label>
					<input type="text" name="rtrusts[t_amount]"  id="rtrusts[t_amount]"  class="form-control" value="<?=$rtrusts['t_amount']?>"  required="true" />
				</div>
				
				<div class="form-group">
					<label for="rtrusts[rt_date]" class="control-label">تاريخ تقديم طلب العهدة</label>
					<input type="text" name="rtrusts[rt_date]" id="rtrusts[rt_date]"  class="form-control" required="true" value="<?=$rtrusts['rt_date']?>" />
				</div>
				<div class="form-group">
					<label for="rtrusts[proj_name]" class="control-label">اسم المشروع</label>
					<select  class="form-control"name="rtrusts[proj_name]"><?=GetProjects((int ) $rtrusts['proj_name'])?></select>
				</div>
				<?   if($rtrusts['rt_status'] <= 0){?>
               <div class="form-group">
					<label for="rtrusts[rt_desc]" class="control-label">ملاحظات</label>
				<textarea  id="rtrusts[rt_desc]" name="rtrusts[rt_desc]" class="form-control" ><?=$rtrusts['rt_desc']?></textarea>
				</div>
<?php }else{ ?>
	<input type="radio" name="rtrusts[rt_status]" id="rt_status1" value="8" /><label for="dtl_status1">استلام</label>
<?php } ?>			
			<div class="form-group ">	
			<input type="submit" value="حفظ وإعتماد" class="btn btn-primary btn-md ">
				</div>
            </form>
			<?php }else{ ?>
			<div class="panel panel-primary">
			<div class="panel-heading">طلبات العهد المسجلة</div>
			<table class="table">
				<tr>
                    <th>اسم المستفيد</th>
                    <th>جهة المستفيد</th>
                    <th>المبلغ</th>
                    <th>اسم المشروع</th>
			        <th>حالة الطلب</th>
                    <th>إجراءات</th>
                </tr>
			<?php if(isset($trusts)) {?>
			<?php foreach($trusts as $row ) { ?>
			 	<tr <?=($row['rt_status'] < 0 ? ' class="danger"':($row['rt_status']==7 ? ' class="success"':'' ))?>>
                    <td><?=$row['recipient_name']?></td>
                    <td><?=$row['recipient_d']?></td>
                    <td><?=$row['t_amount']?></td>
					<td><?=GetProjectsLabel($row['proj_name'])?></td>
					<td><?=($row['rt_status']<0 ? 'يوجد ملاحظات' :($row['rt_status']==7 ? 'بإنتظار الإستلام' : 'جديد') )?></td>
					<? if($row['rt_status'] <= 0){?>
					<td><a href="<?=base_url()?>trusts/rtrust/update/<?=$row['id']?>" class="btn btn-warning">تحديث</a></td>
					<?php }else{ ?>
					 <td><a href="<?=base_url()?>trusts/rtrust/update/<?=$row['id']?>" class="btn btn-success">عرض و استلام</a></td>
					<?php } ?>				 
                </tr>
         		<?php } ?>
         		<?php } ?>
              </table>
              </div>
              <a href="<?=base_url()?>trusts/rtrust/add" class="btn btn-success">تسجيل طلب جديد</a>
              <a href="#" class="btn btn-warning print_btn">طباعة</a>
              </div>
			  <?=$paging?><br/>
              <?php } ?>
