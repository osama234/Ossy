<?php

class used_controller extends controller {
	function __construct() {
		parent::__construct();
	}

	function index($params = null) {
		return (true);
	}

	private $t1 = 'used';
	private $t2 = 'dtl_used';
	private $t3 = 'used_matrial';
	private $appname = 'used';
	private $t1id = 'u_id';
	function add($act = '', $id = 0) {

		if ($act == 'add') {
			if (isset($_POST[$this -> t1])) {
				
				$_POST[$this -> t1]['u_data'] = serialize($_POST[$this -> t1]['u_data']);
				$reqthings = $this -> validateData($_POST[$this -> t1], $act);

				if ($reqthings) {
					$reqthings['u_data'] = serialize($reqthings['u_data']);
					$sql = $this -> mydb -> sql_insert($this -> t1, $reqthings);
					$this -> mydb -> execute($sql, $reqthings);

					$dtl['id'] = $this -> mydb -> insert_id();
					$dtl['dtl_userid'] = $this -> user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];

					$sql = $this -> mydb -> sql_insert($this -> t2, $dtl);
					$this -> mydb -> execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect($this -> appname . '/add');
				}
			}
		} elseif ($act == 'edit') {
			if (isset($_POST[$this -> t1])) {
				
				$_POST[$this -> t1]['u_data'] = serialize($_POST[$this -> t1]['u_data']);
				$reqthings = $this -> validateData($_POST[$this -> t1], $act);
				 
				if ($reqthings) {
					 
					$this -> mydb -> execute($this -> mydb -> sql_update($this -> t1, $reqthings, array('u_id' => $id)), $reqthings, 1);
					$dtl['id'] = $id;
					$dtl['dtl_userid'] = $this -> user['user_id'];
					$dtl['dtl_islast'] = 1;
					$dtl['dtl_time'] = time();
					$dtl['dtl_notes'] = $_POST['dtl']['d_notes'];

					$this -> mydb -> execute('UPDATE ' . $this -> t2 . ' SET dtl_islast=0 WHERE id=:id', array('id' => $id));
					$sql = $this -> mydb -> sql_insert($this -> t2, $dtl);
					$this -> mydb -> execute($sql, $dtl);
					setMessage('تم حفظ البيانات بنجاح', 'success');
					redirect($this -> appname . '/add');
				}
			}
			$sql = 'SELECT * FROM ' . $this -> t1 . ' INNER JOIN ' . $this -> t2 . ' ON (id=u_id AND dtl_islast=1) WHERE dtl_status<=0 AND u_id=:id';
			$this -> vars[$this -> t1] = $this -> mydb -> fetch_assoc($this -> mydb -> execute($sql, array('id' => $id)));
			$this -> vars[$this -> t1]['u_data'] = unserialize($this -> vars[$this -> t1]['u_data']);
			$this -> vars['lastProcess'] = $this -> getLastProcess($this -> vars[$this -> t2]['dtl_status']);
		} else {
			$sql = ('SELECT * FROM ' . $this -> t1 . ' INNER JOIN ' . $this -> t2 . ' ON (id=u_id AND dtl_islast=1) WHERE dtl_status<=0');
			$this -> vars['paging'] = PagingSQL($sql);
			$q = $this -> mydb -> execute($sql);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['items'][] = $row;
			}
		}

	}

	public function archive($id = 0) {
		if ($id) {
			$this -> vars['donation'] = $this -> mydb -> fetch_assoc($this -> mydb -> execute('SELECT * FROM ' . $this -> t1 . ' WHERE ' . $this->t1id . '=:id', array('id'=> $id)));
			$q = $this -> mydb -> execute('SELECT * FROM ' . $this -> t2 . ' WHERE id=:id ORDER BY dtl_time', array('id' => $id),1);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['details'][] = $row;
			}
		} else {
			$sql = ('SELECT * FROM ' . $this -> t1 . ' INNER JOIN ' . $this -> t2 . ' ON (id=' . $this->t1id . ' AND dtl_islast=1) ORDER BY dtl_time');
			$this -> vars['paging'] = PagingSQL($sql);
			 
			$q = $this -> mydb -> execute($sql);
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['donations'][] = $row;
			}
		}
	}

	function one($act = '', $id = 0) {$this -> process($act, $id, 0, 'one');
	}

	function two($act = '', $id = 0) {$this -> process($act, $id, 0, 'two');
	}

	function three($act = '', $id = 0) {$this -> process($act, $id, 1, 'three');
	}

	function four($act = '', $id = 0) {$this -> process($act, $id, 2, 'four');
	}

	function five($act = '', $id = 0) {$this -> process($act, $id, 3, 'five');
	}

	function six($act = '', $id = 0) {$this -> process($act, $id, 4, 'six');
	}

	private function getLastProcess($status) {
		switch (abs($status)) {
			case 0 :
				return 'استقبال الطلب';
			case 1 :
				return 'إصدار صرف';
			case 2 :
				return 'إستلام أحد المواد';
			case 3 :
				return 'إستلام سند صرف';
			case 4 :
				return 'تسجيل قيد صرف  تبرع';
			case 5 :
				return 'إستلام تقرير عن الصرف';
			case 6 :
				return 'إستلام تقرير عن الصرف';
		}
	}

	private function process($act, $id, $status, $redirect) {
		$this -> vars['act'] = $act;
		$this -> vars['status'] = $status;
		if ($act == 'edit' and $id) {

			if (isset($_POST['dtl'])) {
				$restoration = $this -> validateData($_POST['dtl'], $act);
				if ($restoration) {
					$sql = $this -> mydb -> sql_update($this -> t1, $restoration, array($this -> t1id => $id));
					$this -> mydb -> execute($sql, $restoration);
				}
			}
			if (isset($_POST['dtl'])) {
				$dtl = $_POST['dtl'];
				$dtl['id'] = $id;
				$dtl['dtl_userid'] = $this -> user['user_id'];
				$dtl['dtl_islast'] = 1;
				$dtl['dtl_time'] = time();
				$this -> mydb -> execute('UPDATE ' . $this -> t2 . ' SET dtl_islast=0 WHERE id=:id', array('id' => $id));
				$sql = $this -> mydb -> sql_insert($this -> t2, $dtl);
				$this -> mydb -> execute($sql, $dtl);
				setMessage('تم حفظ البيانات بنجاح', 'success');
				redirect($this -> appname . '/' . $redirect);
			}

			$sql = 'SELECT * FROM ' . $this -> t1 . ' INNER JOIN ' . $this -> t2 . ' ON (id= ' . $this -> t1id . ' AND dtl_islast=1) WHERE ' . $this -> t1id . '=' . $id;
			echo $sql;
			$restoration = $this -> mydb -> fetch_assoc($this -> mydb -> execute($sql, array('status' => $status)));
			/*if (!empty($restoration['r_data2'])) {
			 $restoration['r_data2'] = unserialize($restoration['r_data2']);
			 }
			 $restoration['r_data'] = unserialize($restoration['r_data']);
			 $restoration['r_pictures'] = unserialize($restoration['r_pictures']);
			 $restoration['r_pictures2'] = unserialize($restoration['r_pictures2']);
			 $restoration['r_bills'] = unserialize($restoration['r_bills']);*/
			$this -> vars['restoration'] = $restoration;
			$this -> vars['lastProcess'] = $this -> getLastProcess($restoration['dtl_status']);

		} else {
			$sql = 'SELECT * FROM ' . $this -> t1 . ' INNER JOIN ' . $this -> t2 . ' ON (id=' . $this -> t1id . ' AND dtl_islast=1) WHERE dtl_status=:status';
			/*
			 if ($status == 2) {
			 $sql .= ' OR dtl_status IN (-4, -5)';
			 }
			 */
			$this -> vars['paging'] = PagingSQL($sql);
			$q = $this -> mydb -> execute($sql, array('status' => $status));
			while ($row = $this -> mydb -> fetch_assoc($q)) {
				$this -> vars['restorations'][] = $row;
			}
		}
	}

	private function validateData($data, $act = '') {
		return $data;
	}

}
