	<?php if (isset($items)){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">إستقبال الطلبات</div>
			<table class="table">
				<tr>
                    <th>اسم المستفيد</th>
                    <th>رقم المستفيد</th> 
                    <th>اسم الحي</th>
                </tr>
                <?php foreach ($items as $row){ ?>
                <tr<?=($row['dtl_status'] < 0 ? ' class="danger"' : '') ?>>
                    <td><?=$row['u_beneficiary'] ?></td>
                    <td><?=$row['u_no'] ?></td>
                    <td><?=$row['u_dist'] ?></td>
                    <td><a href="<?=base_url() ?>used/add/edit/<?=$row['u_id'] ?>" class="btn btn-warning">تعديل</a></td>
                </tr>
                <?php } ?>
            </table>
        </div>
        <a href="<?=base_url() ?>used/add/add" class="btn btn-success">تسجيل</a>  
<a href="#" class="btn btn-warning print_btn">طباعة</a>
<br/><?=$paging ?>
<?php } else { ?>
	<?php if(isset($used['u_id'])){ ?>
		<?php if ($used['dtl_islast'] > 0){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess ?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($used['dtl_userid'], 'user_name') ?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ardate('d/m/Y', $used['dtl_time']) ?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$used['dtl_notes'] ?></td>
				</tr>
			</table>
		</div>
		<?php } ?>
				<form action="<?=base_url() ?>used/add/edit/<?=$used['u_id'] ?>" method="post" data-toggle="validator" role="form" class="form-horizontal" enctype="multipart/form-data">
			<div class="panel panel-primary">
				<div class="panel-heading">إستقبال الطلبات</div>
		<?php } else { ?>
        <form action="<?=base_url() ?>used/add/add" method="post" data-toggle="validator" role="form" class="form-horizontal" enctype="multipart/form-data">
			<div class="panel panel-primary">
				<div class="panel-heading">تسجيل طلب جديد</div>
		<?php } ?>
				<br />
				<div class="form-group">
					<label for="u_name" class="control-label col-sm-2">اسم المستفيد</label>
					<div class="col-sm-9">
						<input type="text" name="used[u_beneficiary]" id="u_name" value="<?=$used['u_beneficiary'] ?>" class="form-control" required="true" />
					</div>
				</div>	
				<div class="form-group">
					<label for="u_name" class="control-label col-sm-2">رقم المستفيد</label>
					<div class="col-sm-9">
						<input type="text" name="used[u_no]" id="u_name" value="<?=$used['u_no'] ?>" class="form-control" required="true" />
					</div>
				</div>	
				<div class="form-group">
					<label for="u_name" class="control-label col-sm-2">اسم الحي</label>
					<div class="col-sm-9">
						<input type="text" name="used[u_dist]" id="u_name" value="<?=$used['u_dist'] ?>" class="form-control" required="true" />
					</div>
				</div>				
				
					<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<table id="rows">
							<tr>
								<th>الغرض</th>
								<th>عدد</th>  
							</tr>
							<?php if(isset($used['u_data'])){ ?>
							<?php foreach (  $used['u_data']['kind'] as $key=>$v){ ?>
							<tr>
								<td><input type="text" name="used[u_data][kind][]" value="<?=$used['u_data']['kind'][$key] ?>" class="form-control" required="true" /></td>
								<td><input type="text" name="used[u_data][count][]" value="<?=$used['u_data']['count'][$key]  ?>" class="form-control" required="true" /></td>
							 </tr>
							<?php } ?>
							<?php } else { ?>
							<tr>
								<td><input type="text" name="used[u_data][kind][]" class="form-control" required="true" /></td>
								<td><input type="text" name="used[u_data][count][]" class="form-control" required="true" /></td>
							 	</tr>
							<?php } ?>
						</table>
						<button id="add_row" type="button" class="btn btn-success">إضافة</button>
					</div>
				</div>
 
					 
								<div class="form-group">
					<label for="u_name" class="control-label col-sm-2">تاريخ استحقاق الصرف</label>
					<div class="col-sm-9">
						<input name="used[u_date]" id="u_date" value="<?=$used['u_date'] ?>"  type="datetime" class="form-control datepicker" required="true"  />
					</div>
				</div>
								<div class="form-group">
					<label for="u_name" class="control-label col-sm-2">اسم المشروع</label>
					<div class="col-sm-9">
						<select  class="form-control"name='used[u_project]'><?=GetProjects((int )$used['u_project']) ?></select>
						 
					</div>
				</div> 
								<div class="form-group">
					<label for="u_name" class="control-label col-sm-2">ملاحظات</label>
					<div class="col-sm-9">
						<input type="text" name="used[u_note]" id="u_note" value="<?=$used['u_note'] ?>" class="form-control" required="true" />
					</div>
				</div>
			 
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
						<a href="#" class="btn btn-warning print_btn">طباعة</a>
					</div>
				</div>
			</div>
		</form>
				<script type="text/javascript">
					$('#add_row').click(function() {
						$('#rows tbody').append('<tr><td><input type="text" name="used[u_data][kind][]" id="p_beneficiaries" class="form-control" required="true" /></td>' + '<td><input type="text" name="used[u_data][count][]" id="p_beneficiaries" class="form-control" required="true" /></td>' + '</tr>');
					});

		</script>
				<?php } ?>
				
