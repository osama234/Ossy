<?php if (isset($donation)){   ?>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات المستعمل</div>
			<table class="table">
				<tr>
					<th wu_idth="20%">اسم المستفيد</th>
					<td><?=$donation['u_beneficiary']?></td>
				</tr>
				<tr>
					<th wu_idth="20%">نوع المواد</th>
					 <td>
	 				 
						<table  width='100%' id="rows" >
							<tr>
								<th width='60%'>الغرض</th>
								<th width='40%'>عدد</th>  
							</tr>
							<?php if(isset($donation['u_data'])){$rows = unserialize( $donation['u_data']); ?>
							<?php foreach ( $rows['kind'] as $key=>$v){ ?>
							<tr>
								<th><?=$rows['kind'][$key] ?></th>
								<td><?=$rows['count'][$key] ?></td>
							 </tr>
							<?php } ?>
							<?php } ?>
							
						</table>
						 
	 				</td>
				</tr>
 
				<tr>
					<th wu_idth="20%">اسم المشروع</th>
					<td><?=GetProjectsLabel($row['u_project']) ?></td>
				</tr>
				<tr>
					<th wu_idth="20%">تاريخ إستحقاق الصرف</th>
					<td><?=$donation['u_date']?></td>
				</tr>
				<tr>
					<th wu_idth="20%">الماحظات</th>
					<td><?=$donation['u_note']?></td>
				</tr>
				
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">سجل العمليات</div>
        	<table class="table">
        		<tr>
        			<th>المستخدم</th>
        			<th>التاريخ</th>
        			<th>الوقت</th>
        			<th>ملاحظات</th>
        		</tr>
        		<?php foreach ($details as $row){ ?>
        		<tr>
        			<td><?=GetUserById($row['dtl_userid'], 'user_name')?></td>
        			<td><?=ardate('d/m/Y', $row['dtl_time'])?></td>
        			<td><?=ardate('h:i A', $row['dtl_time'])?></td>
        			<td><?=$row['dtl_notes']?></td>
        		</tr>
        		<?php } ?>
        	</table>
		</div>
		<a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية</div>
            <table class="table">
                <tr>
 
                    <th>اسم المستفيد</th>
                    <th>اسم المشروع</th>  
                 
               
                    <th></th>
                </tr>
                <?php if(isset($donations))  
			
			   foreach($donations as $row )
                 {			?>
			 <tr>
                    
                    <td><?=$row['u_beneficiary'] ?></td> 
                     <td><?=GetProjectsLabel($row['u_project']) ?></td>   
              
              
                 <td><a href="<?=base_url() ?>used/archive/<?=$row['u_id'] ?>" class="btn btn-primary">عرض</a></td>
				 
                </tr>
                     		 
                <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div>
        
<a href="#" class="btn btn-warning print_btn">طباعة</a><br/><?=$paging?>
<?php } ?>
