<?php if($act=='edit')
{?>
	<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th wu_idth="20%">اسم العملية</th>
					<td><?=$lastProcess ?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($restoration['dtl_userid'], 'user_name') ?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ardate('d/m/Y', $restoration['dtl_time']) ?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$restoration['dtl_notes'] ?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">إستلام تقرير عن الصرف</div>
			<table class="table">
				<tr>
					<th wu_idth="20%">اسم المستفيد</th>
					<td><?=$restoration['u_beneficiary'] ?></td>
				</tr>
 	<tr>
					<th wu_idth="20%">نوع المواد</th>
					 <td>
	 				 
						<table  width='100%' id="rows" >
							<tr>
								<th width='60%'>الغرض</th>
								<th width='40%'>عدد</th>  
							</tr>
							<?php if(isset($restoration['u_data'])){$rows = unserialize( $restoration['u_data']); ?>
							<?php foreach ( $rows['kind'] as $key=>$v){ ?>
							<tr>
								<th><?=$rows['kind'][$key] ?></th>
								<td><?=$rows['count'][$key] ?></td>
							 </tr>
							<?php } ?>
							<?php } ?>
							
						</table>
						 
	 				</td>
				</tr>
					 
	 				
				<tr>
					<th wu_idth="20%">اسم المشروع</th>
					<td><?=GetProjectsLabel($restoration['u_project'])?></td>
				</tr>
				<tr>
					<th wu_idth="20%">تاريخ إستحقاق الصرف</th>
					<td><?=$restoration['u_date'] ?></td>
				</tr>
				<tr>
					<th wu_idth="20%">الماحظات</th>
					<td><?=$restoration['u_note'] ?></td>
				</tr>
				
				
			</table>
		</div>
		<form action="<?=base_url() ?>used/five/edit/<?=$restoration['u_id'] ?>" method="post" data-toggle="valu_idator" role="form">
			<div class="panel panel-primary">
				<div class="panel-heading">الإجراء المتخذ</div>
				<table class="table">
					<tr>
						<th wu_idth="20%">القرار</th>
						<td>
							<input type="radio" name="dtl[dtl_status]" u_id="rt_status1" value="<?=$status + 1 ?>" /><label for="dtl_status1">اعتماد مبدئي لطلب </label>
							<input type="radio" name="dtl[dtl_status]" u_id="rt_status2" value="0" /><label for="dtl_status2">ملاحظات</label>
						</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[dtl_notes]" rows="3" ></textarea></td>
					</tr>
					<tr>
						<th></th>
						<td><button type="submit" class="btn btn-primary">حفظ واعتماد</button></td>
					</tr>
				</table>
			</div>
		</form>













<?}else{ ?>
	<div class="panel panel-primary">
			<div class="panel-heading">طلبات العهد المدققة</div>
			<table class="table">
				<tr>
                    <th>اسم المستفيد</th>
                    <th>اسم المشروع</th>  
                 
                </tr>
			<?
			if(isset($restorations))  
			
			   foreach($restorations as $row )
                 {			?>
			 <tr>
                    
                    <td><?=$row['u_beneficiary'] ?></td> 
                     <td><?=GetProjectsLabel($row['u_project']) ?></td>   
              
              
                 <td><a href="<?=base_url() ?>used/five/edit/<?=$row['u_id'] ?>" class="btn btn-primary">عرض</a></td>
				 
                </tr>
                     		<? } ?> </table></div> 
                  							<?=$paging ?><br/>
<a href="#" class="btn btn-warning print_btn">طباعة</a>
			<?} ?>
