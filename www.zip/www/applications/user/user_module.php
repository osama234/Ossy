<?php
    class user_controller extends controller 
    {
        function __construct() {
            parent::__construct();
        }
        
       	function index($params=null) {
        	RedirectDefault();
			return(true);
		}
		        
        function login($act='', $id=0) {
            if (!empty($this->user['user_id'])) {
			    return redirect('home');
            }
            if (isset($_POST['user_mail'])) {
				if (empty($_POST['user_mail']) || empty($_POST['user_password'])) {
					SetMessage('You must enter your email and password', 'error');
				} else {
					$_POST['user_password'] = md5($_POST['user_password']);
					
					//die($this->mydb->execute('SELECT * FROM users WHERE user_mail=:user_mail AND user_password=:user_password ', $_POST,1));
					
					$profile = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM users WHERE user_mail=:user_mail AND user_password=:user_password ', $_POST));
					if (!$profile) {
						SetMessage('Invalid email or password', 'error');
					} else {
						$_SESSION['current_user'] = $profile;
						if (!empty($_SESSION['REQUEST'])) {
							$url = $_SESSION['REQUEST'];
							unset($_SESSION['REQUEST']);
							redirect($url);
						} else {
							redirect('home');
						}
					}
				}
			}
            return true;
        }
        
        function logout() {
			unset($_SESSION['current_user']);
			$this->user = false;
			redirect('user/login');
		}
        
        function register($act='', $id=0) {
			
		}
		
		private function validateUser($userData) {
			return $userData;
		}
    }
?>
