		<form action="<?=base_url()?>user/login" method="post" class="form-signin" role="form">
			<h2 class="form-signin-heading">الدخول للنظام</h2>
			<input type="text" name="user_mail" class="form-control" placeholder="إسم المستخدم" required autofocus />
			<input type="password" name="user_password" class="form-control" placeholder="كلمة المرور" required />
			<button class="btn btn-lg btn-primary btn-block" type="submit">تسجيل الدخول</button>
		</form>
 
