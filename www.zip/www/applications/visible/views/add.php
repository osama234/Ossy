	<?php if (isset($items)){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">تسجيل طلب جديد</div>
			<table class="table">
				<tr>
                    <th>اسم المتبرع</th>
                    <th>رقم المتبرع</th>
                    <th>المشروع</th> 
                </tr>
                <?php foreach ($items as $row){ ?>
                <tr<?=($row['dtl_status'] < 0 ? ' class="danger"' : '') ?>>
                    <td><?=$row['v_donor'] ?></td>
                    <td><?=$row['v_mobile'] ?></td>
                    <td><?=$row['v_project'] ?></td> 
                    <td><a href="<?=base_url() ?>visible/add/edit/<?=$row['v_id'] ?>" class="btn btn-warning">تعديل</a></td>
                </tr>
                <?php } ?>
            </table>
        </div>
        <a href="<?=base_url() ?>visible/add/add" class="btn btn-success">تسجيل</a>
        <a href="#" class="btn btn-warning print_btn">طباعة</a><br/><?=$paging ?>
<?php } else { ?>
	<?php if(isset($visible['v_id'])){ ?>
		<?php if ($visible['dtl_islast'] > 0){ ?>
		<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess ?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($visible['dtl_userid'], 'user_name') ?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ardate('d/m/Y', $visible['dtl_time']) ?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$visible['dtl_notes'] ?></td>
				</tr>
			</table>
		</div>
		<?php } ?>
		<form action="<?=base_url() ?>visible/add/edit/<?=$visible['v_id'] ?>" method="post" data-toggle="validator" role="form" class="form-horizontal" enctype="multipart/form-data">
			<div class="panel panel-primary">
				<div class="panel-heading">تعديل طلب صيانة / ترميم</div>
		<?php } else { ?>
        <form action="<?=base_url() ?>visible/add/add" method="post" data-toggle="validator" role="form" class="form-horizontal" enctype="multipart/form-data">
			<div class="panel panel-primary">
				<div class="panel-heading">تسجيل طلب جديد</div><?=$paging ?><br/>
		<?php } ?>
				<br />
				<div class="form-group">
					<label for="v_donor" class="control-label col-sm-2">اسم المتبرع</label>
					<div class="col-sm-9">
						<input type="text" name="visible[v_donor]" id="v_donor" value="<?=$visible['v_donor'] ?>" class="form-control" required="true" />
					</div>
				</div>				
				<div class="form-group">
					<label for="v_donor" class="control-label col-sm-2">رقم الجوال</label>
					<div class="col-sm-9">
						<input type="text" name="visible[v_mobile]" id="v_mobile" value="<?=$visible['v_mobile'] ?>" class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="v_donor" class="control-label col-sm-2">وصف التبرع</label>
					<div class="col-sm-9">
						<input type="text" name="visible[v_description]" id="v_desc" value="<?=$visible['v_description'] ?>" class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="v_donor" class="control-label col-sm-2">الكمية</label>
					<div class="col-sm-9">
						<input type="text" name="visible[v_amount]" id="v_mount" value="<?=$visible['v_amount'] ?>" class="form-control" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="v_donor" class="control-label col-sm-2">تاريخ التبرع</label>
					<div class="col-sm-9">
						<input type="datetime" name="visible[v_date]" id="v_date" value="<?=$visible['v_date'] ?>" class="form-control datepicker" required="true" />
					</div>
				</div>
				<div class="form-group">
					<label for="v_donor" class="control-label col-sm-2">اسم المشروع</label>
					<div class="col-sm-9">
						<select  class="form-control" name='visible[v_project]'><?=GetProjects((int )$used['v_project']) ?></select>
						 
					</div>
				</div>
					<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<table id="rows">
							<tr>
								<th>الغرض</th>
								<th>عدد</th>  
							</tr>
							<?php if(isset($visible['v_data'])){ ?>
							<?php foreach (  $visible['v_data']['kind'] as $key=>$v){ ?>
							<tr>
								<td><input type="text" name="visible[v_data][kind][]" value="<?=$used['v_data']['kind'][$key] ?>" class="form-control" required="true" /></td>
								<td><input type="text" name="visible[v_data][count][]" value="<?=$used['v_data']['count'][$key]  ?>" class="form-control" required="true" /></td>
							 </tr>
							<?php } ?>
							<?php } else { ?>
							<tr>
								<td><input type="text" name="visible[v_data][kind][]" class="form-control" required="true" /></td>
								<td><input type="text" name="visible[v_data][count][]" class="form-control" required="true" /></td>
							</tr>
							<?php } ?>
						</table>
						<button id="add_row" type="button" class="btn btn-success">إضافة</button>
					</div>
				</div>
			 
				<div class="form-group">
					<label for="v_donor" class="control-label col-sm-2">ملاحظات</label>
					<div class="col-sm-9">
						<input type="text" name="visible[v_note]" id="v_note" value="<?=$visible['v_note'] ?>" class="form-control" required="true" />
					</div>
				</div>
			 
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-9">
						<button type="submit" class="btn btn-primary">حفظ واعتماد</button>
						<a href="#" class="btn btn-warning print_btn">طباعة</a>
					</div>
				</div>
			</div>
		</form>
				<script type="text/javascript">
					$('#add_row').click(function() {
						$('#rows tbody').append('<tr><td><input type="text" name="visible[v_data][kind][]" class="form-control" required="true" /></td>' + '<td><input type="text" name="visible[v_data][count][]" id="p_beneficiaries" class="form-control" required="true" /></td>' + '</tr>');
					});

		</script>
				<?php } ?>
				
