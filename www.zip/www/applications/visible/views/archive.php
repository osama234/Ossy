<?php if (isset($donation)){   ?>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المتبرع</th>
					<td><?=$donation['v_donor'] ?></td>
				</tr>
				<tr>
					<th width="20%">رقم الجوال</th>
					<td><?=$donation['v_mobile'] ?></td>
				</tr>
 
				<tr>
					<th width="20%">وصف التبرع</th>
					<td><?=$donation['v_description'] ?></td>
				</tr>
				<tr>
					<th width="20%">المشروع</th>
					<td><?=GetProjectsLabel($donation['v_project']) ?></td>
				</tr>
					<tr>
					<th wu_idth="20%">نوع المواد</th>
					 <td>
	 				 
						<table  width='100%' id="rows" >
							<tr>
								<th width='30%'>الغرض</th>
								<th width='20%'>عدد</th> 
								<th width='30%'>الفرز</th>  
								<th width='20%'>تقيم السعر</th>  
							</tr>
							<?php if(isset($donation['v_data'])){$rows = unserialize( $donation['v_data']); ?>
							<?php foreach ( $rows['kind'] as $key=>$v){ ?>
							<tr>
								<th><?=$rows['kind'][$key] ?></th>
								<td><?=$rows['count'][$key] ?></td>
								<th><?=$rows['sort'][$key] ?></th>
								<td><?=$rows['cost'][$key] ?></td>
							 </tr>
							<?php } ?>
							<?php } ?>
							
						</table>
						 
	 				</td>
				</tr>
				<tr>
					<th width="20%">الكمية</th>
					<td><?=$donation['v_amount'] ?></td>
				</tr>
				<tr>
					<th width="20%">تفريغ التبرع</th>
					<td><?=$donation['v_date'] ?></td>
				</tr>
				<tr>
					<th width="20%">الماحظات</th>
					<td><?=$donation['v_note'] ?></td>
				</tr>
				
				
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">سجل العمليات</div>
        	<table class="table">
        		<tr>
        			<th>المستخدم</th>
        			<th>التاريخ</th>
        			<th>الوقت</th>
        			<th>ملاحظات</th>
        		</tr>
        		<?php foreach ($details as $row){ ?>
        		<tr>
        			<td><?=GetUserById($row['dtl_userid'], 'user_name')?></td>
        			<td><?=ArDate('d/m/Y', $row['dtl_time'])?></td>
        			<td><?=date('h:i A', $row['dtl_time'])?></td>
        			<td><?=$row['dtl_notes']?></td>
        		</tr>
        		<?php } ?>
        	</table>
		</div>
		<a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } else {?>
		<div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية</div>
            <table class="table">
                <tr>
                    <th>اسم المستفيد</th>
                    <th>الكمية</th> 
                    <th></th>  
                </tr>
                <?php if(isset($donations))  
			
			   foreach($donations as $row )
                 {			?>
			 <tr>
                    
<td><?=$row['v_donor'] ?></td>
                    <td><?=$row['v_amount'] ?></td>  
              
              
                 <td><a href="<?=base_url() ?>visible/archive/<?=$row['v_id'] ?>" class="btn btn-primary">عرض</a></td>
				 
                </tr>
                     		 
                <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div>
        
<a href="#" class="btn btn-warning print_btn">طباعة</a><br/><?=$paging?>
<?php } ?>
