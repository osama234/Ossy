<?php if (isset($donation)){ ?>
	<style>
		h1, h2, h3, h4, h5, p, footer {
			text-align: center;
			margin-left: auto;
			margin-right: auto;
		}
		p, .head1, .head2, .head3 {
			display: inline-block;
		}
		.body, .footer {
			display: table;width:90%;
		}
		.head1 {
			width: 35%;
			vertical-align: middle;
		}
		.head2 {
			width: 30%;
			text-align: center;
			vertical-align: middle;
		}
		.head3 {
			width: 25%;
			vertical-align: middle;
		}
		img {
			display: inline-block;
			margin: 0 auto;
			padding:0px;
			width:150px;height:150px;
		}
		.report {
			width: 100%;
			border: 2px solid gray;
			border-radius: 9px;
			background-color: #ffffff;
		}
		.body > div {
			display: inline-block;
		}
		.body > div > p {
			display: table;
		}
		.footer {
			border-top: 2px solid black;
			width: 100%;
			text-align: center;
		}
</style>
<style type="text/css">
	@media print {
		body * {
			visibility: hidden;
			 
		}
		.report * {
			visibility: visible;
		}
		.report {
			position: absolute;
			top: 40px;
			left: 30px;
			width:90%;
		}
	}
</style>
<div class="report">
	<div>
		<div class="head1">
			<h5 style="font-weight:normal;">المملكة العربية السعودية</h5>
			<h4 style="font-weight:bold;">المستودع الخيري بالمجمعة</h4>
			<h5 style="font-weight:normal;">فرع جمعية البر الخيرية بالمجمعة</h5>
			<h5 style="font-weight:normal;">تلفون 016/4321800 - فاكس 016/4325800</h5>
		</div>
		<div class="head2">
			<img src="<?=base_url()?>public/logo.png" />
			<h2 style="font-weight:bolder;">سـنـد إستلام تبرعات عينية</h2>
		</div>
		<div class="head3">
			<h4>التاريخ 
<?=ArDate('Y/m/d', time()) ?>
 هـ</h4>
			<h2 style='color:red;' class='reportnumber'>&nbsp;</h2>
		</div>
		<div class="body">
			<!-- line 1 -->
			<p style="width:20%">
				استلمنا من المكرم
			</p>
			<p style="width:60%;border-bottom:1px dotted black"><?=$donation['v_donor'] ?>&nbsp;</p>
			<p style="width:20%">
				حفظه الله و رعاه
			</p>
			<p style="width:90%;text-align: right;padding-right:3.5%;">
				التبرع العيني التالي :
			</p> 
			<table border=1 style="width:95%;text-align: right;margin-right:3.5%;">
				<tr>
					<th style="text-align: center" width="80%">الوصف</th>
					<th style="text-align: center" width="20%">العدد</th>
				</tr>
				<tr>
					<td style="height:100px;"></td>
			        <td></td>
				</tr>
			</table>
			<p style="width:90%;text-align: center;padding-right:3.5%;">
				سائلين الله له الأجر و الثوبة
			</p> 
			<!-- line 2 -->
			 <!-- line 3 -->
			 <!--
			<p style="width:15%">
				التاريخ
			<?=ArDate('Y/m/d', $row['dtl_time']) ?>	هـ</p> -->
			 
			<!-- line 6 -->
			<!--
				<p style="width:33%">
				المستلم
			</p>
			<p style="width:33%">
				أمين الصندوق
			</p>
			<p style="width:24%">
				المدير التنفيذي للمستودع الخيري
			</p>
			-->
			<!-- line 6 -->
			<!--
			<div style="width:30%;text-align: right;">
				<p style="text-align: right;">
					الإسم /
				</p>
				<p style="text-align: right;">
					التوقيع /
				</p>
			</div>
			<div style="width:30%;text-align: right;">
				<p style="text-align: right;">
					الإسم /
				</p>
				<p style="text-align: right;">
					التوقيع /
				</p>
			</div>
			<div style="width:30%;text-align: right;">
				<p style="text-align: right;">
					الإسم /
				</p>
				<p style="text-align: right;">
					التوقيع /
				</p>
			</div>
-->
		</div>
		<!--
			<div class="footer">
			<p>
				رقم الهاتف 016/4321800 - رقم الجوال 0554321800 - هاتف الأثاث المستعمل 016/4322800
				- رقم الفاكس 016/64315800
			</p>
			<p>
				مصرف الراجحي الحساب العام (SA2080000138608010147994) حساب الوقف (SA15800001386080999162)
			</p>
			<p>
				بنك البلاد الحساب العام (SA3315000999300001240035)
			</p>
		</div>
		-->

	</div>
</div>
<a href="#" class="btn btn-success" onclick="window.print();return false ;">طباعة</a> 
<script>
	function pad (str, max) {
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}
	$('.reportnumber').html(pad( <?=$donation['v_id'] ?>
	,5) );
</script>

<?php } else { ?>
		<div class="panel panel-primary">
            <div class="panel-heading">التبرعات النقدية</div>
            <table class="table">
                <tr>
                    <th>اسم المتبرع</th>
                    <th>رقم المتبرع</th>
                    <th>المشروع</th> 
                    <th></th>
                </tr>
                <?php if (isset($donations) and count($donations)){ ?>
                <?php foreach ($donations as $row){ ?>
                <tr>
                    <td><?=$row['v_donor'] ?></td>
                    <td><?=$row['v_mobile'] ?></td>
                    <td><?=$row['v_project'] ?></td> 
                    <td>
                        <a href="<?=base_url() ?>visible/printing/<?=$row['v_id'] ?>" class="btn btn-primary">عرض</a>
                    </td>
                </tr>
                <?php } ?>
                <?php } else { ?>
                <tr><td colspan="5">لا توجد عمليات حالياً</td></tr>
                <?php } ?>
            </table>
        </div>
               <?=$paging ?><br/>
        <a href="#" class="btn btn-warning print_btn">طباعة</a>
<?php } ?>
