<?php if($act=='edit')
{?>
	<div class="panel panel-primary">
			<div class="panel-heading">العملية السابقة</div>
			<table class="table">
				<tr>
					<th width="20%">اسم العملية</th>
					<td><?=$lastProcess ?></td>
				</tr>
				<tr>
					<th>العملية بواسطة</th>
					<td><?=GetUserById($restoration['dtl_userid'], 'user_name') ?></td>
				</tr>
				<tr>
					<th>تاريخ العملية</th>
					<td><?=ardate('d/m/Y', $restoration['dtl_time']) ?></td>
				</tr>
				<tr>
					<th>ملاحظات</th>
					<td><?=$restoration['dtl_notes'] ?></td>
				</tr>
			</table>
		</div>
		<div class="panel panel-primary">
        	<div class="panel-heading">بيانات الطلب</div>
			<table class="table">
				<tr>
					<th width="20%">اسم المتبرع</th>
					<td><?=$restoration['v_donor'] ?></td>
				</tr>
				<tr>
					<th width="20%">رقم الجوال</th>
					<td><?=$restoration['v_mobile'] ?></td>
				</tr>				
				<tr>
					<th width="20%">المشروع</th>
					<td><?=GetProjectsLabel($restoration['v_project']) ?></td>
				</tr>
  		<tr>
					<th wu_idth="20%">نوع المواد</th>
					 <td>
	 				 
						<table  width='100%' id="rows" >
							<tr>
								<th width='30%'>الغرض</th>
								<th width='20%'>عدد</th> 
								<th width='30%'>الفرز</th>  
								<th width='20%'>تقيم السعر</th>   
							</tr>
							<?php if(isset($restoration['v_data'])){$rows = unserialize( $restoration['v_data']); ?>
							<?php foreach ( $rows['kind'] as $key=>$v){ ?>
							<tr>
								<th><?=$rows['kind'][$key] ?></th>
								<td><?=$rows['count'][$key] ?></td>
								<th><?=$rows['sort'][$key] ?></th>
								<td><?=$rows['cost'][$key] ?></td>
							 </tr>
							<?php } ?>
							<?php } ?>
							
						</table>
						 
	 				</td>
				</tr>
				<tr>
					<th width="20%">وصف التبرع</th>
					<td><?=$restoration['v_description'] ?></td>
				</tr>
				<tr>
					<th width="20%">الكمية</th>
					<td><?=$restoration['v_amount'] ?></td>
				</tr>
				<tr>
					<th width="20%">تاريخ التبرع</th>
					<td><?=$restoration['v_date'] ?></td>
				</tr>
				<tr>
					<th width="20%">الماحظات</th>
					<td><?=$restoration['v_note'] ?></td>
				</tr>
				
				
			</table>
		</div>
		<form action="<?=base_url()?><?=$app1?>/<?=$dir?>/edit/<?=$restoration['v_id']?>" method="post" data-toggle="validator" role="form">
			<div class="panel panel-primary">
				<div class="panel-heading">إعتماد بلاغات</div>
				<table class="table">
					<tr>
						<th width="20%">القرار</th>
						<td>
							<input type="radio" name="dtl[dtl_status]" id="rt_status1" value="<?=$status+1?>" /><label for="dtl_status1">اعتماد مبدئي لطلب </label>
							<input type="radio" name="dtl[dtl_status]" id="rt_status2" value="0" /><label for="dtl_status2">ملاحظات</label>
						</td>
					</tr>
					<tr>
						<th>ملاحظات</th>
						<td><textarea name="dtl[dtl_notes]" rows="3" ></textarea></td>
					</tr>
					<tr>
						<th></th>
						<td><button type="submit" class="btn btn-primary">حفظ واعتماد</button></td>
					</tr>
				</table>
			</div>
		</form>













<?}else{?>
	<div class="panel panel-primary">
			<div class="panel-heading"><?=$appname?></div>
			<table class="table">
				<tr>
                    <th>اسم المستفيد</th>
                    <th>الكمية</th> 
                    <th></th>  
                </tr>
			<?
			if(isset($restorations))  
			
			   foreach($restorations as $row )
                 {			?>
			 <tr>
                    
    				<td><?=$row['v_donor'] ?></td>
                    <td><?=$row['v_amount'] ?></td>  
                    <td><a href="<?=base_url()?><?=$app1?>/<?=$dir?>/edit/<?=$row['v_id']?>" class="btn btn-primary">عرض</a></td>
				 
             </tr>
                     		<? }?> </table></div> 
                  	
			<a href="#" class="btn btn-warning print_btn">طباعة</a><br/><?=$paging?>						
			<?}?>
