<?php
    //auto start session
    session_start();
    // include the main class
    require_once('libraries/phpos.class.php');
	//debug error
	ini_set('error_reporting', E_ALL);
	ini_set('display_errors', 'On');
	//set default timezone
	date_default_timezone_set('Asia/Riyadh');
	
	//path config 
	$real_path = dirname(realpath(__FILE__));
	SetConfig('url_path', explode('/',getPath()));
	SetConfig('app_path', $real_path.'/applications/');
	SetConfig('lib_path', $real_path.'/libraries/');
	SetConfig('my_db', 'mysql://root@127.0.0.1/mcw_data');
	

	
	function SetConfig($key, $val=false) {
		if($key && $val!==false) {
			@$GLOBALS['config'][$key] = $val;
		}
	}
	
	function GetConfig($key, $val=false) {
		if(isset($GLOBALS['config'][$key])){
			return($GLOBALS['config'][$key]);
		}
		return $val;
	}
	
	function getPath()
	{
		return (isset($_SERVER['PATH_INFO'])) ? $_SERVER['PATH_INFO'] : substr($_SERVER['REQUEST_URI'], 1);
	}

?>