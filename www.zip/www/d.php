<meta charset="UTF-8" />
<?php

$emp = array(
array('name'=>'أحمد عبدالله المسعود','username'=>'a.almsud'),
array('name'=>'أحمد محمد الصدي','username'=>'a.alsady'),
array('name'=>'تركي مرضي المطيري','username'=>'t.almutiry'),
array('id'=>14,'name'=>'جبريل موسى جبريل','username'=>'j.albary'),
array('id'=>22,'name'=>'خاتم مطر المطيري','username'=>'k.almutiry'),
array('id'=>18,'name'=>'خالد عبدالله الدحوم','username'=>'k.aldhom'),
array('name'=>'سامي عيد المطيري','username'=>'s.almutiry'),
array('id'=>20,'name'=>'سعد عبدالله السلبود','username'=>'s.alslbud'),
array('name'=>'سليمان ابراهيم العبد الجبار','username'=>'s.alabdaljbar'),
array('name'=>'سيف غضيان المطيري','username'=>'sa.almutiry'),
array('id'=>21,'name'=>'صالح عبدالمحسن الرشيدي','username'=>'s.alrasheedy'),
array('name'=>'صلاح محمد الرشيدي','username'=>'sm.alrasheedy'),
array('id'=>17,'name'=>'عامر ناحي المطيري','username'=>'a.almutiry'),
array('id'=>19,'name'=>'عباالاله عبدالعزيز الشباني','username'=>'a.alshabana'),
array('id'=>13,'name'=>'عبدالرحمن صالح ابانمي','username'=>'a.abanmy'),
array('name'=>'عبدالعزيز عبدالله الدهش','username'=>'a.aldahash'),
array('name'=>'عبدالله عبدالعزيز المسعود','username'=>'a.almsud'),
array('name'=>'علي سالم السهلي','username'=>'a.alshaly'),
array('name'=>'فتح الرحمن محمد احمد','username'=>'f.alrhman'),
array('name'=>'فهد موسى الحمدان','username'=>'f.alhmdan'),
array('name'=>'مؤيد عبدالله الجاسر','username'=>'m.aljasir'),
array('name'=>'ماجد ملفي المطيري','username'=>'m.almutiry'),
array('id'=>12,'name'=>'ماجد موسى الحمدان','username'=>'m.alhndan'),
array('name'=>'محمد عبدالرحمن السبيت','username'=>'m.alsbyat'),
array('id'=>23,'name'=>'محمد خالد الحوراني','username'=>'m.alhorany'),
array('name'=>'محمد علي الحاج','username'=>'m.alhaj'),
array('id'=>16,'name'=>'مسلم سرور الحربي','username'=>'m.alharbi'),
array('name'=>'مصطفى عبدالعظيم احمد','username'=>'m.ahmad'),
array('id'=>15,'name'=>'نزار احمد اسحاق','username'=>'n.ishaq'),
array('name'=>'وليد محمد الثميري','username'=>'w.althomiry')
);

foreach($emp as $k => $d){
	$n = (rand(44444444,89999999));
	$emp[$k]['password'] =  $n;
	$l = md5($n);
	if(@!$d['id'] )	
		echo "insert into users (user_name,user_mail,user_password) values ('{$d['name']}', '{$d['username']}','$l');  <br/>";
	else
		echo "update users set user_mail='{$d['username']}' where user_id={$d['id']};<br/>";
	}
?>
<table border=1 dir=rtl>
<tr>
<th>
الإسم
</th>
<th>
إسم المستخدم
</th>
<th>
الرقم السري
</th>
</tr>

<?php
foreach($emp as $d){
       echo "{<tr><td>{$d['name']}</td><td>{$d['username']}</td><td>{$d['password']} </td></tr>";
}
?>
</table>