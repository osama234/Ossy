<?php
    /*
	 * helper functions
	 */
	function __autoload($className) {
		$path = 'libraries/' . strtolower($className) . '.class.php';
        if (file_exists($path)) {
		    require_once($path);
		    return true;
		}
		// if the file not found, emit fatal error and stop
		die("تعذر العثور على الصنف $className.");
	}
	
	function DBConnection() {
		return phpos::DBConnect(GetConfig('my_db'));
	}
	
    //get base url
	/**
     * @desc get base url
     * @param string $url custom url
     * @return string base url
     */
    function base_url($url=''){
		return(str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']).$url);
	}
    
    //redirect to new location
	/**
     * @desc redirect to new location
     * @param string $location the new location
     * @return void
     */
    function redirect($location=''){
		if(substr($location,0,7) == 'http://' || substr($location,0,8) == 'https://') {
			header('location: '.$location);
		} else {
			header('location: '.base_url($location));
		}
		exit;
	}
	
	//redirect to new location
	/**
     * @desc redirect to defual page of the user
     * @param string $location custom location
     * @return void
     */
    function RedirectDefault($class=''){
		global $_params;
		$class	= ($class)?$class:$_params[0];
		$db		= DBConnection();
		$sql 	= "SELECT * FROM applications WHERE app_name=:app_name";
		$app	= $db->fetch_assoc($db->execute($sql, array('app_name'=>$class)));
		$q 		= $db->execute("SELECT * FROM applications WHERE app_pid=:app_id ORDER BY app_sort", $app);
		while($row	= $db->fetch_assoc($q)) {
			if(phpos::CheckUserPerms($_SESSION['current_user']['user_id'],$row['app_id'])) {
				redirect($row['app_name']);
				return(true);
			}
		}
		redirect('user/logout');
	}
    
    /**
     * @desc Set the error message
     * @param string $msg the message
     * @param string $type to specify the class of displayed error
     * @return void
     */
	function SetMessage($msg, $type='info'){
		$_SESSION['messages'][$type][] = $msg;
	}
    
    /**
     * @desc to check is there an errors
     * @param string $type to select specific types of errors
     * @return bool 
     */
	function NoMessage($type='error'){
		if($type) {
			return(!isset($_SESSION['messages'][$type]));
		}
		return(!isset($_SESSION['messages']));
	}
	
    /**
     * @desc display error messages
     * @return string html that shows messages
     */
    function ShowMessage(){
		$html = '';
		if(isset($_SESSION['messages'])) {
			foreach($_SESSION['messages'] as $type=>$msgs){
				if ($type == 'error') $type = 'danger';
				$html .= '<div class="alert alert-'.$type.' alert-dismissible" role="alert">';
				$html .= '<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><ul>';
				foreach($msgs as $msg){
					$html .= '<li>'.$msg.'</li>';
				}
				$html .= '</ul></div>';
			}
		}
		return($html);
	}

	/**
     * @desc check the input
     * @param string $value value of the input
     * @param string $rule input name 
     * @return bool true if $value is valid and meet $rule, false otherwise. 
     */
	function CheckInput($value, $rule='empty', $default=''){
		if($rule=='fullname')		return(strlen(trim($value))>8);
		if($rule=='idno')			return(preg_match('/(1\\d{9})|(2\\d{9})/',$value));
		if($rule=='mobile')			return(preg_match('/05\\d{8}/',$value));
		if($rule=='empty')			return(strlen(trim($value))>0);
		if($rule=='email')			return(filter_var($value, FILTER_VALIDATE_EMAIL));
		if($rule=='message')		return(strlen(trim($value))>4);
		if($rule=='password')		return(strlen($value)>7);
		return(false);
	}
	
	/**
     * @desc get options tag for departments and nodes or custom array
     * @param mix $node_type to select which table to use "department",custom array or node
     * @param string $node_name to select specific option
     * @param string $option_val option's value
     * @param string $option_name to select option's text language
     * @return string
     */
	function GetOptions($node_type, $node_name='', $option_val= 'node_name', $option_name= 'node_ar') {
		$options 	= '';
		$db 		= DBConnection();
		$sql 		= "SELECT * FROM options WHERE node_type=:node_type ORDER BY node_sort ASC";
		$query		= $db->execute($sql, array('node_type'=>$node_type));
		while($node = $db->fetch_assoc($query)){
			$options .= '<option value="'.$node[$option_val].'"'.(($node[$option_val]==$node_name)?' selected="selected"':'').'>'.GetOptionsArrKey($node,$option_name).'</option>'."\n";
		}
		return($options);
	}
	
	/**
     * @desc get options tag for departments 
     * @param int/string $dept to select specific department
     * @return string
     */
	function GetDepartmentOptions($dept='') {
		$options 	= '';
		$db 		= DBConnection();
		$query		= $db->execute('SELECT * FROM departments ORDER BY d_id ASC');
		while($node = $db->fetch_assoc($query)){
			$options .= '<option value="'.$node['d_id'].'"'.(($node['d_id']==$dept)?' selected="selected"':'').'>'.$node['d_name'].'</option>'."\n";
		}
		return($options);
	}
	
	/**
     * @desc get department name
     * @param int/string $dept_id
     * @return string department name
     */
	function GetDepartmentLabel($dept_id='') {
		$options 	= '';
		$db 		= DBConnection();
		$dept		= $db->fetch_assoc($db->execute('SELECT * FROM departments WHERE d_id=:id', array('id' => $dept_id)));
		if ($dept){
			return $dept['d_name'];
		}
		return($dept_id);
	}
	
	/**
     * @desc get options tag for departments 
     * @param int/string $dept to select specific department
     * @return string
     */
	function GetUsersOptions($user_id='', $user_dept=0) {
		$options 	= '';
		$db 		= DBConnection();
		if ($user_dept) {
			$sql = 'SELECT * FROM users WHERE user_dept=:user_dept ORDER BY user_id ASC';
		} else {
			$sql = 'SELECT * FROM users ORDER BY user_id ASC';
		}
		$query		= $db->execute($sql, array('user_dept' => $user_dept));
		while($node = $db->fetch_assoc($query)){
			$options .= '<option value="'.$node['user_id'].'"'.(($node['user_id']==$user_id)?' selected="selected"':'').'>'.$node['user_name'].'</option>'."\n";
		}
		return($options);
	}
    
    /**
     * @desc get specific text from array
     * @param array $array 
     * @param string $key the keys to select text from array
     * @return string
     */
    function GetOptionsArrKey($array,$key){
		$text ='';
		foreach(explode(',',$key) as $_key){
			$text .= $array[trim($_key)].' ';
		}
		return($text);
	}
    
    /**
     * @desc Get Options Label
     * @param mix $node_type 
     * @param string $node_name 
     * @param string $option_val 
     * @return string
     */
	function GetOptionsLabel($node_type, $node_name, $option_val= 'node_name') {
		$db 		= DBConnection();
		$options 	= '';
		$sql 		= "SELECT * FROM options WHERE node_type=:node_type AND $option_val=:node_name";
		$node		= $db->fetch_assoc($db->execute($sql, array('node_type'=>$node_type,'node_name'=>$node_name)));
		if(isset($node['node_id'])){
			return($node['node_ar']);
		}
		return($node_name);
	}
	
	
	/**
	 * @desc Get Projects Options For Select HTML Tag by id
	 * @param int project id  
	 * @return String 
	 **/
	 function GetProjects($p_pid=0){
		$db 		= DBConnection();
 
		$sql = "SELECT * FROM project_requests ORDER BY p_date ASC";
	 
		$query		= $db->execute($sql,array('p_id'=>$p_pid)); 
		$options 	= '';
		while($node = $db->fetch_assoc($query)){
			$options .= '<option value="'.$node['p_id'].'" '.(( $node['p_id'] == $p_pid)?' selected="selected"':'').'>'.$node['p_name'].'</option>'."\n";
		}
		return $options;
	 }
	 
	 
	// return Projects label  
	/**
     * @desc get department label 
 
     * @return string
     */
    function GetProjectsLabel($p_pid ) {
		$db 		= DBConnection();
		$sql = "SELECT * FROM project_requests WHERE p_id=:p_pid ORDER BY p_date ASC";
		$node = $db->fetch_assoc($db->execute($sql, array('p_pid'=>$p_pid)));
		return $node['p_name'];
	}
	
	
	/**
     * @desc Get Student Info by id
     * @param int    $user_id user id or user mail
     * @param string $attr which feild to return from table
     * @return array
     */
	function GetUserById($user_id, $attr='*'){
		$db 	= DBConnection();
		$sql	= "SELECT * FROM users WHERE user_id=:user_id OR user_mail=:user_id OR user_idno=:user_id";
		$user	= $db->fetch_assoc($db->execute($sql, array('user_id'=>$user_id)));
		if(isset($user['user_id'])){
			if(isset($user[$attr])){
				return($user[$attr]);
			}
			return($user);
		}
		return(false);
	}
	
	/**
     * @desc Format a local time/date in Arabic string
     * @param string $formate Format string (same as PHP date function)
     * @param string $time Unix timestamp
     * @param integer $mode Output mode of date function where:
     *                       1) Hijri format (Islamic calendar)
     *                       2) Arabic month names used in Middle East countries
     *                       3) Arabic Transliteration of Gregorian month names
     *                       4) Both of 2 and 3 formats together
     *                       5) Libya style
     *                       6) Algeria and Tunis style
     *                       7) Morocco style      
     * @return string 
     */
    function ArDate($formate, $time=0, $mode=1) {
		static $Arabic;
		if(!is_object($Arabic)){
			require_once('libraries/Arabic.class.php');
			$Arabic = new I18N_Arabic('Date');
		}
		$time = ($time>0)?$time:time();
		$Arabic->setMode($mode);
		$diff = $Arabic->dateCorrection($time);
		return($Arabic->date($formate, $time, $diff));
	}
	
	/**
     * This will return current Unix timestamp 
     * for given Hijri date (Islamic calendar)
     *          
     * @param integer $m     Hijri month (Islamic calendar)
     * @param integer $d     Hijri day   (Islamic calendar)
     * @param integer $y     Hijri year  (Islamic calendar)
     * @return integer Returns the current time measured in the number of
     *                seconds since the Unix Epoch (January 1 1970 00:00:00 GMT)
     */
    function ArMktime($d, $m='1', $y='1420') {
		static $Arabic;
		if(!is_object($Arabic)){
			require_once('libraries/Arabic.class.php');
			$Arabic = new I18N_Arabic('Mktime');
		}
		//try to be flixabel
		if(strpos($d, '-')) list($y, $m, $d) = explode('-', $d);
		if(strpos($d, '/')) list($y, $m, $d) = explode('/', $d);
		$diff = $Arabic->mktimeCorrection((int)$m, (int)$y);
		return($Arabic->mktime(0, 0, 0, (int)$m,  (int)$d, (int)$y, $diff));
	}
	
	function number2string($number) {
		require_once('libraries/Numbers.php');
		$arabic = new I18N_Arabic_Numbers();
		return $arabic->int2str($number);
	}
	
	/**
     * @desc upload file
     * @param string $name the input's name
     * @param array $allowed_type allowed types
     * @return (array|string) 
     */
	function SaveUploadedFile($name, $allowed_type = FALSE) {
		if (!$allowed_type) {
			$allowed_type = array('png', 'jpg', 'gif', 'zip', 'rar');
		}
		if(isset($_FILES[$name])){
			if(is_array($_FILES[$name]['name'])){
				$count=0;
				$result = FALSE;
				foreach($_FILES[$name]['name'] as $file_name){
					if($_FILES['attachment']['error'][$count] == 0){
						$ext = strtolower(substr($file_name, strrpos($file_name, '.') +1));
						if (in_array($ext, $allowed_type) and $_FILES['attachment']['size'][$count] <= 2097152) {
							$savepath = 'public/uploads/'.microtime(true).$_FILES[$name]['name'][$count];
							if (strlen($savepath) > 128) $savepath = substr($savepath, 0, 124).'.'.$ext;  // fix long filenames
							if(move_uploaded_file($_FILES[$name]['tmp_name'][$count], $savepath)) {
								$result[$count]['path'] 	= $savepath;
								$result[$count]['filename']	= $file_name;
							}
						}else{
							$result[$count] = FALSE;
						}
					}elseif(in_array($_FILES['attachment']['error'][$count], array(1,2,3,5,6,7,8))){
						$result[$count] = FALSE;
					}
					$count++;
				}
				return $result;
			}else{
				$file_name = $_FILES[$name]['name'];
				$ext = strtolower(substr($file_name, strrpos($file_name, '.') +1));
				if (in_array($ext, $allowed_type)) {
					$savepath = 'public/uploads/'.microtime(true).$_FILES[$name]['name'];
					if (strlen($savepath) > 128) $savepath = substr($savepath, 0, 124).'.'.$ext;  // fix long filenames
					if(move_uploaded_file($_FILES[$name]['tmp_name'], $savepath)) {
						return($savepath);
					}
				}
			}
		}
		return(false);
	}
	
	
	// paging result
    /**
     * @desc pagantion 
     * @param string $sql SQL Query
     * @param array $arr
     * @param int $limit limit number
     * @return string - html code
     */
	function PagingSQL(&$sql, $arr=array(), $limit=15) {
		static $counter;
		$page = 'pg'.($counter++);
		$db = DBConnection();
		$sql_hash = md5($sql.serialize($arr).date('i'));
		if($_SESSION[$sql_hash]) {
			$count = $_SESSION[$sql_hash];
		} else {
			$count = $db->fetch_assoc($db->execute('SELECT COUNT(*) FROM ('.preg_replace('/(\s+)LIMIT(\s+)(\d+\s*,\s*\d+|\d+)$/isU', '',$sql, 1).') as COUNT_TBL', $arr));
			$count = $count['COUNT(*)'];
			$_SESSION[$sql_hash] = $count;
		}
		$pages = floor($count/$limit);
		$offset = (int) $_GET[$page] * $limit;
		$offset = ($offset < $count)?$offset:$pages*$limit;
		$pagestart = ($_GET[$page] + 6 <$pages)?$_GET[$page] + 6:$pages;
		$pageend   = ($_GET[$page] - 6 >0)?$_GET[$page] - 6:0;
		for($i=$pageend;$i<=$pagestart;$i++) {
			if(ceil($offset/$limit) == $i ) {
				$paginate .= '<li class="current"><a href="?'.$page.'='.$i.'">'.($i + 1).'</a></li>';
			} else {
				$paginate .= '<li><a href="?'.$page.'='.$i.'">'.($i + 1).'</a></li>';
			}
		}
		if($pageend > 0) {$paginate = '<li><a href=?'.$page.'=0>0</a></li> ... '.$paginate;}
		if($pagestart < $pages) {$paginate = $paginate.' ... <li><a href=?'.$page.'='.$pages.'>'.$pages.'</a></li>';}
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$pager_vars = '<form method="POST" action="?"><input name="pager_vars" type="hidden" value="'.base64_encode(serialize($_POST)).'" /></form>';
			$pager_vars .= '<script>$(function(){$("#pager a").click(function(){$("#pager form").attr("action", $(this).attr("href"));$("#pager form").submit();return(false);});});</script>';
		}
		$paginate = '<div id="pager">'.$pager_vars.'<ul class="pagination">'.$paginate.'</ul></div>';
		$sql = $sql." LIMIT $offset, $limit";
		if ($pages) {
			return($paginate);
		} else {
			return "";
		}
	}
	
?>
