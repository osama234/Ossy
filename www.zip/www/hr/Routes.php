<?php
/**
 * Routes
 */

/* Login/Logout Routes */
Router::both('/user/login', 'user/user@login');
Router::get('/user/logout', 'user/user@logout');

include_once 'apps/control/Routes.php';

/** Routes for Human Resources System */
include_once 'apps/hrs/Routes.php';
