<?php

/*
 * Routes for Control modules
 */

Router::get('/control/users/unlink', 'control/users@unlink');
Router::post('/control/users/link', 'control/users@link');
Router::post('/control/users', 'control/users@index');
Router::group('/control/users', 'control/users');

Router::group('/control/groups', 'control/groups');

Router::both('/control/perms/user', 'control/perms@user');
Router::both('/control/perms/group', 'control/perms@group');
Router::get('/control/perms', 'control/perms@index');

Router::group('/control/options/enable', 'control/options@enable');
Router::group('/control/options/disable', 'control/options@disable');
Router::group('/control/options', 'control/options');
Router::get('/control', 'control/users@index');
