<?php

require_once 'apps/index/models/Group.php';

/**
 * Created by PhpStorm.
 * User: azzozhsn
 * Date: 2/6/2016 AD
 * Time: 1:03 PM
 */
class GroupsController extends controller
{
    /**
     * List all groups
     */
    public function index()
    {
        $this->vars['groups'] = Group::findAll();
    }

    /**
     * Add new group
     */
    public function add()
    {
        if (isset($_POST['group'])) {
            $group = new Group($_POST['group']);
            $group->save();
            setMessage('Group Added!', 'success');
            redirect('control/groups');
        }
    }

    /**
     * Edit Group
     * @param int $id or group to edit
     */
    public function edit($id)
    {
        $group = Group::find($id);
        if (isset($_POST['group'])) {
            $group->update($_POST['group']);
            setMessage('Group Updated!', 'success');
            redirect('control/groups');
        }
        $this->vars['group'] = $group;
    }

    /**
     * Delete Group
     * @param int $id or group to delete
     */
    public function delete($id)
    {
        Group::find($id)->delete();
        setMessage('Group Deleted!', 'success');
        redirect('control/groups');
    }
}
