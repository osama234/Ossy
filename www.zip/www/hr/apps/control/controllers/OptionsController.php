<?php

require_once 'apps/index/models/Option.php';

/**
 * Created by PhpStorm.
 * User: azzozhsn
 * Date: 2/6/2016 AD
 * Time: 1:03 PM
 */
class OptionsController extends controller
{
    /**
     * List all options
     */
    public function index()
    {
        $this->vars['options'] = Option::findAll();
    }

    /**
     * Add new Option
     */
    public function add()
    {
        if (isset($_POST['option'])) {
            $option = new Option($_POST['option']);
            $option->save();
            setMessage('Option Added!', 'success');
            redirect('control/options');
        }
    }

    /**
     * Edit Option
     * @param int $id or option to edit
     */
    public function edit($id)
    {
        $option = Option::find($id);
        if (isset($_POST['option'])) {
            $option->update($_POST['option']);
            setMessage('Option Updated!', 'success');
            redirect('control/options');
        }
        $this->vars['option'] = $option;
    }

    /**
     * Delete Option
     * @param int $id or option to delete
     */
    public function delete($id)
    {
        Option::find($id)->delete();
        setMessage('Option Deleted!', 'success');
        redirect('control/options');
    }

    /**
     * Enable Option
     * @param int $id or option to enable
     */
    public function enable($id)
    {
        $option = Option::find($id);
        $option->node_flag = 1;
        $option->save();
        SetMessage('Option Enabled!', 'success');
        Redirect('control/options');
    }

    /**
     * Disable Option
     * @param int $id or option to disable
     */
    public function disable($id)
    {
        $option = Option::find($id);
        $option->node_flag = -1;
        $option->save();
        SetMessage('Option Disabled!', 'success');
        Redirect('control/options');
    }
}
