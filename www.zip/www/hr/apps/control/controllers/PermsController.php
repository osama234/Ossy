<?php

require_once 'apps/index/models/User.php';

/**
 * Permission Controller
 */
class PermsController extends controller
{
    public function index()
    {
        $this->vars['users'] = User::findAll();
        $this->vars['groups'] = Group::findAll();
    }

    public function user($id)
    {
        if (isset($_POST['perms'])) {
            $this->setPerms('userperm', $id);
        }
        $this->vars['selected_user'] = User::find($id);
        $this->apps();
    }

    public function group($id)
    {
        if (isset($_POST['perms'])) {
            $this->setPerms('groupperm', $id);
        }
        $this->vars['group'] = Group::find($id);
        $this->apps();
    }

    private function setPerms($type, $id)
    {
        //delete old permission rows
        $this->mydb->execute("DELETE FROM core_perm WHERE tree_type=:type AND tree_pid=:tree_pid",
            array('tree_pid' => $id, 'type' => $type));
        // set the new permissions
        foreach ($_POST['perms'] as $key => $value) {
            Permissions::SetPerm($type, $key, $id);
        }
        setMessage('تم تعديل الصلاحيات بنجاح', 'success');
        redirect('control/perms');
    }

    private function apps()
    {
        $q = $this->mydb->execute('SELECT * FROM core_apps WHERE app_pid=0 ORDER BY app_sort ASC');
        while (($row = $this->mydb->fetch_assoc($q)) != false) {
            $q2 = $this->mydb->execute('SELECT * FROM core_apps WHERE app_pid=:app_id ORDER BY app_sort ASC', $row);
            $row['sub'] = array();
            while (($sub = $this->mydb->fetch_assoc($q2)) != false) {
                $q3 = $this->mydb->execute('SELECT * FROM core_apps WHERE app_pid=:app_id ORDER BY app_sort ASC', $sub);
                $sub['act'] = array();
                while (($act = $this->mydb->fetch_assoc($q3)) != false) {
                    $sub['act'][] = $act;
                }
                $row['sub'][] = $sub;
            }
            $this->vars['all_apps'][] = $row;
        }
    }
}