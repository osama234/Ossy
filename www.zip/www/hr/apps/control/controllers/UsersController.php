<?php

require_once 'apps/index/models/User.php';
require_once 'apps/index/models/Option.php';

/**
 * Created by PhpStorm.
 * User: azzozhsn
 * Date: 2/6/2016 AD
 * Time: 1:03 PM
 */
class UsersController extends controller
{
    public function index()
    {
        $filter = '';
        if (!empty($_POST['filter'])) {
            $filter = $_POST['filter'];
            $filter = 'user_name LIKE \'%' . $filter . '%\' OR user_enname LIKE \'%' . $filter . '%\' OR user_mobile LIKE \'%' . $filter . '%\' OR user_idno LIKE \'%' . $filter . '%\' OR user_mail LIKE \'%' . $filter . '%\'';
        }
        $this->vars['users'] = User::findAll($filter);
    }

    public function add()
    {
        if (isset($_POST['user'])) {
            $user = new User($_POST['user']);
            $user->save();
            redirect('control/users');
        }
    }

    public function edit($id)
    {
        $user = User::find($id);
        if (isset($_POST['user'])) {
            $user->update($_POST['user']);
            setMessage('User data saved!', 'success');
            redirect('control/users');
        }
        $this->vars['item'] = $user;
    }

    public function link()
    {
        if (isset($_POST['user_group'])) {
            $this->mydb->execute($this->mydb->sql_insert('user_group', $_POST['user_group']), $_POST['user_group']);
            redirect('control/users/edit/' . $_POST['user_group']['user_id']);
        }
    }

    public function unlink($user_id, $group_id)
    {
        echo $user_id;
        $this->mydb->execute('DELETE FROM user_group WHERE user_id=:user_id AND group_id=:group_id',
            array('user_id' => $user_id, 'group_id' => $group_id));
        redirect('control/users/edit/' . $user_id);
    }

    public function delete($id)
    {
        User::find($id)->delete();
        redirect('control/users');
    }
}