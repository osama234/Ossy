<?php
$GLOBALS['lang']['ar']['title'] = 'اللقب';
$GLOBALS['lang']['en']['title'] = 'Title';

$GLOBALS['lang']['ar']['ar_name'] = 'الاسم الثلاثي';
$GLOBALS['lang']['en']['ar_name'] = 'Name in Arabic';

$GLOBALS['lang']['ar']['en_name'] = 'الاسم باللغة الإنجليزية';
$GLOBALS['lang']['en']['en_name'] = 'Name in English';

$GLOBALS['lang']['ar']['job'] = 'الوظيفة';
$GLOBALS['lang']['en']['job'] = 'Job';

$GLOBALS['lang']['ar']['email'] = 'البريد الإلكتروني';
$GLOBALS['lang']['en']['email'] = 'E-mail';

$GLOBALS['lang']['ar']['idno'] = 'رقم الهوية';
$GLOBALS['lang']['en']['idno'] = 'ID Number';

$GLOBALS['lang']['ar']['mobile'] = 'رقم الجوال';
$GLOBALS['lang']['en']['mobile'] = 'Mobile';

$GLOBALS['lang']['ar']['gender'] = 'الجنس';
$GLOBALS['lang']['en']['gender'] = 'Gender';

$GLOBALS['lang']['ar']['update'] = 'حفظ البيانات';
$GLOBALS['lang']['en']['update'] = 'Update';

$GLOBALS['lang']['ar']['data_updated'] = 'تم تحديث البيانات بنجاح!';
$GLOBALS['lang']['en']['data_updated'] = 'Data updated successfully!';
