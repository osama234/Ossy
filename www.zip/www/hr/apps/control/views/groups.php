<div class="panel panel-default">
	<?=View::PanelHeader('المجموعات', View::ActionButton('control/groups/add', '', 'add', 0, 'إضافة'))?>
	<table class="table">
		<?php $i=1; foreach ($groups as $row){ ?>
		<tr>
			<td><?=$i++?></td>
			<td><?=$row->group_name_ar?></td>
			<td><?=$row->group_name_en?></td>
			<td>
				<div class="btn-group pull-right">
					<?=View::ActionButton('control/groups/edit', '', 'edit', $row->group_id, 'تعديل')?>
					<?=View::ActionButton('control/groups/delete', '', 'delete', $row->group_id, 'حذف')?>
				</div>
			</td>
		</tr>
		<?php } ?>
	</table>
</div>
