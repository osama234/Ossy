<?=View::OpenForm('control/groups/edit/'.$group->group_id)?>
<div class="panel panel-default">
    <?=View::PanelHeader('تعديل مجموعة')?>
    <div class="panel-body">
        <?=Input::TelH1('الاسم', 'group_name_ar', $group->group_name_ar, 'group', 'required')?>
        <?=Input::TelH1('Name', 'group_name_en', $group->group_name_en, 'group', 'required')?>
    </div>
    <?=View::FormFooter('حفظ', 'إلغاء', 'control/groups')?>
</div>
<?=View::CloseForm()?>
