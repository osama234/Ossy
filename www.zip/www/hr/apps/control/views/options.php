<div class="panel panel-default">
    <?= View::PanelHeader('الخيارات', View::ActionButton('control/options/add', '', 'add')) ?>
    <table class="table">
        <tr>
            <th>#</th>
            <th>النوع</th>
            <th>القيمة</th>
            <th>الوصف</th>
            <th>Description</th>
            <th>الترتيب</th>
            <td></td>
        </tr>
        <?php foreach ($options as $row) { ?>
            <tr>
                <td><?= $row->node_id ?></td>
                <td><?= $row->node_type ?></td>
                <td><?= $row->node_name ?></td>
                <td><?= $row->node_ar ?></td>
                <td><?= $row->node_en ?></td>
                <td><?= $row->node_sort ?></td>
                <td>
                    <div class="pull-right">
                        <?= View::ActionButton('control/options/edit', '', 'edit', $row->node_id) ?>
                        <?php if ($row->node_flag >= 0) { ?>
                            <?= View::ActionButton('control/options/disable', '', 'disable', $row->node_id) ?>
                        <?php } else { ?>
                            <?= View::ActionButton('control/options/enable', '', 'enable', $row->node_id) ?>
                        <?php } ?>
                        <?= View::ActionButton('control/options/delete', '', 'delete', $row->node_id) ?>
                    </div>
                </td>
            </tr>
        <?php } ?>
    </table>
</div>
