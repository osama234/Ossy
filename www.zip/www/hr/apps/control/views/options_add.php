<?=View::OpenForm('control/options/add/')?>
<div class="panel panel-default">
	<?=View::PanelHeader('إضافة خيار')?>
	<div class="panel-body">
		<?=Input::TextH1('النوع', 'node_type', '', 'option', 'required')?>
		<?=Input::TextH1('القيمة', 'node_name', '', 'option', 'required')?>
		<?=Input::TextH1('الوصف', 'node_ar', '', 'option', 'required')?>
		<?=Input::TextH1('Description', 'node_en', '', 'option')?>
		<?=Input::TelH1('الترتيب', 'node_sort', '', 'option')?>
	</div>
	<?=View::FormFooter('حفظ البيانات', 'إلغاء', 'control/options')?>
</div>
<?=View::CloseForm()?>
