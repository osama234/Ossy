<div class="panel panel-default">
    <?= View::PanelHeader('المستخدمين') ?>
    <table class="table">
        <tr>
            <th>م</th>
            <th>الاسم</th>
            <th>البريد الإلكتروني</th>
            <th>الجوال</th>
            <th></th>
        </tr>
        <?php foreach ($users as $row) { ?>
            <tr>
                <td><?= $row->user_id ?></td>
                <td><?= $row->user_name ?></td>
                <td><?= $row->user_mail ?></td>
                <td><?= $row->user_mobile ?></td>
                <td>
                    <div class="pull-right">
                        <?= View::ActionButton('control/perms/user', 'الصلاحيات', 'edit', $row->user_id) ?>
                    </div>
                </td>
            </tr>
        <?php } ?>
    </table>
</div>

<div class="panel panel-default">
    <?= View::PanelHeader('المجموعات') ?>
    <table class="table">
        <?php $i = 1;
        foreach ($groups as $row) { ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= $row->group_name_ar ?></td>
                <td>
                    <div class="pull-right">
                        <?= View::ActionButton('control/perms/group', 'الصلاحيات', 'edit', $row->group_id) ?>
                    </div>
                </td>
            </tr>
        <?php } ?>
    </table>
</div>
