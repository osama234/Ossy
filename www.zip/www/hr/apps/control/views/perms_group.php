<?= View::OpenForm('control/perms/group/'.$group->group_id)?>
    <div class="panel panel-default">
        <?= View::PanelHeader($group->group_name_ar) ?>
        <div class="panel-body">
            <?php foreach($all_apps as $app) { ?>
                <div class="app" style="padding-right: 20px; padding-left: 20px;">
                    <?php if(Permissions::CheckGroupPerms($group->group_id, $app['app_id'])==1) { ?>
                        <input style="padding-right: 20px; padding-left: 20px;" type="checkbox" name="perms[<?=$app['app_id']?>]" class="app_checkbox" value="1" checked />
                    <?php } elseif(Permissions::CheckGroupPerms($group->group_id, $app['app_id'])>=2) {?>
                        <input  style="padding-right: 20px; padding-left: 20px;" type="checkbox" name="perms[<?=$app['app_id']?>]" class="app_checkbox" value="1" checked disabled="disabled" />
                    <?php } else { ?>
                        <input  style="padding-right: 20px; padding-left: 20px;" type="checkbox" name="perms[<?=$app['app_id']?>]" class="app_checkbox" value="1" />
                    <?php } ?>
                    <a href="#" class="link"><?=$app['app_ar']?></a>
                    <?php foreach($app['sub'] as $sub) { ?>
                        <div style="padding-right: 20px; padding-left: 20px;">
                            <?php if(Permissions::CheckGroupPerms($group->group_id, $sub['app_id'])==1) { ?>
                                <input type="checkbox" name="perms[<?=$sub['app_id']?>]" class="sub_checkbox" value="1" checked />
                            <?php } elseif(Permissions::CheckGroupPerms($group->group_id, $sub['app_id'])>=2) {?>
                                <input type="checkbox" name="perms[<?=$sub['app_id']?>]" class="sub_checkbox" value="1" checked disabled="disabled" />
                            <?php } else { ?>
                                <input type="checkbox" name="perms[<?=$sub['app_id']?>]" class="sub_checkbox" value="1" />
                            <?php } ?>
                            <?=$sub['app_ar']?>
                            <?php foreach($sub['act'] as $act) { ?>
                                <div style="padding-right: 20px; padding-left: 20px;">
                                    <?php if(Permissions::CheckGroupPerms($group->group_id, $act['app_id'])==1) { ?>
                                        <input type="checkbox" name="perms[<?=$act['app_id']?>]" class="sub_checkbox" value="1" checked />
                                    <?php } elseif(Permissions::CheckGroupPerms($group->group_id, $act['app_id'])>=2) {?>
                                        <input type="checkbox" name="perms[<?=$act['app_id']?>]" class="sub_checkbox" value="1" checked disabled="disabled" />
                                    <?php } else { ?>
                                        <input type="checkbox" name="perms[<?=$act['app_id']?>]" class="sub_checkbox" value="1" />
                                    <?php } ?>
                                    <?=$act['app_ar']?>
                                </div>
                            <?php } ?>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
        <?= View::FormFooter('حفظ البيانات', 'إلغاء', 'control/perms') ?>
    </div>
</form>