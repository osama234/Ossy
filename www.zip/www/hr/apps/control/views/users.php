<?= View::OpenForm('control/users') ?>
    <div class="form-group">
        <div class="col-sm-10">
            <input type="text" placeholder="اسم، رقم جوال، بريد إلكتروني" class="form-control" value="" name="filter">
        </div>
        <div class="col-sm-2">
            <button class="btn btn-default" type="submit"><i class="fa fa-search"></i> بحث</button>
        </div>
    </div>
<?= View::CloseForm() ?>
<div class="panel panel-default">
    <?= View::PanelHeader('المستخدمين', View::ActionButton('control/users/add', '', 'add', 0, 'إضافة')) ?>
    <table class="table">
        <tr>
            <td>م</td>
            <td><?= lang('ar_name') ?></td>
            <td><?= lang('job') ?></td>
            <td><?= lang('email') ?></td>
            <td><?= lang('mobile') ?></td>
            <td></td>
        </tr>
        <?php foreach ($users as $row) { ?>
            <tr>
                <td><?= $row->user_id ?></td>
                <td><?= $row->user_name ?></td>
                <td><?= $row->user_desc ?></td>
                <td><?= $row->user_mail ?></td>
                <td><?= $row->user_mobile ?></td>
                <td>
                    <span class="pull-right">
                        <?= View::ActionButton('control/users/edit', '', 'edit', $row->user_id, 'تعديل') ?>
                        <?= View::ActionButton('control/users/delete', '', 'delete', $row->user_id, 'حذف') ?>
                    </span>
                </td>
            </tr>
        <?php } ?>
    </table>
</div>
