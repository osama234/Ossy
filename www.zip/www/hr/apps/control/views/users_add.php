<?=View::OpenForm('control/users/add/')?>
    <div class="panel panel-default">
        <?=View::PanelHeader('إضافة مستخدم')?>
        <div class="panel-body">
            <?=Input::TextH1(lang('ar_name'), 'user_name', '', 'user')?>
            <?=Input::TextH1(lang('en_name'), 'user_enname', '', 'user')?>
            <?=Input::TextH1(lang('job'), 'user_desc', '', 'user')?>
            <?=Input::EmailH1(lang('email'), 'user_mail', '', 'user')?>
            <?=Input::PasswordH1(lang('password'), 'user_password', '', 'user')?>
            <?=Input::TelH1(lang('idno'), 'user_idno', '', 'user')?>
            <?=Input::TelH1(lang('mobile'), 'user_mobile', '', 'user')?>
            <?=Input::SelectH1(lang('gender'), 'user_sex', Option::GetOptions('gender'), 'user')?>
        </div>
        <?=View::FormFooter(lang('update'))?>
    </div>
<?=View::CloseForm()?>