<?=View::OpenForm('control/users/edit/'.$item->user_id)?>
    <div class="panel panel-default">
        <?=View::PanelHeader('تعديل')?>
        <div class="panel-body">
            <?=Input::TextH1(lang('ar_name'), 'user_name', $item->user_name, 'user')?>
            <?=Input::TextH1(lang('en_name'), 'user_enname', $item->user_enname, 'user')?>
            <?=Input::TextH1(lang('job'), 'user_desc', $item->user_desc, 'user')?>
            <?=Input::EmailH1(lang('email'), 'user_mail', $item->user_mail, 'user')?>
            <?=Input::TelH1(lang('idno'), 'user_idno', $item->user_idno, 'user')?>
            <?=Input::TelH1(lang('mobile'), 'user_mobile', $item->user_mobile, 'user')?>
            <?=Input::SelectH1(lang('gender'), 'user_sex', Option::GetOptions('gender', $item->user_sex), 'user')?>
        </div>
        <?=View::FormFooter(lang('update'))?>
    </div>
<?=View::CloseForm()?>

<?=View::OpenForm('control/users/link')?>
    <input type="hidden" name="user_group[user_id]" value="<?=$item->user_id?>" />
    <div class="panel panel-default">
        <?=View::PanelHeader('المجموعات المنتمي لها')?>
        <div class="panel-body">
            <?php foreach ($item->groups() as $row){ ?>
                <p>
                    <?=View::ActionButton('control/users/unlink', '', 'delete', $item->user_id.'/'.$row->group_id)?>
                    <?=$row->group_name_ar?>
                </p>
            <?php } ?>
            <?=Input::SelectH2('المجموعة', 'group_id', Group::getOptions(), 'user_group', 'required')?>
            <button class="btn btn-success" type="submit"> <i class="fa fa-check"></i> إضافة للمجموعة</button>
        </div>
    </div>
<?=View::CloseForm()?>
