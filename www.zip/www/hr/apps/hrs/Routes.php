<?php
/**
 * Routes for HR system
 */

Router::both('/hrs/vacations/add', 'hrs/vacations@add');
Router::both('/hrs/vacations/show', 'hrs/vacations@show');
Router::both('/hrs/vacations/accept', 'hrs/vacations@accept');
Router::both('/hrs/vacations/reject', 'hrs/vacations@reject');
Router::both('/hrs/vacations/approve', 'hrs/vacations@approve');
Router::both('/hrs/vacations/deny', 'hrs/vacations@deny');
Router::get('/hrs/vacations', 'hrs/vacations@index');

Router::get('/hrs/manage/show', 'hrs/manage@show');
Router::get('/hrs/manage/approve', 'hrs/manage@approve');
Router::get('/hrs/manage/reject', 'hrs/manage@reject');
Router::get('/hrs/manage/balances', 'hrs/manage@balances');
Router::both('/hrs/manage', 'hrs/manage@index');

Router::group('/hrs/employees', 'hrs/employees');

Router::both('/hrs/departments/add', 'hrs/departments@add');
Router::both('/hrs/departments/edit', 'hrs/departments@edit');
Router::get('/hrs/departments/delete', 'hrs/departments@delete');
Router::get('/hrs/departments/list', 'hrs/departments@depts');
Router::get('/hrs/departments', 'hrs/departments@index');

Router::get('/hrs', 'hrs/vacations@index');
Router::get('/', 'hrs/vacations@index');
