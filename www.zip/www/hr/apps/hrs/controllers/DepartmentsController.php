<?php

require_once 'apps/hrs/models/Dept.php';

class DepartmentsController extends controller
{
    public function index()
    {
        $this->vars['tree'] = Dept::getDeptsTree();
    }

    public function depts()
    {
        $this->vars['depts'] = Dept::findAll('', 'd_pid ASC, d_id ASC');
    }

    public function add()
    {
        if (isset($_POST['dept'])) {
            $dept = new Dept($_POST['dept']);
            $dept->save();
            redirect('hrs/departments/list');
        }
    }

    public function edit($id)
    {
        $dept = Dept::find($id);
        if (isset($_POST['dept'])) {
            $dept->update($_POST['dept']);
            redirect('hrs/departments/list');
        }
        $this->vars['dept'] = $dept;
    }

    public function delete($id)
    {
        Dept::find($id)->delete();
        redirect('hrs/departments/list');
    }
}
