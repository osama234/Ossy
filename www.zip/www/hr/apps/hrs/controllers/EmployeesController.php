<?php

require_once 'apps/index/models/User.php';
require_once 'apps/index/models/Option.php';
require_once 'apps/hrs/models/Dept.php';

class EmployeesController extends controller
{
    public function index()
    {
        $this->vars['users'] = User::findAll();
    }

    public function add()
    {
        if (isset($_POST['user'])) {
            $user = new User($_POST['user']);
            $user->save();
            setMessage('تمت إضافة المستخدم!', 'success');
            redirect('hrs/employees');
        }
    }

    public function edit($id)
    {
        $user = User::find($id);
        if (isset($_POST['user'])) {
            $user->update($_POST['user']);
            setMessage('تم تعديل المستخدم!', 'success');
            redirect('hrs/employees');
        }
        $this->vars['item'] = $user;
    }

    public function delete($id)
    {
        User::find($id)->delete();
        redirect('hrs/employees');
    }
}
