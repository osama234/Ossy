<?php

require_once 'apps/index/models/User.php';
require_once 'apps/index/models/Option.php';
require_once 'apps/hrs/models/Vacation.php';

class ManageController extends controller
{
    public function index()
    {
        $vacations = Vacation::findAll();
        $calendar = new HijriCalendar();
        foreach ($vacations as $row) {
            $calendar->addEvent($row->v_start, $row->v_duration, User::find($row->v_userid)->user_name);
        }
        $this->vars['calendar'] = $calendar->render();
        $this->vars['vacations'] = $vacations;
    }

    public function balances()
    {
        $this->vars['balances'] = VacationBalance::findAll();
    }

    public function show($id)
    {
        $this->vars['vacation'] = Vacation::find($id);
    }

    public function approve($id)
    {
        $vacation = Vacation::find($id);
        $vacation->v_status = 4;
        $vacation->v_signer = $this->user['user_id'];
        $vacation->save();
        redirect('hrs/manage');
    }

    public function reject($id)
    {
        $vacation = Vacation::find($id);
        $vacation->v_status = -4;
        $vacation->v_signer = $this->user['user_id'];
        $vacation->save();
        redirect('hrs/manage');
    }
}