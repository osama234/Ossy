<?php

require_once 'apps/index/models/User.php';
require_once 'apps/index/models/Option.php';
require_once 'apps/hrs/models/Vacation.php';

class VacationsController extends controller
{
    public function index()
    {
        $this->vars['vacations'] = Vacation::findAll('v_userid=' . $this->user['user_id']);
        $this->vars['requests'] = Vacation::findAll('v_status = 1 AND v_altuser=' . $this->user['user_id']);
        if ($this->user['user_level'] == 2) {
            // select users who suppose to approve to them
            $users_ids = [];
            $sql = 'SELECT user_id FROM users
                                        INNER JOIN departments ON user_dept=d_id
                                        WHERE (user_dept=:user_dept AND user_level=1)
                                        OR (d_pid=:user_dept AND user_level=2)';
            $query = $this->mydb->execute($sql, $this->user);
            while ($row = $this->mydb->fetch_assoc($query)) {
                $users_ids[] = $row['user_id'];
            }
            $this->vars['approval'] = Vacation::findAll('v_status = 2 AND v_userid IN(' . implode(', ', $users_ids) . ')');
        }
    }

    public function add()
    {
        if (!empty($_POST['vacation'])) {
            $_POST['vacation']['v_start'] .= 'هـ ' . $_POST['v_start2'];
            $vacation = new Vacation($_POST['vacation']);
            $vacation->v_userid = $this->user['user_id'];
            $vacation->save();
        }
    }

    public function show($id)
    {
        $this->vars['vacation'] = Vacation::find($id);
    }

    public function accept($id)
    {
        $vacation = Vacation::find($id);
        $vacation->v_status = 2;
        $vacation->save();
        redirect('hrs/vacations');
    }

    public function reject($id)
    {
        $vacation = Vacation::find($id);
        $vacation->v_status = -2;
        $vacation->save();
        redirect('hrs/vacations');
    }

    public function approve($id)
    {
        $vacation = Vacation::find($id);
        $vacation->v_status = 3;
        $vacation->v_signer = $this->user['user_id'];
        $vacation->save();
        redirect('hrs/vacations');
    }

    public function deny($id)
    {
        $vacation = Vacation::find($id);
        $vacation->v_status = -3;
        $vacation->v_signer = $this->user['user_id'];
        $vacation->save();
        redirect('hrs/vacations');
    }
}
