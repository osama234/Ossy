<?php

/**
 * Dept Model
 */
class Dept extends Model
{
    /**
     * Dept constructor.
     * Set table name and primary key
     * @param bool $attrs
     */
    public function __construct($attrs = false)
    {
        $this->pk = 'd_id';
        $this->table = 'departments';
        parent::__construct($attrs);
    }

    public static function getDeptsTree($pid = 0)
    {
        $depts = Dept::findAll('d_pid=' . $pid);
        foreach ($depts as $key => $dept) {
            $depts[$key]->sub = Dept::getDeptsTree($dept->d_id);
        }
        return $depts;
    }

    public static function renderTree($items)
    {
        $render = '<ul>';
        foreach ($items as $item) {
            $render .= '<li><a href="#">' . $item->d_name . '</a>';
            $render .= Dept::renderTree($item->sub);
            $render .= '</li>';
        }
        return $render . '</ul>';
    }

    public static function getOptions($selected = 0, $emptyOption = false)
    {
        $tree = Dept::getDeptsTree();
        $options = Dept::getDeptOptions($tree, $selected);
        if ($emptyOption) {
            $options = '<option value="0"></option>' . $options;
        }
        return $options;
    }

    private static function getDeptOptions($items, $selected = 0, $level = 0)
    {
        $render = '';
        foreach ($items as $item) {
            $render .= '<option value="' . $item->d_id . '"' . ($item->d_id == $selected ? ' selected' : '') . '>' . str_repeat('-',
                    $level) . ' ' . $item->d_name . '</option>';
            $render .= Dept::getDeptOptions($item->sub, $selected, $level + 1);
        }
        return $render;
    }
}
