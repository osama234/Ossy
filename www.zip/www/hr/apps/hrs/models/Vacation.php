<?php

/**
 * Vacation Model
 */
class Vacation extends Model
{
    function __construct($attr = false)
    {
        $this->pk = 'v_id';
        $this->table = 'vacations';
        parent::__construct($attr);
    }

    public static function getUserBalance($user_id)
    {
        $balance = VacationBalance::find($user_id);
        if (explode('/', $balance->lastupdate)[1] != arDate('m')) {
            Vacation::updateBalances();
            $balance = VacationBalance::find($user_id);
        }
        $days = 0;
        $vacations = Vacation::findAll('v_status=4 AND v_userid='.$user_id);
        foreach ($vacations as $row) {
            $days += $row->v_duration;
        }
        return $balance->balance - $days;
    }

    private static function updateBalances()
    {
        $balances = VacationBalance::findAll();
        foreach ($balances as $balance) {
            $datetime1 = new DateTime($balance->lastupdate);
            $datetime2 = new DateTime(arDate('Y/m/d'));
            $interval = $datetime1->diff($datetime2);
            $mons = $interval->y * 12 + $interval->m;

            $nat = User::find($balance->user_id)->user_nat;
            $add = 1.75 * $mons;
            if ($nat == 'SA') {
                $add = 2.5 * $mons;
            }
            $balance->balance += $add;
            $balance->lastupdate = arDate('Y/m/01');
            $balance->save();
        }
    }
}

class VacationBalance extends Model
{
    function __construct($attr = false)
    {
        $this->pk = 'user_id';
        $this->table = 'vacation_balance';
        parent::__construct($attr);
    }
}