<link href="<?= base_url('web/css/tree.css') ?>" rel="stylesheet" />

<div class=" panel panel-default">
    <?= View::PanelHeader('الهيكل الإداري') ?>
    <div class="panel-body tree">
        <?= Dept::renderTree($tree) ?>
    </div>
    <?= View::PanelFooter(View::ActionButton('hrs/departments/list', 'تعديل', 'edit')) ?>
</div>
