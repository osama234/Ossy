<link href="<?= base_url('web/css/tree.css') ?>" rel="stylesheet" />

<?= View::OpenForm('hrs/departments/add') ?>
    <div class=" panel panel-default">
        <?= View::PanelHeader('إضافة إدارة') ?>
        <div class="panel-body tree">
            <?= Input::TextH1('اسم الإدارة', 'd_name', false, 'dept', 'required') ?>
            <?= Input::SelectH1('فرع من', 'd_pid', Dept::getOptions(), 'dept') ?>
        </div>
        <?= View::FormFooter('حفظ', 'إلغاء', 'hrs/departments/list') ?>
    </div>
<?= View::CloseForm() ?>
