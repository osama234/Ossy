<div class="panel panel-default">
    <?= View::PanelHeader('الإدارات', View::ActionButton('hrs/departments/add', 'إضافة', 'add')) ?>
    <table class="table">
        <?php foreach ($depts as $row) { ?>
            <tr>
                <td><?= $row->d_name ?></td>
                <td><div class="pull-right">
                    <?= View::ActionButton('hrs/departments/edit', '', 'edit', $row->d_id) ?>
                    <?= View::ActionButton('hrs/departments/delete', '', 'delete', $row->d_id) ?>
                </div></td>
            </tr>
        <?php } ?>
    </table>
    <?= View::PanelFooter(View::ActionButton('hrs/departments', 'رجوع', 'back')) ?>
</div>