<div class="panel panel-default">
    <?= View::PanelHeader('الموظفين', View::ActionButton('hrs/employees/add', '', 'add', 0, 'إضافة')) ?>
    <table class="table">
        <tr>
            <td>م</td>
            <td>الاسم</td>
            <td>الوظيفة</td>
            <td>الإدارة</td>
            <td>رقم الجوال</td>
            <td></td>
        </tr>
        <?php foreach ($users as $row) { ?>
        <tr>
            <td><?= $row->user_id ?></td>
            <td><?= $row->user_name ?></td>
            <td><?= $row->user_desc ?></td>
            <td><?= Dept::find($row->user_dept)->dep_ar ?></td>
            <td><?= $row->user_mobile ?></td>
            <td>
                <span class="pull-right">
                    <?= View::ActionButton('hrs/employees/edit', '', 'edit', $row->user_id, 'تعديل') ?>
                    <?= View::ActionButton('hrs/employees/delete', '', 'delete', $row->user_id, 'حذف') ?>
                </span>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>
