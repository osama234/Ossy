<?=View::OpenForm('hrs/employees/add')?>
<div class="panel panel-default">
    <?=View::PanelHeader('إضافة موظف')?>
    <div class="panel-body">
        <?=Input::TextH1('الاسم الثلاثي', 'user_name', false, 'user')?>
        <?=Input::TextH1('الوظيفة', 'user_desc', false, 'user')?>
        <?=Input::SelectH1('الإدارة', 'user_dept', Dept::getOptions(), 'user')?>
        <div class="form-group">
            <label for="v_start" class="control-label col-md-2">المستوى الوظيفي في الإدارة</label>
            <div class="col-md-10">
                <label class="radio-inline"><input type="radio" name="user[user_level]" value="1" checked /> موظف</label>
                <label class="radio-inline"><input type="radio" name="user[user_level]" value="2" /> مدير</label>
            </div>
        </div>
        <?=Input::SelectH1('الجنسية', 'user_nat', Option::getOptions('nationality', false, true), 'user' , 'required')?>
        <?=Input::TelH1('رقم الهوية', 'user_idno', false, 'user')?>
        <?=Input::TelH1('رقم الجوال', 'user_mobile', false, 'user')?>
        <?=Input::EmailH1('البريد الإلكتروني', 'user_mail', false, 'user')?>
    </div>
    <?=View::FormFooter('حفظ البيانات', 'إلغاء', 'hrs/employees')?>
</div>
<?=View::CloseForm()?>
