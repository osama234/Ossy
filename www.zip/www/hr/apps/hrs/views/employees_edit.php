<?=View::OpenForm('hrs/employees/edit/'.$item->user_id)?>
    <div class="panel panel-default">
        <?=View::PanelHeader('تعديل')?>
        <div class="panel-body">
            <?=Input::TextH1('الاسم الثلاثي', 'user_name', $item->user_name, 'user')?>
            <?=Input::TextH1('الوظيفة', 'user_desc', $item->user_desc, 'user')?>
            <?=Input::SelectH1('الإدارة', 'user_dept', Dept::getOptions($item->user_dept), 'user')?>
            <div class="form-group">
                <label for="v_start" class="control-label col-md-2">المستوى الوظيفي في الإدارة</label>
                <div class="col-md-10">
                    <label class="radio-inline"><input type="radio" name="user[user_level]" value="1" <?= ($item->user_level == 1 ? 'checked ':'') ?> /> موظف</label>
                    <label class="radio-inline"><input type="radio" name="user[user_level]" value="2" <?= ($item->user_level == 2 ? 'checked ':'') ?> /> مدير</label>
                </div>
            </div>
            <?=Input::SelectH1('الجنسية', 'user_nat', Option::getOptions('nationality', $item->user_nat), 'user')?>
            <?=Input::TelH1('رقم الهوية', 'user_idno', $item->user_idno, 'user')?>
            <?=Input::TelH1('رقم الجوال', 'user_mobile', $item->user_mobile, 'user')?>
            <?=Input::EmailH1('البريد الإلكتروني', 'user_mail', $item->user_mail, 'user')?>
        </div>
        <?=View::FormFooter('حفظ البيانات', 'إلغاء', 'hrs/employees')?>
    </div>
<?=View::CloseForm()?>
