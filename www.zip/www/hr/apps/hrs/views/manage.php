<div class="panel panel-default">
    <?= $calendar ?>
</div>


<div class="panel panel-default">
    <?= View::PanelHeader('الإجازات', View::ActionButton('hrs/manage/balances', 'رصيد الإجازات', '')) ?>
    <table class="table">
        <tr>
            <th>الموظف</th>
            <th>نوع الإجازة</th>
            <th>مدتها</th>
            <th>بدايتها</th>
            <th>الموظف البديل</th>
            <th>الحالة</th>
        </tr>
        <?php foreach ($vacations as $row ) { ?>
        <tr>
            <td><?= User::find($row->v_userid)->user_name ?></td>
            <td><?= Option::getOptionsLabel('vacation_type', $row->v_type) ?></td>
            <td><?= $row->v_duration ?> يوم</td>
            <td><?= $row->v_start ?></td>
            <td><?= User::find($row->v_altuser)->user_name ?></td>
            <td><?= Option::getOptionsLabel('vacation_status', $row->v_status) ?></td>
            <td>
                <div class="pull-right"><?= View::ActionButton('hrs/manage/show', 'عرض', 'show', $row->v_id) ?></div>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>
