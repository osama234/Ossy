<div class="panel panel-default">
    <?= View::PanelHeader('رصيد الموظفين من الإجازات') ?>
    <table class="table">
        <?php foreach ($balances as $row) { ?>
        <tr>
            <td><?= User::find($row->user_id)->user_name ?></td>
            <td><?= $row->balance ?>يوم</td>
        </tr>
        <?php } ?>
    </table>
    <?= View::PanelFooter(View::ActionButton('hrs/manage', 'رجوع', 'back')) ?>
</div>