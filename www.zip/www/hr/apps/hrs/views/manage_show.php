<div class="panel panel-default">
    <?= View::PanelHeader('طلب إجازة') ?>
    <table class="table">
        <tr>
            <th width="20%">نوع الإجازة</th>
            <td><?= Option::getOptionsLabel('vacation_type', $vacation->v_type) ?></td>
        </tr>
        <tr>
            <th>مدتها</th>
            <td><?= $vacation->v_duration ?></td>
        </tr>
        <tr>
            <th>من تاريخ</th>
            <td><?= $vacation->v_start ?></td>
        </tr>
        <tr>
            <th>صاحب الطلب</th>
            <td><?= User::find($vacation->v_userid)->user_name ?></td>
        </tr>
        <tr>
            <th>الموظف البديل</th>
            <td><?= User::find($vacation->v_altuser)->user_name ?></td>
        </tr>
        <tr>
            <th>حالة الطلب</th>
            <td><?= Option::getOptionsLabel('vacation_status', $vacation->v_status) ?></td>
        </tr>
    </table>
        <?= View::PanelFooter(
            View::ActionButton('hrs/manage', 'رجوع', 'back').' '.
            View::ActionButton('hrs/manage/approve', 'قبول', 'submit', $vacation->v_id).' '.
            View::ActionButton('hrs/manage/reject', 'رفض', 'cancel', $vacation->v_id)
        ) ?>
</div>
