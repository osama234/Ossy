<h2>رصيد الإجازات الحالي: <?= Vacation::getUserBalance($user['user_id'])?> يوم</h2>
<div class="panel panel-default">
    <?= View::PanelHeader('إجازاتي', View::ActionButton('hrs/vacations/add', 'طلب إجازة', 'add')) ?>
    <table class="table">
        <tr>
            <th>نوع الإجازة</th>
            <th>مدتها</th>
            <th>بدايتها</th>
            <th>الموظف البديل</th>
            <th>الحالة</th>
        </tr>
        <?php foreach ($vacations as $row) { ?>
        <tr>
            <td><?= Option::getOptionsLabel('vacation_type', $row->v_type) ?></td>
            <td><?= $row->v_duration ?> يوم</td>
            <td><?= $row->v_start ?></td>
            <td><?= User::find($row->v_altuser)->user_name ?></td>
            <td><?= Option::getOptionsLabel('vacation_status', $row->v_status) ?></td>
        </tr>
        <?php } ?>
    </table>
</div>

<?php if (!empty($requests)) {?>
<div class="panel panel-default">
    <?= View::PanelHeader('إجازات الزملاء') ?>
    <table class="table">
        <tr>
            <th>نوع الإجازة</th>
            <th>مدتها</th>
            <th>بدايتها</th>
            <th>الموظف البديل</th>
        </tr>
        <?php foreach ($requests as $row) { ?>
            <tr>
                <td><?= Option::getOptionsLabel('vacation_type', $row->v_type) ?></td>
                <td><?= $row->v_duration ?> يوم</td>
                <td><?= $row->v_start ?></td>
                <td><?= User::find($row->v_userid)->user_name ?></td>
                <td>
                    <div class="pull-right"><?= View::ActionButton('hrs/vacations/show', 'عرض', 'show', $row->v_id) ?></div>
                </td>
            </tr>
        <?php } ?>
    </table>
</div>
<?php } ?>
