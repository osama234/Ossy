<?= View::OpenForm('hrs/vacations/add') ?>
    <div class="panel panel-default">
        <?= View::PanelHeader('طلب إجازة') ?>
        <div class="panel-body">
            <div class="form-group">
                <label for="v_start" class="control-label col-md-2">نوع الإجازة</label>
                <div class="col-md-10">
                    <label class="radio-inline">
                        <input type="radio" name="vacation[v_type]" value="1"> عادية
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="vacation[v_type]" value="2"> مرضية
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="vacation[v_type]" value="3"> اضطرارية
                    </label>
                </div>
            </div>
            <div class="form-group">
            <?= str_replace('type="text"', 'type="number" step="0.5" min="0.5" max="'.Vacation::getUserBalance($user['user_id']).'"', Input::TextH2('مدتها', 'v_duration', false, 'vacation', 'required')) ?>
            </div>
            <div class="form-group">
                <?= Input::TextH2('من تاريخ', 'v_start', false, 'vacation', 'ardatepicker required') ?>
                <div class="col-md-6">
                    <label class="radio-inline">
                        <input type="radio" name="v_start2" value="صباحاً"> صباحاً
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="v_start2" value="مساءً"> مساءً
                    </label>
                </div>
            </div>
            <div class="form-group">
                <?= Input::SelectH2('الموظف البديل', 'v_altuser', User::getOptions(0, true), 'vacation') ?>
            </div>
        </div>
        <?= View::FormFooter('إرسال الطلب', 'إلغاء', 'pms/vacations') ?>
    </div>
<?= View::CloseForm() ?>
