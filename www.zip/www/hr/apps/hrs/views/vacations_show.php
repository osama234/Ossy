<div class="panel panel-default">
    <?= View::PanelHeader('طلب إجازة') ?>
    <table class="table">
        <tr>
            <th width="20%">نوع الإجازة</th>
            <td><?= Option::getOptionsLabel('vacation_type', $vacation->v_type) ?></td>
        </tr>
        <tr>
            <th>من تاريخ</th>
            <td><?= $vacation->v_start ?></td>
        </tr>
        <tr>
            <th>إلى تاريخ</th>
            <td><?= $vacation->v_end ?></td>
        </tr>
        <tr>
            <th>الموظف البديل</th>
            <td><?= User::find($vacation->v_altuser)->user_name ?></td>
        </tr>
        <tr>
            <th>صاحب الطلب</th>
            <td><?= User::find($vacation->v_userid)->user_name ?></td>
        </tr>
        <tr>
            <th>حالة الطلب</th>
            <td><?= Option::getOptionsLabel('vacation_status', $vacation->v_status) ?></td>
        </tr>
    </table>
    <?php if ($vacation->v_status == 1) { ?>
    <?= View::PanelFooter(
            '<p>يرغب الموظف المبين اسمه أعلاه في أن تحل محله خلال إجازته</p>'.
            View::ActionButton('hrs/vacations/accept', 'قبول', 'submit', $vacation->v_id).' '.
            View::ActionButton('hrs/vacations/reject', 'رفض', 'cancel', $vacation->v_id)
        ) ?>
    <?php } else { ?>
        <?= View::PanelFooter(
            View::ActionButton('hrs/vacations/approve', 'قبول', 'submit', $vacation->v_id).' '.
            View::ActionButton('hrs/vacations/deny', 'رفض', 'cancel', $vacation->v_id)
        ) ?>
    <?php } ?>
</div>
