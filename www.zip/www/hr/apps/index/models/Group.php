<?php

/**
 * Group Model
 */
class Group extends Model
{
    /**
     * Group constructor.
     * Set table name and primary key
     * @param bool $attrs
     */
    public function __construct($attrs = false)
    {
        $this->pk = 'group_id';
        $this->table = 'groups';
        parent::__construct($attrs);
    }

    /**
     * Get options for select inputs, usually to pass it to Input::SelectH1 or Input::SelectH2
     * @return string options html code.
     */
    public static function getOptions()
    {
        $groups = Group::findAll();
        $options = '';
        foreach ($groups as $group) {
            $options .= '<option value="' . $group->group_id . '">' . (getUserLang() == 'ar' ? $group->group_name_ar : $group->group_name_en) . '</options>';
        }
        return $options;
    }
}