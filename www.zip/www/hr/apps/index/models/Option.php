<?php

/**
 * Option Model Class.
 */
class Option extends Model
{
    /**
     * Option constructor.
     * Set table name and primary key
     * @param bool $attrs
     */
    public function __construct($attrs = false)
    {
        $this->pk = 'node_id';
        $this->table = 'options';
        parent::__construct($attrs);
    }

    /**
     * Get options for select inputs, usually to pass it to Input::SelectH1 or Input::SelectH2
     * @return string options html code.
     */
    public static function getOptions($type, $selected = null, $emptyOption = false)
    {
        $options = '';
        if ($emptyOption) {
            $options = '<option></option>';
        }
        $nodes = Option::findAll("node_type = '$type'");
        foreach ($nodes as $option) {
            $options .= '<option value="' . $option->node_name . '" ' . ($option->node_name == $selected ? ' selected' : '') . '>' . (lang() == 'ar' ? $option->node_ar : $option->node_en) . '</options>';
        }
        return $options;
    }

    /**
     * Get option's description.
     * @param $type string options type.
     * @param $selected int selected option.
     * @return string option's description.
     */
    public static function getOptionsLabel($type, $selected)
    {
        $option = Option::findAll([
            'node_type=:type AND node_name=:value ',
            ['type' => $type, 'value' => $selected]
        ])[0];
        $label = (lang() == 'ar' ? $option->node_ar : $option->node_en);
        return $label;
    }
}