<?php

require_once 'apps/index/models/Group.php';

/**
 * User Model
 */
class User extends Model
{
    /**
     * User constructor.
     * Set table name and primary key
     * @param bool $attrs
     */
    public function __construct($attrs = false)
    {
        $this->pk = 'user_id';
        $this->table = 'users';
        parent::__construct($attrs);
    }

    /**
     * Get User's groups.
     * @return array user's groups
     */
    public function groups()
    {
        $groups = [];
        $q = $this->db->execute('SELECT * FROM user_group WHERE user_id=:id', ['id' => $this->user_id]);
        while ($row = $this->db->fetch_assoc($q)) {
            $groups[] = Group::find($row['group_id']);
        }
        return $groups;
    }

    /**
     * Get options for select inputs, usually to pass it to Input::SelectH1 or Input::SelectH2
     * @return string options html code.
     */
    public static function getOptions($selected = null, $emptyOption = false)
    {
        $users = User::findAll();
        $options = '';
        if ($emptyOption) {
            $options = '<option></option>';
        }
        foreach ($users as $user) {
            $options .= '<option value="' . $user->user_id . '" ' . ($user->user_id == $selected ? ' selected' : '') . '>' . (lang() == 'ar' ? $user->user_name : $user->user_enname) . '</options>';
        }
        return $options;
    }
}
