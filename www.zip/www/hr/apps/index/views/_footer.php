				<br />
				<br />
				<br />
				</div><!-- container-fluid -->
			</div><!-- page-content-wrapper -->
	    </div><!-- wrapper -->
        <script type="text/javascript" src="<?= base_url('web/js/jquery.min.js') ?>"></script>
        <script type="text/javascript" src="<?= base_url('web/js/jquery.plugin.js') ?>"></script>
        <script type="text/javascript" src="<?= base_url('web/js/jquery.calendars.min.js') ?>"></script>
        <script type="text/javascript" src="<?=base_url()?>web/js/bootstrap.min.js"></script>
	    <script type="text/javascript" src="<?=base_url()?>web/js/validator.js"></script>
	    <script type="text/javascript">
			$('.datepicker').calendarsPicker({calendar: $.calendars.instance(), dateFormat:'yyyy/mm/dd', onClose: function(){ $(this).parent().parent().removeClass('has-error'); }});
    	    $('.ardatepicker').calendarsPicker({calendar: $.calendars.instance('ummalqura', 'ar'), onClose: function(){ $(this).parent().parent().removeClass('has-error'); }});
            $(".active").parent().addClass("in");
    	    $("#menu-toggle").click(function (e) {
	            e.preventDefault();
	            $("#wrapper").toggleClass("toggled");
	        });
	        if ($('#page-content-wrapper').height() > $('#sidebar-wrapper').height()) {
	        	$('#sidebar-wrapper').height($('#page-content-wrapper').height());
	        }
	        $('.delete').click(function(){return(confirm('هل أنت متأكد من عملية الحذف؟'))});
	    </script>
	</body>
</html>