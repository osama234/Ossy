<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>المستودع الخيري بالمجمعة</title>
    <link href="<?= base_url('web/css/bootstrap.min.css') ?>" rel="stylesheet"/>
    <link href="<?= base_url('web/css/font-awesome.min.css') ?>" rel="stylesheet"/>
    <link href="<?= base_url('web/css/layla-thuluth.css') ?>" rel="stylesheet"/>
    <link href="<?= base_url('web/css/droidarabickufi.css') ?>" rel="stylesheet"/>
    <link href="<?= base_url('web/css/droidarabicnaskh.css') ?>" rel="stylesheet"/>
    <link href="<?= base_url('web/css/bootstrap-rtl.css') ?>" rel="stylesheet"/>
    <link href="<?= base_url('web/css/style.css') ?>" rel="stylesheet"/>
    <link href="<?= base_url('web/css/jquery.calendars.picker.css') ?>" rel="stylesheet"/>
    <link href="<?= base_url('web/css/print.css') ?>" rel="stylesheet" media="print"/>
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body dir="rtl">
<header>
    <div class="header">
        <div class="logo">
            <h1>
                <a href="<?= base_url() ?>"><img src="<?= base_url('web/img/header-logo.png') ?>"></a>
            </h1>
        </div>
        <div class="headtitle hidden-xs">
            <h1>المُستَوْدَع الخَيْري بالمَجْمَعَة</h1>
        </div>
        <div class="top_links hidden-sm hidden-xs">
            <div class="info">
                <p><?= @$user['user_mail'] ?> | <a href="<?= base_url('user/logout') ?>">خروج</a></p>
                <p>مرحباً بك <?= @$user['user_name'] ?></p>
            </div>
            <div class="datearea pull-right">
                <div>
                    <b><?= ArDate('d') ?></b>
                    <p style="text-algin: right;"><?= ArDate('l') ?><br><?= ArDate('M Y') ?></p>
                </div>
                <div dir="ltr">
                    <b><?= date('d') ?></b>
                    <p><?= date('l') ?><br><?= date('M Y') ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <section class="topbar">
        <a href="#menu-toggle" class="btn btn-default btn-sm" id="menu-toggle"><i class="fa fa-bars"></i></a>
    </section>
</header>
<div id="wrapper">
    <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <?php foreach ($apps as $app) { ?>
                <li><a href="javascript:void(0);" data-toggle="collapse"
                       data-target="#<?= $app['app_name'] ?>"><?= lang() == 'ar' ? $app['app_ar'] : $app['app_en'] ?></a>
                </li>
                <ul class="collapse" id="<?= $app['app_name'] ?>">
                    <?php foreach ($app['sub'] as $sub) { ?>
                        <li<?= ($sub['app_name'] == $GLOBALS['APPLICATION_LINK'] ? ' class="active"' : '') ?>>
                            <a href="<?= base_url($sub['app_name']) ?>"><?= lang() == 'ar' ? $sub['app_ar'] : $sub['app_en'] ?></a>
                        </li>
                    <?php } ?>
                </ul>
            <?php } ?>
        </ul>
    </div><!-- sidebar-wrapper -->
    <div id="page-content-wrapper">
        <div class="container-fluid">
            <?= ShowMessages() ?>
