<?php

class UserController extends controller
{
    function index()
    {
        return (true);
    }

    function login()
    {
        if (!empty($this->user['user_id'])) {
            redirect();
        }
        if (isset($_POST['user_mail'])) {
            if (empty($_POST['user_mail']) || empty($_POST['user_password'])) {
                setMessage('يجب إدخال اسم المستخدم وكلمة المرور', 'error');
            } else {
                $_POST['user_password'] = md5($_POST['user_password']);
                $profile = $this->mydb->fetch_assoc($this->mydb->execute('SELECT * FROM users WHERE user_mail=:user_mail AND user_password=:user_password ', $_POST));
                if (!$profile) {
                    setMessage('البيانات المدخلة غير صحيحة', 'error');
                } else {
                    $_SESSION['current_user'] = $profile;
                    if (!empty($_SESSION['REQUEST'])) {
                        $url = $_SESSION['REQUEST'];
                        unset($_SESSION['REQUEST']);
                        redirect($url);
                    } else {
                        redirect();
                    }
                }
            }
        }
        return true;
    }

    function logout()
    {
        unset($_SESSION['current_user']);
        $this->user = false;
        redirect('user/login');
    }
}
