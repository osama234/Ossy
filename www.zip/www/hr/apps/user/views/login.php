				<form action="<?= base_url('user/login') ?>" method="post" class="form-signin" role="form">
				    <img src="<?= base_url('web/img/login-logo.png') ?>" alt="" />
				    <br /><br /><br />
                    <?= ShowMessages() ?>
					<h3 align="center">تسجيل الدخول</h3>
					<input type="text" name="user_mail" class="form-control" placeholder="البريد الإلكتروني" required autofocus />
					<input type="password" name="user_password" class="form-control" placeholder="كلمة المرور" required />
					<button class="btn btn-lg btn-primary btn-block" type="submit">دخول</button>
				</form>
 
