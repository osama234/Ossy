<?php
/**
 * Configurations file
 */

define('DS', DIRECTORY_SEPARATOR);

$GLOBALS['config'] = [
    'app_path'   => dirname(realpath(__FILE__)) . '/apps',
    'lib_path'   => dirname(realpath(__FILE__)) . '/libs',
    'error_view' => dirname(realpath(__FILE__)) . '/apps/user/views/error_view.php',
    'database'   => 'mysql://root@127.0.0.1/mcw_data',
];

/** Set Time zone */
date_default_timezone_set('Asia/Riyadh');

/** Start session here */
session_start();
/** Report all errors */
error_reporting(E_ALL);
ini_set('display_errors', 'On');

/** Set error handler */
set_error_handler('error_handler');
