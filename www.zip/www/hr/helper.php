<?php
/**
 * Helper Functions
 */

function __autoload($class_name) {
    $paths = array(
        $GLOBALS['config']['lib_path']. DS . $class_name . '.class.php',
        strtolower(str_replace('\\', DS, $class_name)).'.php'
    );
    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once($path);
            return true;
        }
    }
    throw new Exception('Sorry, the page you are looking for could not be found. [LIB]');
}

/**
 *
 * Custom error handler
 *
 * @param $code int: error code number.
 * @param $error string: error message.
 * @param $file string: the file where the error occurred.
 * @param $line int: the line number where the error occurred.
 * @return bool is the error handled or not.
 */
function error_handler($code, $error, $file, $line, $error_context)
{
    if ($code != 8) {
        ob_get_contents();
        @ob_end_clean();
        $file = substr($file, strlen(getcwd()) + 1);
        $stack = debug_backtrace();
        unset($stack[0]);
        include($GLOBALS['config']['error_view']);
        exit();
    }
}

/**
 * @desc Redirect to new location then exit
 * @param string $location the new location
 * @return void
 */
function redirect($location=''){
    if(substr($location,0,7) == 'http://' || substr($location,0,8) == 'https://') {
        header('location: '.$location);
    } else {
        header('location: '.base_url($location));
    }
    exit(0);
}

/**
 * @desc get base url
 * @param string $url custom url
 * @return string base url
 */
function base_url($url=''){
    if ($url == '#') return $url;
    return(str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']).$url);
}

/**
 * @desc Set the error message
 * @param string $msg the message
 * @param string $type to specify the class of displayed error
 * @return void
 */
function setMessage($msg, $type='info'){
    $_SESSION['messages'][$type][] = $msg;
}

/**
 * @desc to check is there an errors
 * @param string $type to select specific types of errors
 * @return bool
 */
function noMessage($type='error'){
    if($type) {
        return(!isset($_SESSION['messages'][$type]));
    }
    return(!isset($_SESSION['messages']));
}

/**
 * @desc display error messages
 * @return string html that shows messages
 */
function showMessages(){
    $html = '';
    if(isset($_SESSION['messages'])) {
        foreach($_SESSION['messages'] as $type=>$msgs){
            if ($type == 'error') $type = 'danger';
            $html .= '<div class="alert alert-'.$type.' alert-dismissible" role="alert">';
            $html .= '<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><ul>';
            foreach($msgs as $msg){
                $html .= '<li>'.$msg.'</li>';
            }
            $html .= '</ul></div>';
        }
    }
    return($html);
}

function lang($key = false) {
    $lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'ar';
    if (!$key) return $lang;
    return $GLOBALS['lang'][$lang][$key];
}

/**
 * @desc Format a local time/date in Arabic string
 * @param string $formate Format string (same as PHP date function)
 * @param string $time Unix timestamp
 * @param integer $mode Output mode of date function where:
 *                       1) Hijri format (Islamic calendar)
 *                       2) Arabic month names used in Middle East countries
 *                       3) Arabic Transliteration of Gregorian month names
 *                       4) Both of 2 and 3 formats together
 *                       5) Libya style
 *                       6) Algeria and Tunis style
 *                       7) Morocco style
 * @return string
 */
function arDate($formate, $time=0, $mode=1) {
    static $Arabic;
    if(!is_object($Arabic)){
        $Arabic = new I18N_Arabic_Date();
    }
    $time = ($time>0)?$time:time();
    $Arabic->setMode($mode);
    $diff = $Arabic->dateCorrection($time);
    return($Arabic->date($formate, $time, $diff));
}

/**
 * This will return Unix timestamp
 * for given Hijri date (Islamic calendar)
 *
 * @param integer $d     Hijri day   (Islamic calendar)
 * @param integer $m     Hijri month (Islamic calendar)
 * @param integer $y     Hijri year  (Islamic calendar)
 * @return integer Returns the measured in the number of
 *                seconds since the Unix Epoch (January 1 1970 00:00:00 GMT)
 */
function arMktime($d, $m = '1', $y = '1420') {
    static $arabic;
    if(!is_object($arabic)){
        $arabic = new I18N_Arabic_Mktime();
    }
    //try to be flixabel
    if (strpos($d, '-'))
        list($y, $m, $d) = explode('-', $d);
    if (strpos($d, '/'))
        list($y, $m, $d) = explode('/', $d);
    $diff = $arabic->mktimeCorrection((int) $m, (int) $y);
    return($arabic->mktime(0, 0, 0, (int) $m, (int) $d, (int) $y, $diff));
}

function arNumbers($text) {
    return str_replace(['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'], ['١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩', '٠'], $text);
}

/**
 * @desc upload file
 * @param string $name the input's name
 * @param array $allowed_type allowed types
 * @return bool|string file path if succeeded, false if not.
 */
function saveUploadedFile($name, $allowed_type = []) {
    if (empty($allowed_type)) {
        $allowed_type = ['png', 'jpg', 'gif', 'pdf', 'zip', 'rar'];
    }
    if(isset($_FILES[$name])){
        if(is_array($_FILES[$name]['name'])){
            $count=0;
            $result = FALSE;
            foreach($_FILES[$name]['name'] as $file_name){
                if($_FILES['attachment']['error'][$count] == 0){
                    $ext = strtolower(substr($file_name, strrpos($file_name, '.') +1));
                    if (in_array($ext, $allowed_type) and $_FILES['attachment']['size'][$count] <= 2097152) {
                        $savepath = 'public/uploads/'.microtime(true).$_FILES[$name]['name'][$count];
                        if (strlen($savepath) > 128) $savepath = substr($savepath, 0, 124).'.'.$ext;  // fix long filenames
                        if(move_uploaded_file($_FILES[$name]['tmp_name'][$count], $savepath)) {
                            $result[$count]['path'] 	= $savepath;
                            $result[$count]['filename']	= $file_name;
                        }
                    }else{
                        $result[$count] = FALSE;
                    }
                }elseif(in_array($_FILES['attachment']['error'][$count], array(1,2,3,5,6,7,8))){
                    $result[$count] = FALSE;
                }
                $count++;
            }
            return $result;
        } else {
            $file_name = $_FILES[$name]['name'];
            $ext = strtolower(substr($file_name, strrpos($file_name, '.') + 1));
            if (!in_array($ext, $allowed_type)) {
                return false;
            }
            $save_path = 'public/uploads/' . microtime(true) . $_FILES[$name]['name'];
            // fix long file name
            if (strlen($save_path) > 128) {
                $save_path = substr($save_path, 0, 124) . '.' . $ext;
            }
            if (move_uploaded_file($_FILES[$name]['tmp_name'], $save_path)) {
                return ['path' => $save_path, 'filename' => $file_name];
            }
        }
    }
    return(false);
}
