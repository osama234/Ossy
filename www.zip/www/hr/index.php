<?php
/**
 * Entry Point for this website.
 */


/** Require Helper Functions */
require_once('helper.php');

/** Require Config File */
require_once('config.php');

/** Require Routes File */
require_once('Routes.php');

/** Launch! */
Application::load(Router::getInstance()->match());
