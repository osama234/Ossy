<?php

/**
 * Created by PhpStorm.
 * User: azzozhsn
 * Date: 1/2/2016 AD
 * Time: 11:03 PM
 */
class Application
{
    public static function load($route) {
        // Connect to database.
        DB::getInstance()->connect($GLOBALS['config']['database']);

        /** extract params from request uri */
        $request = $route['route'];
        $url = $route['action'];
				
		$requestUri = '/'.substr($_SERVER['REQUEST_URI'], strlen(base_url()));
        $params = str_replace($request, '', $requestUri);
        $params = explode('/', trim($params, '/'));

        /** get app location and method to execute */
        list($folder, $url) = explode('/', $url);
        if (empty($url) and !empty($folder)) {
            $url = $folder;
            $folder = '';
        }
        list($app, $action) = explode('@', $url);
        $path = $GLOBALS['config']['app_path'] . DS;
        if (!empty($folder)) {
            $path .= $folder . DS;
        }
        $GLOBALS['APPLICATION_PATH'] = str_replace('@', '/', $route['action']);
        $GLOBALS['APPLICATION_LINK'] = substr($route['action'], 0, strpos($route['action'], '@'));
        if (self::checkPermission($route['action'])) {
            /** Load and execute */
            $data = Application::loadClass($path, $app, $action, $params);
            array_unshift($params, $action);
            array_unshift($params, $app);
            echo Application::loadView($path, $params, $data);
        } else {
            throw new Exception('Access Denied. <br />You do not have permission to access this page.');
        }
    }

    private static function loadClass($path, $app, $action, $params) {
        // Load application language file if exists
        $paths = array('../index/lang.php', '../../index/lang.php', '../../index/lang.php', 'lang.php');
        foreach ($paths as $row) {
            if (file_exists($path . $row)) {
                include_once($path . $row);
            }
        }
        // Load the controller and execute the method
        $class = ucfirst($app) . 'Controller';
        $path .= 'controllers' . DS .$class . '.php';
        if (file_exists($path)) {
            require_once($path);
            $object = new $class();
            call_user_func_array(array($object, $action), $params);
            return $object->vars;
        } else {
            throw new Exception('Sorry, the page you are looking for could not be found. [APP]');
        }
    }

    private static function loadView($path, $params, $data) {
        if (is_array($data)) {
            extract($data, EXTR_SKIP);
        }
        $headers = array($path . 'views/_header.php', $path . '../views/_header.php', $path . '../index/views/_header.php', $path . '../../index/views/_header.php');
        $footers = array($path . 'views/_footer.php', $path . '../views/_footer.php', $path . '../index/views/_footer.php', $path . '../../index/views/_footer.php');
        ob_start();
        foreach ($headers as $_path) {
            if (file_exists($_path)) {
                include_once($_path);
                break;
            }
        }
        @include(Application::getViewPath($path, $params));
        foreach ($footers as $_path) {
            if (file_exists($_path)) {
                include_once($_path);
                break;
            }
        }
        $response = ob_get_contents();
        ob_end_clean();
        unset($_SESSION['messages']);
        return $response;
    }

    private static function getViewPath($path, $params = array())
    {
        if (file_exists($path . 'views/' . $params[0] . '_' . $params[1] . '_' . $params[2] . '.php')) {    // path/views/class_method_param1_param2.php
            return($path . 'views/' . $params[0] . '_' . $params[1] . '_' . $params[2] . '.php');
        } elseif (file_exists($path . 'views/' . $params[0] . '_' . $params[1] . '.php')) {                 // path/views/class_method_param1.php
            return($path . 'views/' . $params[0] . '_' . $params[1] . '.php');
        } elseif (file_exists($path . 'views/' . $params[0] . '_' . $params[2] . '.php')) {                 // path/views/class_param1.php
            return($path . 'views/' . $params[0] . '_' . $params[2] . '.php');
        } elseif (file_exists($path . 'views/' . $params[1] . '.php')) {                                    // path/views/param1.php
            return($path . 'views/' . $params[1] . '.php');
        } elseif (file_exists($path . 'views/' . $params[0] . '.php')) {                                    // path/views/class.php
            return($path . 'views/' . $params[0] . '.php');
        } elseif (file_exists($path . 'views/index.php')) {                                                 // path/views/index.php
            return($path . 'views/index.php');
        }
    }

    /**
     * @param $app string app name
     * @return bool
     */
    public static function checkPermission($appId)
    {
        // user class do not need login or permissions
        if (substr($appId, 0, 4)  == 'user') {
            return (true);
        }
        // if not login go to login first
        if (!isset($_SESSION['current_user']['user_id'])) {
            // store current path to return to after login
            if (trim($_SERVER['REQUEST_URI'], '/') != 'user/login') {
                $_SESSION['REQUEST'] = $_SERVER['REQUEST_URI'];
            }
            redirect('user/login');
            exit(0);
        }
        //check user permission
        if (Permissions::CheckUserPerms($_SESSION['current_user']['user_id'], Permissions::GetAppID($appId))) {
            return (true);
        }
        return (false);
    }
}