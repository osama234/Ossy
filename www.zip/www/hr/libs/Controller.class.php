<?php
	class Controller {
		public $vars 		= array();
		protected $user 	= array();
		protected $mydb 	= null;
		protected $post 	= array();
		protected $get 		= array();

        function __construct()
        {
            $this->mydb = DB::getInstance();
            $this->user = $this->vars['user'] = (isset($_SESSION['current_user'])) ? $_SESSION['current_user'] : false;
            $this->secureInputs();
            $this->vars['apps'] = array();
            $q = $this->mydb->execute('SELECT * FROM core_apps WHERE app_pid=0 ORDER BY app_sort ASC');
            while (($row = $this->mydb->fetch_assoc($q)) != false) {
                if (Permissions::CheckUserPerms($this->user['user_id'], $row['app_id'])) {
                    $q2 = $this->mydb->execute('SELECT * FROM core_apps WHERE app_pid=:app_id ORDER BY app_sort ASC', array('app_id' => $row['app_id']));
                    $row['sub'] = array();
                    while (($sub = $this->mydb->fetch_assoc($q2)) != false) {
                        if (Permissions::CheckUserPerms($this->user['user_id'], $sub['app_id'])) {
                            $row['sub'][] = $sub;
                        }
                    }
                    $this->vars['apps'][] = $row;
                }
            }
        }
		
		private function secureInputs() {
		    //make copy of $_POST, $_GET
	        $this->post	= $_POST;
	        $this->get	= $_GET;
	        $_POST	= $this->xss_clean($_POST);
	        $_GET	= $this->xss_clean($_GET);
		}
		
		//function to clean xss
        private function xss_clean(&$str) {
	        if (is_array($str)) {
		        foreach($str as $key=>$val) {
			        $str[$key] = $this->xss_clean($str[$key]);
		        }
	        } else {
		        $str = strip_tags($str);
	        }
	        return($str);
	    }
	}
