<?php
    class DB {
        private $conn;
        private $affected_rows;
        
        private function __construct() {

        }
        
        public static function getInstance() {
            static $instance = null;
            if ($instance == null) {
                $instance = new static();
            }
            return $instance;
        }
        
        public function connect($dns, $charset = 'utf8') {
            $db = parse_url($dns);
            $dns = $db['scheme'].':host='.$db['host'].';dbname='.str_replace('/', '', $db['path']);
            $db['pass'] = isset($db['pass']) ? $db['pass'] : '';
            $this->conn = new PDO($dns, $db['user'], $db['pass']);
            //$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
            $this->execute("SET NAMES $charset");
        }
        
        public function execute($sql, $inputarr=array()) {
            $stmt = $this->conn->prepare($sql);
            foreach ($inputarr as $key=>$value) {
                if (strpos($sql, ':'.$key) === false) {
                    unset($inputarr[$key]);
                }
            }
            $stmt->execute($inputarr);
            $this->affected_rows = $stmt->rowCount();
            return $stmt;
        }
        
        function fetch_assoc($query) {
            if (!$query) return false;
            return($query->fetch(PDO::FETCH_ASSOC));
        }
        
        function fetch_row($query) {
            if (!$query) return false;
            return($query->fetch(PDO::FETCH_NUM));
        }
        
        function fetch_object($query) {
            if (!$query) return false;
            return($query->fetch(PDO::FETCH_OBJ));
        }
        
        function insert_id() {
            return $this->conn->lastInsertId();
        }
        
        function affected_rows() {
            return $this->affected_rows;
        }
        
        function sql_insert($table, $data){
            $bind = ':'.implode(', :', array_keys($data));
            return "INSERT INTO $table (".implode(',', array_keys($data)).") VALUES (".$bind.")";
        }
        
        function sql_update($table, $arr, $where){
            $update_arr = $where_arr = array();
            foreach($arr as $key=>$val) {
                $update_arr[]= $key .' = :'.$key;
            }
            foreach($where as $key=>$val) {
                $where_arr[]= $key.' = :'.$key;
            }
            return("UPDATE $table SET ".implode(', ',$update_arr)." WHERE ".implode(' AND ',$where_arr));
        }
        
        function error() {
            return $this->conn->errorCode().': '.$this->conn->errorInfo();
        }
    }

