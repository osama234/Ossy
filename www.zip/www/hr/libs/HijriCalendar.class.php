<?php

class HijriCalendar
{
    private $time;
    private $month;
    private $year;
    private $events = [];

    function __construct()
    {
        if (!isset($_SESSION['HijriCalendarClassMonth'])) {
            $_SESSION['HijriCalendarClassMonth'] = arDate('m');
            $_SESSION['HijriCalendarClassYear'] = arDate('Y');
        }
        $this->month = $_SESSION['HijriCalendarClassMonth'];
        $this->year = $_SESSION['HijriCalendarClassYear'];
    }

    public function addEvent($start, $duration, $title, $am = 'am')
    {
        $start = str_replace(['صباحاً', ' ', 'هـ', 'مساءً'], '', $start);
        $this->events[] = ['start' => $start, 'duration' => $duration, 'title' => $title];
    }

    public function render()
    {
        if (isset($_POST['prev'])) {
            $this->month--;
            if ($this->month == 0) {
                $this->month = 12;
                $this->year--;
            }
        }
        if (isset($_POST['next'])) {
            $this->month++;
            if ($this->month == 13) {
                $this->month = 1;
                $this->year++;
            }
        }
        if (isset($_POST['today'])) {
            $this->month = arDate('m');
            $this->year = arDate('Y');
        }
        $_SESSION['HijriCalendarClassMonth'] = $this->month;
        $_SESSION['HijriCalendarClassYear'] = $this->year;
        $start = arMktime(1, $this->month, $this->year);
        $this->time = $start;
        $day_of_week = arDate('N', $start) . '<br />';
        if ($day_of_week < 7) {
            $this->time = $start - (arDate('N', $start) * 86400);
        }
        $output = '<style type="text/css">
                .cc { display: block; width: 100%; height: 120px; min-width: 420px; position: relative; z-index: 1; }
                .cr { display: block; width: 100%; height: 120px; position: absolute; top: 0; left: 0; z-index: 1; }
                .vr { display: block; width: 100%; position: absolute; bottom: 10px; left: 0; z-index: 4; }
                .cr table { height: 121px; }
                .cr table.table.table-bordered tbody tr td { border-bottom: 0}
                .vr table tbody tr td { font-size: 11px}
                .calendar td { width: 14.28%; }
                .holiday { background: #eee; }
                .today { background: #FCF8E3; }
                .this-month { font-size: 28px; color: #333; }
                .other-month { font-size: 20px; color: #ccc; }
            </style>
            <form action="" method="post" class="calendar">
                <div class="cc">
                <table class="table table-bordered" style="height: 100%">
                <tr>
                    <td colspan="7"><h4 class="pull-left">' . arDate('M Yهـ', arMktime(10, $this->month, $this->year)) . '</h4>
                        <div class="pull-right">
                            <input type="submit" name="prev" value="&lt;&lt;" />
                            <input type="submit" name="today" value="اليوم" />
                            <input type="submit" name="next" value="&gt;&gt;" />
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>الأحد</td>
                    <td>الاثنين</td>
                    <td>الثلاثاء</td>
                    <td>الأربعاء</td>
                    <td>الخميس</td>
                    <td class="holiday">الجمعة</td>
                    <td class="holiday">السبت</td>
                </tr></table></div>';
        while (arDate('m', $this->time) <= $this->month && arDate('Y', $this->time) == $this->year || arDate('Y',
                $this->time) < $this->year) {
            $output .= $this->printRow();
        }
        $output .= '</form>';
        return $output;
    }

    /**
     * @return string html code for one row in the calendar.
     */
    private function printRow()
    {
        $colors = ['#A594C1', '#EAB57F', '#BAB28B', '#B7D28B', '#1D718D', '#6B6A6F', '#3A6CB3', '#817541', '#79A8E0', '#63802C', '#D28484', '#E15603'];
        $start = $reset = $this->time;
        $today = arDate('Y/m/d');
        $output = '<div class="cc"><div class="cr"><table class="table table-bordered"><tr>';
        for ($i = 0; $i < 7; $i++) {
            $date = arDate('Y/m/d', $this->time += 86400);
            $output .= '<td id="' . arDate('Y-m-d', $this->time) . '" class="' . ($i > 4 ? 'holiday ' : '') . (arDate('m', $this->time) == $this->month ? 'this-month' : 'other-month') . ' ' . ($date == $today ? 'today' : '') . '">' . arNumbers((int)arDate('d', $this->time)) . '</td>' . "\n";
        }
        $output .= '</tr></table></div>';
        $end = $this->time;
        $output .= '<div class="vr">';
        $rows = 0;
        foreach ($this->events as $key => $row) {
            $row['start'] = arMktime($row['start']);
            $row['end'] = $row['start'] + $row['duration'] * 86400;
            if (($row['start'] >= $start and $row['start'] < $end) or ($row['end'] >= $start and $row['end'] <= $end)) {
                $cols = 0;
                // limit number of events in the same week to prevent cover dates.
                if ($rows > 3) break;
                $output .= '<table width="100%" height="15"><tr>';
                for ($i = 0; $i < 7; $i++) {
                    if ($start < $row['start']) {
                        $output .= '<td width="14.28%"></td>';
                        if ($cols > 0) {
                            $output .= '<td colspan="' . $cols . '" style="background: ' . $colors[$key] . '; width: ' . ($cols * 14.28) . '%;">' . $row['title'] . '</td>';
                            $cols = 0;
                        }
                    } elseif ($start >= $row['end']) {
                        if ($cols > 0) {
                            $output .= '<td colspan="' . $cols . '" style="background: ' . $colors[$key] . '; width: ' . ($cols * 14.28) . '%;">' . $row['title'] . '</td>';
                            $cols = 0;
                        }
                        $output .= '<td width="14.28%"></td>';
                    } else {
                        $cols++;
                    }
                    $start += 86400;
                }
                if ($cols > 0) {
                    $output .= '<td colspan="' . $cols . '" style="background: ' . $colors[$key] . '; width: ' . ($cols * 14.28) . '%;">' . $row['title'] . '</td>';
                }
                $output .= '</tr></table>';
                $rows++;
            }
            $start = $reset;
        }
        $output .= '</div></div>';
        return $output;
    }
}
