<?php

/**
 * Input Helper
 * This class is a helper library of function to generate code for Bootstrap inputs in different layouts.
 * @author Azzoz Al-Hasani <azzozhsn@gmail.com>
 *
 */
class Input
{
    /**
     * Generate HTML code for text input with label that take full width. The label and the input will be aligned horizontally. No need wrap this with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param string|bool $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TextH1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputH1($label, $name, 'text', $value, $group, $class);
    }

    /**
     * Generate HTML code for tel input with label that take full width. The label and the input will be aligned horizontally. No need wrap this with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TelH1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputH1($label, $name, 'tel', $value, $group, $class);
    }

    /**
     * Generate HTML code for file input with label that take full width. The label and the input will be aligned horizontally. No need wrap this with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function FileH1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputH1($label, $name, 'file', $value, $group, $class);
    }

    /**
     * Generate HTML code for password input with label that take full width. The label and the input will be aligned horizontally. No need wrap this with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function PasswordH1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputH1($label, $name, 'password', $value, $group, $class);
    }

    /**
     * Generate HTML code for email input with label that take full width. The label and the input will be aligned horizontally. No need wrap this with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function EmailH1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputH1($label, $name, 'email', $value, $group, $class);
    }

    /**
     * Generate HTML code for input with label that take full width. The label and the input will be aligned horizontally. No need wrap this with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param string $type input type, should text, file or password
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    private static function InputH1($label, $name, $type = 'text', $value = false, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            $class = str_replace('required', '', $class);
        } else {
            $required = '';
        }
        if (strpos($class, 'multiple') !== false) {
            $multiple = ' multiple="true"';
            $class = str_replace('multiple', '', $class);
            $name .= '[]';
        } else {
            $multiple = '';
        }
        if ($value) {
            // for security to prevent xss
            $value = str_replace(array('<', '>', '"'), '', $value);
        }
        return '<div class="form-group"><label class="control-label col-md-2" for="' . $id . '">' . $label . '</label>
        <div class="col-md-10">
        <input class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '" type="' . $type . '" ' . ($value ? 'value="' . $value . '"' : '') . $required . $multiple .' />
        </div></div>';
    }

    /**
     * Generate HTML code for text input with label that take half the width. The label and the input will be aligned horizontally. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TextH2($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputH2($label, $name, 'text', $value, $group, $class);
    }

    /**
     * Generate HTML code for tel input with label that take half the width. The label and the input will be aligned horizontally. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TelH2($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputH2($label, $name, 'tel', $value, $group, $class);
    }

    /**
     * Generate HTML code for file input with label that take half the width. The label and the input will be aligned horizontally. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function FileH2($label, $name, $group = false, $class = '')
    {
        return Input::InputH2($label, $name, 'file', false, $group, $class);
    }

    /**
     * Generate HTML code for password input with label that take half the width. The label and the input will be aligned horizontally. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function PasswordH2($label, $name, $group = false, $class = '')
    {
        return Input::InputH2($label, $name, 'password', false, $group, $class);
    }

    /**
     * Generate HTML code for email input with label that take half the width. The label and the input will be aligned horizontally. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function EmailH2($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputH2($label, $name, 'email', $value, $group, $class);
    }

    /**
     * Generate HTML code for input with label that take half the width. The label and the input will be aligned horizontally. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param string $type input type, should text, file or password
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    private static function InputH2($label, $name, $type = 'text', $value = false, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            $class = str_replace('required', '', $class);
        } else {
            $required = '';
        }
        if (strpos($class, 'multiple') !== false) {
            $multiple = ' multiple="true"';
            $class = str_replace('multiple', '', $class);
        } else {
            $multiple = '';
        }
        return '<label class="control-label col-md-2" for="' . $id . '">' . $label . '</label>
        <div class="col-md-4">
        <input class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '" type="' . $type . '"' . ($value ? ' value="' . $value . '"' : '') . $required . $multiple . ' />
        </div>';
    }

    /**
     * Generate HTML code for text input with label that take half the width. The label will be over the input. You do not need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TextV1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV1($label, $name, 'text', $value, $group, $class);
    }

    /**
     * Generate HTML code for tel input with label that take half the width. The label will be over the input. You do not need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */

    public static function TelV1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV1($label, $name, 'tel', $value, $group, $class);
    }

    /**
     * Generate HTML code for email input with label that take half the width. The label will be over the input. You do not need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */

    public static function EmailV1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV1($label, $name, 'email', $value, $group, $class);
    }

    /**
     * Generate HTML code for password input with label that take half the width. The label will be over the input. You do not need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */

    public static function PasswordV1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV1($label, $name, 'password', $value, $group, $class);
    }

    /**
     * Generate HTML code for file input with label that take half the width. The label will be over the input. You do not need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function FileV1($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV1($label, $name, 'file', $value, $group, $class);
    }

    /**
     * Generate HTML code for input that specified by $type parameter with label that take half the width. The label will be over the input. You do not need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param string $type type of input. text, tel, email, password or file.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    private static function InputV1($label, $name, $type = 'text', $value = false, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            str_replace('required', '', $class);
        } else {
            $required = '';
        }
        if ($value) {
            // for security to prevent xss
            $value = str_replace(array('<', '>', '"'), '', $value);
        }
        return '<div class="form-group">
                    <label class="control-label" for="' . $id . '">' . $label . '</label>
                    <input class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '" type="' . $type . '" ' . ($value ? ' value="' . $value . '"' : '') . $required . ' />
                </div>';
    }

    /**
     * Generate HTML code for input with label that take half the width. The label will be over the input. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TextV2($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV2($label, $name, 'text', $value, $group, $class);
    }

    /**
     * Generate HTML code for tel input with label that take half the width. The label will be over the input. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TelV2($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV2($label, $name, 'tel', $value, $group, $class);
    }

    /**
     * Generate HTML code for email input with label that take half the width. The label will be over the input. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function EmailV2($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV2($label, $name, 'email', $value, $group, $class);
    }

    /**
     * Generate HTML code for password input with label that take half the width. The label will be over the input. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function PasswordV2($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV2($label, $name, 'password', $value, $group, $class);
    }

    /**
     * Generate HTML code for file input with label that take half the width. The label will be over the input. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function FileV2($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV2($label, $name, 'file', $value, $group, $class);
    }

    /**
     * Generate HTML code for input that specified by $type parameter with label that take half the width. The label will be over the input. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param string $type type of input. text, tel, email, password or file.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    private static function InputV2($label, $name, $type = 'text', $value = false, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            str_replace('required', '', $class);
        } else {
            $required = '';
        }
        if ($value) {
            // for security to prevent xss
            $value = str_replace(array('<', '>', '"'), '', $value);
        }
        return '<div class="col-md-6 col-sm-6">
					<label class="control-label" for="' . $id . '">' . $label . '</label>
					<input class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '" type="' . $type . '" ' . ($value ? ' value="' . $value . '"' : '') . $required . ' />
				</div>';
    }

    /**
     * Generate HTML code for text input with label that take third the width. The label will be over the input. You need wrap three or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TextV3($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV3($label, $name, 'text', $value, $group, $class);
    }

    /**
     * Generate HTML code for tel input with label that take third the width. The label will be over the input. You need wrap three or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TelV3($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV3($label, $name, 'tel', $value, $group, $class);
    }

    /**
     * Generate HTML code for email input with label that take third the width. The label will be over the input. You need wrap three or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function EmailV3($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV3($label, $name, 'email', $value, $group, $class);
    }

    /**
     * Generate HTML code for password input with label that take third the width. The label will be over the input. You need wrap three or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function PasswordV3($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV3($label, $name, 'password', $value, $group, $class);
    }

    /**
     * Generate HTML code for file input with label that take third the width. The label will be over the input. You need wrap three or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function FileV3($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV3($label, $name, 'file', $value, $group, $class);
    }

    /**
     * Generate HTML code for input that specified by $type parameter with label that take third the width. The label will be over the input. You need wrap three or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param string $type type of input. text, tel, email, password or file.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    private static function InputV3($label, $name, $type, $value = false, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            str_replace('required', '', $class);
        } else {
            $required = '';
        }
        return '<div class="col-md-4">
					<label class="control-label" for="' . $id . '">' . $label . '</label>
					<input class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '" type="' . $type . '" ' . ($value ? 'value="' . $value . '"' : '') . $required . ' />
				</div>';
    }

    /**
     * Generate HTML code for text input with label that take quarter the width. The label will be over the input. You need wrap four or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TextV4($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV4($label, $name, 'text', $value, $group, $class);
    }

    /**
     * Generate HTML code for tel input with label that take quarter the width. The label will be over the input. You need wrap four or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TelInputV4($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV4($label, $name, 'tel', $value, $group, $class);
    }

    /**
     * Generate HTML code for email input with label that take quarter the width. The label will be over the input. You need wrap four or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function EmailV4($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV4($label, $name, 'email', $value, $group, $class);
    }

    /**
     * Generate HTML code for password input with label that take quarter the width. The label will be over the input. You need wrap four or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function PasswordV4($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV4($label, $name, 'password', $value, $group, $class);
    }

    /**
     * Generate HTML code for file input with label that take quarter the width. The label will be over the input. You need wrap four or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function FileV4($label, $name, $value = false, $group = false, $class = '')
    {
        return Input::InputV4($label, $name, 'file', $value, $group, $class);
    }

    /**
     * Generate HTML code for input that specified by $type parameter with label that take quarter the width. The label will be over the input. You need wrap four or less inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param string $type type of input. text, tel, email, password or file.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    private static function InputV4($label, $name, $type, $value = false, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            str_replace('required', '', $class);
        } else {
            $required = '';
        }
        return '<div class="col-md-3 col-sm-6">
					<label class="control-label" for="' . $id . '">' . $label . '</label>
					<input class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '" type="' . $type . '" ' . ($value ? ' value="' . $value . '"' : '') . $required . ' />
				</div>';
    }

    /**
     * Generate HTML code for select with label that take full width. The label and the select will be aligned horizontally. No need wrap this with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param string $options the options of select. Use GetOptions helper function to generate it.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function SelectH1($label, $name, $options, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            str_replace('required', '', $class);
        } else {
            $required = '';
        }
        return '<div class="form-group"><label class="control-label col-md-2" for="' . $id . '">' . $label . '</label>
        <div class="col-md-10">
        <select class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '" ' . $required . '>' . $options . '</select>
        </div></div>';
    }

    /**
     * Generate HTML code for select with label that take full width. The label and the select will be aligned horizontally. You need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param string $options the options of select. Use GetOptions helper function to generate it.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function SelectH2($label, $name, $options, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            str_replace('required', '', $class);
        } else {
            $required = '';
        }
        return '<label class="control-label col-md-2" for="' . $id . '">' . $label . '</label>
        <div class="col-md-4">
        <select class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '"' . $required . '>' . $options . '</select>
        </div>';
    }

    /**
     * Generate HTML code for text area with label that take full width. The label and the textarea will be aligned horizontally. No need wrap this with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TextAreaH1($label, $name, $value = false, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            str_replace('required', '', $class);
        } else {
            $required = '';
        }
        return '<div class="form-group"><label class="control-label col-md-2" for="' . $id . '">' . $label . '</label>
        <div class="col-md-10">
        <textarea class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '" rows="4" ' . $required . '>' . ($value ? $value : '') . '</textarea>
        </div></div>';
    }

    /**
     * Generate HTML code for text area with label that take full width. The label will be over the input. You do not need wrap one or tow inputs with <div class="form-group">....</div>
     * @param string $label label's text for the input.
     * @param string $name the value of 'name' property of the input, also the key of array if you want to group some inputs.
     * @param bool|string $value the value of 'value' property of the input.
     * @param bool|string $group if you want to make the name of the inputs as a field of array here you can specify the array name.
     * @param bool|string $class any additional class needed to add to the input.
     * @return string generated HTML code.
     */
    public static function TextAreaV1($label, $name, $value = false, $group = false, $class = '')
    {
        $id = $name;
        if ($group) {
            $name = $group . '[' . $name . ']';
        }
        if (strpos($class, 'required') !== false) {
            $required = ' required="true"';
            str_replace('required', '', $class);
        } else {
            $required = '';
        }
        return '<div class="form-group"><label class="control-label" for="' . $id . '">' . $label . '</label>
        <textarea class="form-control ' . $class . '" id="' . $id . '" name="' . $name . '" rows="4" ' . $required . ' >' . ($value ? $value : '') . '</textarea>
        </div>';
    }
}
