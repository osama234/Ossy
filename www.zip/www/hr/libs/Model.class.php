<?php
/**
 * Basic Model Class
 * Sets up the Model interface
 */
    Class Model {
        /**
         * @property object $db Database interface
         */
        protected $db;
        
        /**
         * @property string $table Model's table name
         */
        protected $table;
        
        /**
         * @property string $pk Model's table primary key
         */
        protected $pk;
        
        /**
         * @property array $attributes Model's original attributes
         */
        protected $attributes;
        
        /**
         * @property array $new_attrs Model's attributes
         */
        protected $new_attrs;

        /**
         * Model constructor.
         * @param bool|array $attr initial attributes.
         */
        public function __construct($attr = false) {
            $this->db = DB::getInstance();
            if ($attr) {
                $this->attributes = $attr;
                $this->new_attrs = $attr;
            }
        }
        
        /**
         * Model attribute getter.
         * @param string $name attribute name
         * @return mixed attribute value
         */
        public function __get($name) {
            if (isset($this->new_attrs[$name])) {
                return $this->new_attrs[$name];
            }
            return null;
        }
        
        /**
         * Mdeol attribute setter
         * @param string $name attribute name
         * @param unknown $value attribute value
         * @return boolean wether the attribute set or not
         */
        public function __set($name, $value) {
            // Don't change the primary key value
            if ($name == $this->pk) {
                return false;
            }
            $this->new_attrs[$name] = $value;
            return true;
        }
        
        /**
         * Find model object by id
         * @param int $id model identifier
         */
        public static function find($id) {
            $class = get_called_class();
            $obj = new $class();
            $sql = 'SELECT * FROM '.$obj->table.' WHERE '.$obj->pk.' = '.$id;
            $query = $obj->db->execute($sql);
            $attr = $obj->db->fetch_assoc($query);
            return new $class($attr);
        }
        
        /**
         * Search or get all models.
         * @param string $where search conditions.
         * @param string $order sort result by.
         * @param int|array $limit limit the search by count or start/end array
         */
        public static function findAll($where = '', $order = '', $limit = '') {
            $inputs = [];
            $class = get_called_class();
            $obj = new $class();
            $sql = 'SELECT * FROM '.$obj->table;
            if (!empty($where)) {
                if (is_array($where)) {
                    $inputs = $where[1];
                    $where = $where[0];
                }
                $sql .= ' WHERE '.$where;
            }
            if (!empty($order)) {
                $sql .= ' ORDER BY '.$order;
            }
            if (!empty($limit)) {
                if (is_array($limit)) {
                    $sql .= ' LIMIT '.$limit[0].', '.$limit[1];
                } else {
                    $sql .= ' LIMIT '.$limit;
                }
            }
            $result = array();
            $query = $obj->db->execute($sql, $inputs);
            while (($row = $obj->db->fetch_assoc($query)) != false) {
                $result[] = new $class($row);
            }
            return $result;
        }
        
        /**
         * Insert model as new record to database
         */
        protected function insert() {
            $sql = $this->db->sql_insert($this->table, $this->new_attrs);
            $this->db->execute($sql, $this->new_attrs);
            $this->new_attrs[$this->pk] = $this->db->insert_id();
        }
        
        /**
         * Update model's record in database
         * @param array $new_attrs set group of attributes as an array.
         */
        public function update($new_attrs = false) {
            if ($new_attrs) {
                $this->new_attrs = $new_attrs;
            }
            $attrs = array();
            foreach ($this->new_attrs as $key => $value) {
                if ($this->new_attrs[$key] != $this->attributes[$key]) {
                    $attrs[$key] = $value;
                }
            }
            if (!empty($attrs)) {
                $sql = $this->db->sql_update($this->table, $attrs, array($this->pk => $this->attributes[$this->pk]));
                $attrs[$this->pk] = $this->attributes[$this->pk];
                $this->db->execute($sql, $attrs);
            }
        }
        
        /**
         * Save model to database.
         */
        public function save() {
            if (isset($this->attributes[$this->pk]) and $this->attributes[$this->pk]) {
                $this->update();
            } else {
                $this->insert();
            }
            $this->attributes = $this->new_attrs;
        }
        
        /**
         * Delete model from database.
         */
        public function delete() {
            $this->db->execute('DELETE FROM '.$this->table.' WHERE '.$this->pk.' = :id', array('id' => $this->attributes[$this->pk]));
        }
		
		/**
         * return model's properties as an array.
         */
        public function toArray() {
            return $this->attributes;
        }
    }

