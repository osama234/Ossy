<?php

require_once 'apps/index/models/User.php';

class Permissions {

    /**
     * @desc Get application ID
     * @param string $app_name application name
     * @return mix
     */
    static function GetAppID($app_name = '') {
        if (empty($app_name)) {
            $app_name = $GLOBALS['APPLICATION_PATH'];
        }
        $db = DB::getInstance();
        $sql = "SELECT * FROM core_apps WHERE app_name=:app_name";
        $node = $db->fetch_assoc($db->execute($sql, array('app_name' => str_replace('@', '/', $app_name))));
        if (isset($node['app_id'])) {
            return $node['app_id'];
        } else {
            // if no need to special permission to an action, get the app id
            $app_name = $GLOBALS['APPLICATION_LINK'];
            $sql = "SELECT * FROM core_apps WHERE app_name=:app_name";
            $node = $db->fetch_assoc($db->execute($sql, array('app_name' => $app_name)));
            if (isset($node['app_id'])) {
                return $node['app_id'];
            }
        }
        // if not found just return false
        return(false);
    }

    //set permissions to user
    /**
     * @desc set permissions to user
     * @param string $node_type permission type (user/group)
     * @param string $app_name application name
     * @param int $node_id user/group id
     * @return void
     */
    static function SetPerm($type, $app_id, $user_id) {
        if ($app_id > 0) {
            $db = DB::getInstance();
            Permissions::DelPerm($type, $app_id, $user_id);
            $sql = "INSERT INTO  core_perm (tree_type,tree_pid,tree_nid) VALUES (:type, :user_id, :app_id)";
            $db->execute($sql, array('type' => $type, 'user_id' => $user_id, 'app_id' => $app_id));
        }
    }

    //delete permissions from user
    /**
     * @desc delete permissions to user
     * @param string $node_type permission type (user/group)
     * @param string $app_name application name
     * @param int $node_id user/group id
     * @return void
     */
    static function DelPerm($type, $app_id, $user_id) {
        if ($app_id > 0) {
            $db = DB::getInstance();
            $sql = "DELETE FROM  core_perm  WHERE tree_type=:type AND tree_pid = :user_id AND tree_nid=:app_id LIMIT 1";
            $db->execute($sql, array('type' => $type, 'user_id' => $user_id, 'app_id' => $app_id));
        }
    }

    //check permissions by group  
    /**
     * @desc check permissions by group
     * @param int $group_id group id
     * @param int $app_id application id
     * @return int
     */
    static function CheckGroupPerms($group_id, $app_id = false) {
        static $rows;
        if (!isset($rows[$group_id])) {
            $db = DB::getInstance();
            $sql = "SELECT * FROM core_perm WHERE tree_type='groupperm' AND tree_pid=:group_id";
            $query = $db->execute($sql, array('group_id' => $group_id));
            while ($row = $db->fetch_assoc($query)) {
                $rows[$group_id][$row['tree_nid']] = true;
            }
        }
        if (isset($rows[$group_id][$app_id])) {
            return(1);
        } elseif (isset($rows[$group_id]) && $app_id == false) {
            return($rows[$group_id]);
        }
        return(false);
    }

    //check permissions by user  
    /**
     * @desc check permissions by user
     * @param int $user_id user id
     * @param int $app_id application id
     * @return int
     */
    static function CheckUserPerms($user_id, $app_id = false) {
        static $rows;
		if (!isset($rows[$user_id])) {
            $db = DB::getInstance();
            $sql = "SELECT * FROM core_perm WHERE tree_type='userperm' AND tree_pid=:user_id";
            $query = $db->execute($sql, array('user_id' => $user_id));
            while ($row = $db->fetch_assoc($query)) {
                $rows[$user_id][$row['tree_nid']] = true;
            }
			$user = User::find($user_id);
			$rows[$user_id]['group'] = Permissions::CheckGroupPerms($user->user_group);
        }
        if (isset($rows[$user_id][$app_id])) {
            return(1);
        } elseif (isset($rows[$user_id]['group'][$app_id])) {
            return(2);
        }
        return(0);
    }
}
