<?php

/**
 * Basic Router Class
 */
class Router
{
    protected $map = array();

    private function __construct()
    {

    }

    public static function getInstance()
    {
        static $instance = null;
        if ($instance == null) {
            $instance = new static();
        }
        return $instance;
    }

    public static function group($route, $app)
    {
        Router::get($route . '/show', $app . '@show');
        Router::get($route . '/delete', $app . '@delete');
        Router::both($route . '/edit', $app . '@edit');
        Router::both($route . '/add', $app . '@add');
        Router::both($route . '/index', $app . '@index');
        Router::both($route, $app . '@index');
    }

    public static function get($route, $action)
    {
        $instance = Router::getInstance();
        $instance->map[] = array('request' => 'GET', 'route' => $route, 'action' => $action);
    }

    public static function post($route, $action)
    {
        $instance = Router::getInstance();
        $instance->map[] = array('request' => 'POST', 'route' => $route, 'action' => $action);
    }

    public static function both($route, $action)
    {
        Router::get($route, $action);
        Router::post($route, $action);
    }

    public function match()
    {
        $requestUrl = '/' . substr($_SERVER['REQUEST_URI'], strlen(base_url()));
        foreach ($this->map as $route) {
            if ($_SERVER['REQUEST_METHOD'] == $route['request']) {
                $req = substr($requestUrl, 0, strlen($route['route']));
                if (strcasecmp($route['route'], $req) === 0) {
                    return $route;
                }
            }
        }
        throw new Exception('Sorry, the page you are looking for could not be found. 404');
    }
}
