<?php

/**
 * View Helper Class
 * This class is a helper library of function to generate code for Bootstrap Panel heading/footer, form tags  and action buttons.
 * @author Azzoz Al-Hasani <azzozhsn@gmail.com>
 * 
 */

/**
 * View Helper Class
 * This class is a helper library of function to generate code for Bootstrap Panel heading/footer, form tags  and action buttons.
 * 
 */

class View{
    /**
     * Generate HTML code for panel-heading 
     * @param string $title first param will be the title of the panel.
     * @param string $params optional action buttons or any thing else, will be in the other side of the header
     * @return string generated HTML code.
     */
    public static function PanelHeader() {
        $params = func_get_args();
        $title = array_shift($params);
        if (empty($params)) {
            $html = '<h4>'.$title.'</h4>';
        } else {
            $html = '<h4 class="pull-left">'.$title.'</h4>
            <div class="pull-right">'.implode("\n", $params).'</div>
            <div class="clearfix"></div>';
        }
        return '<div class="panel-heading">'.$html.'</div>';
    }
    
    /**
     * Generate HTML code for panel-footer 
     * @param string $contents the content of the panel. will be wraped by <div class="panel-footer">...</div>
     * @return string generated HTML code.
     */
    public static function PanelFooter($contents) {
        return '<div class="panel-footer">'.$contents.'</div>';
    }
    
    /**
     * Generate HTML code for form tag with action and properties needed for styling and validation
     * @param string $action where the data will be post.
     * @param bool $multipart optional whether the form should upload files or not.
     * @return string generated HTML code.
     */
    public static function OpenForm($action, $multipart = false) {
        return '<form action="' . base_url($action) . '" method="post" role="form" data-toggle="validator" class="form-horizontal"' . ($multipart ? ' enctype="multipart/form-data"':'') . ' >';
    }
    
    /**
     * Simply colse tag for form
     * @return string generated HTML code.
     */
    public static function CloseForm() {
        return '</form>';
    }
    
    
    /**
     * Generate HTML code for panel-footer with submit button and cancel button witch is optional. The content will be in <div class="panel-footer">...</div>
     * @param string $submitLabel the label for submit button
     * @param string $cancelLabel the label for cancel button
     * @param string $cancelLink the url of cancel button
     * @return string generated HTML code.
     */
    public static function FormFooter($submitLabel, $cancelLabel = '', $cancelLink = '') {
        $footer = '
        <div class="panel-footer">
            <button type="submit" class="btn btn-success"><i class="fa fa-check"></i> '.$submitLabel.'</button>';
        if (!empty($cancelLabel) and !empty($cancelLink)) {
            $footer .= '
            <a href="'.base_url($cancelLink).'" class="btn btn-danger"><i class="fa fa-times"></i> '.$cancelLabel.'</a>';
        }
        $footer .= '
        </div>';
        return $footer;
    }
    
    /**
     * Generate HTML code for panel-footer with submit button and cancel button witch is optional. The content will be in <div class="panel-footer">...</div>
     * @param string $action the label for submit button
     * @param string $label the label for cancel button
     * @param string $type the url of cancel button
     * @param string $id the url of cancel button
     * @param string $hint the url of cancel button
     * @return string generated HTML code.
     */
    public static function ActionButton($action, $label, $type, $id=0, $hint='') {
        if (Permissions::CheckUserPerms($_SESSION['current_user']['user_id'], Permissions::GetAppID($action))) {
            $class = 'btn-primary';
            if ($type == 'add') {
                $class = 'btn-success';
                $icon  = 'fa-plus';
            }
            if ($type == 'ok') {
                $class = 'btn-success';
                $icon  = 'fa-check';
            }
            if ($type == 'show') {
                $class = 'btn-primary';
                $icon  = 'fa-eye';
            }
            if ($type == 'copy') {
                $class = 'btn-success';
                $icon  = 'fa-copy';
            }
            if ($type == 'download') {
                $class = 'btn-success';
                $icon  = 'fa-download';
            }
            if ($type == 'edit') {
                $class = 'btn-warning';
                $icon  = 'fa-edit';
            }
            if ($type == 'print') {
                $class = 'btn-primary print';
                $icon  = 'fa-print';
            }
            if ($type == 'moveup') {
                $class = 'btn-warning';
                $icon  = 'fa-arrow-up';
            }
            if ($type == 'movedown') {
                $class = 'btn-warning';
                $icon  = 'fa-arrow-down';
            }
            if ($type == 'disable') {
                $class = 'btn-primary';
                $icon  = 'fa-stop';
            }
            if ($type == 'enable') {
                $class = 'btn-primary';
                $icon  = 'fa-play';
            }
            if ($type == 'delete') {
                $class = 'btn-danger delete';
                $icon  = 'fa-trash-o';
            }
            if ($type == 'submit') {
                $class = 'btn-success';
                $icon  = 'fa-check';
            }
            if ($type == 'back') {
                $class = 'btn-primary';
                $icon  = (lang() == 'en') ? 'fa-backward':'fa-forward';
            }
            if ($type == 'cancel') {
                $class = 'btn-danger';
                $icon  = 'fa-times';
            }
			if ($type == 'reply') {
                $class = 'btn-warning';
                $icon  = 'fa-reply';
            }
            if ($type == 'send') {
                $class = 'btn-warning';
                $icon  = 'fa-envelope-o';
            }
			if ($type == 'info') {
                $class = 'btn-primary';
                $icon  = 'fa-info';
            }
            if ($type == 'trans') {
                $class = 'btn-success';
                $icon  = '';
            }
            if ($type == 'inv') {
                $class = 'btn-inverse';
                $icon  = 'fa-check';
            }
            if ($type == 'transfer') {
                $class = 'btn-warning';
                $icon  = 'fa-paper-plane';
            }
			
            if ($type == 'message') {
                $class = 'btn-primary';
                $icon  = 'fa-envelope';
            }
            if ($id) {
                $action .= '/'.$id;
            }
            return '<a class="btn '.$class.' hidden-print" href="' . base_url($action) . '" title="'.$hint.'"><i class="fa '.$icon.'"></i> '.$label.'</a>';
        }
        return '';
    }    
}
