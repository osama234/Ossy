<?php
    require_once('config.php');
    require_once('helper.php');
    $url_path = GetConfig('url_path');
	$app_path = GetConfig('app_path');

	foreach($url_path as $path) {
		if($path) {
			if(is_dir($app_path.$path) && !isset($_path)) {
				$_path    	= $app_path.$path.'/';
			}
			if(isset($_path) && file_exists($_path.$path.'_module.php')) {
				$_class   	= $path;
			}
			if(isset($_path) && isset($_class)) {
				$_params[]	= $path;
			}
		}
	}
	//if request not found, call default class
	if(!isset($_path)) {
		$_path	 = $app_path.'home/';
		$_class	 = 'home';
		$_params =  explode('/',getPath());
	}
	//load class
	if(isset($_path) && isset($_class) && file_exists($_path.$_class.'_module.php')) {
		if(phpos::CheckUserPerms($_path, $_class, $_params)){
			$log_id	= phpos::OpenLog();
			$data 	= phpos::LoadClass($_path, $_class, $_params);
			phpos::LoadView($_path, $_params, $data);
			phpos::CloseLog($log_id);
		} else {
			print '<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><title>المستودع الخيري بالمجمعة</title></head><body><br /><br /><br /><center><h2>ممنوع الدخول</h2><p>ليس لديك الصلاحية لدخول هذه الصفحة</p></center></body></html>';
		}
	} else {
		print 'Error: '.getPath().' not found.';
	}
?>