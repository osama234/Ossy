<?php
	include_once('config.php');
	include_once('helper.php');
	
	
	$db = DBConnection();
	$_GET['n'] = $_GET['q'];
	$_GET['q'] = '%'.$_GET['q'].'%';
	$q = $db->execute('SELECT b_id, b_name, r_dist FROM mcw_committee.beneficiaries INNER JOIN mcw_committee.residences ON b_id=r_bid WHERE b_id = :n OR b_name LIKE :q', $_GET);
	
	$data = array();
	while ($row = $db->fetch_assoc($q)) {
		$data[] = array($row['b_id'], $row['b_name'], $row['r_dist']);
	}
	echo json_encode($data);
	exit(0);
?>