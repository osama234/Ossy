<?php
	//phpos controller
	class controller {
		var $vars 	= array();
		var $user 	= array();
		var $db 	= null;
		var $mydb 	= null;
		var $apps 	= null;
		var $post 	= array();
		var $get 	= array();
		function __construct() {
			$this->mydb = $GLOBALS['my_db'];
			$this->user	= (isset($_SESSION['current_user'])) ? $_SESSION['current_user'] : false;
			$this->secureInputs();
			$q = $this->mydb->execute('SELECT * FROM applications WHERE app_pid=0 ORDER BY app_sort ASC');
			while ($row = $this->mydb->fetch_assoc($q)) {
				if (Permissions::CheckUserPerms($this->user['user_id'], $row['app_id'])) {
					$q2 = $this->mydb->execute('SELECT * FROM applications WHERE app_pid=:app_id ORDER BY app_sort ASC', $row);
					$row['sub'] = array();
					while ($sub = $this->mydb->fetch_assoc($q2)) {
						if (Permissions::CheckUserPerms($this->user['user_id'], $sub['app_id'])) {
							$row['sub'][] = $sub;
						}
					}
					$this->vars['apps'][] = $row;
				}
			}
		}
		//Remapping Function Calls
		function _remap($method, $params = array()) {
			if (method_exists($this, $method)){
				return call_user_func_array(array($this, $method), array_slice($params,1));
			} elseif(method_exists($this, 'index')) {
				return call_user_func_array(array($this, 'index'), $params);
			}
		}
		
		private function secureInputs() {
		    //make copy of $_POST, $_GET
	        $this->POST	= $_POST;
	        $this->GET	= $_GET;
	        $_POST	= $this->xss_clean($_POST);
	        $_GET	= $this->xss_clean($_GET);
		}
		
		//function to clean xss
        private function xss_clean(&$str) {
	        if (is_array($str)) {
		        foreach($str as $key=>$val) {
			        $str[$key] = $this->xss_clean($str[$key]);
		        }
	        } else {
		        $str = strip_tags($str);
	        }
	        return($str);
	    }
	}
?>
