<?php

//mysql db driver 
class mysql_driver {
	var $link = null; //database link
	var $affectedRows = false;
	
	//connect to database
	function connect($host, $user, $pass, $db='', $charset='utf8'){
		$this->link = @mysql_pconnect($host, $user, $pass);
		if($this->link) {
			$this->charset($charset);
			mysql_select_db($db, $this->link);
			return($this->link);
		} else {
			die('Could not connect: ' . mysql_error());
		}
	}
	function execute($sql, $inputarr=array(), $echo=0) {
		$arr = array('null','current_timestamp','now');
		foreach($inputarr as $key => $val) {
			if(!is_array($val) && in_array(strtolower($val), $arr)){
				$val=$this->escape($val);
			}elseif(is_string($val)){
				$val=$this->escape($val, true);
			} elseif ($val === false || $val === null){
				$val = 'null';
			}
			$sql = preg_replace('/:'.$key.'(\s|,|\))/', $val.'\1', $sql.' ');
		}
		if ($echo) {
			echo $sql.'<br />';
		}
		$result = mysql_query($sql, $this->link);
		$this->affectedRows = mysql_affected_rows();
		return $result;
	}
	function fetch_row($query) {
		if (!$query) return false;
		return(mysql_fetch_row($query));
	}
	function fetch_assoc($query) {
		if (!$query) return false;
		return(mysql_fetch_assoc($query));
	}
	function insert_id() {
		return(mysql_insert_id($this->link));
	}
	function affected_rows() {
	    return($this->affectedRows);
	}
	function num_rows($query) {
		return(mysql_num_rows($query));
	}
	function escape($str, $quote=false){
		$str = mysql_real_escape_string($str, $this->link);
		return(($quote)?"'$str'":$str);
	}
	function sql_insert($table, $arr){
        $keys = $vals = array();
        foreach($arr as $key=>$val) {
			$keys[] = $this->escape($key);
			$vals[] = $this->escape($val, true);
		}
		return("INSERT INTO $table (".implode(',',$keys).") VALUES (".implode(',',$vals).")");
	}
	function sql_update($table, $arr, $where){
        $update_arr = $where_arr = array();
		foreach($arr as $key=>$val) {
			$update_arr[]= $this->escape($key).'='.$this->escape($val, true);
		}
		foreach($where as $key=>$val) {
			$where_arr[]= $this->escape($key).'='.$this->escape($val, true);
		}
		return("UPDATE $table SET ".implode(',',$update_arr)." WHERE ".implode(' AND ',$where_arr));
	}
	function charset($charset){
		return($this->execute("SET NAMES $charset"));
	}
	function error(){
		return(mysql_error($this->link));
	}
	function close(){
		return(mysql_close($this->link));
	}
	
}
	
?>
