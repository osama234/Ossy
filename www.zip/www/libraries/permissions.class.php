<?php
	class Permissions {
		
		/**
		 * @desc Get application ID
		 * @param string $app_name application name
		 * @param bool $array to return array or string
		 * @return mix
		 */
		static function GetAppID($app_name='', $array=false) {
			global $_params;
			if(!$app_name) {
				$app_name = (isset($_params[1]))?$_params[0].'/'.$_params[1]:$_params[0];
			}
			$db		= DBConnection();
			$sql 	= "SELECT * FROM applications WHERE app_name=:app_name";
			$node	= $db->fetch_assoc($db->execute($sql, array('app_name'=>$app_name)));
			if(isset($node['app_id'])){
				return  $node['app_id'];
			}
			return(false);
		}
	
		//set permissions to user
		/**
		 * @desc set permissions to user
		 * @param string $app_name application name
		 * @param int $user_id user id
		 * @return void
		 */
		static function SetPerm($app_id, $user_id) {
			if($app_id>0) {
				$db = DBConnection();
				Permissions::DelPerm($app_id, $user_id);
				$sql = "INSERT INTO  tree (tree_type,tree_pid,tree_nid) VALUES ('userperm',:user_id,:app_id)";
				$db->execute($sql, array('user_id'=>$user_id, 'app_id'=>$app_id));
			}
		}
		
		//delete permissions from user
		/**
		 * @desc delete permissions to user
		 * @param string $app_name application name
		 * @param int $user_id user id
		 * @return void
		 */
		static function DelPerm($app_id, $user_id) {
			if($app_id>0) {
				$db  = DBConnection();
				$sql = "DELETE FROM  tree  WHERE tree_type='userperm' AND tree_pid = :user_id AND tree_nid=:app_id LIMIT 1";
				$db->execute($sql, array('user_id'=>$user_id, 'app_id'=>$app_id));
			}
		}
		
		//check permissions by group  
		/**
		 * @desc check permissions by group
		 * @param int $group_id group id
		 * @param int $app_id application id
		 * @return int
		 */
		static function CheckGroupPerms($group_id, $app_id=false) {
			static $rows;
			if(!isset($rows[$group_id])) {
				$db 		= DBConnection();
				$sql 		= "SELECT * FROM tree WHERE tree_type='grouperm' AND tree_pid=:group_id";
				$query		= $db->execute($sql, array('group_id'=>$group_id));
				while($row 	= $db->fetch_assoc($query)){
					$rows[$group_id][$row['tree_nid']] = true;
				}
			}
			if(isset($rows[$group_id][$app_id])){
				return('1');
			}elseif(isset($rows[$group_id]) && $app_id==false){
				return($rows[$group_id]);
			}
			return(false);
		}
		
		//check permissions by user  
		/**
		 * @desc check permissions by user
		 * @param int $user_id user id
		 * @param int $app_id application id
		 * @return int
		 */
		static function CheckUserPerms($user_id, $app_id=false) {
			static $rows;
			if(!isset($rows[$user_id])) {
				$user 		= GetUserById($user_id);
				$db 		= DBConnection();
				$sql 		= "SELECT * FROM tree WHERE tree_type='userperm' AND tree_pid=:user_id";
				$query		= $db->execute($sql, array('user_id'=>$user_id));
				while($row 	= $db->fetch_assoc($query)){
					$rows[$user_id][$row['tree_nid']] = true;
				}
				$rows['group']	= Permissions::CheckGroupPerms($user['user_group']);
			}
			if(isset($rows[$user_id][$app_id])){
				return('1');
			}elseif(isset($rows['group'][$app_id])){
				return('2');
			}
			return(false);
		}
	}
?>
