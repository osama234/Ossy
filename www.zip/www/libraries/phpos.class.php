<?php
	//phpos class
	class phpos{
		//check user permission
		static function CheckUserPerms($_path='', $_class='', $_params=array()){
			//if user not login redirect to login page
			if(!isset($_SESSION['current_user']['user_id']) && !in_array($_class,array('user','index'))){
				if (trim($_SERVER['REQUEST_URI'], '/') != 'user/login') {
					$_SESSION['REQUEST'] = trim($_SERVER['REQUEST_URI'], '/');
				}
				redirect('user/login');
				exit(0);
			}
			//connect to database
			$GLOBALS['my_db'] = phpos::DBConnect(GetConfig('my_db')); //mysql database
			//global permission for login user
			if(in_array($_class,array('user','index'))) {
				return(true);
			}
			//get application id from database
			//check user permission
			if(Permissions::CheckUserPerms($_SESSION['current_user']['user_id'], Permissions::GetAppID())) {
				return(true);
			}
			return(false);
		}
		
		//log all requests
		static function OpenLog(){
			$GLOBALS['my_db'] =  phpos::DBConnect(GetConfig('my_db')); //mysql database
			$GLOBALS['openlog'] = microtime(true);
			$log['log_addr'] = ip2long($_SERVER['REMOTE_ADDR']);
			$log['log_req'] = ($_SERVER['REQUEST_METHOD']=='POST')?'2':'1';
			$log['log_path'] = implode('/',GetConfig('url_path'));
			$log['log_data'] = serialize($_REQUEST);
			$log['log_user'] = (isset($_SESSION['current_user']['user_id']))?$_SESSION['current_user']['user_id']:0;
			$log_sql = "INSERT INTO logs(log_addr,log_req,log_path,log_data,log_user) VALUES (:log_addr,:log_req,:log_path,:log_data,:log_user)";
			$GLOBALS['my_db']->execute($log_sql, $log);
			return($GLOBALS['my_db']->insert_id());
		}
		static function CloseLog($log_id=0){
			$GLOBALS['closelog'] = microtime(true);
			$log_sql = "UPDATE logs SET log_time=:log_time WHERE log_id=:log_id";
			return($GLOBALS['my_db']->execute($log_sql, array('log_id'=>$log_id,'log_time'=>($GLOBALS['closelog']-$GLOBALS['openlog']))));
		}
		//log errors
		static function ErrorLog($error) {
			$db  = & DBConnect(GetConfig('my_db'));
		    $log['log_addr'] = ip2long($_SERVER['REMOTE_ADDR']);
			$log['log_req'] = ($_SERVER['REQUEST_METHOD']=='POST')?'2':'1';
			$log['log_path'] = (getPath() == '') ? '/':getPath();
			$log['log_data'] = $error;
			$log['log_user'] = (isset($_SESSION['current_user']['user_id']))?$_SESSION['current_user']['user_id']:0;
			$log['log_type'] = 2;
			$log_sql = "INSERT INTO logs(log_addr,log_req,log_path,log_data,log_user, log_type) VALUES (:log_addr,:log_req,:log_path,:log_data,:log_user, :log_type)";
			return($db->execute($log_sql, $log));
		}
		
		//loading class
		static function LoadClass($_path='', $_class='', $_params=array()){
			require_once($_path.$_class.'_module.php');
			//this is for paging
			$_POST  = isset($_POST['pager_vars'])?unserialize(base64_decode($_POST['pager_vars'])):$_POST;
			$_class = $_class.'_controller';
			$_object = new $_class;
			if(method_exists($_object, '_remap')) {
				$data = @call_user_func_array(array($_object, '_remap'), array($_params[1], array_slice($_params,1)));
			} else {
				$data = call_user_func_array(array($_object, $_params[1]), array_slice($_params,1));
			}
			$_object->vars['user'] = $_object->user;
			$data = (is_array($data))?$data+$_object->vars:$_object->vars;
			return($data);
		}
		//loading view
		static function LoadView($_path='', $_params=array(), $data=array()){
			if(is_array($data)) {
			    extract($data, EXTR_SKIP);
			}
			if(file_exists($_path.'views/_header.php')){
			    include($_path.'views/_header.php');
			} else {
			    include($_path.'../index/views/_header.php');
			}
			@include(phpos::GetViewPath($_path, $_params));
			if(file_exists($_path.'views/_footer.php')){
			    include($_path.'views/_footer.php');
			} else {
			    include($_path.'../index/views/_footer.php');
			}
			unset($_SESSION['messages']);
		}
		
		static function GetViewPath($_path='', $_params=array()) {
			if (@file_exists($_path.'views/'.$_params[1].'_'.$_params[2].'_'.$_params[3].'.php')) { // class/views/method_param1_param2.php
				return($_path.'views/'.$_params[1].'_'.$_params[2].'_'.$_params[3].'.php');
			} elseif(@file_exists($_path.'views/'.$_params[1].'_'.$_params[2].'.php')) {            // class/views/method_param1.php
				return($_path.'views/'.$_params[1].'_'.$_params[2].'.php');
			} elseif(@file_exists($_path.'views/'.$_params[1].'.php')) {					        // class/views/method.php
				return($_path.'views/'.$_params[1].'.php');
			} elseif(@file_exists($_path.'views/'.$_params[0].'.php')) {				            // class/views/class.php
				return($_path.'views/'.$_params[0].'.php');
			} elseif(@file_exists($_path.'views/index.php')) {							            // class/views/index.php
				return($_path.'views/index.php');
			}
		}
		
		//database connection
		static function DBConnect($db_str='mysql://root:toor@localhost/test', $charset='utf8'){
			$db = parse_url($db_str);
			if(isset($db['scheme']) && isset($db['host']) && $db['user'] && $db['path']) {
				$driver = strtolower($db['scheme']);
				if(file_exists(GetConfig('lib_path').$driver."_driver.php")){
					require_once(GetConfig('lib_path').$driver."_driver.php");
					$driver = $driver."_driver";
					$db_object = new $driver;
					$db_object->connect($db['host'], $db['user'], @$db['pass'], str_replace('/','',$db['path']),$charset);
					return($db_object);
				} else {
					echo 'Driver not found: '.$driver.'_driver.php';
				}
			} elseif(trim($db_str)!='') {
				echo 'Method usage: DBConnect("driver://username:password@hostname/database");';
			}
		}
	}
?>
