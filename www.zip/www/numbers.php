<?php
	header('Content-Type: text/html; charset=utf-8');
	include_once('helper.php');
	$value = (int) $_GET['val'];
	echo number2string($value) . ' ريال فقط لاغير';
	exit(0);
?>