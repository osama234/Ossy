<?php 
	header('Content-Type: text/html; charset=utf-8');
	include_once('config.php');
	include_once('helper.php');
	$db = DBConnection();

	$beneficiary = $db->fetch_assoc($db->execute(
									'SELECT * FROM mcw_committee.beneficiaries
									 INNER JOIN mcw_committee.residences ON r_bid=b_id
									 LEFT JOIN mcw_committee.class ON c_bid=b_id
									 WHERE b_file_no=:id', $_GET));
			$q = $db->execute('SELECT * FROM mcw_committee.phones WHERE p_bid=:b_id', $beneficiary);
			while ($row = $db->fetch_assoc($q)) {
				$phones[] = $row;
			}
?>
<div class="panel panel-primary">
    <div class="panel-heading">البيانات الأساسية</div>
    <table class="table">
    	<tr>
    		<th>اسم المستفيد</th>
    		<td><?= $beneficiary['b_name'] ?></td>
    		<th>رقم ملف المستفيد</th>
    		<td><?= $beneficiary['b_file_no'] ?></td>
    	</tr>
    	<tr>
    		<th>رقم الهوية</th>
    		<td><?= $beneficiary['b_idno'] ?></td>
    		<th>الجنسية</th>
    		<td><?= GetOptionsLabel('nationality', $beneficiary['b_natid']) ?></td>
    	</tr>
    	<tr>
    		<th>عدد الزوجات</th>
    		<td><?= $beneficiary['b_wives'] ?></td>
    		<th>اسم الزوجة</th>
    		<td><?= $beneficiary['b_wife_name'] ?></td>
    	</tr>
    	<tr>
    		<th>حالة المستفيد</th>
    		<td><?= GetOptionsLabel('user_status', $beneficiary['b_status']) ?></td>
    		<th>رقم حساب المستفيد</th>
    		<td><?= $beneficiary['b_account_no'] ?></td>
    	</tr>
    </table>
</div>
<br />

<div class="panel panel-primary">
    <div class="panel-heading">هواتف المستفيد</div>
    <table class="table">
        <tr>
            <th>رقم الهاتف</th>
            <th>صاحب الرقم</th>
            <th>تاريخ الإضافة</th>
        </tr>
        <?php foreach ($phones as $row) { ?>
        <tr>
            <td><?=$row['p_no']?></td>
            <td><?=$row['p_name']?></td>
            <td><?=ArDate('Y/m/d', $row['p_time'])?></td>
        </tr>
        <?php } ?>
    </table>
</div>

<br />
<div class="panel panel-primary">
    <div class="panel-heading">سكن المستفيد</div>
    <table class="table">
    	<tr>
    		<th>الحي</th>
    		<td><?= $beneficiary['r_dist'] ?></td>
    		<th>اسم الشارع</th>
    		<td><?= $beneficiary['r_street'] ?></td>
    	</tr>
    	<tr>
    		<th>رقم المنزل</th>
    		<td><?= $beneficiary['r_no'] ?></td>
    		<th>نوع السكن</th>
    		<td><?= GetOptionsLabel('residence_type', $beneficiary['r_type']) ?> (<?= $beneficiary['r_owned'] == 1 ? "ملك" : "مستأجر" ?>)</td>
    	</tr>
    	<tr>
    		<th>الإيجار السنوي</th>
    		<td><?= $beneficiary['r_rent'] ?></td>
    		<th>احداثيات المنزل</th>
    		<td>E<?= $beneficiary['r_lat'] ?>, N<?= $beneficiary['r_long'] ?></td>
    	</tr>
    </table>
</div>