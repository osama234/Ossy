<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
App::uses('CakeTime', 'Utility');
class AppController extends Controller {
        public $option_row_other = 10;
	
	//public $timezone = 'UTC'; //
	//public $userTimezone = 'UTC'; // for compatiblity actuallt $timezone was used from start
	//public $serverTimezone = 'UTC'; //
	
	public $date_format;
	public $datetime_format;
	public $appTitle;
	public $appUrl;
	
	public $edit_timesheet; // should normal user can edit their timesheet
	
	public $components = array(
			'Session',
			'Acl',
			'Email',
			'Auth' => array(
					'loginAction' => array('controller' => 'users','action' => 'login','plugin' => ''),
					'loginRedirect' => array('plugin'=>'','controller' => 'timesheets', 'action' => 'dashboard'),
					'logoutRedirect' => array('plugin'=>'','controller' => 'users', 'action' => 'login'),
					'authorize' => array('Actions' => array('actionPath' => 'controllers'))
			),
			'Cookie',
                        'Search.Prg',
                        'RequestHandler'
	);
	
	public $helpers = array(
			'Session',
			'Time',
			'Js',
			'Html' => array('className' => 'TwitterBootstrap.BootstrapHtml'),
                        'Form' => array('className' => 'TwitterBootstrap.BootstrapForm'),
			'Paginator' => array('className' => 'TwitterBootstrap.BootstrapPaginator'),
                        'Cache'
	);
	
	public $uses = array('Option','User','Group');
	
	public function beforeFilter() {
                parent::beforeFilter();
                
                // set cookie options
                $this->Cookie->path = Router::url('/');  
                $this->Cookie->key = 'qSI232qs*&sXOw!adre@34SAv!@*(XSL#$%)asGb$@11~_+!@#HKis~#^D-on:Dhiman';
                $this->Cookie->httpOnly = true; 
                if($this->Cookie->read('remember')) :
                    $cookie = $this->Cookie->read('remember');               
                    if(isset($cookie['username']) && isset($cookie['password'])) : 
                        $user_active = $this->User->find('first', array(
                            'conditions' => array(
                                'User.username' => $cookie['username'],
                                'User.password' => $this->Auth->password($cookie['password'])
                            )
                        ));

                        if (!empty($user_active)) :
                            if (!$user_active['User']['active']) :
                                $this->redirect('/users/logout');
                            else :
                                if ($this->Auth->login($user_active['User'])) :
                                    //
                                endif;
                            endif;
                        else : 
                            $this->redirect('/users/logout');
                        endif;
                    endif;                   
                else :
                    if(!$this->Auth->login()) :
                        if ($this->params['action'] != 'logout' && $this->params['action'] != 'login' && $this->params['action'] != 'setPhotoAndName' && $this->params['action'] != 'language' && $this->params['action'] != 'forgot') :
                            $this->redirect('/users/logout');
                        endif;
                    endif;
                endif;
                
                $this->checkLanguage();
                
                $option_server_timezone = $this->Option->find('first',array('conditions'=>array('name'=>'server_timezone')));
		if(!empty($option_server_timezone)){
			$this->serverTimezone = $option_server_timezone['Option']['value'];
		}
                
                if ($this->serverTimezone != null) {
                    date_default_timezone_set($this->serverTimezone); //override core.php set global php timezone
                }
		
		//$this->timezone = date_default_timezone_get(); //removed bcoz we may have different user timezone
		
		$user_timezone = $this->User->find('first',array('conditions'=>array('User.id'=>$this->Auth->user('id'))));
                if (!empty($user_timezone)) {
                    $this->timezone = $user_timezone['User']['user_timezone'];
                    $this->userTimezone = $this->timezone;
                } else {
                    $option_user_timezone = $this->Option->find('first',array('conditions'=>array('name'=>'user_timezone')));
                    if(!empty($option_user_timezone)) {
                        $this->timezone = $option_user_timezone['Option']['value'];
                    }
                    $this->userTimezone = $this->timezone;
                }
		
		$this->Auth->authError = "You need to login!!";
	
		$option_title = $this->Option->find('first',array('conditions'=>array('name'=>'title')));
		if(!empty($option_title)){
			$this->appTitle = $option_title['Option']['value']; 
		}
		else {
			$this->appTitle = '';
		}
		$this->appUrl = Router::url('/',true);
		
		$option_row_other = $this->Option->find('first',array('conditions'=>array('name'=>'row_other')));
		if(!empty($option_row_other)){
			$this->option_row_other = $option_row_other['Option']['value'];
		}
		else {
			$this->option_row_other = 30;
		}
		
		$option_date_format = $this->Option->find('first',array('conditions'=>array('name'=>'date_format')));
		if(!empty($option_date_format)){
			$this->date_format = $option_date_format['Option']['value'];
		}
		else {
			$this->date_format = 'M j, Y';
		}
		
		$option_datetime_format = $this->Option->find('first',array('conditions'=>array('name'=>'datetime_format')));
		if(!empty($option_datetime_format)){
			$this->datetime_format = $option_datetime_format['Option']['value'];
		}
		else {
			$this->datetime_format = 'M j, Y g:i A';
		}
		
		$option_edit_timesheet = $this->Option->find('first',array('conditions'=>array('name'=>'edit_timesheet')));
		if(!empty($option_edit_timesheet)){
			$this->edit_timesheet = $option_edit_timesheet['Option']['value'];
		} else {
			$this->edit_timesheet = true;
		}
		//new option for manager see multiple user
		$option_manager_see_multi_lavels = $this->Option->find('first',array('conditions'=>array('name'=>'manager_see_multi_lavels')));
		if(!empty($option_manager_see_multi_lavels)){
			$this->manager_see_multi_lavels = $option_manager_see_multi_lavels['Option']['value'];
		}
		else {
			$this->manager_see_multi_lavels = false;
		}
		//debug($option_manager_see_multi_lavels);
		//end
		
	}
	
	public function beforeRender(){
		parent::beforeRender();
		//--load header settings
		$option_title = $this->Option->find('first',array('conditions'=>array('name'=>'title')));
		if(!empty($option_title)){
			$this->set('title',$option_title['Option']['value']);
		}
		else {
			$this->set('title','');
		}
		
		$option_currency = $this->Option->find('first',array('conditions'=>array('name'=>'currency')));
		if(!empty($option_currency)){
			$this->set('currency',$option_currency['Option']['value']);
		}
		else {
			$this->set('currency','$');
		}
		
		$option_show_copyright = $this->Option->find('first',array('conditions'=>array('name'=>'show_copyright')));
		if(!empty($option_show_copyright)){
			$this->set('show_copyright',$option_show_copyright['Option']['value']);
		}
		else {
			$this->set('show_copyright',true);
		}
		
		$option_date_format = $this->Option->find('first',array('conditions'=>array('name'=>'date_format')));
		if(!empty($option_date_format)){
			$this->set('date_format',$option_date_format['Option']['value']);
		}
		else {
			$this->set('date_format','M j, Y');
		}
		
		$option_datetime_format = $this->Option->find('first',array('conditions'=>array('name'=>'datetime_format')));
		if(!empty($option_datetime_format)){
			$this->set('datetime_format',$option_datetime_format['Option']['value']);
		}
		else {
			$this->set('datetime_format','M j, Y g:i A');
		}
		
		$this->set('timezone',$this->timezone);
		
		$option_copyright = $this->Option->find('first',array('conditions'=>array('name'=>'copyright')));
                if(!empty($option_copyright)){
			$this->set('copyright',$option_copyright['Option']['value']);
		
			if($option_copyright['Option']['logo_dir']){
				$temp_logo = $option_copyright['Option']['logo_dir'] . "/logo_" . $option_copyright['Option']['logo'];
				$this->set('logo',$temp_logo);
			}
			else {
				$this->set('logo','');
			}
		}
		else {
			$this->set('copyright','');
			$this->set('logo','');
		}
		
		if($this->Auth->loggedIn()){
                    $this->set('currentUser',$this->User->read(null,$this->Auth->user('id')));
		}
		//-----end load header settings
		
	}
	
	public function first_active_admin(){
		$admin = $this->User->find('first',array('conditions'=>array('User.group_id'=>1,'User.active'=>true)));
		return $admin;
	}
        
        
    
        public function checkLanguage() { 
            if ($this->Cookie->read('lang')) : 
                Configure::write('Config.language', "".$this->Cookie->read('lang'));
            else :
                $lng = $this->Option->find('all', array(
                    'conditions' => array('Option.name' => 'default_language')
                ));

                $this->Cookie->write('lang', $lng[0]['Option']['value'], false, '365 days');
                Configure::write('Config.language', $lng[0]['Option']['value']);
            endif;
        }
        
        
        
    
}