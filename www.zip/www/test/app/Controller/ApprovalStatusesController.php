<?php
class ApprovalStatusesController extends AppController {
	
	public function index($csvFile = null) {
		$searched = false;
		$search_user_full_name = '';
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_name'])){
				$searched = true;
			}
				
		}
	
	
		$this->set('searched',$searched);
	
		$this->Prg->commonProcess();
		//$this->ApprovalStatus->recursive = 1;
	
		if ($csvFile) {
			$this->paginate = array(
					'conditions' => $this->ApprovalStatus->parseCriteria($this->passedArgs),
					'order' => array(
							'ApprovalStatus.modified' => 'desc'
					)
			);
			$this->request->params['named']['page'] = null;
		}
		else {
			$this->paginate = array(
					'conditions' => $this->ApprovalStatus->parseCriteria($this->passedArgs),
					'limit' => $this->option_row_other,
					'order' => array(
							'ApprovalStatus.modified' => 'desc'
					)
			);
		}
	
		$this->set('approvalStatuses', $this->Paginate());
	}
	
	public function view($id = null){
		$this->ApprovalStatus->id = $id;
		if(!$this->ApprovalStatus->exists()){
			throw new NotFoundException('Record not found');
		}
	
		$ApprovalStatus = $this->ApprovalStatus->read();
	
		$this->set('approvalStatus',$ApprovalStatus);
	
	}
	
	public function add(){
	
		if($this->request->is('post')){
			//$this->request->data['Job']['user_id'] = $this->Auth->user('id');
	
			$this->ApprovalStatus->create();
				
			$isSaved = $this->ApprovalStatus->save($this->request->data);
				
			if($isSaved){
				$this->Session->setFlash(__('New Approval Status added'),'alert');
				$this->redirect(array('action'=>'index'));
			}
			else
			{
				$this->Session->setFlash(__('Unable to add'),'alert', array('class'=>'alert-error'));
			}
		}
	}
	
	public function edit($id = null){
		$this->ApprovalStatus->id = $id;
		if(!$this->ApprovalStatus->exists()){
			throw new NotFoundException('Record not found');
		}
	
		if($this->request->is('post')){
	
			if($this->ApprovalStatus->save($this->request->data)){
				$this->Session->setFlash('Approval Status data saved ','alert');
				$this->redirect(array('action'=>'index'));
			}
			else
			{
				$this->Session->setFlash(__('Unable to save changes'),'alert', array('class'=>'alert-error'));
			}
		}
		else
		{
	
			$this->request->data = $this->ApprovalStatus->read();
		}
	}
	
	public function delete($id = null){
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
	
		$this->ApprovalStatus->id = $this->request->data['id']; //--
		if(!$this->ApprovalStatus->exists()){
			throw new NotFoundException('Record not found');
		}
	
		if($this->ApprovalStatus->delete($id)){
			$this->Session->setFlash(__('Approval Status deleted'),'alert');
			$this->redirect(array('action'=>'index'));
		}
		else
		{
			$this->Session->setFlash(__('Unable to delete'),'alert', array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		}
	}
}