<?php
class DepartmentsController extends AppController {
	public function beforeFilter() {
		parent::beforeFilter();
	
		// For CakePHP 2.1 and up
		$this->Auth->allow('index', 'view', 'add', 'edit', 'delete');
	}
// not required so commented out
	public function index(){
		if(!$this->Auth->user('id'))
		{
			$this->redirect(array('controller'=>'users', 'action'=>'logout'));
		}
		$departments = $this->Department->find('all');
		$this->set('departments',$departments);
	}
	
	public function view() {
		
	}
	
	public function add() {
		if(!$this->Auth->user('id'))
		{
			$this->redirect(array('controller'=>'users', 'action'=>'logout'));
		}
		if ($this->request->is('post')) {
			$this->Department->create();
			if ($this->Department->save($this->request->data)) {
				$this->Session->setFlash(__('The department has been saved'));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The department could not be saved. Please, try again.'));
			}
		}
	}
	
	public function edit($id = null) {
	
            $this->Department->id = $id;
            
            if (!$this->Department->exists()) {
			throw new NotFoundException(__('Invalid Department'));
            }
            
            if (($this->Auth->user('group_id') != 1)) {
			$this->Session->setFlash(__('You do not have permission to edit department detail'),'alert',array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
            }
            
            if ($this->request->is('post') || $this->request->is('put')) {
                
                if ($this->Department->save($this->request->data)) {
                        $this->Session->setFlash('Department details has been saved','alert',array('class'=>'alert-success'));
                        $this->redirect(array('action' => 'index'));
                } else {
                        $this->Session->setFlash(__('The user could not be saved. Please, try again.'));
                }
            }
            
            $this->request->data = $this->Department->read(null, $id);
            
	}
	
	public function delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->Department->id = $id;
		if (!$this->Department->exists()) {
			throw new NotFoundException(__('Invalid Department'));
		}
                
		if ($this->Department->delete($id)) {
			$this->Session->setFlash(__('Department deleted'));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Department was not deleted'));
		$this->redirect(array('action' => 'index'));
	}
	
}