<?php
class JobsController extends AppController {
	
	public function beforeFilter() {
		parent::beforeFilter();
		$this->Auth->allow('names');
	}
	
	public function index($csvFile = null) {
		$curdate = CakeTime::format('Y-m-d',date('Y-m-d H:i:s'),null,$this->timezone); // to user timezone
		$searched = false;
		$search_user_full_name = '';
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_name'])){
				$searched = true;
			}
			if(isset($args['search_user_id'])){
				$temp = $this->User->findById($args['search_user_id']);
				if ($temp){
					$search_user_full_name = $temp['User']['full_name'];
				}
			}
		}
		
		$this->set('search_user_full_name', $search_user_full_name);
		$this->set('searched',$searched);
	
		$this->Prg->commonProcess();
		//$this->Job->recursive = 1;
	
		if ($csvFile) {
			$this->paginate = array(
					'conditions' => $this->Job->parseCriteria($this->passedArgs),
					'order' => array(
							'Job.modified' => 'desc'
					)
			);
			$this->request->params['named']['page'] = null;
		}
		else {
			if($this->Auth->user('group_id') == 1) {
				$this->paginate = array(
						'conditions' => array_merge($this->Job->parseCriteria($this->passedArgs),array(
                                                    'Job.end_date >=' => $curdate
                                                )),
						'limit' => $this->option_row_other,
						'order' => array(
								'User.full_name'=>'asc'
						)
				);
			//debug($this->paginate);exit;
			} 
			else {
				//conditional users
					$directChildren = $this->User->children($this->Auth->user('id'));			
					foreach($directChildren as $directChildren){
						$b[] = $directChildren['User']['id'];
					}			
					$b[] = $this->Auth->user('id');				
					$a = $this->User->find('all',array('conditions'=>array(
														'OR'=>array('User.id'=>$b,
															  'User.parent_id'=>$this->Auth->user('id'))
														)
												)
										);
													
					foreach($a as $val){
							$child[] = $val['User']['id'];
					}
					//debug($child);		
			
			if($this->manager_see_multi_lavels == 1){
				$this->paginate = array(
							'conditions' => array_merge($this->Job->parseCriteria($this->passedArgs),array(
							
							'OR'=>array(
									
									'Job.user_id' => $child,
									'User.parent_id' => $this->Auth->user('id')
							),
							'AND'=>array(
                                                            'Job.end_date >=' => $curdate
                                                        )
							)),
							'limit' => $this->option_row_other,
							'order' => array(
									'Job.modified' => 'desc'
							)
					);			
			}
			else{
					$this->paginate = array(
							'conditions' => array_merge($this->Job->parseCriteria($this->passedArgs),array(
							
							'OR'=>array(
									'Job.user_id' => $this->Auth->user('id'),
									'User.parent_id' => $this->Auth->user('id')
							),
							'AND'=>array(
                                                            'Job.end_date >=' => $curdate
                                                        )
							)),
							'limit' => $this->option_row_other,
							'order' => array(
									'Job.modified' => 'desc'
							)
					);
				}
			}
			
		}
		$userList = $this->User->find('list');
	
		$this->set('userList',$userList);
		$this->set('jobs', $this->Paginate());
	}
	
	public function expired($csvFile = null) {
		$curdate = CakeTime::format('Y-m-d',date('Y-m-d H:i:s'),null,$this->timezone); // to user timezone
		$searched = false;
		$search_user_full_name = '';
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_name'])){
				$searched = true;
			}
			if(isset($args['search_user_id'])){
				$temp = $this->User->findById($args['search_user_id']);
				if ($temp){
					$search_user_full_name = $temp['User']['full_name'];
				}
			}
		}
		
		$this->set('search_user_full_name',$search_user_full_name);
		$this->set('searched',$searched);
	
		$this->Prg->commonProcess();
		//$this->Job->recursive = 1;
	
		if ($csvFile) {
			$this->paginate = array(
					'conditions' => $this->Job->parseCriteria($this->passedArgs),
					'order' => array(
							'Job.modified' => 'desc'
					)
			);
			$this->request->params['named']['page'] = null;
		}
		else {
			$directChildren = $this->User->children($this->Auth->user('id'));			
			foreach($directChildren as $directChildren){
				$b[] = $directChildren['User']['id'];
			}		
			$b[] = $this->Auth->user('id');			
			$a = $this->User->find('all',array('conditions'=>array(
												'OR'=>array('User.id'=>$b,
													  'User.parent_id'=>$this->Auth->user('id'))
												)
										)
								);			
			foreach($a as $val){
					$child[] = $val['User']['id'];
			}
			if($this->Auth->user('group_id') == 1) {
				$this->paginate = array(
						'conditions' => array_merge($this->Job->parseCriteria($this->passedArgs),array('Job.end_date < '=>$curdate)),
						'limit' => $this->option_row_other,
						'order' => array(
								'Job.modified' => 'desc'
						)
				);
			} else {
				if($this->manager_see_multi_lavels == 1){
					$this->paginate = array(
							'conditions' => array_merge($this->Job->parseCriteria($this->passedArgs),
									array(
										'OR'=>array(
											'Job.user_id' => $child,
											'User.parent_id' => $this->Auth->user('id')
									),
										'AND'=>array('Job.end_date < '=>$curdate))								
									),
									
							'limit' => $this->option_row_other,
							'order' => array(
									'Job.modified' => 'desc'
							)
					);
				}
				else{
					$this->paginate = array(
							'conditions' => array_merge($this->Job->parseCriteria($this->passedArgs),
									array(
										'OR'=>array(
											'Job.user_id' => $this->Auth->user('id'),
											'User.parent_id' => $this->Auth->user('id')
									),
										'AND'=>array('Job.end_date < '=>$curdate))								
									),
									
							'limit' => $this->option_row_other,
							'order' => array(
									'Job.modified' => 'desc'
							)
					);
				}
				
			}
			
		}
	
		$userList = $this->User->find('list');
		
		$this->set('userList',$userList);
		$this->set('jobs', $this->Paginate());
		$this->render('index');
	}
	public function view($id = null){
		$this->Job->id = $id;
		if(!$this->Job->exists()){
			throw new NotFoundException('Record not found');
		}
		
		$is_manager = false;
		
		$user_id = $this->Job->read(array('Job.user_id','User.parent_id'), $id);
		//ok regular user can only view there own data
		if($this->Auth->user('group_id') == 3 && (($user_id['Job']['user_id'] != $this->Auth->user('id')) && ($user_id['User']['parent_id'] != $this->Auth->user('id')))) {
			$this->Session->setFlash(__('Oops! Looks like you are not the owner of Job. Only the user corresponding to the job can view it.'),'alert',array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		} elseif ($this->Auth->user('group_id') == 3 && ($user_id['User']['parent_id'] == $this->Auth->user('id'))){
			//manager
			$is_manager = true;
		}
		
		$job = $this->Job->read();
	
		$this->set('job',$job);
		$this->set('is_manager',$is_manager);
	
	}
	
	public function add($id=null){
		if($this->Auth->user('group_id') !=1 ) {
			$this->Session->setFlash(__('Only Administrator can add new job'),'alert',array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		}
                
                if ($id != null) {
                    $this->set('preSelectedUser', $id);
                }
		
		$option_default_start_time = $this->Option->find('first',array('conditions'=>array('name'=>'default_start_time')));
		if(!empty($option_default_start_time)){
			$default_start_time = $option_default_start_time['Option']['value'];
		}
		else {
			$default_start_time = '09:00';
		}
			
		$option_default_end_time = $this->Option->find('first',array('conditions'=>array('name'=>'default_end_time')));
		if(!empty($option_default_end_time)){
			$default_end_time = $option_default_end_time['Option']['value'];
		}
		else {
			$default_end_time = '18:00';
		}
		//vacation days
		$option_default_vacation_days = $this->Option->find('first',array('conditions'=>array('name'=>'vacation_per_year')));
		if(!empty($option_default_vacation_days)){
			$default_vacation_days = $option_default_vacation_days['Option']['value'];
		}
		else {
			$default_vacation_days = '10';
		}
                
                if($this->request->is('post')){
			//$this->request->data['Job']['user_id'] = $this->Auth->user('id');
                        if (empty($this->request->data['Job']['hourly_salary'])) {
                            $this->request->data['Job']['hourly_salary'] = 0;                            
                        }
                        
                        if (empty($this->request->data['Job']['expected_hours'])) {
                            $this->request->data['Job']['expected_hours'] = 0;                            
                        }
                        
                        if (empty($this->request->data['Job']['start_date'])) {
                            $this->request->data['Job']['start_date'] = CakeTime::toServer(date('Y-m-d'), $this->userTimezone,'Y-m-d');
                        } else {
                            $this->request->data['Job']['start_date'] = CakeTime::toServer($this->request->data['Job']['start_date'],$this->userTimezone,'Y-m-d');
                        }
                        
                        if (empty($this->request->data['Job']['end_date'])) :
                            $this->request->data['Job']['end_date'] = '9999-12-31';                        
                        endif;
			
                        			
			// failsafe
			if(isset($this->request->data['Job']['start_time']) && empty($this->request->data['Job']['start_time'])){
				$this->request->data['Job']['start_time'] = $default_start_time;
			}
			//failsafe
			if(isset($this->request->data['Job']['end_time']) && empty($this->request->data['Job']['end_time'])){
				$this->request->data['Job']['end_time'] = $default_end_time;
			}
			
			$this->Job->create();
			
			$isSaved = $this->Job->save($this->request->data);
			
			if($isSaved){
				$this->Session->setFlash(__('New Job added'),'alert');
				$this->redirect(array('action'=>'index'));
			}
			else
			{
				//$this->request->data['Job']['start_date'] = CakeTime::format('Y-m-d',$this->request->data['Job']['start_date'],null,$this->timezone);
				//$this->request->data['Job']['end_date'] = CakeTime::format('Y-m-d',$this->request->data['Job']['end_date'],null,$this->timezone);
				
				$this->Session->setFlash(__('Unable to add'),'alert', array('class'=>'alert-error'));
			}
		} 
		$this->set('userList',$this->User->find('list'));
		$this->set('default_start_time',$default_start_time);
		$this->set('default_end_time',$default_end_time);
		$this->set('default_vacation_days',$default_vacation_days);
	}
	
	public function edit($id = null){
		$this->Job->id = $id;
		if(!$this->Job->exists()){
			throw new NotFoundException('Record not found');
		}
		
		$is_manager = false;
		
		$user_id = $this->Job->read(array('Job.user_id','User.parent_id'), $id);
		//ok regular user can only view there own data
		if($this->Auth->user('group_id') == 3 && (($user_id['Job']['user_id'] != $this->Auth->user('id')) && ($user_id['User']['parent_id'] != $this->Auth->user('id')))) {
			$this->Session->setFlash(__('Oops! Looks like you are not the manager of Job. Only the manager corresponding to the job can edit it.'),'alert',array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		} elseif ($this->Auth->user('group_id') == 3 && ($user_id['User']['parent_id'] == $this->Auth->user('id'))){
			//manager
			$is_manager = true;
		} 
		
		$restricted = false;
		
		//if it is regular user and this is its own data then user cannot change user field
		if($this->Auth->user('group_id') == 3 && ($user_id['Job']['user_id'] == $this->Auth->user('id'))) {
			$restricted = true; // useless because of code below 
			// user cannot edit their own job
			$this->Session->setFlash(__('Oops! regular user cannot edit their own job.'),'alert',array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		}
		
		if($this->request->is('post')){
			//$this->request->data['Job']['start_date'] = CakeTime::toServer($this->request->data['Job']['start_date'],$this->userTimezone,'Y-m-d');
			//$this->request->data['Job']['end_date'] = CakeTime::toServer($this->request->data['Job']['end_date'],$this->userTimezone,'Y-m-d');
			/*
			if (strtotime($this->request->data['Job']['end_date']) < strtotime($this->request->data['Job']['start_date'])){
				$this->request->data['Job']['end_date'] = $this->request->data['Job']['start_date'];
			}
			*/
			if($restricted) {
				// unset restricted fields here for safety
				unset($this->request->data['Job']['user_id']);//regular user cannot modify his own user_id field 
			}
			if($this->Job->save($this->request->data)){
				$this->Session->setFlash('Job data saved ','alert');
				$this->redirect(array('action'=>'index'));
			}
			else
			{
				$this->Session->setFlash(__('Unable to save changes'),'alert', array('class'=>'alert-error'));
			}
		}

		$this->set('userList',$this->User->find('list'));
		$this->request->data = $this->Job->read();
		$this->set('job',$this->Job->read());
		$this->request->data['Job']['start_time'] = CakeTime::format('H:i',$this->request->data['Job']['start_time']);
		$this->request->data['Job']['end_time'] = CakeTime::format('H:i',$this->request->data['Job']['end_time']);
		$this->set('restricted',$restricted);
		$this->set('is_manager',$is_manager);
		
	}
	
	public function delete($id = null){
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
	
		$this->Job->id = $this->request->data['id']; //--
		if(!$this->Job->exists()){
			throw new NotFoundException('Record not found');
		}
	
		$user_id = $this->Job->read(array('Job.user_id','User.parent_id'), $id);
		if($this->Auth->user('group_id') == 3 && ($user_id['Job']['user_id'] == $this->Auth->user('id'))) {
			// user cannot edit their own job so obviously cannot delete it too
			$this->Session->setFlash(__('Oops! regular user cannot delete their own job.'),'alert',array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		}
		
		if($this->Job->delete($id)){
			$this->Session->setFlash(__('Job deleted'),'alert');
			$this->redirect(array('action'=>'index'));
		}
		else
		{
			$this->Session->setFlash(__('Unable to delete'),'alert', array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		}
	}
        
        public function names() {
            $data = $this->User->find('all', array(
                'fields' => array('User.name'),
                'conditions' => array(
                    'OR' => array(
                        'User.first_name LIKE' => '%' . $this->request->data['arg'] . '%',
                        $this->User->virtualFields['full_name'] . ' LIKE' => '%' . $this->request->data['arg'] . '%'
                    )
                ),
                'order' => array('User.first_name ASC')
            ));
            
            if (empty($data)) :
                echo 'No';
                exit;
            else :
                $tmp_arr = array();
                foreach ($data as $rec) :
                    $firstLetter = strtolower(substr($rec['User']['name'], 0, 1));
                    if ($firstLetter == strtolower($this->request->data['arg'])) :
                        $tmp_arr[] = $rec['User']['name'];
                    endif;         
                endforeach;
                foreach ($data as $rec) :
                    $firstLetter = strtolower(substr($rec['User']['name'], 0, 1));
                    if ($firstLetter != strtolower($this->request->data['arg'])) :
                        $tmp_arr[] = $rec['User']['name'];
                    endif;         
                endforeach;
                $temp = '';
                $i = 0;
                for ($i = 0; $i < count($tmp_arr); $i ++) {
                    if ($temp == '') :
                        $temp = $tmp_arr[$i];
                    else :
                        $temp .= ',' . $tmp_arr[$i];
                    endif; 
                }
                echo $temp;
                exit;
            endif;
       }
}