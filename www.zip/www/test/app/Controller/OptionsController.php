<?php
class OptionsController extends AppController {
        public $uses = array('Option', 'Language');

	public function beforeFilter() {
		parent::beforeFilter();
                
		//$this->Auth->allow('sync'); 
	}
	/* not used
	public function sync(){
		$this->autoRender = false;
		App::uses('ShellDispatcher', 'Console');
		$command = '-app '.APP.' AclExtras.AclExtras aco_sync';
		$args = explode(' ', $command);
		$dispatcher = new ShellDispatcher($args, false);
		if($dispatcher->dispatch()) {
			echo 'OK';
		} else {
			echo 'Cannot run shell script';
			//debug($args);
		}
	}
	*/
	/* not used
	public function index(){
		$this->set('options',$this->Option->find('all'));
	}
	*/
	public function edit(){
            $this->User->unbindModel(array(
                'hasMany' => array('Job','Timesheet','Vacation')
            ));
            $userlist = $this->User->find('all', array('fields' => array('User.id', 'User.full_name'),'order' => 'User.id DESC'));
            $userlist = $this->Option->userlist($userlist);  
            $this->set('userlist', $userlist);
		if($this->request->is('post')){ //debug($this->request->data); exit;
                    //debug($this->request->data['Language']); exit;
                    //if (COUNT($this->request->data['Language'])) :
                        $tmps = $this->request->data['Language'];
                        $c = COUNT($tmps['name']);
                        $i = 0;
                        while ($i < $c) {
                            $this->loadModel('Language');
                            $lang_find = $this->Language->find('all', array(
                                'conditions' => array(
                                    'Language.language' => $tmps['name'][$i]
                                )
                            ));
                            
                            if(!empty($lang_find)) {
                                $this->Language->id = $lang_find[0]['Language']['id'];
                                $this->Language->saveField('display',$tmps['display'][$i]);
                            } else {
                                if ($tmps['display'][$i] != '') :
                                    $this->Language->create();
                                    $data = array('language' => $tmps['name'][$i], 'display' => $tmps['display'][$i]);
                                    $this->Language->save($data);
                                endif;
                            }
                            $i ++;
                        }
                        
                        
                        $option_title = $this->Option->findByName('default_language');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['default_language']);
					
			}
			else {
				$option_data['Option']['name'] = 'default_language';
				$option_data['Option']['value'] = $this->request->data['Option']['default_language'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
                        
                        
                        
                        
                    //else :
                        //debug($this->request->data['Option']);exit;
			$extra_msg = '';
			$option_title = $this->Option->findByName('title');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['title']);
                        }
			else {
				$option_data['Option']['name'] = 'title';
				$option_data['Option']['value'] = $this->request->data['Option']['title'];
				//$option_data['Option']['logo'] = $this->request->data['Option']['logo'];
				//$option_data['Option']['logo_dir'] = $this->request->data['Option']['logo_dir'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('row_other');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['row_other']);
					
			}
			else {
				$option_data['Option']['name'] = 'row_other';
				$option_data['Option']['value'] = $this->request->data['Option']['row_other'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email']);
			
			}
			else {
				$option_data['Option']['name'] = 'email';
				$option_data['Option']['value'] = $this->request->data['Option']['email'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_title');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_title']);
					
			}
			else {
				$option_data['Option']['name'] = 'email_title';
				$option_data['Option']['value'] = $this->request->data['Option']['email_title'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_host');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_host']);
			}
			else {
				$option_data['Option']['name'] = 'email_host';
				$option_data['Option']['value'] = $this->request->data['Option']['email_host'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_port');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_port']);
					
			}
			else {
				$option_data['Option']['name'] = 'email_port';
				$option_data['Option']['value'] = $this->request->data['Option']['email_port'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_user');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_user']);
					
			}
			else {
				$option_data['Option']['name'] = 'email_user';
				$option_data['Option']['value'] = $this->request->data['Option']['email_user'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_password');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_password']);
					
			}
			else {
				$option_data['Option']['name'] = 'email_password';
				$option_data['Option']['value'] = $this->request->data['Option']['email_password'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('currency');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['currency']);
					
			}
			else {
				$option_data['Option']['name'] = 'currency';
				$option_data['Option']['value'] = $this->request->data['Option']['currency'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('date_format');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['date_format']);
					
			}
			else {
				$option_data['Option']['name'] = 'date_format';
				$option_data['Option']['value'] = $this->request->data['Option']['date_format'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('datetime_format');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['datetime_format']);
					
			}
			else {
				$option_data['Option']['name'] = 'datetime_format';
				$option_data['Option']['value'] = $this->request->data['Option']['datetime_format'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('vacation_email');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['vacation_email']);
					
			}
			else {
				$option_data['Option']['name'] = 'vacation_email';
				$option_data['Option']['value'] = $this->request->data['Option']['vacation_email'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('vacation_per_year');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['vacation_per_year']);
					
			}
			else {
				$option_data['Option']['name'] = 'vacation_per_year';
				$option_data['Option']['value'] = $this->request->data['Option']['vacation_per_year'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('notify_after_days');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['notify_after_days']);
			}
			else {
				$option_data['Option']['name'] = 'notify_after_days';
				$option_data['Option']['value'] = $this->request->data['Option']['notify_after_days'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('webservice_api_key');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['webservice_api_key']);
			}
			else {
				$option_data['Option']['name'] = 'webservice_api_key';
				$option_data['Option']['value'] = $this->request->data['Option']['webservice_api_key'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('twilio_api_key');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['twilio_api_key']);
			}
			else {
				$option_data['Option']['name'] = 'twilio_api_key';
				$option_data['Option']['value'] = $this->request->data['Option']['twilio_api_key'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('twilio_sid');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['twilio_sid']);
			}
			else {
				$option_data['Option']['name'] = 'twilio_sid';
				$option_data['Option']['value'] = $this->request->data['Option']['twilio_sid'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('sender_phone_number');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['sender_phone_number']);
			}
			else {
				$option_data['Option']['name'] = 'sender_phone_number';
				$option_data['Option']['value'] = $this->request->data['Option']['sender_phone_number'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('can_request_vacation_above_limit');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['can_request_vacation_above_limit']);
					
			}
			else {
				$option_data['Option']['name'] = 'can_request_vacation_above_limit';
				$option_data['Option']['value'] = $this->request->data['Option']['can_request_vacation_above_limit'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			//manager see multi label
			$option_title = $this->Option->findByName('manager_see_multi_lavels');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['manager_see_multi_lavels']);
					
			}
			else {
				$option_data['Option']['name'] = 'manager_see_multi_lavels';
				$option_data['Option']['value'] = $this->request->data['Option']['manager_see_multi_lavels'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			//end
			
			$option_title = $this->Option->findByName('auto_approve_timesheet');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['auto_approve_timesheet']);
					
			}
			else {
				$option_data['Option']['name'] = 'auto_approve_timesheet';
				$option_data['Option']['value'] = $this->request->data['Option']['auto_approve_timesheet'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('auto_approve_vacation');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['auto_approve_vacation']);
					
			}
			else {
				$option_data['Option']['name'] = 'auto_approve_vacation';
				$option_data['Option']['value'] = $this->request->data['Option']['auto_approve_vacation'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_template_vacation');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_template_vacation']);
					
			}
			else {
				$option_data['Option']['name'] = 'email_template_vacation';
				$option_data['Option']['value'] = $this->request->data['Option']['email_template_vacation'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_template_notify');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_template_notify']);
					
			}
			else {
				$option_data['Option']['name'] = 'email_template_notify';
				$option_data['Option']['value'] = $this->request->data['Option']['email_template_notify'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_template_newuser');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_template_newuser']);
					
			}
			else {
				$option_data['Option']['name'] = 'email_template_newuser';
				$option_data['Option']['value'] = $this->request->data['Option']['email_template_newuser'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_template_reset');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_template_reset']);
					
			}
			else {
				$option_data['Option']['name'] = 'email_template_reset';
				$option_data['Option']['value'] = $this->request->data['Option']['email_template_reset'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('email_template_newpassword');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['email_template_newpassword']);
					
			}
			else {
				$option_data['Option']['name'] = 'email_template_newpassword';
				$option_data['Option']['value'] = $this->request->data['Option']['email_template_newpassword'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('user_add_timesheet_calendar');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['user_add_timesheet_calendar']);
					
			}
			else {
				$option_data['Option']['name'] = 'user_add_timesheet_calendar';
				$option_data['Option']['value'] = $this->request->data['Option']['user_add_timesheet_calendar'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('edit_timesheet');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['edit_timesheet']);
					
			}
			else {
				$option_data['Option']['name'] = 'edit_timesheet';
				$option_data['Option']['value'] = $this->request->data['Option']['edit_timesheet'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('manager_vacation_notification');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['manager_vacation_notification']);
					
			}
			else {
				$option_data['Option']['name'] = 'manager_vacation_notification';
				$option_data['Option']['value'] = $this->request->data['Option']['manager_vacation_notification'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('alert_using_sms');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['alert_using_sms']);
					
			}
			else {
				$option_data['Option']['name'] = 'alert_using_sms';
				$option_data['Option']['value'] = $this->request->data['Option']['alert_using_sms'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
                        
                        /* -------------------------- MODIFIED ON 27-10-2014 ----------------------------- */
                        $option_title = $this->Option->findByName('ip_restriction_status');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['ip_restriction_status']);
					
			}
			else {
				$option_data['Option']['name'] = 'ip_restriction_status';
				$option_data['Option']['value'] = $this->request->data['Option']['ip_restriction_status'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
                        
                        $option_title = $this->Option->findByName('allowed_ip_addresses');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['allowed_ip_addresses']);
					
			}
			else {
				$option_data['Option']['name'] = 'allowed_ip_addresses';
				$option_data['Option']['value'] = $this->request->data['Option']['allowed_ip_addresses'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
                        
                        
                        $option_title = $this->Option->findByName('access_outside');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
                                if(is_array($this->request->data['Option']['access_outside']))
                                    $access_outside = implode(',',$this->request->data['Option']['access_outside']);
				$this->Option->saveField('value',$access_outside);
					
			}
			else {
                                if(is_array($this->request->data['Option']['access_outside']))
                                    $access_outside = implode(',',$this->request->data['Option']['access_outside']);
                                
				$option_data['Option']['name'] = 'access_outside';
				$option_data['Option']['value'] = $access_outside;
				$this->Option->create();
				$this->Option->save($option_data);
			}
                        
                        /*------------------------------- 0-0-0-0 -----------------------------*/
			
			$option_title = $this->Option->findByName('admin_vacation_notification');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['admin_vacation_notification']);
					
			}
			else {
				$option_data['Option']['name'] = 'admin_vacation_notification';
				$option_data['Option']['value'] = $this->request->data['Option']['admin_vacation_notification'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('manager_edit_staff_timesheet');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['manager_edit_staff_timesheet']);
					
			}
			else {
				$option_data['Option']['name'] = 'manager_edit_staff_timesheet';
				$option_data['Option']['value'] = $this->request->data['Option']['manager_edit_staff_timesheet'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('timer_notification');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['timer_notification']);
					
			}
			else {
				$option_data['Option']['name'] = 'timer_notification';
				$option_data['Option']['value'] = $this->request->data['Option']['timer_notification'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('timer_endtime');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['timer_endtime']);
					
			}
			else {
				$option_data['Option']['name'] = 'timer_endtime';
				$option_data['Option']['value'] = $this->request->data['Option']['timer_endtime'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('default_start_time');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['default_start_time']);
					
			}
			else {
				$option_data['Option']['name'] = 'default_start_time';
				$option_data['Option']['value'] = $this->request->data['Option']['default_start_time'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('default_end_time');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['default_end_time']);
					
			}
			else {
				$option_data['Option']['name'] = 'default_end_time';
				$option_data['Option']['value'] = $this->request->data['Option']['default_end_time'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('default_homepage');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['default_homepage']);
			}
			else {
				$option_data['Option']['name'] = 'default_homepage';
				$option_data['Option']['value'] = $this->request->data['Option']['default_homepage'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('default_work_description');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['default_work_description']);
			}
			else {
				$option_data['Option']['name'] = 'default_work_description';
				$option_data['Option']['value'] = $this->request->data['Option']['default_work_description'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
                        
                        $option_title = $this->Option->findByName('auto_clock_out_hours');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['auto_clock_out_hours']);
			}
			else {
				$option_data['Option']['name'] = 'auto_clock_out_hours';
				$option_data['Option']['value'] = $this->request->data['Option']['auto_clock_out_hours'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
                        
                        $option_title = $this->Option->findByName('hours_before_auto_clock_out');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['hours_before_auto_clock_out']);
			}
			else {
				$option_data['Option']['name'] = 'hours_before_auto_clock_out';
				$option_data['Option']['value'] = $this->request->data['Option']['hours_before_auto_clock_out'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('server_timezone');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['server_timezone']);
					
			}
			else {
				$option_data['Option']['name'] = 'server_timezone';
				$option_data['Option']['value'] = $this->request->data['Option']['server_timezone'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			
			$option_title = $this->Option->findByName('user_timezone');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['user_timezone']);
					
			}
			else {
				$option_data['Option']['name'] = 'user_timezone';
				$option_data['Option']['value'] = $this->request->data['Option']['user_timezone'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			$option_title = $this->Option->findByName('show_copyright');
			if(!empty($option_title)){
				$this->Option->id = $option_title['Option']['id'];
				$this->Option->saveField('value',$this->request->data['Option']['show_copyright']);
					
			}
			else {
				$option_data['Option']['name'] = 'show_copyright';
				$option_data['Option']['value'] = $this->request->data['Option']['show_copyright'];
				$this->Option->create();
				$this->Option->save($option_data);
			}
			
			// logo saving routine has to be in last
			$option_data['Option']['name'] = 'copyright';
                        $option_data['Option']['value'] = $this->request->data['Option']['copyright'];
                        if ($this->request->data['Option']['logo']['name'] != '') {
                            $option_data['Option']['logo'] = $this->request->data['Option']['logo'];
                            $option_data['Option']['logo_dir'] = $this->request->data['Option']['logo_dir'];
                        }
			$option_copyright = $this->Option->findByName('copyright');
			if(!empty($option_copyright)){
                            $this->Option->id = $option_copyright['Option']['id'];                            
                            $this->Option->save($option_data);
                        } else {
                            $this->Option->create();
                            $this->Option->save($option_data);
			}			
		
			$this->Session->setFlash(__('Settings saved. '),'alert',array('class'=>'alart-success'));
			$this->redirect(array('controller'=>'options','action'=>'edit')); //immiediate effect workarround
                      //  endif;
                        
		}// end of if request
		
		$option_title = $this->Option->find('first',array('conditions'=>array('name'=>'title')));
		if(!empty($option_title)){
			$this->request->data['Option']['title'] = $option_title['Option']['value'];
		}
		else {
			$this->request->data['Option']['title'] = '';
		}
		
		$option_row_other = $this->Option->find('first',array('conditions'=>array('name'=>'row_other')));
		if(!empty($option_row_other)){
			$this->request->data['Option']['row_other'] = $option_row_other['Option']['value'];
		}
		else {
			$this->request->data['Option']['row_other'] = 30;
		}
		
		$option_email = $this->Option->find('first',array('conditions'=>array('name'=>'email')));
		if(!empty($option_email)){
			$this->request->data['Option']['email'] = $option_email['Option']['value'];
		}
		else {
			$this->request->data['Option']['email'] = 'admin@zhen-hrm.com';
		}
		
		$option_email_title = $this->Option->find('first',array('conditions'=>array('name'=>'email_title')));
		if(!empty($option_email_title)){
			$this->request->data['Option']['email_title'] = $option_email_title['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_title'] = 'Distribution';
		}
		
		$option_email_host = $this->Option->find('first',array('conditions'=>array('name'=>'email_host')));
		if(!empty($option_email_host)){
			$this->request->data['Option']['email_host'] = $option_email_host['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_host'] = '';
		}
		
		$option_email_port = $this->Option->find('first',array('conditions'=>array('name'=>'email_port')));
		if(!empty($option_email_port)){
			$this->request->data['Option']['email_port'] = $option_email_port['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_port'] = '';
		}
		
		$option_email_user = $this->Option->find('first',array('conditions'=>array('name'=>'email_port')));
		if(!empty($option_email_port)){
			$this->request->data['Option']['email_user'] = $option_email_port['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_user'] = '';
		}
		
		$option_email_password = $this->Option->find('first',array('conditions'=>array('name'=>'email_password')));
		if(!empty($option_email_password)){
			$this->request->data['Option']['email_password'] = $option_email_password['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_password'] = '';
		}
		
		$option_email_template_newuser = $this->Option->find('first',array('conditions'=>array('name'=>'email_template_newuser')));
		if(!empty($option_email_template_newuser)){
			$this->request->data['Option']['email_template_newuser'] = $option_email_template_newuser['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_template_newuser'] = '<p>Following are the credential</p><p>Username: {{username}}</p><p>Password: {{password}}</p><p>Don\'\'t forget to change it for security reasons.</p><p>&nbsp;</p>';
		}
		
		$option_email_template_reset = $this->Option->find('first',array('conditions'=>array('name'=>'email_template_reset')));
		if(!empty($option_email_template_reset)){
			$this->request->data['Option']['email_template_reset'] = $option_email_template_reset['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_template_reset'] = '<p>Please click on the link below to reset your password.</p><p>{{resetlink}}</p><p>In case the above link dosen\'\'t work, you can also copy the URL in the browser address bar.</p><p>&nbsp;</p>';
		}
		
		$option_email_template_newpassword = $this->Option->find('first',array('conditions'=>array('name'=>'email_template_newpassword')));
		if(!empty($option_email_template_newpassword)){
			$this->request->data['Option']['email_template_newpassword'] = $option_email_template_newpassword['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_template_newpassword'] = '<p>Following are the new credential</p><p>Username: {{username}}</p><p>Password: {{password}}</p><p>Don\'\'t forget to change it for security reasons.</p><p>&nbsp;</p>';
		}
		
		$option_email_template_vacation = $this->Option->find('first',array('conditions'=>array('name'=>'email_template_vacation')));
		if(!empty($option_email_template_vacation)){
			$this->request->data['Option']['email_template_vacation'] = $option_email_template_vacation['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_template_vacation'] = '<p>Vacation notification for {{fullname}}.</p><p>Vacation Dates:</p><p>{{vacationlist}}</p><p>&nbsp;</p>';
		}
		
		$option_email_template_notify = $this->Option->find('first',array('conditions'=>array('name'=>'email_template_notify')));
		if(!empty($option_email_template_notify)){
			$this->request->data['Option']['email_template_notify'] = $option_email_template_notify['Option']['value'];
		}
		else {
			$this->request->data['Option']['email_template_notify'] = '<p>You have not filled out timesheet for {{sincedays}} days.</p><p>&nbsp;</p>';
		}
		
		$option_currency = $this->Option->find('first',array('conditions'=>array('name'=>'currency')));
		if(!empty($option_currency)){
			$this->request->data['Option']['currency'] = $option_currency['Option']['value'];
		}
		else {
			$this->request->data['Option']['currency'] = '$';
		}
		
		$option_date_format = $this->Option->find('first',array('conditions'=>array('name'=>'date_format')));
		if(!empty($option_date_format)){
			$this->request->data['Option']['date_format'] = $option_date_format['Option']['value'];
		}
		else {
			$this->request->data['Option']['date_format'] = 'M j, Y';
		}
		
		$option_datetime_format = $this->Option->find('first',array('conditions'=>array('name'=>'datetime_format')));
		if(!empty($option_datetime_format)){
			$this->request->data['Option']['datetime_format'] = $option_datetime_format['Option']['value'];
		}
		else {
			$this->request->data['Option']['datetime_format'] = 'M j, Y g:i A';
		}
		
		$option_vacation_email = $this->Option->find('first',array('conditions'=>array('name'=>'vacation_email')));
		if(!empty($option_vacation_email)){
			$this->request->data['Option']['vacation_email'] = $option_vacation_email['Option']['value'];
		}
		else {
			$this->request->data['Option']['vacation_email'] = 'admin@zhen-hrm.com';
		}
		
		$option_vacation_per_year = $this->Option->find('first',array('conditions'=>array('name'=>'vacation_per_year')));
		if(!empty($option_vacation_per_year)){
			$this->request->data['Option']['vacation_per_year'] = $option_vacation_per_year['Option']['value'];
		}
		else {
			$this->request->data['Option']['vacation_per_year'] = '10';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'notify_after_days')));
		if(!empty($option_setting)){
			$this->request->data['Option']['notify_after_days'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['notify_after_days'] = '7';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'webservice_api_key')));
		if(!empty($option_setting)){
			$this->request->data['Option']['webservice_api_key'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['webservice_api_key'] = 'skjdjlko932n9n932n9nwedwekldssio093n9ewn3n';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'twilio_api_key')));
		if(!empty($option_setting)){
			$this->request->data['Option']['twilio_api_key'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['twilio_api_key'] = '6ec001d68e7f2f3862e6dc732fb10d3e';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'twilio_sid')));
		if(!empty($option_setting)){
			$this->request->data['Option']['twilio_sid'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['twilio_sid'] = 'ACa1d745f86e9450292f76f61276bd0021';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'sender_phone_number')));
		if(!empty($option_setting)){
			$this->request->data['Option']['sender_phone_number'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['sender_phone_number'] = '+919292929992';
		}

		//manager_see_multi_lavels

		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'manager_see_multi_lavels')));
		if(!empty($option_setting)){
			$this->request->data['Option']['manager_see_multi_lavels'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['manager_see_multi_lavels'] = 'false';
		}
		
		//end
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'user_add_timesheet_calendar')));
		if(!empty($option_setting)){
			$this->request->data['Option']['user_add_timesheet_calendar'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['user_add_timesheet_calendar'] = 'true';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'edit_timesheet')));
		if(!empty($option_setting)){
			$this->request->data['Option']['edit_timesheet'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['edit_timesheet'] = 'true';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'manager_edit_staff_timesheet')));
		if(!empty($option_setting)){
			$this->request->data['Option']['manager_edit_staff_timesheet'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['manager_edit_staff_timesheet'] = 1;
		}
                		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'timer_notification')));
		if(!empty($option_setting)){
			$this->request->data['Option']['timer_notification'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['timer_notification'] = false;
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'can_request_vacation_above_limit')));
		if(!empty($option_setting)){
			$this->request->data['Option']['can_request_vacation_above_limit'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['can_request_vacation_above_limit'] = 'true';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'auto_approve_timesheet')));
		if(!empty($option_setting)){
			$this->request->data['Option']['auto_approve_timesheet'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['auto_approve_timesheet'] = false;
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'auto_approve_vacation')));
		if(!empty($option_setting)){
			$this->request->data['Option']['auto_approve_vacation'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['auto_approve_vacation'] = false;
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'manager_vacation_notification')));
		if(!empty($option_setting)){
			$this->request->data['Option']['manager_vacation_notification'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['manager_vacation_notification'] = 'true';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'alert_using_sms')));
		if(!empty($option_setting)){
			$this->request->data['Option']['alert_using_sms'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['alert_using_sms'] = 'true';
		}
                
                /*---------------------------- MODIFIED ON 27-10-2014 -------------------------------------*/
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'ip_restriction_status')));
		if(!empty($option_setting)){
			$this->request->data['Option']['ip_restriction_status'] = $option_setting['Option']['value'];  
		}
		else {
			$this->request->data['Option']['ip_restriction_status'] = false;
		}
              
                $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'allowed_ip_addresses')));
		if(!empty($option_setting)){
			$this->request->data['Option']['allowed_ip_addresses'] = $option_setting['Option']['value'];  
		}
		else {
			$this->request->data['Option']['allowed_ip_addresses'] = false;
		}
                
                
                $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'access_outside')));
		if(!empty($option_setting)){
			$this->request->data['Option']['access_outside'] = explode(',',$option_setting['Option']['value']);
		}
		else {
			$this->request->data['Option']['access_outside'] = false;
		}
                
                /*------------------------------------- 0-0-0-0 -------------------------------------------*/
                
                $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'admin_vacation_notification')));
		if(!empty($option_setting)){
			$this->request->data['Option']['admin_vacation_notification'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['admin_vacation_notification'] = 'true';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'timer_endtime')));
		if(!empty($option_setting)){
			$this->request->data['Option']['timer_endtime'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['timer_endtime'] = false;
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'default_start_time')));
		if(!empty($option_setting)){
			$this->request->data['Option']['default_start_time'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['default_start_time'] = '09:00';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'default_end_time')));
		if(!empty($option_setting)){
			$this->request->data['Option']['default_end_time'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['default_end_time'] = '18:00';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'default_homepage')));
		if(!empty($option_setting)){
			$this->request->data['Option']['default_homepage'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['default_homepage'] = '0'; //timer
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'default_work_description')));
		if(!empty($option_setting)){
			$this->request->data['Option']['default_work_description'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['default_work_description'] = 'Working'; 
		}
                
                $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'auto_clock_out_hours')));
		if(!empty($option_setting)){
			$this->request->data['Option']['auto_clock_out_hours'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['auto_clock_out_hours'] = '8'; 
		}
                
                $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'hours_before_auto_clock_out')));
		if(!empty($option_setting)){
			$this->request->data['Option']['hours_before_auto_clock_out'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['hours_before_auto_clock_out'] = '18'; 
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'server_timezone')));
		if(!empty($option_setting)){
			$this->request->data['Option']['server_timezone'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['server_timezone'] = 'UTC';
		}
		
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'user_timezone')));
		if(!empty($option_setting)){
			$this->request->data['Option']['user_timezone'] = $option_setting['Option']['value'];
		}
		else {
			$this->request->data['Option']['user_timezone'] = 'UTC';
		}
                
                $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'default_language')));
                if(!empty($option_setting)){
                        $this->request->data['Option']['default_language'] = $option_setting['Option']['value'];
                }
                else {
                        $this->request->data['Option']['default_language'] = 'eng';
                }
		
		$option_show_copyright = $this->Option->find('first',array('conditions'=>array('name'=>'show_copyright')));
		if(!empty($option_show_copyright)){
			$this->request->data['Option']['show_copyright'] = $option_show_copyright['Option']['value'];
		}
		else {
			$this->request->data['Option']['show_copyright'] = 'true';
		}
		
		$option_copyright = $this->Option->find('first',array('conditions'=>array('name'=>'copyright')));
		if(!empty($option_copyright)){
			$this->request->data['Option']['copyright'] = $option_copyright['Option']['value'];
		}
		else {
			$this->request->data['Option']['copyright'] = '';
		}
		
                
                
                
                $this->set('readonly', $readonly);
		$this->set('listTimezone',$this->Option->timezone_list());
                
                //for Language tab
                $lang_tmp = scandir(APP.'/Locale');
                $lang = array();
                $i = 0;
                foreach($lang_tmp as $each) :
                    if ($i > 1) :
                        $lang[] = $each;
                    endif;
                    $i ++;
                endforeach;
                //debug($lang);
                $this->set('languages', $lang);
                $this->loadModel('Language');
                $data = $this->Language->find('all', array(
                    //'fields' => array('Language.display'),
                    'conditions' => array(
                        'Language.language' => $lang
                    ),
					'order'=>array('Language.language'=> 'ASC')
                ));
                //debug($data); exit;
                $this->set('languagedata', $data);
                
                for($i=0; $i<COUNT($data); $i++):
                    $languagelist[$data[$i]['Language']['language']] = $data[$i]['Language']['language'];
					
                endfor;
                
                //debug($languagelist);
                 
                $this->set('languagelist', $languagelist);
	}
}
