<?php
App::import('Vendor', 'Twilio',array('file'=>'Services'.DS.'Twilio.php'));
App::uses('CakeEmail', 'Network/Email');
class TimesheetsController extends AppController {	
	public $uses = array('Timesheet','ApprovalStatus','Job');	
	public $components = array('RequestHandler');        
        //public $helpers = array('Cache');
	
	var $from_email;
	var $from_email_title;
	var $smtp_host;
	var $smtp_port;
	var $smtp_user;
	var $smtp_password;
	var $use_smtp;
        
	
	public function beforeFilter(){
		parent::beforeFilter();                
                
                $this->Auth->allow('stop_spinner','getTotalHours', 'calendarFeedNotEndedEvent', 'calendarFeed','checktimesheet','reportsAggregate','getManagerUsers','reportsUsers','reportsUsersCsv2','reportsLast','dashboard', 'announcementpopup','ajax_notify_user', 'checkLogin');
		
		$option_email = $this->Option->find('first',array('conditions'=>array('name'=>'email')));
		if(!empty($option_email)){
			$this->from_email = $option_email['Option']['value'];
		}
		else {/*
			$euser = $this->User->find('first',array('conditions'=>array('active'=>1)));
			if(isset($euser[0]['User']['email'])){
			$this->from_email = $euser[0]['User']['email'];
			} else {
			$this->from_email = '';
			}
			*/
			$first_admin = $this->first_active_admin();
			if($first_admin){
				$this->from_email = $first_admin['User']['email'];
				$this->from_email_title = $first_admin['User']['name'];
			} else {
				$this->from_email_title = $this->appTitle;
			}
		}
		
		$option_email_title = $this->Option->find('first',array('conditions'=>array('name'=>'email_title')));
		if(!empty($option_email)){
			$this->from_email_title = $option_email_title['Option']['value'];
		}
		else {
			$this->from_email_title = $this->appTitle;
		}
		
		$option_smtp_host = $this->Option->find('first',array('conditions'=>array('name'=>'email_host')));
		if(!empty($option_smtp_host)){
			$this->smtp_host = $option_smtp_host['Option']['value'];
		}
		else {
			$this->smtp_host = '';
		}
		
		$option_smtp_port = $this->Option->find('first',array('conditions'=>array('name'=>'email_port')));
		if(!empty($option_smtp_port)){
			$this->smtp_port = $option_smtp_port['Option']['value'];
		}
		else {
			$this->smtp_port = '';
		}
		
		$option_smtp_user = $this->Option->find('first',array('conditions'=>array('name'=>'email_user')));
		if(!empty($option_smtp_user)){
			$this->smtp_user = $option_smtp_user['Option']['value'];
		}
		else {
			$this->smtp_user = '';
		}
		
		$option_smtp_password = $this->Option->find('first',array('conditions'=>array('name'=>'email_password')));
		if(!empty($option_smtp_password)){
			$this->smtp_password = $option_smtp_password['Option']['value'];
		}
		else {
			$this->smtp_password = '';
		}
		
		if(!empty($this->smtp_host) && !empty($this->smtp_port) && !empty($this->smtp_user) && !empty($this->smtp_password)) {
			$this->use_smtp = true;
		} else {
			$this->use_smtp = false;
		}
	}
	
	public function index($csvFile = null) {
                $searched = false;
		$search_user_full_name = '';
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_name'])){
				$searched = true;
			}
			if(isset($args['search_user_id'])){
				$temp = $this->User->findById($args['search_user_id']);
				if ($temp){
					$search_user_full_name = $temp['User']['full_name'];
				}
				
			}
		}
		
		$this->set('search_user_full_name',$search_user_full_name);
	
		$this->set('searched',$searched);
	
		$this->Prg->commonProcess();
		//$this->Timesheet->recursive = 1;
	
		if ($csvFile) {
			$this->paginate = array(
					'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),array('ApprovalStatus.name'=>'Submitted')),
					'order' => array(
							'Timesheet.modified' => 'desc'
					)
			);
			$this->request->params['named']['page'] = null;
		}
		else {
			if($this->Auth->user('group_id') == 1) {
				$this->paginate = array(
						'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
								array('ApprovalStatus.name'=>'Submitted')
								),
						'limit' => $this->option_row_other,
						'order' => array(
								'Timesheet.modified' => 'desc'
						)
				);
			} 
			else {
			
					///all children
					$directChildren = $this->User->children($this->Auth->user('id'));
					foreach($directChildren as $directChildren){
						$b[] = $directChildren['User']['id'];
					}
					$b[] = $this->Auth->user('id');
					$a = $this->User->find('all',array('conditions'=>array(
														'OR'=>array('User.id'=>$b,
															  'User.parent_id'=>$this->Auth->user('id'))
														)
												)
										);			
					foreach($a as $val){
							$child[] = $val['User']['id'];
					}
					if($this->manager_see_multi_lavels == 1){
						$this->paginate = array(
								'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
										array(array('ApprovalStatus.name'=>'Submitted'),
												'AND' => array(
														'OR'=>array(
																'Timesheet.user_id'=>$child,
																'User.parent_id'=>$this->Auth->user('id')
												))
										)),
								'limit' => $this->option_row_other,
								'order' => array(
										'Timesheet.modified' => 'desc'
								)
						);
					}
					else{
							$this->paginate = array(
									'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
											array(array('ApprovalStatus.name'=>'Submitted'),
													'AND' => array(
															'OR'=>array(
																	'Timesheet.user_id'=>$this->Auth->user('id'),
																	'User.parent_id'=>$this->Auth->user('id')
													))
											)),
									'limit' => $this->option_row_other,
									'order' => array(
											'Timesheet.modified' => 'desc'
									)
							);
						}
				}
			
			}
			
			$userList = $this->User->find('list');
			
			$this->set('userList',$userList);
			
			$statusList = $this->ApprovalStatus->find('list');
			$this->set('statusList',$statusList);
			$this->set('timesheets', $this->Paginate());
	}
	
	public function all() { 
                $calView = null;
		$searched = false;
		$calendarView = false;
		$search_user_full_name = '';
                
                $userId = $this->Auth->user('id');
                $userDetails = $this->User->find('all', array('conditions'=>array('User.id'=>$userId)));                
                $userTimezone = $userDetails[0]['User']['user_timezone'];
                $this->set('userTimezone', $userTimezone);
                
                
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_name'])){
				$searched = true;
			}
			if(isset($args['search_user_id'])){
				$temp = $this->User->findById($args['search_user_id']);
				if ($temp){
					$search_user_full_name = $temp['User']['full_name'];
				}
				//$calendarView = true;
				
			}
			if(isset($args['view']) || isset($args['search_status_id'])){
				$calendarView = false;
				$calView = false; //force table view
			}
		}
	
		$this->set('search_user_full_name',$search_user_full_name);
	
		$this->set('searched',$searched);
	
		$this->Prg->commonProcess();
		
		$findParam = array();
			if($this->Auth->user('group_id') == 1) {
				$this->paginate = array(
						'conditions' => $this->Timesheet->parseCriteria($this->passedArgs),
						'limit' => $this->option_row_other,
						'order' => array(
								'Timesheet.modified' => 'desc'
						)
				);
				$calendarTimesheets = $this->Timesheet->find('all',array(
						'conditions' => $this->Timesheet->parseCriteria($this->passedArgs)
				));
				
				$findParam = array(
						'conditions' => $this->Timesheet->parseCriteria($this->passedArgs),
						'order' => array(
								'Timesheet.modified' => 'desc'
						));
			} else {
				
				/////////conditional user
				$directChildren = $this->User->children($this->Auth->user('id'));
				foreach($directChildren as $directChildren){
					$b[] = $directChildren['User']['id'];
				}
				$b[] = $this->Auth->user('id');
				$a = $this->User->find('all',array('conditions'=>array(
													'OR'=>array('User.id'=>$b,
														  'User.parent_id'=>$this->Auth->user('id'))
													)
											)
									);			
				foreach($a as $val){
						$child[] = $val['User']['id'];
				}
			
			
				if($this->manager_see_multi_lavels == 1){
						$this->paginate = array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(
											'AND' => array(
													'OR'=>array(
															'Timesheet.user_id'=>$child,
															'User.parent_id'=>$this->Auth->user('id')
													))
									)),
							'limit' => $this->option_row_other,
							'order' => array(
									'Timesheet.modified' => 'desc'
							)
					);
					
					$calendarTimesheets = $this->Timesheet->find('all',array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(
											'AND' => array(
													'OR'=>array(
															'Timesheet.user_id'=>$child,
															'User.parent_id'=>$this->Auth->user('id')
													))
									))
							
					));
					$findParam = array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(
											'AND' => array(
													'OR'=>array(
															'Timesheet.user_id'=>$child,
															'User.parent_id'=>$this->Auth->user('id')
													))
									)),
							'order' => array(
									'Timesheet.modified' => 'desc'
							)
					);
				}
				else{
					$this->paginate = array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(
											'AND' => array(
													'OR'=>array(
															'Timesheet.user_id'=>$this->Auth->user('id'),
															'User.parent_id'=>$this->Auth->user('id')
													))
									)),
							'limit' => $this->option_row_other,
							'order' => array(
									'Timesheet.modified' => 'desc'
							)
					);
					
					$calendarTimesheets = $this->Timesheet->find('all',array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(
											'AND' => array(
													'OR'=>array(
															'Timesheet.user_id'=>$this->Auth->user('id'),
															'User.parent_id'=>$this->Auth->user('id')
													))
									))
							
					));
					$findParam = array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(
											'AND' => array(
													'OR'=>array(
															'Timesheet.user_id'=>$this->Auth->user('id'),
															'User.parent_id'=>$this->Auth->user('id')
													))
									)),
							'order' => array(
									'Timesheet.modified' => 'desc'
							)
					);
				}
			}
		/*		
		}
		*/
		$calendarData = array();
		foreach($calendarTimesheets as $calendarTimesheet) {
			if ($this->Auth->user('group_id')==1 || $calendarTimesheet['User']['parent_id'] == $this->Auth->user('id')){
				$statusUpdate = '<div class="status-icons">';
				//submitted
				$statusUpdate .= '<a href="javascript:changeToSubmitted('.$calendarTimesheet['Timesheet']['id'].')" class="change-status submitted ';
				if($calendarTimesheet['ApprovalStatus']['id']=='1'){
					$statusUpdate .= 'status-active ';
				}
				$statusUpdate .= ' row-submitted-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= ' row-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '"  title="Submitted" alt="Submitted" timesheetid="';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '" statusid="1" ><i class="icon-question"></i></a>';
				
				//approved
				$statusUpdate .= '<a href="javascript:changeToApproved('.$calendarTimesheet['Timesheet']['id'].')" class="change-status approved ';
				if($calendarTimesheet['ApprovalStatus']['id']=='2'){
					$statusUpdate .= 'status-active ';
				}
				$statusUpdate .= ' row-approved-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= ' row-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '"  title="Submitted" alt="Rejected" timesheetid="';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '" statusid="2" ><i class="icon-ok"></i></a>';
				
				//rejected
				$statusUpdate .= '<a href="javascript:changeToRejected('.$calendarTimesheet['Timesheet']['id'].')" class="change-status rejected ';
				if($calendarTimesheet['ApprovalStatus']['id']=='3'){
					$statusUpdate .= 'status-active ';
				}
				$statusUpdate .= ' row-rejected-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= ' row-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '"  title="Submitted" alt="Submitted" timesheetid="';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '" statusid="3" ><i class="icon-ban-circle"></i></a>';
				
				//revision
				$statusUpdate .= '<a href="javascript:changeToRevision('.$calendarTimesheet['Timesheet']['id'].')" class="change-status revision ';
				if($calendarTimesheet['ApprovalStatus']['id']=='4'){
					$statusUpdate .= 'status-active ';
				}
				$statusUpdate .= ' row-revision-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= ' row-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '"  title="Needs Review" alt="Needs Review" timesheetid="';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '" statusid="4" ><i class="icon-refresh"></i></a>';
				
				$statusUpdate .= '<span class="spinner row-'. $calendarTimesheet['Timesheet']['id'] .'"></i></span>';
				$statusUpdate .= '</div>';
			} else {
				$statusUpdate = '';
			}
			$calendarData[] = array(
					'id' => $calendarTimesheet['Timesheet']['id'],
					'title'=>CakeTime::format('g:i A',$calendarTimesheet['Timesheet']['start_time'],null,$this->timezone) . ' - ' . 
							CakeTime::format('g:i A',$calendarTimesheet['Timesheet']['end_time'],null,$this->timezone),
					'start'=>$calendarTimesheet['Timesheet']['start_time'],
					'end' => $calendarTimesheet['Timesheet']['end_time'],
					'allDay' => false,
					'url' => Router::url('/',true) . '/timesheets/view/'.$calendarTimesheet['Timesheet']['id'],
					'details' => $calendarTimesheet['Timesheet']['note'],
					'className' => 'status'.$calendarTimesheet['ApprovalStatus']['id']. ' ts-'.$calendarTimesheet['Timesheet']['id'],
					'toolTip' => '<strong>'.substr($calendarTimesheet['Timesheet']['hours'],0,strlen($calendarTimesheet['Timesheet']['hours'])-3) . ' hours'."</strong>\r\n<br>".$calendarTimesheet['Timesheet']['note'],
					'statusUpdate' => $statusUpdate
			);
		}
		
		if ($this->Auth->user('group_id') == 1){
			$userList = $this->User->find('list');
		} else {
			$userList = $this->User->find('list',array(
					'conditions'=>array('OR'=>array(
							'User.id'=>$this->Auth->user('id'),
							'User.parent_id'=>$this->Auth->user('id')
					))
			
			));
		}
		
		$this->set('userList',$userList);
		$statusList = $this->ApprovalStatus->find('list');
		$this->set('statusList',$statusList);
		if($this->RequestHandler->responseType() == 'csv'){
			$this->set('timesheets', $this->Timesheet->find('all',$findParam));
		} else {
			$this->set('timesheets', $this->Paginate());
		}
		
		$this->set('calendarData',$calendarData);
		
		if ($calView) {
			$this->render('calendar');
		} elseif ($calendarView) {
			$this->render('calendar');
		} else {
			$this->render('index');
		}
	
	}
	
	public function unapproved($csvFile = null) {
                $searched = false;
		$search_user_full_name = '';
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_name'])){
				$searched = true;
			}
			if(isset($args['search_user_id'])){
				$temp = $this->User->findById($args['search_user_id']);
				if ($temp){
					$search_user_full_name = $temp['User']['full_name'];
				}
			}
		}
	
		$this->set('search_user_full_name',$search_user_full_name);
	
		$this->set('searched',$searched);
	
		$this->Prg->commonProcess();
		//$this->Timesheet->recursive = 1;
	
		if ($csvFile) {
			$this->paginate = array(
					'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),array('ApprovalStatus.name'=>'Submitted')),
					'order' => array(
							'Timesheet.modified' => 'desc'
					)
			);
			$this->request->params['named']['page'] = null;
		}
		else {
			if($this->Auth->user('group_id') == 1) {
				$this->paginate = array(
						'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),array('ApprovalStatus.name'=>'Submitted')),
						'limit' => $this->option_row_other,
						'order' => array(
								'Timesheet.modified' => 'desc'
						)
				);
				$calendarTimesheets = $this->Timesheet->find('all',array(
						'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),array('ApprovalStatus.name'=>'Submitted'))
				));
			} else {
				//user children
				$directChildren = $this->User->children($this->Auth->user('id'));
				foreach($directChildren as $directChildren){
					$b[] = $directChildren['User']['id'];
				}
				$b[] = $this->Auth->user('id');
				$a = $this->User->find('all',array('conditions'=>array(
													'OR'=>array('User.id'=>$b,
														  'User.parent_id'=>$this->Auth->user('id'))
													)
											)
									);			
				foreach($a as $val){
						$child[] = $val['User']['id'];
				}
				if($this->manager_see_multi_lavels == 1){
						$this->paginate = array(
											'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
											array(array('ApprovalStatus.name'=>'Submitted'),
												'AND' => array(
														'OR'=>array(
																'Timesheet.user_id'=>$child,
																'User.parent_id'=>$this->Auth->user('id')
														))
											)),
											'limit' => $this->option_row_other,
											'order' => array(
											'Timesheet.modified' => 'desc'
											)
						);

						$calendarTimesheets = $this->Timesheet->find('all',array(
													'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
													array(array('ApprovalStatus.name'=>'Submitted'),
														'AND' => array(
																'OR'=>array(
																		'Timesheet.user_id'=>$child,
																		'User.parent_id'=>$this->Auth->user('id')
																))
													))
						));

				}
				else{
						$this->paginate = array(
								'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
										array(array('ApprovalStatus.name'=>'Submitted'),
												'AND' => array(
														'OR'=>array(
																'Timesheet.user_id'=>$this->Auth->user('id'),
																'User.parent_id'=>$this->Auth->user('id')
														))
										)),
								'limit' => $this->option_row_other,
								'order' => array(
										'Timesheet.modified' => 'desc'
								)
						);
						
						$calendarTimesheets = $this->Timesheet->find('all',array(
								'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
										array(array('ApprovalStatus.name'=>'Submitted'),
												'AND' => array(
														'OR'=>array(
																'Timesheet.user_id'=>$this->Auth->user('id'),
																'User.parent_id'=>$this->Auth->user('id')
														))
										))
						));
				}
			}
				
		}
		
		$calendarData = array();
		foreach($calendarTimesheets as $calendarTimesheet) {
			$calendarData[] = array(
					'id' => $calendarTimesheet['Timesheet']['id'],
					'title'=>$calendarTimesheet['Timesheet']['note'],
					'start'=>CakeTime::format('Y-m-d H:i:s',$calendarTimesheet['Timesheet']['start_time'],null,$this->userTimezone),
					'end' => CakeTime::format('Y-m-d H:i:s',$calendarTimesheet['Timesheet']['end_time'],null,$this->userTimezone),
					'allDay' => false,
					'url' => Router::url('/',true) . '/timesheets/view/'.$calendarTimesheet['Timesheet']['id'],
					'details' => $calendarTimesheet['Timesheet']['note'],
					'className' => 'status'.$calendarTimesheet['ApprovalStatus']['id'],
					'toolTip' => $calendarTimesheet['Timesheet']['note']
			);
		}
		
		if ($this->Auth->user('group_id') == 1){
			$userList = $this->User->find('list');
		} else {
				//user children
				$directChildren = $this->User->children($this->Auth->user('id'));
				foreach($directChildren as $directChildren){
					$b[] = $directChildren['User']['id'];
				}
				$b[] = $this->Auth->user('id');
				$a = $this->User->find('all',array('conditions'=>array(
													'OR'=>array('User.id'=>$b,
														  'User.parent_id'=>$this->Auth->user('id'))
													)
											)
									);			
				foreach($a as $val){
						$child[] = $val['User']['id'];
				}
				if($this->manager_see_multi_lavels == 1){
					$userList = $this->User->find('list',array(
							'conditions'=>array('OR'=>array(
									'User.id'=>$child,
									'User.parent_id'=>$this->Auth->user('id')
							))
								
					));
				}
				else{
					$userList = $this->User->find('list',array(
							'conditions'=>array('OR'=>array(
									'User.id'=>$this->Auth->user('id'),
									'User.parent_id'=>$this->Auth->user('id')
							))
								
					));
				}
		}
		
		$this->set('userList',$userList);
		
		$statusList = $this->ApprovalStatus->find('list');
		$this->set('statusList',$statusList);
		
		$this->set('timesheets', $this->Paginate());
		$this->set('calendarData',$calendarData);
		
		$this->render('index');
	}
	
        public function approved($calView = null) {
                $calendarTimesheets = array();
		$searched = false;
		$calendarView = false;
		$search_user_full_name = '';
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_name'])){
				$searched = true;
			}
			if(isset($args['search_user_id'])){
				$temp = $this->User->findById($args['search_user_id']);
				if ($temp){
					$search_user_full_name = $temp['User']['full_name'];
				}
				$calendarView = true;
			}
		}
	
		$this->set('search_user_full_name',$search_user_full_name);
	
		$this->set('searched',$searched);
	
		$this->Prg->commonProcess();
		
		
			if($this->Auth->user('group_id') == 1) {
				$this->paginate = array(
						'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),array('ApprovalStatus.name'=>'Approved')),
						'limit' => $this->option_row_other,
						'order' => array(
								'Timesheet.modified' => 'desc'
						)
				);
				
				$calendarTimesheets = $this->Timesheet->find('all',array(
						'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),array('ApprovalStatus.name'=>'Approved'))
						
				));
				
			} else {
				//user children
				$directChildren = $this->User->children($this->Auth->user('id'));
				foreach($directChildren as $directChildren){
					$b[] = $directChildren['User']['id'];
				}
				$b[] = $this->Auth->user('id');
				$a = $this->User->find('all',array('conditions'=>array(
													'OR'=>array('User.id'=>$b,
														  'User.parent_id'=>$this->Auth->user('id'))
													)
											)
									);			
				foreach($a as $val){
						$child[] = $val['User']['id'];
				}
				if($this->manager_see_multi_lavels == 1){
					$this->paginate = array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(array('ApprovalStatus.name'=>'Approved'),
									'AND' => array(
											'OR'=>array(
													'Timesheet.user_id'=>$child,
													'User.parent_id'=>$this->Auth->user('id')
									))	
					)),
							'limit' => $this->option_row_other,
							'order' => array(
									'Timesheet.modified' => 'desc'
							)
					);
					
					$calendarTimesheet = $this->Timesheet->find('all',array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(array('ApprovalStatus.name'=>'Approved'),
									'AND' => array(
											'OR'=>array(
													'Timesheet.user_id'=>$child,
													'User.parent_id'=>$this->Auth->user('id')
									))	
					))
					));
				}
				else{
					$this->paginate = array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(array('ApprovalStatus.name'=>'Approved'),
									'AND' => array(
											'OR'=>array(
													'Timesheet.user_id'=>$this->Auth->user('id'),
													'User.parent_id'=>$this->Auth->user('id')
									))	
					)),
							'limit' => $this->option_row_other,
							'order' => array(
									'Timesheet.modified' => 'desc'
							)
					);
					
					$calendarTimesheet = $this->Timesheet->find('all',array(
							'conditions' => array_merge($this->Timesheet->parseCriteria($this->passedArgs),
									array(array('ApprovalStatus.name'=>'Approved'),
									'AND' => array(
											'OR'=>array(
													'Timesheet.user_id'=>$this->Auth->user('id'),
													'User.parent_id'=>$this->Auth->user('id')
									))	
					))
					));
				}
			}
		/*	
		}
		*/
		$calendarData = array();
		foreach($calendarTimesheets as $calendarTimesheet) {
			$calendarData[] = array(
					'id' => $calendarTimesheet['Timesheet']['id'],
					'title'=>CakeTime::format('g:i A',$calendarTimesheet['Timesheet']['start_time'],null,$this->timezone) . '-' .
					CakeTime::format('g:i A',$calendarTimesheet['Timesheet']['end_time'],null,$this->timezone) . ' ' .
					substr($calendarTimesheet['Timesheet']['hours'],0,strlen($calendarTimesheet['Timesheet']['hours'])-3) . 'Hours',
					'start'=>CakeTime::format('Y-m-d H:i:s',$calendarTimesheet['Timesheet']['start_time'],null,$this->timezone),
					'end' => CakeTime::format('Y-m-d H:i:s',$calendarTimesheet['Timesheet']['end_time'],null,$this->timezone),
					'allDay' => false,
					'url' => Router::url('/',true) . '/timesheets/view/'.$calendarTimesheet['Timesheet']['id'],
					'details' => $calendarTimesheet['Timesheet']['note'],
					'className' => 'status'.$calendarTimesheet['ApprovalStatus']['id'],
					'toolTip' => $calendarTimesheet['Timesheet']['note']
			);
		}
		if ($this->Auth->user('group_id') == 1){
			$userList = $this->User->find('list');
		} else {
				//user children
				$directChildren = $this->User->children($this->Auth->user('id'));
				foreach($directChildren as $directChildren){
					$b[] = $directChildren['User']['id'];
				}
				$b[] = $this->Auth->user('id');
				$a = $this->User->find('all',array('conditions'=>array(
													'OR'=>array('User.id'=>$b,
														  'User.parent_id'=>$this->Auth->user('id'))
													)
											)
									);			
				foreach($a as $val){
						$child[] = $val['User']['id'];
				}
				if($this->manager_see_multi_lavels == 1){
					$userList = $this->User->find('list',array(
					'conditions'=>array('OR'=>array(
							'User.id'=>$child,
							'User.parent_id'=>$this->Auth->user('id')
						))							
					));
				}
				else{
					$userList = $this->User->find('list',array(
							'conditions'=>array('OR'=>array(
									'User.id'=>$this->Auth->user('id'),
									'User.parent_id'=>$this->Auth->user('id')
							))
								
					));
				}
		}
		$this->set('userList',$userList);
		
		$statusList = $this->ApprovalStatus->find('list');
		$this->set('statusList',$statusList);
		
		$this->set('timesheets', $this->Paginate());
		$this->set('calendarData',$calendarData);
		if ($calView) {
			$this->render('calendar');
		} elseif ($calendarView) {
			$this->render('calendar');
		} else {
			$this->render('index');
		}
	}

	public function calendar($user=NULL) {
		// Unbind user hasMany to allow user names to load faster
		$this->User->unbindModel(array(
			'hasMany' => array('Job','Timesheet','Vacation')
		));

		if(!isset($user)) {
			$user = $this->Auth->user('id');
		}
		$add_timesheet = true;
		if ($this->Auth->user('group_id') != 1){
			// if not admin then check if allowed to add in timeaheet in calendar
			$option_add_timesheet = $this->Option->find('first',array('conditions'=>array('name'=>'user_add_timesheet_calendar')));
			if(!empty($option_add_timesheet)){
				$add_timesheet = $option_add_timesheet['Option']['value'];
			} else {
				$add_timesheet = true;
			}
		} else {
			$add_timesheet = true;
		}
                
		//$allBelowStaffs = $this->User->children($this->Auth->user('id'),false,array('User.id')); 
                if ($this->Auth->user('group_id') != 1) :
                    $allBelowStaffs = $this->User->find('all', array(
                        'fields' => array('User.id'),
                        'conditions' => array('User.parent_id' => $this->Auth->user('id'))
                    ));
                else : 
                    $allBelowStaffs = $this->User->find('all', array(
                        'fields' => array('User.id'),
                        'conditions' => array(
                            'User.id !=' => $this->Auth->user('id')
                            )
                        )
                    );
                endif;
                
		$allBelowStaffIds = array();
		foreach ($allBelowStaffs as $allBelowStaff){
			$allBelowStaffIds[] = $allBelowStaff['User']['id'];
		}
		
		//managerAllowedEditStaff
		$option_manager_edit_staff = $this->Option->find('first',array('conditions'=>array('name'=>'manager_edit_staff_timesheet')));
                if($option_manager_edit_staff['Option']['value'] == 1){
			$managerAllowedEditStaff = (boolean) $option_manager_edit_staff['Option']['value'];
		} else {
			$managerAllowedEditStaff = false;
		}
		
		if ($this->Auth->user('group_id') == 1){
			// no problem admin can see all
		} elseif ($user == $this->Auth->user('id')){
			// currents user's own timesheet... no prob
		} 
		else {
			$selUser = $this->User->read(array('User.parent_id'), $user); // get selected user's parent id
			if(isset($selUser['User']) && ($selUser['User']['parent_id'] == $this->Auth->user('id'))){
				// current user is manager of selected uset .. thats fine
			} else {
				$user = $this->Auth->user('id');
				$this->Session->setFlash(__('You are not authorized to view the other person\'s timesheet'),'alert', array('class'=>'alert-error'));
			}			
		}
                
                $day = date('w');
                $week_start = date('Y-m-d', strtotime('-'.$day.' days'));
                $week_end = date('Y-m-d', strtotime('+'.(6-$day).' days'));
                $week_start_client = CakeTime::format('Y-m-d', $week_start, null, $this->userTimezone);                 
                $week_end_client = CakeTime::format('Y-m-d', $week_end, null, $this->userTimezone);
                $week_start_server = CakeTime::format('Y-m-d H:i:s', $week_start_client, null, $this->serverTimezone);
                $week_end_server = CakeTime::format('Y-m-d H:i:s', strtotime($week_end_client . ' 23:59:59'), null, $this->serverTimezone);
                $calendarTimesheets = $this->Timesheet->find('all', array(
                    'conditions' => array(
                        'User.id' => $user,
                        'Timesheet.start_time' => $week_start_server,
                        'Timesheet.end_time' => $week_end_server
                    )
                ));
                
		$calendarData = array();
		foreach($calendarTimesheets as $calendarTimesheet) {
			if ($this->Auth->user('group_id')==1 || $calendarTimesheet['User']['parent_id'] == $this->Auth->user('id')){
				
				$statusUpdate = '<div class="status-icons">';
				//submitted
				$statusUpdate .= '<a href="javascript:changeToSubmitted('.$calendarTimesheet['Timesheet']['id'].')" class="change-status submitted ';
				
				if($calendarTimesheet['ApprovalStatus']['id']=='1'){
					$statusUpdate .= 'status-active ';
				}
				$statusUpdate .= ' row-submitted-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= ' row-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '"  title="Submitted" alt="Submitted" timesheetid="';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '" statusid="1" ><i class="icon-question"></i></a>';
				
				//approved
				$statusUpdate .= '<a href="javascript:changeToApproved('.$calendarTimesheet['Timesheet']['id'].')" class="change-status approved ';
				if($calendarTimesheet['ApprovalStatus']['id']=='2'){
					$statusUpdate .= 'status-active ';
				}
				$statusUpdate .= ' row-approved-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= ' row-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '"  title="Submitted" alt="Rejected" timesheetid="';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '" statusid="2" ><i class="icon-ok"></i></a>';
				
				//rejected
				$statusUpdate .= '<a href="javascript:changeToRejected('.$calendarTimesheet['Timesheet']['id'].')" class="change-status rejected ';
				if($calendarTimesheet['ApprovalStatus']['id']=='3'){
					$statusUpdate .= 'status-active ';
				}
				$statusUpdate .= ' row-rejected-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= ' row-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '"  title="Submitted" alt="Submitted" timesheetid="';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '" statusid="3" ><i class="icon-ban-circle"></i></a>';
				
				//revision
				$statusUpdate .= '<a href="javascript:changeToRevision('.$calendarTimesheet['Timesheet']['id'].')" class="change-status revision ';
				if($calendarTimesheet['ApprovalStatus']['id']=='4'){
					$statusUpdate .= 'status-active ';
				}
				$statusUpdate .= ' row-revision-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= ' row-';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '"  title="Needs Review" alt="Needs Review" timesheetid="';
				$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
				$statusUpdate .= '" statusid="4" ><i class="icon-refresh"></i></a>';

				$statusUpdate .= '<span class="spinner row-'. $calendarTimesheet['Timesheet']['id'] .'"></i></span>';
				$statusUpdate .= '</div>';
			} else {
				$statusUpdate = '';
			}
                        
                        $userId = $this->Auth->user('id');
                        $userDetails = $this->User->find('all', array('conditions'=>array('User.id'=>$userId)));                
                        $userTimezone = $userDetails[0]['User']['user_timezone'];
			$calendarData[] = array(
					'id' => $calendarTimesheet['Timesheet']['id'],
					'title'=> CakeTime::format('g:i A',$calendarTimesheet['Timesheet']['start_time'],null,$this->userTimezone) . ' - ' . 
                                        CakeTime::format('g:i A',$calendarTimesheet['Timesheet']['end_time'],null,$this->userTimezone),
					'start'=>CakeTime::format('Y-m-d H:i:s',$calendarTimesheet['Timesheet']['start_time'],null,$this->userTimezone),
					'end' => CakeTime::format('Y-m-d H:i:s',$calendarTimesheet['Timesheet']['end_time'],null,$this->userTimezone),
					'allDay' => false,
					'url' => Router::url('/',true) . '/timesheets/edit/'.$calendarTimesheet['Timesheet']['id'],
					'details' => $calendarTimesheet['Timesheet']['note'],
					'className' => 'status'.$calendarTimesheet['ApprovalStatus']['id']. ' ts-'.$calendarTimesheet['Timesheet']['id'],
					'toolTip' => '<strong>'.substr($calendarTimesheet['Timesheet']['hours'],0,strlen($calendarTimesheet['Timesheet']['hours'])-3) . ' hours'."</strong>\r\n<br>".$calendarTimesheet['Timesheet']['note'],
					'statusUpdate' => $statusUpdate
			);
		}
		
		if ($this->Auth->user('group_id') == 1){
			$userList = $this->User->find('list',array('order'=>array('User.first_name ASC','User.last_name ASC')));
                } else {
			$a = $this->User->find('all',array('conditions'=>array(
                            'OR'=>array('User.id'=>$this->Auth->user('id'),
                                        'User.parent_id'=>$this->Auth->user('id'))
                            ),
                            'recursive' => -1
                        ));			
			foreach($a as $val){
					$child[] = $val['User']['id'];
			}
                        
			if($this->manager_see_multi_lavels == 1){
								$userList = $this->User->find('list',array(
						'conditions'=>array('OR'=>array(
								'User.id'=>$child,
								'User.parent_id'=>$this->Auth->user('id')
						)),
						'order' => array('User.first_name ASC','User.last_name ASC')
				));
                                                            
                                                                
			}
			else{
				$userList = $this->User->find('list',array(
						'conditions'=>array('OR'=>array(
								'User.id'=>$this->Auth->user('id'),
								'User.parent_id'=>$this->Auth->user('id')
						)),
						'order' => array('User.first_name ASC','User.last_name ASC')
				));
			}
		}
		$this->request->data['Timesheet']['search_user_id'] = $user;
		$this->set('userList',$userList);
		$this->set('user_id',$user); //current user
		$this->set("calendarData", $calendarData);
                $this->set('allowUserAddTimesheet',$add_timesheet);
		$this->set('logedInUserId',$this->Auth->user('id'));
		$this->set('allStaffIds',$allBelowStaffIds);
		$this->set('managerAllowedEditStaff',$managerAllowedEditStaff);
	}
	
	public function reports($user = NULL){
                Controller::disableCache();
		if(!isset($user)) {
			$user = $this->Auth->user('id');
		}
                
                if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_report_from'])){
				if(empty($args['search_report_from'])){
					$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
					$args['search_report_from'] = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
				} else {
					$start = $args['search_report_from'];
				}
			} else {
				$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
			}
			if(isset($args['search_report_to'])){
				if(empty($args['search_report_to'])){
					$end = date('Y-m-d');
					$args['search_report_to'] = date('Y-m-d');
				} else {
					$end = $args['search_report_to'];
				}
			} else {
				$end = date('Y-m-d');
			}
			if(isset($args['search_user_id'])){
				if(empty($args['search_user_id'])){
					$args['search_user_id'] = $user;
				} else {
					$user = $args['search_user_id'];
				}
			}
		} else {
			$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
			$end = date('Y-m-d');
		}
		$this->Prg->commonProcess();
                
                $start_client = CakeTime::format('Y-m-d', strtotime($start), null, $this->userTimezone);                 
                $end_client = CakeTime::format('Y-m-d', strtotime($end), null, $this->userTimezone);
                
                $start_server = CakeTime::format('Y-m-d H:i:s', strtotime($start_client), null, $this->serverTimezone);
                $end_server = CakeTime::format('Y-m-d H:i:s', strtotime($end_client . ' 23:59:59'), null, $this->serverTimezone);
                		
                $dayHours = $this->Timesheet->getDayHours($start_server, $end_server, $user); 
		$weekHours = $this->Timesheet->getWeekHours($start_server, $end_server, $user);
		$monthHours = $this->Timesheet->getMonthHours($start_server, $end_server, $user);
		
		//start candlestick 
		$cs_data = $this->Timesheet->find('all', array('fields' => array('Timesheet.start_time', 'Timesheet.end_time'),
		                                               'conditions' => array('Timesheet.user_id' => $user,
                                                               'Timesheet.start_time >=' => $start_server,
                                                               'Timesheet.end_time <=' => $end_server),
                                                               'order' => array('Timesheet.start_time ASC')));
                
                $candlestick = array();
                foreach ($cs_data as $val) :
                    if (date('Y-m-d', strtotime($val['Timesheet']['start_time'])) == date('Y-m-d', strtotime($val['Timesheet']['end_time']))) :
                        $only_start_time = DATE("H:i:s", strtotime($val['Timesheet']['start_time']));					
                        $time_arr = explode(':', $only_start_time);
                        $seconds_h = intval($time_arr[0]) * 3600;
                        $seconds_m = intval($time_arr[1]) * 60;
                        $seconds_s = intval($time_arr[2]);
                        $start_hour = floor(($seconds_h + $seconds_m + $seconds_s) / (60*60));

                        $only_end_time = DATE("H:i:s", strtotime($val['Timesheet']['end_time']));
                        $time_arr = explode(':', $only_end_time);
                        $seconds_h = intval($time_arr[0]) * 3600;
                        $seconds_m = intval($time_arr[1]) * 60;
                        $seconds_s = intval($time_arr[2]);
                        $end_hour = floor(($seconds_h + $seconds_m + $seconds_s) / (60*60));

                        $candlestick[date("Y-m-d", strtotime($val['Timesheet']['start_time']))] = array($start_hour, $end_hour);
                    else :
                        $dt = $this->Timesheet->dateRange(date('Y-m-d', strtotime($val['Timesheet']['start_time'])), date('Y-m-d', strtotime($val['Timesheet']['end_time'])));
                        foreach ($dt as $key => $date_val) :
                            if ($key == 0) :
                                $only_start_time = DATE("H:i:s", strtotime($val['Timesheet']['start_time']));					
                                $time_arr = explode(':', $only_start_time);
                                $seconds_h = intval($time_arr[0]) * 3600;
                                $seconds_m = intval($time_arr[1]) * 60;
                                $seconds_s = intval($time_arr[2]);
                                $start_hour = floor(($seconds_h + $seconds_m + $seconds_s) / (60*60));

                                $end_hour = floor(24);
                                
                                $candlestick[date("Y-m-d", strtotime($val['Timesheet']['start_time']))] = array($start_hour, $end_hour);
                            elseif ($key == count($dt) - 1) :
                                $start_hour = floor(0);
                                
                                $only_end_time = DATE("H:i:s", strtotime($val['Timesheet']['end_time']));
                                $time_arr = explode(':', $only_end_time);
                                $seconds_h = intval($time_arr[0]) * 3600;
                                $seconds_m = intval($time_arr[1]) * 60;
                                $seconds_s = intval($time_arr[2]);
                                $end_hour = floor(($seconds_h + $seconds_m + $seconds_s) / (60*60));

                                $candlestick[date("Y-m-d", strtotime($val['Timesheet']['end_time']))] = array($start_hour, $end_hour);
                            else :
                                $start_hour = floor(0);
                                $end_hour = floor(24);
                                $candlestick[date("Y-m-d", strtotime($date_val))] = array($start_hour, $end_hour);
                            endif;
                        endforeach;
                    endif;
                endforeach;

                $dates = array();
		$current = strtotime($start_server);
		$last = strtotime($end_server);
		while( $current <= $last ) {	
                    $dates[] = DATE("Y-m-d", $current);
                    $current = strtotime("+1 day", $current);
		}
                $candlestick_data = array();
		foreach($dates as $date) :
                    if (empty($candlestick)) :
                        $candlestick_data[] = '["' . $date . '",' . 0 . ',' . 0 . ']';
                    else :
                        foreach ($candlestick as $key => $val) :
                            if (strtotime($date) == strtotime($key)) :
                                $candlestick_data[] = '["' . $date . '",' . $val[0] . ',' . $val[1] . ']';
                            else :
                                $candlestick_data[] = '["' . $date . '",' . 0 . ',' . 0 . ']';
                            endif;
                        endforeach;  
                   endif;                        
                endforeach;
                $this->set('candlestick', $candlestick_data);
		//end candlestick
				
		if ($this->Auth->user('group_id') == 1){
			$userList = $this->User->find('list',array('order'=>array('User.first_name ASC','User.last_name ASC')));
		} else {
			$a = $this->User->find('all',array('conditions'=>array(
												'OR'=>array('User.id'=>$this->Auth->user('id'),
													  'User.parent_id'=>$this->Auth->user('id'))
												)
										)
								);			
			foreach($a as $val){
					$child[] = $val['User']['id'];
			}
			if($this->manager_see_multi_lavels == 1){
				$userList = $this->User->find('list',array(
					'conditions'=>array('OR'=>array(
							'User.id'=>$child,
							'User.parent_id'=>$this->Auth->user('id')
					)),
					'order' => array('User.first_name ASC','User.last_name ASC')
			));
			}
			else{
				$userList = $this->User->find('list',array(
						'conditions'=>array('OR'=>array(
								'User.id'=>$this->Auth->user('id'),
								'User.parent_id'=>$this->Auth->user('id')
						)),
						'order' => array('User.first_name ASC','User.last_name ASC')
				));
			}
		}
		
		$start_client = CakeTime::format('Y-m-d', strtotime($start_server), null, $this->userTimezone);
                $end_client = CakeTime::format('Y-m-d', strtotime($end_server), null, $this->userTimezone);
                $this->request->data['Timesheet']['search_user_id'] = $user;
		$this->request->data['Timesheet']['search_report_from'] = $start_client;
		$this->request->data['Timesheet']['search_report_to'] = $end_client;
		$this->set('userList',$userList);
		$this->set('dayHours',$dayHours);
		$this->set('weekHours',$weekHours);
		$this->set('monthHours',$monthHours);
	}
	
	public function reportsAggregate($csvFile = null){
                Controller::disableCache();
		$start_date = '';
		$end_date = '';
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['start_date'])){
				$start_date = $args['start_date'];
			} else {
				$start_date = $this->passedArgs['start_date'] = date('Y-m-d', strtotime('first day of last month'));
			}
			if(isset($args['end_date'])){
				$end_date = $args['end_date'];
			} else {
				$end_date = $this->passedArgs['end_date'] = date('Y-m-d', strtotime('last day of last month'));
			}
		} else {
			$start_date = $this->passedArgs['start_date'] = date('Y-m-d', strtotime('first day of last month'));
			$end_date = $this->passedArgs['end_date'] = date('Y-m-d', strtotime('last day of last month'));
		}
		
		$group = $this->Auth->user('group_id');
		$uid = $this->Auth->user('id');
		
		$this->Prg->commonProcess();
		$findOptions = array();
		if($group == 1){//admin
			
			$findOptions = array(
					'contain'=>array(),
					'order' => array('User.full_name'=>'asc')
			);
			
			$allCount = $this->Timesheet->User->find('count',$findOptions);
			
			$this->paginate = array(
					'contain'=>array(),
					'order' => array('User.full_name'=>'asc'),
					'limit' => $allCount//$this->option_row_other
			);
			
			
		} else {
				// user children
				$directChildren = $this->User->children($this->Auth->user('id'));
				foreach($directChildren as $directChildren){
					$b[] = $directChildren['User']['id'];
				}
				$b[] = $this->Auth->user('id');
				$a = $this->User->find('all',array('conditions'=>array(
													'OR'=>array('User.id'=>$b,
														  'User.parent_id'=>$this->Auth->user('id'))
													)
											)
									);			
				foreach($a as $val){
						$child[] = $val['User']['id'];
				}
				if($this->manager_see_multi_lavels == 1){
					
					
					$findOptions = array(
							'conditions'=>array('User.id'=>$child,'User.parent_id'=>$uid),
							'contain'=>array(
									),
							'order' => array('User.full_name'=>'asc')
					);
					
					$allCount = $this->Timesheet->User->find('count',$findOptions);
					
					$this->paginate = array(
							'conditions'=>array('User.id'=>$child,'User.parent_id'=>$uid),
							'contain'=>array(
							),
							'order' => array('User.full_name'=>'asc'),
							'limit' => $allCount // using datatables $this->option_row_other
					);
				}
				else{
					
					
					$findOptions = array(
							'conditions'=>array('User.id'=>$uid,'User.parent_id'=>$uid),
							'contain'=>array(
									),
							'order' => array('User.full_name'=>'asc')
					);
					
					$allCount = $this->Timesheet->User->find('count',$findOptions);
					
					$this->paginate = array(
							'conditions'=>array('User.id'=>$uid,'User.parent_id'=>$uid),
							'contain'=>array(
							),
							'order' => array('User.full_name'=>'asc'),
							'limit' => $allCount // no limit coz we will be using datatables $this->option_row_other
					);
				}
		}
		
		if($csvFile){
			$users = $this->Timesheet->User->find('all',$findOptions);
		} else {
			//$users = $this->paginate($this->User);
			//OR we can use find instead of modifying pagination-limit for datatable
			$users = $this->Timesheet->User->find('all',$findOptions);
		}
		
		$start = CakeTime::toServer($start_date,$this->userTimezone);
		$end = CakeTime::toServer($end_date . ' 23:59:59',$this->userTimezone);
		foreach($users as $key=>$val){ // find total hours worked and total timesheets between dates for each user
			$users[$key]['TotalHours'] = $this->getTotalHoursWorked($val['User']['id'],$start,$end);
			$users[$key]['TotalTimesheet'] = $this->getTotalTimesheet($val['User']['id'],$start,$end);
			$dates = $this->_dateRange($start, $end);
			$totalDays = count($dates);
			//get hours in decimal
			$parts = explode(':',$users[$key]['TotalHours']);
		 	$decHours = $parts[0] + ($parts[1]/60);
		 	
		 	//Average hours per workday (= Total hours worked * 7 / Total days * 5 )
		 	
		 	$averageHours = ($decHours*7)/($totalDays*5);
		 	$wholeHour = floor($averageHours);
		 	$decPart = $averageHours - $wholeHour;
		 	$minutes = $decPart * 60;
		 	$formatedHours = $wholeHour . ':' . floor($minutes);
		 	$users[$key]['AverageHours'] = $formatedHours;
		}
		//debug($users);
		$this->set('timesheets',$users);
		$this->request->data['Timesheet']['start_date'] = CakeTime::format('Y-m-d',$start_date,null,$this->userTimezone);
		$this->request->data['Timesheet']['end_date'] = CakeTime::format('Y-m-d',$end_date,null,$this->userTimezone);
		
	}
	
	private function getTotalHoursWorked($user = null, $start= null,$end=null){
                $totalSeconds = 0;
		
		// get timesheets -start end is between the dates
		$userTimesheets = $this->Timesheet->find('all',array('conditions'=>array(
				'User.id'=>$user,
				'Timesheet.start_time >=' => $start,
				'Timesheet.end_time <=' => $end
		)));
		
		foreach($userTimesheets as $userTimesheet) {
			$seconds = 0;
			$parts = explode(':', $userTimesheet['Timesheet']['hours']);
				
			$seconds = ($parts[0] * 60 * 60) + ($parts[1] * 60) + $parts[2];
				
			$totalSeconds = $totalSeconds + $seconds;
				
		}
		
		// get timesheets -starts before the cal-start-date but ends before cal-end-date
		$userTimesheets = $this->Timesheet->find('all',array('fields'=>array('start_time','TIMEDIFF(Timesheet.end_time,\''.$start.'\') as phours'),'conditions'=>array(
				'User.id'=>$user,
				'Timesheet.start_time <' => $start,
				'Timesheet.end_time <=' => $end,
				'Timesheet.end_time >' => $start
		)));
		
		foreach($userTimesheets as $userTimesheet) {
			$seconds = 0;
			$parts = explode(':', $userTimesheet[0]['phours']);
		
			$seconds = ($parts[0] * 60 * 60) + ($parts[1] * 60) + $parts[2];
		
			$totalSeconds = $totalSeconds + $seconds;
		}
		
		// get timesheets -starts after cal-start-date but ends after cal-end-date
		$userTimesheets = $this->Timesheet->find('all',array('fields'=>array('TIMEDIFF(\''.$end.'\',Timesheet.start_time) as lhours'),'conditions'=>array(
				'User.id'=>$user,
				'Timesheet.start_time >=' => $start,
				'Timesheet.end_time >' => $end,
				'Timesheet.start_time <' => $end
		)));
		
		foreach($userTimesheets as $userTimesheet) {
			$seconds = 0;
			$parts = explode(':', $userTimesheet[0]['lhours']);
		
			$seconds = ($parts[0] * 60 * 60) + ($parts[1] * 60) + $parts[2];
		
			$totalSeconds = $totalSeconds + $seconds;
		}
		$totalHours = '';
		// extract hours
		$hours = floor($totalSeconds / (60 * 60));
		
		// extract minutes
		$divisor_for_minutes = $totalSeconds % (60 * 60);
		$minutes = floor($divisor_for_minutes / 60);
		
		// extract the remaining seconds
		$divisor_for_seconds = $divisor_for_minutes % 60;
		$seconds = ceil($divisor_for_seconds);
		if($hours == 0){
			$hours = '00';
		}
		if($minutes == 0){
			$minutes = '00';
		}
		$totalHours = $hours .':'.$minutes;
		
		return $totalHours;
	}
	
	private function getTotalTimesheet($userId = null, $start = null, $end = null){
                $timesheet = $this->Timesheet->find('count',array('conditions'=>array(
				'Timesheet.user_id'=>$userId,
				'Timesheet.start_time >=' => $start,
				'Timesheet.start_time <=' => $end
		)));		
		return $timesheet;
	}
	
	private function _dateRange($first, $last, $step = '+1 day', $format = 'Y-m-d' ) {
                $dates = array();
		$current = strtotime($first);
		$last = strtotime($last);
	
		while( $current <= $last ) {
	
			$dates[] = date($format, $current);
			$current = strtotime($step, $current);
		}
	
		return $dates;
	}
                	
	public function reportsLast(){
                Controller::disableCache();
		$group = $this->Auth->user('group_id');
		$uid = $this->Auth->user('id'); 
                
                $theTimesheets = $this->Timesheet->find('all', array(
                    'fields' => array('Timesheet.user_id', 'MAX(Timesheet.start_time)', 'MAX(Timesheet.end_time)'),
                    'condition' => array(),
                    'group' => array('Timesheet.user_id')
                ));
                
                $this->set('theTimesheets', $theTimesheets);
                
                if($group == 1){//admin     
                	
//                     $this->paginate = array(
//                         'limit' =>$this->option_row_other,
//                         'group' => array('Timesheet.user_id'),
//                         'order' => array('User.first_name' => 'asc')
//                     );
                    $findOptions =  array(
                        'group' => array('Timesheet.user_id'),
                        'order' => array('User.first_name' => 'asc')
                    );
		} else {
//                     $this->paginate = array(
//                         'conditions' => array(
//                             'OR' => array(
//                                 'User.id' => $uid,
//                                 'User.parent_id' => $uid
//                             )
// 			),
// 			'group' => array('Timesheet.user_id'),
//                         'order' => array('User.first_name' => 'asc')
//                     );
                $findOptions = array(
                        'conditions' => array(
                            'OR' => array(
                                'User.id' => $uid,
                                'User.parent_id' => $uid
                            )
			),
			'group' => array('Timesheet.user_id'),
                        'order' => array('User.first_name' => 'asc')
                    );
		}
                
               //$this->set('timesheets', $this->paginate());
               $this->set('timesheets',$this->Timesheet->find('all',$findOptions));
               $this->set('timezone', $this->userTimezone);
	}
	
	public function reportsUsersCsv2(){
                Controller::disableCache();
		if(!isset($user)) {
			$user = $this->Auth->user('id');
		}
		
		$users = array();
                                
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_report_from'])){
				if(empty($args['search_report_from'])){
					$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
					$args['search_report_from'] = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
				} else {
					$start = $args['search_report_from'];
				}
			} else {
				$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
			}
			if(isset($args['search_report_to'])){
				if(empty($args['search_report_to'])){
					$end = date('Y-m-d');
					$args['search_report_to'] = date('Y-m-d');
				} else {
					$end = $args['search_report_to'];
				}
			} else {
				$end = date('Y-m-d');
			}
			if(isset($args['search_user_id'])){
				if(empty($args['search_user_id'])){
					$args['search_user_id'] = $user;
                                        $users = $user;
				} else {
					$users = explode(',',$args['search_user_id']);
				}
			}
		} else {
			$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
			$end = date('Y-m-d');
		}
		$this->Prg->commonProcess();
                
                $csv2data = $this->Timesheet->find('all', array(
                    'conditions' => array(
                        'Timesheet.user_id' => $users,
                        'DATE(Timesheet.start_time) >=' => $start,
                        'DATE(Timesheet.end_time) <=' => $end
                        ),
                    'order' => array('Timesheet.user_id ASC')
                    )
                );
                
                $i = 0;
                $totalhours = array();
                foreach($csv2data as $row) {
                    $totalstarttime = strtotime($row['Timesheet']['start_time']);
                    $totalendtime = strtotime($row['Timesheet']['end_time']);                                        
                    $totalhour = (float)(($totalendtime - $totalstarttime) / (60 * 60));
                    
                    if ($totalhour <= 0) {
                        $totalhour = 0;                        
                    }
                    
                    $totalhours[$i] = $totalhour;
                    $i ++;
                }
                
                $this->set('csv2data', $csv2data);
                $this->set('csvth', $totalhours);
        }
        
        public function reportsUsers(){
                Controller::disableCache();
		if(!isset($user)) {
			$user = $this->Auth->user('id');
		}
		
		$users = array();
                
                
		if ($this->passedArgs) {
			$args = $this->passedArgs;
			if(isset($args['search_report_from'])){
				if(empty($args['search_report_from'])){
					$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
					$args['search_report_from'] = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
				} else {
					$start = $args['search_report_from'];
				}
			} else {
				$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
			}
			if(isset($args['search_report_to'])){
				if(empty($args['search_report_to'])){
					$end = date('Y-m-d');
					$args['search_report_to'] = date('Y-m-d');
				} else {
					$end = $args['search_report_to'];
				}
			} else {
				$end = date('Y-m-d');
			}
			if(isset($args['search_user_id'])){
				if(empty($args['search_user_id'])){
					$args['search_user_id'] = $user;
				} else {
					$users = explode(',',$args['search_user_id']);
				}
			}
		} else {
			$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
			$end = date('Y-m-d');
		}
		$this->Prg->commonProcess();
                
                $serverTimezone = new DateTimeZone($this->serverTimezone);
                $start_server = CakeTime::format('Y-m-d H:i:s', strtotime($start), null, $this->serverTimezone);
                $end_server = CakeTime::format('Y-m-d H:i:s', strtotime($end), null, $this->serverTimezone);
                
		$dayHours = array();
			
		foreach($users as $user){
			$dayHours[] = $this->Timesheet->getDayHours($start_server, $end_server, $user);
                        
		}
                
		
		//start candlestick
		$cs_data = array();
		$cs_users = array();
		$cs_final_data = array();
                
                foreach($users as $user){
			$cs_users[] = $this->Timesheet->find('first', array('fields' => array('User.first_name', 'User.last_name'),
		                                                        'conditions' => array('Timesheet.user_id' => $user)));
			$cs_data = $this->Timesheet->find('all', array('fields' => array('Timesheet.start_time', 'Timesheet.end_time'),
		                                               'conditions' => array('Timesheet.user_id' => $user,
													                         'DATE(Timesheet.start_time) >=' => $start_server,
																			 'DATE(Timesheet.end_time) <=' => $end_server),
													   'order' => array('Timesheet.start_time ASC')));
		
			$candlestick = array();
                        if (!empty($cs_data)) :
                            foreach ($cs_data as $val) :
                                if (date('Y-m-d', strtotime($val['Timesheet']['start_time'])) == date('Y-m-d', strtotime($val['Timesheet']['end_time']))) :
                                    $only_start_time = DATE("H:i:s", strtotime($val['Timesheet']['start_time']));					
                                    $time_arr = explode(':', $only_start_time);
                                    $seconds_h = intval($time_arr[0]) * 3600;
                                    $seconds_m = intval($time_arr[1]) * 60;
                                    $seconds_s = intval($time_arr[2]);
                                    $start_hour = floor(($seconds_h + $seconds_m + $seconds_s) / (60*60));

                                    $only_end_time = DATE("H:i:s", strtotime($val['Timesheet']['end_time']));
                                    $time_arr = explode(':', $only_end_time);
                                    $seconds_h = intval($time_arr[0]) * 3600;
                                    $seconds_m = intval($time_arr[1]) * 60;
                                    $seconds_s = intval($time_arr[2]);
                                    $end_hour = floor(($seconds_h + $seconds_m + $seconds_s) / (60*60));

                                    $candlestick[date("Y-m-d", strtotime($val['Timesheet']['start_time']))] = array($start_hour, $end_hour);
                                else :
                                    $dt = $this->Timesheet->dateRange(date('Y-m-d', strtotime($val['Timesheet']['start_time'])), date('Y-m-d', strtotime($val['Timesheet']['end_time'])));
                                    foreach ($dt as $key => $date_val) :
                                        if ($key == 0) :
                                            $only_start_time = DATE("H:i:s", strtotime($val['Timesheet']['start_time']));					
                                            $time_arr = explode(':', $only_start_time);
                                            $seconds_h = intval($time_arr[0]) * 3600;
                                            $seconds_m = intval($time_arr[1]) * 60;
                                            $seconds_s = intval($time_arr[2]);
                                            $start_hour = floor(($seconds_h + $seconds_m + $seconds_s) / (60*60));

                                            $end_hour = floor(24);

                                            $candlestick[date("Y-m-d", strtotime($val['Timesheet']['start_time']))] = array($start_hour, $end_hour);
                                        elseif ($key == count($dt) - 1) :
                                            $start_hour = floor(0);

                                            $only_end_time = DATE("H:i:s", strtotime($val['Timesheet']['end_time']));
                                            $time_arr = explode(':', $only_end_time);
                                            $seconds_h = intval($time_arr[0]) * 3600;
                                            $seconds_m = intval($time_arr[1]) * 60;
                                            $seconds_s = intval($time_arr[2]);
                                            $end_hour = floor(($seconds_h + $seconds_m + $seconds_s) / (60*60));

                                            $candlestick[date("Y-m-d", strtotime($val['Timesheet']['end_time']))] = array($start_hour, $end_hour);
                                        else :
                                            $start_hour = floor(0);
                                            $end_hour = floor(24);
                                            $candlestick[date("Y-m-d", strtotime($date_val))] = array($start_hour, $end_hour);
                                        endif;
                                    endforeach;
                                endif;
                            endforeach;
                        else :
                            $candlestick['X'] = array(0, 0);
                        endif;

                        $dates = array();
                        $current = strtotime($start_server);
                        $last = strtotime($end_server);
                        while( $current <= $last ) {	
                            $dates[] = DATE("Y-m-d", $current);
                            $current = strtotime("+1 day", $current);
                        }
                        $candlestick_data = array();
                        foreach ($dates as $date) :
                            foreach ($candlestick as $key => $val) :
                                if (strtotime($date) == strtotime($key)) :
                                    $candlestick_data[] = '["' . $date . '",' . $val[0] . ',' . $val[1] . ']';
                                else :
                                    $candlestick_data[] = '["' . $date . '",' . 0 . ',' . 0 . ']';
                                endif;
                            endforeach;
                            /*foreach ($candlestick as $subcandlestick) :
                                if (!in_array($subcandlestick, $candlestick_data)) :
                                    $candlestick_data[] = $subcandlestick;
                                endif;
                            endforeach;*/
                        endforeach;
                        $cs_final_data[] = $candlestick_data;
		}
                                
                
		$this->set('candlestick_users', $cs_users);
		$this->set('candlestick_final', $cs_final_data);
                //end candlestick
		
		$usernames = $this->User->find('all',array('fields'=>array('User.username'),'conditions'=>array('User.id'=>$users)));
		$managerList = array();
		if ($this->Auth->user('group_id') == 1){
                    $userList = $this->User->find('all', array(
                        'fields'=>array('User.id','User.full_name','User.photo','User.photo_dir'),
                        'order'=>array('User.first_name ASC','User.last_name ASC'),
                        'recursive' => -1
                    ));
                    
                    $managerList = $this->User->find('all', array(
                        'fields'=>array('User.id','User.full_name','User.photo','User.photo_dir'),
                        'conditions'=>array('User.group_id'=>2),
                        'order'=>array('User.first_name ASC', 'User.last_name ASC'),
                        'recursive' => -1
                    ));
		} else {
                    $directChildren = $this->User->children($this->Auth->user('id'));
                    foreach($directChildren as $directChildren){
                            $b[] = $directChildren['User']['id'];
                    }
                    $b[] = $this->Auth->user('id');
                    $a = $this->User->find('all', array(
                        'fields' =>array('User.id'),
                        'conditions'=>array(
                            'OR'=>array(
                                'User.id'=>$b,
                                'User.parent_id'=>$this->Auth->user('id')
                            )
                        ),
                        'recursive' => -1
                    ));
                    foreach($a as $val){
                        $child[] = $val['User']['id'];
                    }
                    
                    if($this->manager_see_multi_lavels == 1){
                        $userList = $this->User->find('all', array(
                            'fields'=>array('User.id','User.name','User.photo','User.photo_dir'),
                            'conditions'=>array(
                                'OR'=>array(
                                    'User.id'=>$this->Auth->user('id'),
                                    'User.parent_id'=>$this->Auth->user('id')
                                )
                            ),
                            'order' => array('User.first_name ASC','User.last_name ASC'),
                            'recursive' => -1
                        ));
                        
                        //populate manager list
                        $managerList = $this->User->find('all', array(
                            'fields'=>array('User.id','User.full_name','User.photo','User.photo_dir'),
                            'conditions'=>array(
                                'AND'=>array(
                                    'User.group_id'=>2,
                                    'User.id'=>$child
                                )
                            ),
                            'order'=>array('User.first_name ASC', 'User.last_name ASC'),
                            'recursive' => -1
                        ));
                    } else {
                        $userList = $this->User->find('all', array(
                            'fields'=>array('User.id','User.name','User.photo','User.photo_dir'),
                            'conditions'=>array(
                                'OR'=>array(
                                    'User.id'=>$this->Auth->user('id'),
                                    'User.parent_id'=>$this->Auth->user('id')
                                )
                            ),
                            'order' => array('User.first_name ASC','User.last_name ASC'),
                            'recursive' => -1
                        ));

                        //populate manager list
                        $managerList = $this->User->find('all', array(
                            'fields'=>array('User.id','User.full_name','User.photo','User.photo_dir'),
                            'conditions'=>array(
                                'AND'=>array(
                                    'User.group_id'=>2,
                                    'User.parent_id'=>$this->Auth->user('id')
                                )
                            ),
                            'order'=>array('User.first_name ASC', 'User.last_name ASC'),
                            'recursive' => -1
                        ));
                    }
		}
		
		$finalList = array();
		$finalPopulateList = array();
		foreach($userList as $uList){
			$temp = $uList['User'];
			if($uList['User']['photo']){
				$temp['photo'] = Router::url('/',true).'files/user/photo/'.$uList['User']['photo_dir'].'/view_'.$uList['User']['photo'];
			} else {
				$temp['photo'] = Router::url('/',true). 'img/no-picture.png';
			}
			if(isset($temp['photo_dir'])){
				unset($temp['photo_dir']);
			}
			if($temp['full_name']){
				$temp['name'] = $temp['full_name'];
				unset($temp['full_name']); 
			}
			$finalList[] = $temp;
			if(in_array($temp['id'],$users)){
				$finalPopulateList[] = $temp;
			}			
		}
		
		$reportUserList = array();
		foreach($users as $user){
			foreach ($finalList as $fnList){
				if($fnList['id'] == $user){
					$reportUserList[] = '<div style="margin-bottom:10px;"><a href="'. $this->base . '/timesheets/calendar/'.$fnList["id"]. '" style="text-decoration:none;">'.$fnList["name"].'</a><span>&nbsp;<span><img class="img-circle" style="width:32px;height32px;border-radius:50%" src="'.$fnList['photo'].'"/></div>';
                                        //$reportUserList[] = '<div style="margin-top:5px;">'.$fnList["name"].'<span>&nbsp;<span><img class="img-circle" style="width:32px;height32px;border-radius:50%" src="'.$fnList['photo'].'" width="32" height="32"/></div>';
				}
			}
		}
		//for manager list populate
						
			$finalManagerList = array();
			$finalPopulateManagerList = array();
			foreach($managerList as $mList){
				$temp = $mList['User'];
				if($uList['User']['photo']){
					$temp['photo'] = Router::url('/',true).'files/user/photo/'.$mList['User']['photo_dir'].'/view_'.$mList['User']['photo'];
				} else {
					$temp['photo'] = Router::url('/',true). 'img/no-picture.png';
				}
				if(isset($temp['photo_dir'])){
					unset($temp['photo_dir']);
				}
				if($temp['full_name']){
					$temp['name'] = $temp['full_name'];
					unset($temp['full_name']); 
				}
				$finalManagerList[] = $temp;
				if(in_array($temp['id'],$users)){
					$finalPopulateManagerList[] = $temp;
				}				
			}
			
			$reportManagerList = array();
			foreach($users as $user){
				foreach ($finalManagerList as $fnmList){
					if($fnmList['id'] == $user){
						$reportManagerList[] = '<div style="margin-top:5px;">'.$fnmList['name'].'<span>&nbsp;<span><img class="img-circle" style="width:32px;height32px;border-radius:50%" src="'.$fnmList['photo'].'" /></div>';
					}
				}
			}
		//end
		$this->request->data['Timesheet']['search_user_id'] = $user;
                $start_client = CakeTime::format('Y-m-d', strtotime($start_server), null, $this->userTimezone);
                $end_client = CakeTime::format('Y-m-d', strtotime($end_server), null, $this->userTimezone);
		$this->request->data['Timesheet']['search_report_from'] = $start_client;
		$this->request->data['Timesheet']['search_report_to'] = $end_client;
		$this->set('tokenUser',json_encode($finalList));
		$this->set('tokenManager',json_encode($finalManagerList));
		$this->set('prePopulate',json_encode($finalPopulateList));
		
		$this->set('dayHours',$dayHours);
		$this->set('usernames',$usernames);
		$this->set('reportUsers',$reportUserList);
		
	}
	
	public function getManagerUsers(){
                $this->layout = "ajax";
		$this->autoRender = false;
		if($this->request->is('post')){
		$id = $this->request->data['user'];
		$managerList = $this->User->find('all',array(
                    'fields'=>array('id','full_name','photo','photo_dir'),
                    'conditions'=>array(
                        'User.parent_id'=>$id
                    ),
                    'order'=>array('User.first_name ASC', 'User.last_name ASC'),
                    'recursive' => -1
                ));
                
                //debug($managerList); exit;
                        
                        $finalManagerList = array();
			$finalPopulateManagerList = array();
			foreach($managerList as $mList){
				$temp = $mList['User'];
				if($mList['User']['photo']){
					$temp['photo'] = Router::url('/',true).'files/user/photo/'.$mList['User']['photo_dir'].'/view_'.$mList['User']['photo'];
				} else {
					$temp['photo'] = Router::url('/',true). 'img/no-picture.png';
				}
				if(isset($temp['photo_dir'])){
					unset($temp['photo_dir']);
				}
				if($temp['full_name']){
					$temp['name'] = $temp['full_name'];
					unset($temp['full_name']); 
				}
				$finalManagerList[] = $temp;				
			}			
			echo json_encode($finalManagerList);
			exit;
		}
		
	}
	
	public function getReportsUsers(){
                $this->layout = "ajax";
		$dayHours = array();
		if($this->request->is('post') || $this->request->is('ajax')){
			foreach($users as $user){
				$dayHours[] = $this->Timesheet->getDayHours($start, $end, $user);
			}
		}
		$this->set('dayHours',$dayHours);
	}
        
	public function calendarFeedNotEndedEvent() {
                $userId = $this->Auth->user('id');
                $userDetails = $this->User->find('all', array('conditions'=>array('User.id'=>$userId)));                
                $userTimezone = $userDetails[0]['User']['user_timezone'];
                
                $this->layout = 'ajax';
		$endDate = array();
		if($this->request->is('post')){
                        $id = $this->request->data['id'];
                        $endDateData = $this->Timesheet->find('all', array('conditions' => array('Timesheet.id' => $id)));
                        //echo CakeTime::format('Y-m-d H:i',$endDateData[0]['Timesheet']['end_time'],null,$this->userTimezone);
                        $endDate[] = CakeTime::format('Y-m-d H:i',$endDateData[0]['Timesheet']['end_time'],null,$userTimezone);
                        //$this->set('json', json_encode($endDate));
                        echo json_encode($endDate);
                        exit;
                }
        }
        
        public function calendarFeed(){
                $userTimezone = new DateTimeZone($this->userTimezone);
                $serverTimezone = new DateTimeZone($this->serverTimezone);
		$this->layout = 'ajax';
		$calendarData = array();
		if($this->request->is('post')){ 
                        $start_time = date('Y-m-d H:i:s', strtotime($this->request->data['start']));//debug($this->request->data['start']); exit;
                        $tmp_start_time = CakeTime::toServer($start_time,$userTimezone);
                        $start_time_server = new DateTime($tmp_start_time, $serverTimezone);
                        $start = date('Y-m-d H:i:s', $start_time_server->format('U')); 
			
			$end_time = date('Y-m-d H:i:s', strtotime($this->request->data['end']));//debug($this->request->data['end']); exit;
                        $tmp_end_time = CakeTime::toServer($end_time,$userTimezone);
                        $end_time_server = new DateTime($tmp_end_time, $serverTimezone);
                        $end = date('Y-m-d H:i:s', $end_time_server->format('U')); 
                        
			$user = $this->request->data['user'];
			$calendarTimesheets = $this->Timesheet->find('all',array('conditions'=>array(
					'User.id'=>$user,
					'Timesheet.start_time >=' => $start,
					'Timesheet.start_time <' => $end
			)));
                        
			
			foreach($calendarTimesheets as $calendarTimesheet) {
				if ($this->Auth->user('group_id')==1 || $calendarTimesheet['User']['parent_id'] == $this->Auth->user('id')){
			
					$statusUpdate = '<div class="status-icons">';
					//submitted
					$statusUpdate .= '<a href="javascript:changeToSubmitted('.$calendarTimesheet['Timesheet']['id'].')" class="change-status submitted ';
			
					if($calendarTimesheet['ApprovalStatus']['id']=='1'){
						$statusUpdate .= 'status-active ';
					}
					$statusUpdate .= ' row-submitted-';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= ' row-';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= '"  title="Submitted" alt="Submitted" timesheetid="';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= '" statusid="1" ><i class="icon-question"></i></a>';
			
					//approved
					$statusUpdate .= '<a href="javascript:changeToApproved('.$calendarTimesheet['Timesheet']['id'].')" class="change-status approved ';
					if($calendarTimesheet['ApprovalStatus']['id']=='2'){
						$statusUpdate .= 'status-active ';
					}
					$statusUpdate .= ' row-approved-';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= ' row-';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= '"  title="Submitted" alt="Rejected" timesheetid="';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= '" statusid="2" ><i class="icon-ok"></i></a>';
			
					//rejected
					$statusUpdate .= '<a href="javascript:changeToRejected('.$calendarTimesheet['Timesheet']['id'].')" class="change-status rejected ';
					if($calendarTimesheet['ApprovalStatus']['id']=='3'){
						$statusUpdate .= 'status-active ';
					}
					$statusUpdate .= ' row-rejected-';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= ' row-';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= '"  title="Submitted" alt="Submitted" timesheetid="';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= '" statusid="3" ><i class="icon-ban-circle"></i></a>';
			
					//revision
					$statusUpdate .= '<a href="javascript:changeToRevision('.$calendarTimesheet['Timesheet']['id'].')" class="change-status revision ';
					if($calendarTimesheet['ApprovalStatus']['id']=='4'){
						$statusUpdate .= 'status-active ';
					}
					$statusUpdate .= ' row-revision-';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= ' row-';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= '"  title="Needs Review" alt="Needs Review" timesheetid="';
					$statusUpdate .= $calendarTimesheet['Timesheet']['id'];
					$statusUpdate .= '" statusid="4" ><i class="icon-refresh"></i></a>';
			
					$statusUpdate .= '<span class="spinner row-'. $calendarTimesheet['Timesheet']['id'] .'"></i></span>';
					$statusUpdate .= '</div>';
				} else {
					$statusUpdate = '';
				}
				
				$editAllowed = $this->isTimesheetEditAllowed($calendarTimesheet['Timesheet']['id']);
				
				$userId = $this->Auth->user('id');
                                $userDetails = $this->User->find('all', array('conditions'=>array('User.id'=>$userId)));                
                                $userTimezone = $userDetails[0]['User']['user_timezone'];
                                $calendarData[] = array(
						'id' => $calendarTimesheet['Timesheet']['id'],
						'title'=>CakeTime::format('g:i A',$calendarTimesheet['Timesheet']['start_time'], null, $this->userTimezone) . ' - ' .
						CakeTime::format('g:i A',$calendarTimesheet['Timesheet']['end_time'], null, $this->userTimezone)."\r\n".'['.substr($calendarTimesheet['Timesheet']['hours'],0,strlen($calendarTimesheet['Timesheet']['hours'])-3) . ' total'.']'."\r\n"."\r\n".$calendarTimesheet['Timesheet']['note'],
						'start'=>CakeTime::format('Y-m-d H:i:s',$calendarTimesheet['Timesheet']['start_time'], null, $this->userTimezone),
						'end' => CakeTime::format('Y-m-d H:i:s',$calendarTimesheet['Timesheet']['end_time'], null, $this->userTimezone),
						'allDay' => false,
						'url' => Router::url('/',true) . 'timesheets/edit/'.$calendarTimesheet['Timesheet']['id'],
						'details' => $calendarTimesheet['Timesheet']['note'],
						'className' => 'status'.$calendarTimesheet['ApprovalStatus']['id']. ' ts-'.$calendarTimesheet['Timesheet']['id'],
						//'toolTip' => '<strong>'.substr($calendarTimesheet['Timesheet']['hours'],0,strlen($calendarTimesheet['Timesheet']['hours'])-3) . ' hours'."</strong>\r\n<br>".$calendarTimesheet['Timesheet']['note'],
						'statusUpdate' => $statusUpdate,
						'editAllowed' => $editAllowed
				);
			}
		}
                //echo json_encode($calendarData);
                $this->set("json", json_encode($calendarData));
	}
	
	public function getTotalHours(){
                $this->layout = 'ajax';
		//Configure::write()// dissable error
		
		$hourMessage = '';
		if($this->request->is('post')){
			if(isset($this->request->data['start'])){
				$user = $this->request->data['user'];
				$start = $this->request->data['start'];
				$end = $this->request->data['end'];
				
				$totalSeconds = 0;
				
				// get timesheets -start end is between the dates 
				$userTimesheets = $this->Timesheet->find('all',array('conditions'=>array(
						'User.id'=>$user,
						'Timesheet.start_time >=' => CakeTime::toServer($start,$this->userTimezone),
						'Timesheet.end_time <=' => CakeTime::toServer($end,$this->userTimezone)
				)));
				
				foreach($userTimesheets as $userTimesheet) {
					$seconds = 0;
					$parts = explode(':', $userTimesheet['Timesheet']['hours']);
					
					$seconds = ($parts[0] * 60 * 60) + ($parts[1] * 60) + $parts[2];
					
					$totalSeconds = $totalSeconds + $seconds;
					
				}
				
				// get timesheets -starts before the cal-start-date but ends before cal-end-date
				$userTimesheets = $this->Timesheet->find('all',array('fields'=>array('start_time','TIMEDIFF(Timesheet.end_time,\''.$start.'\') as phours'),'conditions'=>array(
						'User.id'=>$user,
						'Timesheet.start_time <' => CakeTime::toServer($start,$this->userTimezone),
						'Timesheet.end_time <=' => CakeTime::toServer($end,$this->userTimezone),
						'Timesheet.end_time >' => CakeTime::toServer($start,$this->userTimezone)
				)));
				
				foreach($userTimesheets as $userTimesheet) {
					$seconds = 0;
					$parts = explode(':', $userTimesheet[0]['phours']);
						
					$seconds = ($parts[0] * 60 * 60) + ($parts[1] * 60) + $parts[2];
						
					$totalSeconds = $totalSeconds + $seconds;
				}
				
				// get timesheets -starts after cal-start-date but ends after cal-end-date
				$userTimesheets = $this->Timesheet->find('all',array('fields'=>array('TIMEDIFF(\''.$end.'\',Timesheet.start_time) as lhours'),'conditions'=>array(
						'User.id'=>$user,
						'Timesheet.start_time >=' => CakeTime::toServer($start,$this->userTimezone),
						'Timesheet.end_time >' => CakeTime::toServer($end,$this->userTimezone),
						'Timesheet.start_time <' => CakeTime::toServer($end,$this->userTimezone)
				)));
				
				foreach($userTimesheets as $userTimesheet) {
					$seconds = 0;
					$parts = explode(':', $userTimesheet[0]['lhours']);
						
					$seconds = ($parts[0] * 60 * 60) + ($parts[1] * 60) + $parts[2];
						
					$totalSeconds = $totalSeconds + $seconds;
				}
				$totalHours = '';
				// extract hours
				$hours = floor($totalSeconds / (60 * 60));
				
				// extract minutes
				$divisor_for_minutes = $totalSeconds % (60 * 60);
				$minutes = floor($divisor_for_minutes / 60);
				
				// extract the remaining seconds
				$divisor_for_seconds = $divisor_for_minutes % 60;
				$seconds = ceil($divisor_for_seconds);
				if($hours == 0){
					$hours = '00';
				}
				if($minutes == 0){
					$minutes = '00';
				}
				$totalHours = $hours .':'.$minutes;
				
				$hourMessage = "Total hours worked from ".substr($this->request->data['start'], 0,strlen($this->request->data['start'])-5)." to ".substr($this->request->data['end'], 0,strlen($this->request->data['end'])-5)." = ".$totalHours." hours";
			}
		}
		echo $hourMessage; exit;
		
	}
	
        public function userTimesheet($user= NULL) {
                $this->layout = 'ajax';
		
		$timesheets = $this->Timesheet->find('all',array('conditions'=>array('User.id'=>$user)));
		foreach($timesheets as $timesheet){
			
			$data[] = array(
					'id' => $timesheet['Timesheet']['id'],
					'title'=>$timesheet['Timesheet']['note'],
					'start'=>CakeTime::format('Y-m-d H:i:s',$timesheet['Timesheet']['start_time'],null,$this->userTimezone),
					'end' => CakeTime::format('Y-m-d H:i:s',$timesheet['Timesheet']['end_time'],null,$this->userTimezone),
					'allDay' => false,
					//'url' => Router::url('/',true) . '/timesheet/edit/'.$timesheet['Timesheet']['id'],
					'details' => $timesheet['Timesheet']['note'],
					'className' => 'status'.$timesheet['ApprovalStatus']['id'],
					'toolTip' => $timesheet['Timesheet']['note']
			);
		}
		$this->set("json", json_encode($data));
	}
	
	public function dashboard($id=null) {
                //TODO date time work
                $option_server_timezone = $this->Option->find('first', array('conditions' => array('name' => 'server_timezone')));
                $option_hours_before_auto_clock_out = $this->Option->find('first',array('conditions'=>array('name'=>'hours_before_auto_clock_out')));
                $option_hours_before_auto_clock_out = $option_hours_before_auto_clock_out['Option']['value'];
                $option_auto_clock_out_hours = $this->Option->find('first',array('conditions'=>array('name'=>'auto_clock_out_hours')));
                $option_auto_clock_out_hours = $option_auto_clock_out_hours['Option']['value'];
                
                $this->set('userTimezone', $this->userTimezone);	
                
                $this->set('userTimezone', $this->userTimezone);
                $userTimezone = new DateTimeZone($this->userTimezone);
                $start = new DateTime(date('Y-m-d H:i:s'), $userTimezone);
                $start = date('Y-m-d H:i:s', $start->format('U'));
                $end = new DateTime(date('Y-m-d H:i:s', strtotime('-1 day')), $userTimezone);
                $end = date('Y-m-d H:i:s', $end->format('U'));
                
                $serverTimezone = new DateTimeZone(date_default_timezone_get());
                $start = new DateTime($start, $serverTimezone);
                $start = date('Y-m-d H:i:s', $start->format('U'));
                $end = new DateTime($end, $serverTimezone);
                $end = date('Y-m-d H:i:s', $end->format('U'));	
                
                $option_hours_before_auto_clock_out_second = $option_hours_before_auto_clock_out * 3600;
                $end_auto_clockout_second = strtotime($start)  - $option_hours_before_auto_clock_out_second;
                $end_auto_clockout = date('Y-m-d H:i:s', $end_auto_clockout_second);
                
               
                //for any open timesheet checking
                $previousTimesheets = $this->Timesheet->find('all', array(
                        'conditions' => array(
                                'Timesheet.user_id' => $this->Auth->user('id'),
				'Timesheet.end_time <=' => $end_auto_clockout,
				'Timesheet.start_time = Timesheet.end_time'
                                )
                        )
                );
                
                $option_timer_endtime = $this->Option->find('first',array('conditions'=>array('name'=>'timer_endtime')));
                if ($option_timer_endtime['Option']['value'] == true) {
                        $auto_fill = true;
                } else {
                        $auto_fill = false;
                }
		
		if ($auto_fill) :
                        foreach($previousTimesheets as $previousTimesheet) {
                                $option_auto_clock_out_hours_second = $option_auto_clock_out_hours * 3600;
                                $prevEnd = strtotime($previousTimesheet['Timesheet']['end_time']) + $option_auto_clock_out_hours_second; 
                                
                                $setEndTime = date('Y-m-d H:i:s', $prevEnd);
                               
                                $this->Timesheet->id = $previousTimesheet['Timesheet']['id'];
                                $this->Timesheet->saveField('end_time',$setEndTime);
                                $this->Timesheet->saveField('note','[Auto filled]');
                                
                        }
                endif; 
		
                
                $timesheets = $this->Timesheet->find('all', array(
                        'conditions' => array(
                                'Timesheet.user_id' => $this->Auth->user('id'),
                                'Timesheet.end_time >=' => $end,
                                ),
				'order' => 'Timesheet.end_time ASC'
                        )
                );
				
				
                $dayTimesheets = array();
                $open = false;
		//$greetCompareTime = $curDateTime; // current time by default
		
		if($timesheets){
			$greetCompareTime = $timesheets[0]['Timesheet']['start_time'];
			
			foreach($timesheets as $timesheet) {
                                if($timesheet['Timesheet']['start_time'] == $timesheet['Timesheet']['end_time']) {
                                        $timesheet['Timesheet']['end_time'] = ''; //make end time blank for display
					$dayTimesheets[] = $timesheet;
                                        $open = true;
				} else {
					$dayTimesheets[] = $timesheet;
				}
			}
		}
                $this->set('dayTimesheets',$dayTimesheets);
		$this->set('open',$open);
		
		//vacation remaining
                //$userTimezone = new DateTimeZone($userTimezone);
                $fdoy = new DateTime(date('Y-m-d', strtotime('first day of January this year')), $serverTimezone);                 
                $fdoy = date('Y-m-d', $fdoy->format('U'));
                $ldoy = new DateTime(date('Y-m-d', strtotime('last day of December this year')), $serverTimezone);                 
                $ldoy = date('Y-m-d', $ldoy->format('U'));
                
                /*$fdoy = new DateTime($fdoy, $serverTimezone);                 
                $fdoy = date('Y-m-d', $fdoy->format('U'));
                $ldoy = new DateTime($ldoy, $serverTimezone);                 
                $ldoy = date('Y-m-d', $ldoy->format('U'));*/
                
                $this->loadModel('Vacation');
                //for vacations
                $vacations = $this->Vacation->find('all', array(
                    'conditions' => array(
                        'Vacation.user_id' => $this->Auth->user('id'),
                        'Vacation.start_date <>' => '0000-00-00',
                        'Vacation.end_date <>' => '0000-00-00',
                        //'Vacation.approval_status_id' => 2,
                        'Vacation.start_date >=' => $fdoy,
                        'Vacation.end_date <=' => $ldoy
                    )                    
                ));
                
                $totalVacations = 0;
                foreach($vacations as $vacation) :
                    $vc = 0;
                    $temp_dates = $this->_dateRange($vacation['Vacation']['start_date'], $vacation['Vacation']['end_date']);
                    if ($vacation['Vacation']['start_date'] == $vacation['Vacation']['end_date']) :
                        foreach($temp_dates as $vdate) {
                            if(!$this->isWeekend($vdate)) {
                                $vc = 1;
                            }
                        }
                    else :
                        $temp_count = 0;
                        foreach($temp_dates as $vdate) {
                            if(!$this->isWeekend($vdate)) {
                                $temp_count ++;
                            }
                        }
                        $vc = $vc + $temp_count;
                        
                    endif;
                    $totalVacations = $totalVacations + $vc;
                endforeach;
                
                //for sick days
                $vacations = $this->Vacation->find('all', array(
                    'conditions' => array(
                        'Vacation.user_id' => $this->Auth->user('id'),
                        'Vacation.type_id' => 1,
                        'Vacation.start_date <>' => '0000-00-00',
                        'Vacation.end_date <>' => '0000-00-00',
                        //'SickDay.approval_status_id' => 2,
                        'Vacation.start_date >=' => $fdoy,
                        'Vacation.end_date <=' => $ldoy
                    )                    
                ));
                             
                $totalSickDays = 0;
                foreach($vacations as $vacation) :
                    $sd = 0;
                    $temp_dates = $this->_dateRange($vacation['Vacation']['start_date'], $vacation['Vacation']['end_date']);
                    if ($vacation['Vacation']['start_date'] == $vacation['Vacation']['end_date']) :
                        foreach($temp_dates as $vdate) {
                            if(!$this->isWeekend($vdate)) {
                                $sd = 1;
                            }
                        }
                    else :
                        $temp_count = 0;
                        foreach($temp_dates as $vdate) {
                            if(!$this->isWeekend($vdate)) {
                                $temp_count ++;
                            }
                        }
                        $sd = $sd + $temp_count;                        
                    endif;
                    $totalSickDays = $totalSickDays + $sd;
                endforeach;
                                
                $this->loadModel('Job');
                $job = $this->Job->find('all', array(
                    'conditions' => array('Job.user_id' => $this->Auth->user('id')),
                    'order' => array('Job.modified'=>'desc'),
                    'limit' => 1
                    )
                );
                if ($job[0]['Job']['vacation_days'] > 0) {
                    $total_vacations = $job[0]['Job']['vacation_days'];
                } else {
                    $option_vacation_per_year = $this->Option->find('first',array('conditions'=>array('name'=>'vacation_per_year')));
                    if(!empty($option_vacation_per_year)) {
                            $total_vacations = $option_vacation_per_year['Option']['value'];
                    } else {
                            $total_vacations = 0;
                    }
                }
                                
                $this->set('total_vacation', $total_vacations);
                $vacations = $totalVacations;
                $this->set('total_sickdays', $totalSickDays);
                $this->set('vacation', $vacations);
                
                $class = '';
                if ($total_vacations != 0) {
                    $cal = round(($vacations/ $total_vacations)*100);
                    if ($cal <= 50) {
                        $class = 'meter progress-success nostripes';
                        $width = $cal . '%';
                    } elseif ($cal > 50 && $cal < 100) {
                        $class = 'meter progress-warning nostripes';
                        $width = $cal . '%';
                    } elseif ($cal >= 100) {
                        $class = 'meter progress-danger nostripes';
                        $width = '100%';
                    }
                }
                
                $this->set('vacation_class', $class);
                $this->set('vacation_width', $width);
                
                //Latest announcements
                $this->loadModel('Announcement');
                $announcements = $this->Announcement->find('all', array(
                    'order' => 'Announcement.modified DESC',
                    'limit' => 5
                ));
                $this->set('announcements', $announcements);
                
                //Last two weeks graph
                $day = date('w');
                $week_start = date('Y-m-d H:i:s', strtotime('-'.$day.' days'));
                //$week_end = date('Y-m-d H:i:s ', strtotime('+'.(6-$day).' days'));
                $last_two_weeks_start = date('Y-m-d H:i:s', strtotime($week_start . ' -7 days'));
                $last_two_weeks_end = date('Y-m-d H:i:s', strtotime(date('Y-m-d H:i:s') . ' +0 days'));
                
                $start_client = CakeTime::format('Y-m-d', strtotime($last_two_weeks_start), null, $this->userTimezone);                 
                $end_client = CakeTime::format('Y-m-d', strtotime($last_two_weeks_end), null, $this->userTimezone);
                
                $last_two_weeks_start = CakeTime::format('Y-m-d H:i:s', strtotime($start_client), null, $this->serverTimezone);
                $last_two_weeks_end = CakeTime::format('Y-m-d H:i:s', strtotime($end_client . ' 23:59:59'), null, $this->serverTimezone);
                $dayHours = $this->Timesheet->getDayHours($last_two_weeks_start, $last_two_weeks_end, $this->Auth->user('id'));
                                              
                //cache
                if ($this->Cookie->read('cachetime')) {
                    if ($this->Cookie->read('cachetime') > CakeTime::format('Y-m-d', date('Y-m-d H:i:s'), null, $this->userTimezone)) {
                        $this->set('graph', $this->Cookie->read('cachedata'));                        
                    } else {
                        $validtime = CakeTime::format('Y-m-d', date('Y-m-d H:i:s', strtotime('+12 hours')), null, $this->userTimezone);
                        $this->Cookie->write('cachetime', $validtime, false, '20 days');
                        $this->Cookie->write('cachedata', $dayHours, false, '20 days');
                        $this->set('graph', $dayHours);
                    }                    
                } else {
                    $validtime = CakeTime::format('Y-m-d', date('Y-m-d H:i:s', strtotime('+12 hours')), null, $this->userTimezone);
                    $this->Cookie->write('cachetime', $validtime, false, '20 days');
                    $this->Cookie->write('cachedata', $dayHours, false, '20 days');
                    $this->set('graph', $dayHours);
                }                                
        }
        
        public function timer_edit(){
                $this->autoRender = false;
		//$this->layout = 'ajax';
		if(isset($this->request->data['pk'])){
			$id = $this->request->data['pk'];
			$field = $this->request->data['name'];
			$value = $this->request->data['value'];
			
			$this->Timesheet->id = $id;
			$this->Timesheet->saveField($field,$value);
		}
	}
	
	public function timer_table(){//TODO timezone glitch work
                $this->layout = 'ajax';
		
                $this->set('userTimezone', $this->userTimezone);
                $userTimezone = new DateTimeZone($this->userTimezone);
                $start = new DateTime(date('Y-m-d H:i:s'), $userTimezone);
                $start = date('Y-m-d H:i:s', $start->format('U'));
                $end = new DateTime(date('Y-m-d H:i:s', strtotime('-1 day')), $userTimezone);
                $end = date('Y-m-d H:i:s', $end->format('U'));
                
                $serverTimezone = new DateTimeZone($this->serverTimezone);
                $start = new DateTime($start, $serverTimezone);
                $start = date('Y-m-d H:i:s', $start->format('U'));
                $end = new DateTime($end, $serverTimezone);
                $end = date('Y-m-d H:i:s', $end->format('U'));
                
                $timesheets = $this->Timesheet->find('all', array(
                        'conditions' => array(
                                'Timesheet.user_id' => $this->Auth->user('id'),
                                'Timesheet.end_time >=' => $end
                                ),
								'order' => 'Timesheet.end_time ASC'
                        )
                );
		$dayTimesheets = array();
		if($timesheets){
			foreach($timesheets as $timesheet){
				if($timesheet['Timesheet']['start_time'] == $timesheet['Timesheet']['end_time'])
				{
					$timesheet['Timesheet']['end_time'] = ''; //make end time blank for display
					$dayTimesheets[] = $timesheet;
						
				} else {
					$dayTimesheets[] = $timesheet;
				}
			}
		}
                $this->set('dayTimesheets',$dayTimesheets);
	}
	
	public function timer_start(){// TODO test for possible date glitch in retirving current job
                Configure::write('debug',0);//dissable error message for ajax
                $this->layout = 'ajax';
                
		$userId = $this->Auth->user('id');
                //$start = date('Y-m-d H:i:s');
                $userDetails = $this->User->find('all', array('conditions'=>array('User.id'=>$userId)));
               
                
                $option_server_timezone = $this->Option->find('first', array('conditions' => array('name' => 'server_timezone')));
                if(!empty($option_server_timezone)) {
                        $server_timezone = $option_server_timezone['Option']['value'];                            
                } else {
                        $server_timezone = 'UTC';
                }
                
                $currentDate = date('Y-m-d H:i:s');
                $serverTimezone = new DateTimeZone($server_timezone);
                $start = CakeTime::format('Y-m-d H:i:s',$currentDate,null,$serverTimezone);
               
                
                $success = false;
		$timesheet = array();
		
                $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'default_work_description')));
                if(!empty($option_setting)){
                        $default_text = $option_setting['Option']['value'];
                }
                else {
                        $default_text = 'Working';
                }
                $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'auto_approve_timesheet')));
                if(!empty($option_setting)){
                        $autoApprove = $option_setting['Option']['value'];
                }
                else {
                        $autoApprove = false;
                }

                $timesheet['Timesheet']['user_id'] = $userId;
                $timesheet['Timesheet']['start_time'] = $start;
                $timesheet['Timesheet']['end_time'] = $start;
                $timesheet['Timesheet']['note'] = $default_text;

                if($autoApprove == true){
                        $timesheet['Timesheet']['approval_status_id'] = 2; //approved
                } else {
                        $timesheet['Timesheet']['approval_status_id'] = 1; //submitted
                }

                $this->Timesheet->create();
                if($this->Timesheet->save($timesheet)){
                        $success = true;
                } else {
                        $success = false;
                }
                
                echo json_encode($success);
                exit;
	}
	
	public function timer_end($id=NULL){//TODO check for possible date glitch
                Configure::write('debug',0);
		$this->layout = 'ajax';
		$userId = $this->Auth->user('id');
		$userDetails = $this->User->find('all', array('conditions'=>array('User.id'=>$userId)));
                
                $option_server_timezone = $this->Option->find('first', array('conditions' => array('name' => 'server_timezone')));
                if(!empty($option_server_timezone)) {
                        $server_timezone = $option_server_timezone['Option']['value'];                            
                } else {
                        $server_timezone = 'UTC';
                }
                
                $currentDate = date('Y-m-d H:i:s');
                $serverTimezone = new DateTimeZone($server_timezone);
                $stop_time = CakeTime::format('Y-m-d H:i:s',$currentDate,null,$serverTimezone); 
                
                $timesheets = $this->Timesheet->find('all', array(
                    'joins' => array(
                        array(
                            'table' => 'timesheets',
                            'alias' => 'T',
                            'type' => 'INNER',
                            'conditions' => array(
                                'Timesheet.start_time = T.end_time'
                            )
                        )
                    ),
                    'conditions' => array(
                        'Timesheet.user_id' => $userId
                    ),
                    'fields' => array('Timesheet.*'),
                    'limit' => 1,
                    'order' => 'Timesheet.id DESC'
                ));

                $tid = NULL;
		$success = false;
		if($timesheets){
				
                        $tid =  $timesheets[0]['Timesheet']['id'];
			if($tid){ // got open timesheet
				$this->Timesheet->id = $tid;
				if($this->Timesheet->saveField('end_time',$stop_time)){
					// saved
					$success = true;
				} else {
					// cannot save
					$success = false;
				}
			} else  { // no open timesheet found
				// cannot save
				$success = false;
			}
		} else {
			// cannot save
			$success = false;
		}
		
		echo json_encode($success); exit;
	}
	
	public function timer_delete($id=NULL){
                $this->layout = 'ajax';
		$userId = $this->Auth->user('id');
		$success = false;
		if($this->request->is('POST') && isset($this->request->data['id'])){
			$this->Timesheet->id = $this->request->data['id'];
			// check current user is the owner
			$timesheet = $this->Timesheet->read();
			if(isset($timesheet['Timesheet']['user_id']) && ($timesheet['Timesheet']['user_id'] == $userId)){
				if($this->Timesheet->delete()){
					$success = true;
				} else {
					$success = false;
				}
			} else {
				$success = 'not the current user';
			}
			
		} else {
			$success = false;
		}
		echo json_encode($success); exit;
	}
	
	public function updateStatus($id=NULL) {
		
	}
	
	public function update() {
		
	}
	
	public function view($id = null){
                $this->Timesheet->id = $id;
		if(!$this->Timesheet->exists()){
			throw new NotFoundException('Record not found');
		}
		
		$user_id = $this->Timesheet->read(array('Timesheet.user_id','User.parent_id'), $id);
		
		if($this->Auth->user('group_id') == 3 && (($user_id['Timesheet']['user_id'] != $this->Auth->user('id')) && ($user_id['User']['parent_id'] != $this->Auth->user('id')))) {
			$this->Session->setFlash(__('Oops! Looks like you are not the owner of Timesheet. Only the user corresponding to the Timesheet can view it.'),'alert',array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		} elseif ($this->Auth->user('group_id') == 3 && ($user_id['User']['parent_id'] == $this->Auth->user('id'))) {
			//manager
		}
		$timesheet = $this->Timesheet->read();
	
		$this->set('timesheet',$timesheet);
	
	}
	public function ajax_joblist($id = null) {//TODO check for possible date glitch
                $curdate = date('Y-m-d H:i:s');
		if($this->request->is('post')){
			if (is_numeric($id)) {
				
				$jobList = $this->Job->find('list',array(
						'conditions'=> array(
								'AND' => array(
									'Job.user_id' => $id,
									'Job.end_date >= '=>$curdate
								)
						)
				));
				$this->set('jobList',$jobList);
			}
			else {
				$this->set('jobList',array());
			}
		} else {
			$this->set('jobList',array());
		}
	}
        
        
	public function add($arg = null) { 
		$userTimezone = new DateTimeZone($this->userTimezone);
		$date = CakeTime::format('Y-m-d H:i', date('Y-m-d H:i:s'), null, $this->userTimezone);
		$this->set('today', $date);
		
		$this->loadModel('Option');
		$options = $this->Option->find('first', array('fields'=>array('value'), 'conditions'=>array('name'=>'user_add_timesheet_calendar')));
		$user_timesheet_add_right = false;
		if ($options['Option']['value'] == 1) {
			$user_timesheet_add_right = true;
		}
        if ($this->Auth->user('group_id') == 3) {
			if (!$user_timesheet_add_right) {
				$this->Session->setFlash(__('The admin has disabled adding or editing of timesheets outside the timer.'));
				if ($arg != null) {
					$comp = explode('-', $arg);
					$this->redirect(array('controller' => strtolower($comp[0]), 'action' => $comp[1]));                            
				}
			}
		}
		
		if ($this->request->is('post') || $this->request->is('ajax')) {
			$isAjax = false;
			if (isset($this->request->data['Timesheet']['ajax'])) {
				$isAjax = true;
			}
			if ($this->Auth->user('group_id') != 1) {
				$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'auto_approve_timesheet')));
				if (!empty($option_setting)) {
					$autoApprove = $option_setting['Option']['value'];
				} else {
					$autoApprove = false;
				}
				
				if ($autoApprove == true) {
					$this->request->data['Timesheet']['approval_status_id'] = 2; //approved
				} else {
					$this->request->data['Timesheet']['approval_status_id'] = 1; //submitted
				}
			}

			$curdate = CakeTime::format('Y-m-d H:i:s', date('Y-m-d H:i:s'), null, $this->userTimezone);
			$curdate = CakeTime::format('Y-m-d H:i:s', strtotime($curdate), null, $this->serverTimezone);
			$this->request->data['Timesheet']['approved_by_id'] = $this->Auth->user('id');
			$this->request->data['Timesheet']['approved_at'] = $curdate;
			
			$serverTimezone = new DateTimeZone($this->serverTimezone);
			if (isset($this->request->data['Timesheet']['start_time'])) {
				$start_time = date('Y-m-d H:i:s', strtotime($this->request->data['Timesheet']['start_time'].':00'));
				$tmp_start_time = CakeTime::toServer($start_time,$userTimezone);
				$start_time_server = new DateTime($tmp_start_time, $serverTimezone);
				$start = date('Y-m-d H:i:s', $start_time_server->format('U'));
				$this->request->data['Timesheet']['start_time'] = $start;
			}
			
			if (isset($this->request->data['Timesheet']['end_time'])) {
				$end_time = date('Y-m-d H:i:s', strtotime($this->request->data['Timesheet']['end_time'].':00')); 
				$tmp_end_time = CakeTime::toServer($end_time,$userTimezone);
				$end_time_server = new DateTime($tmp_end_time, $serverTimezone);
				$end = date('Y-m-d H:i:s', $end_time_server->format('U'));
				$this->request->data['Timesheet']['end_time'] = $end;                                
			}
			
			$this->Timesheet->create();
			$isSaved = $this->Timesheet->save($this->request->data);
			if ($isSaved) {
				if ($isAjax == false) {
					$this->Session->setFlash(__('New Timesheet added'),'alert');
					$this->redirect(array('action'=>'calendar'));
				} else {
					echo 'Ok'; exit;
				}
			} else {
				if($isAjax == false) {
					$this->Session->setFlash(__('Unable to add'),'alert', array('class'=>'alert-error'));
				} else {
					echo 'Unable to add'; exit;
				}
			}
		} elseif ($this->request->is('get')) {
			if (isset($this->request['url']['start'])) $this->request->data['Timesheet']['start_time'] = $this->request['url']['start'];
			if (isset($this->request['url']['end'])) $this->request->data['Timesheet']['end_time'] = $this->request['url']['end'];
			if (isset($this->request['url']['url'])) $this->request->data['Timesheet']['user_id'] = $this->request['url']['usr'];
		}
		$this->set('userList',$this->User->find('list'));
		$this->set('approvalStatusList',$this->ApprovalStatus->find('list'));
	}
	
	public function edit($id = null){
		$this->Timesheet->id = $id;
		if(!$this->Timesheet->exists()){
			throw new NotFoundException('Record not found');
		}
		$this->set('userList',$this->User->find('list'));
		$this->set('approvalStatusList',$this->ApprovalStatus->find('list'));
		$this->request->data = $this->Timesheet->read();
		if(isset($this->request->data['Timesheet']['start_time'])){
			$this->request->data['Timesheet']['start_time'] = CakeTime::format('Y-m-d H:i',$this->request->data['Timesheet']['start_time'],null,$this->userTimezone);
		}
		if(isset($this->request->data['Timesheet']['end_time'])){
			$this->request->data['Timesheet']['end_time'] = CakeTime::format('Y-m-d H:i',$this->request->data['Timesheet']['end_time'],null,$this->userTimezone);
		}
		$jobList = $this->Job->find('list',array(
				'conditions'=> array(
						'Job.id' => $this->request->data['Timesheet']['user_id'],
						'Job.end_date <= '=>$curdate
				)
		));		
		$this->set('jobList',$jobList);
		$is_manager = false;
		$user_id = $this->Timesheet->read(array('Timesheet.user_id','User.parent_id'), $id);
		if ($user_id['User']['parent_id'] == $this->Auth->user('id')) {
			$is_manager = true;
		}
		$this->set('is_manager',$is_manager);
		
		$this->loadModel('Option');
		$options = $this->Option->find('first', array('fields'=>array('value'), 'conditions'=>array('name'=>'edit_timesheet')));
		$user_timesheet_edit_right = false;
		if ($options['Option']['value'] == 1) {
			$user_timesheet_edit_right = true;
		}
		$options = $this->Option->find('first', array('fields'=>array('value'), 'conditions'=>array('name'=>'manager_edit_staff_timesheet')));
		$manager_timesheet_edit_right = false;
		if ($options['Option']['value'] == 1) {
			$manager_timesheet_edit_right = true;
		}
		
		if ($this->Auth->user('group_id') == 3) {
			if (!$user_timesheet_edit_right) {
				$this->Session->setFlash(__('The admin has disabled editing of timesheets outside the timer.'));
				$this->redirect(array('action' => 'index'));
			}
		}
		
		if ($this->Auth->user('group_id') == 2) {
			$target_user = $this->Timesheet->find('first', array('fields'=>array('User.id'), 'conditions'=>array('Timesheet.id' => $id)));
			if ($target_user['User']['id'] != $this->Auth->user('id')) {
				if (!$manager_timesheet_edit_right) {
					$this->Session->setFlash(__('The admin has disabled editing of timesheets outside the timer.'));
					$this->redirect(array('action' => 'index'));                   
				}
			}
		} 
			
		if ($is_manager) {
			if (!$manager_timesheet_edit_right) {
				$this->Session->setFlash(__('Manager is not allowed to edit staff timesheet'),'alert',array('class'=>'alert-error'));
				$this->redirect(array('action'=>'index'));
			}
		} else {
			if($this->Auth->user('group_id') == 3 && $user_id['Timesheet']['user_id'] != $this->Auth->user('id')) {
				$this->Session->setFlash(__('Oops! Looks like you are not the owner of Timesheet. Only the user corresponding to the Timesheet can edit it.'),'alert',array('class'=>'alert-error'));
				$this->redirect(array('action'=>'index'));
			}
		}               
		
		$curdate = CakeTime::format('Y-m-d H:i:s', date('Y-m-d H:i:s'), null, $this->userTimezone);
		$curdate = CakeTime::format('Y-m-d H:i:s', strtotime($curdate), null, $this->serverTimezone);
		
		if ($this->request->is('post')) {
			if ($this->Auth->user('group_id') == 1 || $this->Auth->user('group_id') == 2) {
				$this->request->data['Timesheet']['approved_by_id'] = $this->Auth->user('id');
				$this->request->data['Timesheet']['approved_at'] = $curdate;                            
			}
			
			if(isset($this->resquest->data['Timesheet']['status'])) {
				unset($this->resquest->data['Timesheet']['status']);
			}

			if(isset($this->request->data['Timesheet']['user_id'])){
				$uid = $this->request->data['Timesheet']['user_id'];
			} else {
				$uid = $this->Auth->user('id');
			}
			
			$jobList = $this->Job->find('all',array(
				'conditions'=> array(
					'AND' => array(
						'Job.user_id' => $uid,
						'OR' => array('Job.end_date '=> null,'Job.end_date >= '=>$curdate)
					)
				),
				'order' => array('Job.start_date'=>'desc')
			));
				
			foreach ($jobList as $theJob){
				$current_job = $theJob['Job']['id']; // get the first job and exit
				break;
			}
			
			if (isset($current_job) && (!$restricted)){
				$this->request->data['Timesheet']['job_id'] = $current_job;
			}
			
			if(isset($this->request->data['Timesheet']['job_id'])){
				if(isset($this->request->data['Timesheet']['start_time'])){
					$this->request->data['Timesheet']['start_time'] = CakeTime::format('Y-m-d H:i:s', strtotime($this->request->data['Timesheet']['start_time'].':00'), null, $this->serverTimezone);
				}
				if(isset($this->request->data['Timesheet']['end_time'])){
					$this->request->data['Timesheet']['end_time'] = CakeTime::format('Y-m-d H:i:s', strtotime($this->request->data['Timesheet']['end_time'].':00'), null, $this->serverTimezone);
				}
				if ($this->Timesheet->save($this->request->data)) {
					$this->Session->setFlash('Timesheet data saved ','alert');
					$this->redirect(array('action'=>'calendar'));
				} else {
					$this->Session->setFlash(__('Unable to save changes'),'alert', array('class'=>'alert-error'));
				}
			} else {
				$this->Session->setFlash(__('Unable to save changes, Please select Job'),'alert', array('class'=>'alert-error'));
			}
		}
	}
	
	public function ajax_edit(){
                $userId = $this->Auth->user('id');
                $userDetails = $this->User->find('all', array('conditions'=>array('User.id'=>$userId)));                
                $user_timezone = $userDetails[0]['User']['user_timezone'];
                $userTimezone = new DateTimeZone($user_timezone);
                
                $option_server_timezone = $this->Option->find('first', array('conditions' => array('name' => 'server_timezone')));
                if(!empty($option_server_timezone)) {
                        $server_timezone = $option_server_timezone['Option']['value'];                            
                } else {
                        $server_timezone = 'UTC';
                }
                $serverTimezone = new DateTimeZone($server_timezone);
                
		$this->autoRender = false;
		$isAjax = false;
		$success = false;
		if($this->request->is('post') || $this->request->is('ajax')){
			if (isset($this->request->data['Timesheet']['ajax'])) {
				$isAjax = true;
			}
			
			if (isset($this->request->data['Timesheet']['id'])) {
				$tid = $this->request->data['Timesheet']['id'];
				
				$this->Timesheet->id = $tid;
				
				//o: check for permission of current user
				$user_id = $this->Timesheet->read(array('Timesheet.user_id','User.parent_id'), $tid);
				
				if($this->Auth->user('group_id') == 3 && (($user_id['Timesheet']['user_id'] != $this->Auth->user('id')) && ($user_id['User']['parent_id'] != $this->Auth->user('id')))) {
					//
					echo json_encode(false);
					exit;
				} elseif ($this->Auth->user('group_id') == 3 && ($user_id['User']['parent_id'] == $this->Auth->user('id'))) {
					//manager
					$is_manager = true;
				}
				
				if(isset($this->request->data['Timesheet']['start_time'])){
                                        $start_time = date('Y-m-d H:i:s', strtotime($this->request->data['Timesheet']['start_time'].':00'));
                                        $s = CakeTime::toServer($start_time,$userTimezone);
                                        $start_time = new DateTime($s, $serverTimezone);
                                        $start = date('Y-m-d H:i:s', $start_time->format('U'));
                                        $this->request->data['Timesheet']['start_time'] = $start;
                                }
				if(isset($this->request->data['Timesheet']['end_time'])){
                                        $end_time = date('Y-m-d H:i:s', strtotime($this->request->data['Timesheet']['end_time'].':00')); 
                                        $e = CakeTime::toServer($end_time,$userTimezone);
                                        $end_time = new DateTime($e, $serverTimezone);
                                        $end = date('Y-m-d H:i:s', $end_time->format('U'));
                                        $this->request->data['Timesheet']['end_time'] = $end;
                                }
				if($this->Timesheet->save($this->request->data)){
					//
					$success = true;
				} else {
					$success = false;
				}
			} else {
				//
				$success = false;
			}
		}
		echo json_encode($success);
		exit;
	}
	public function ajax_delete(){
                $this->autoRender = false;
		$isAjax = false;
		$success = false;
		if($this->request->is('post') || $this->request->is('ajax')){
			if (isset($this->request->data['Timesheet']['ajax'])) {
				$isAjax = true;
			}
				
			if (isset($this->request->data['Timesheet']['id'])) {
				$tid = $this->request->data['Timesheet']['id'];
		
				$this->Timesheet->id = $tid;
		
				//o: check for permission of current user
				
				if($this->Timesheet->delete($tid)){
					//
					$success = true;
				} else {
				$success = false;
				}
			} else {
				//
				$success = false;
			}
			
		}
		echo json_encode($success);
		exit;
	}
	public function changeStatus($id = null) {
                $this->Timesheet->id = $id;
		if(!$this->Timesheet->exists()){
			throw new NotFoundException('Record not found');
		}
		
		if($this->request->is('post')){
			$status_id = $this->request->data('statusid');
			//print_r($status_id);
			//exit;
			if($this->Timesheet->saveField('approval_status_id',$status_id)){
                            $this->Timesheet->saveField('approved_by_id',$this->Auth->user('id'));
                            $curdate = CakeTime::format('Y-m-d H:i:s', date('Y-m-d H:i:s'), null, $this->userTimezone);
                            $curdate = CakeTime::format('Y-m-d H:i:s', strtotime($curdate), null, $this->serverTimezone);
                            $this->Timesheet->saveField('approved_at',$curdate);
				echo 'Ok';
			}
			else {
				echo 'Err';
			}
		}
		exit;
	}
	
	public function delete($id = null){
                if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$user_id = $this->Timesheet->read('Timesheet.user_id', $id);
		
		if($this->Auth->user('group_id') == 3 && ($user_id['Timesheet']['user_id'] != $this->Auth->user('id'))) {
			$this->Session->setFlash(__('Oops! Looks like you are not the owner of Timesheet. Only the user corresponding to the Timesheet can delete it.'),'alert',array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		}
		$this->Timesheet->id = $this->request->data['id']; //--
		if(!$this->Timesheet->exists()){
			throw new NotFoundException('Record not found');
		}
	
		if($this->Timesheet->delete($id)){
			$this->Session->setFlash(__('Timesheet deleted'),'alert');
			$this->redirect(array('action'=>'index'));
		}
		else
		{
			$this->Session->setFlash(__('Unable to delete'),'alert', array('class'=>'alert-error'));
			$this->redirect(array('action'=>'index'));
		}
	}

	public function checktimesheet(){
                $this->layout = false;
		$this->autoRender = false;
		$apiKey = null;
		if($this->request->is('post')){
			if(isset($this->request->data['apiKey'])){
				$apiKey = $this->request->data['apiKey'];
			} else {
				echo 'request_Error';
				exit;
			}
		} else {
			echo 'request_Error';
			exit;
		}
		
		// get api key 
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'webservice_api_key')));
		if(!empty($option_setting)){
			$settingApiKey = $option_setting['Option']['value'];
		}
		else {
			$settingApiKey = '4974kjsfweiubiusdh9re8b89ew';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'notify_after_days')));
		if(!empty($option_setting)){
			$notifyAfterDays = (int) $option_setting['Option']['value'];
		}
		else {
			$notifyAfterDays = 7;
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'alert_using_sms')));
		if(!empty($option_setting)){
			$alertUsingSMS = $option_setting['Option']['value'];
		}
		else {
			$alertUsingSMS = false;
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'twilio_api_key')));
		if(!empty($option_setting)){
			$twilioApiKey = $option_setting['Option']['value'];
		}
		else {
			$twilioApiKey = '6ec001d68e7f2f3862e6dc732fb10d3e';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'twilio_sid')));
		if(!empty($option_setting)){
			$AccountSid = $option_setting['Option']['value'];
		}
		else {
			$AccountSid = 'ACa1d745f86e9450292f76f61276bd0021';
		}
		
		$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'sender_phone_number')));
		if(!empty($option_setting)){
			$senderPhoneNumber = $option_setting['Option']['value'];
		}
		else {
			$senderPhoneNumber = '+91999999999';
		}
		
		if($settingApiKey != $apiKey){ // check api key
			// exit
			echo 'API_key_error';
			exit; 
		}
		
		$this->User->Behaviors->load('Containable');
		$userTimesheets = $this->User->find('all',array('contain'=>array(
				'Timesheet' =>array(
						'order'=>array('Timesheet.end_time'=>'desc'),
						'limit'=>1
		)
		)));
		
		foreach($userTimesheets as $userTimesheet){
			if(isset($userTimesheet['Timesheet'][0])){
				
				$start = strtotime($userTimesheet['Timesheet'][0]['start_time']);
				$end = strtotime(date('Y-m-d')); // today
				
				$days_between = ceil(abs($end - $start) / 86400);
				
				$startTimeDuration = $days_between;
				
				$start = strtotime($userTimesheet['Timesheet'][0]['end_time']);
				$days_between = ceil(abs($end - $start) / 86400);
				
				$endTimeDuration = $days_between;
				
				if(($startTimeDuration > $notifyAfterDays)||($endTimeDuration > $notifyAfterDays)) {
					
					//notify user thru email
					$sinceDays = 0;
					if ($startTimeDuration > $endTimeDuration){
						$sinceDays = $endTimeDuration;
					} else {
						$sinceDays = $startTimeDuration;
					}
					$email_content = "You have not filled out timesheet for ".$sinceDays." days.";
					
					if (filter_var($userTimesheet['User']['email'], FILTER_VALIDATE_EMAIL)) { // check if email is valid
						$email = new CakeEmail('default');
							
						if ($this->from_email){
							$email->from(array($this->from_email=>$this->from_email_title));
						}
						$email->to($userTimesheet['User']['email']);
						$email->subject('Timesheet Notification');
						if($this->use_smtp){
							$email->transport('Smtp');
							$email->config(array('host'=>$this->smtp_host,'port'=>$this->smtp_port,'username'=>$this->smtp_user,'password'=>$this->smtp_password));
							$smtpError = false;
							try {
								if ($email->send($email_content)) {
									// email sent
								}
								else {
									$smtpError = true;
								}
							}
							catch(Exception $e) {
								$smtpError = true;
							}
						
							if($smtpError) {
								$email->transport('Mail');
								try {
									if ($email->send($email_content)) {
										// email sent
									}
								}
								catch(Exception $e) {
									// do notthing
								}
								}
								} else {
								$email->transport('Mail');
								try {
								if ($email->send($email_content)) {
									// sent 
								}
								}
								catch(Exception $e) {
									//do notthing
								}
						}
					}
		
					//now send SMS if we need to
					if($alertUsingSMS == true){
						if(!empty($userTimesheet['User']['phone'])){
							// set your AccountSid and AuthToken from www.twilio.com/user/account
							//$AccountSid = "ACa1d745f86e9450292f76f61276bd0021";
							//$AuthToken = "6ec001d68e7f2f3862e6dc732fb10d3e";

							$client = new Services_Twilio($AccountSid, $twilioApiKey);
							// send sms
							$message = '';
							try{
							$message = $client->account->messages->sendMessage(
									$senderPhoneNumber, // From this number
									$userTimesheet['User']['phone'], // To this number
									$email_content //message
							);
							} catch (Services_Twilio_RestException $e) {
								//echo $e->getMessage(); // do not echo
							}
							
						}
					}
				}
			}
		}
		
		echo 'Ok';
		
	}
	
	public function ajax_notify_user($uid = NULL){
                $this->layout = false;
		$this->autoRender = false;
		
		$error = false;
		$emailError = false;
		$smsError = false;
		$emailErrorMessage = '';
		$smsErrorMessage = '';
		$state = '1';
		if($this->request->is('post') || $this->request->is('ajax')){
			if(isset($this->request->data['user_id'])){
				$uid = $this->request->data['user_id'];
			}
			if(!empty($uid)){
				$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'alert_using_sms')));
				if(!empty($option_setting)){
					$alertUsingSMS = $option_setting['Option']['value'];
				}
				else {
					$alertUsingSMS = false;
				}
					
				$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'twilio_api_key')));
				if(!empty($option_setting)){
					$twilioApiKey = $option_setting['Option']['value'];
				}
				else {
					$twilioApiKey = '6ec001d68e7f2f3862e6dc732fb10d3e';
				}
					
				$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'twilio_sid')));
				if(!empty($option_setting)){
					$AccountSid = $option_setting['Option']['value'];
				}
				else {
					$AccountSid = 'ACa1d745f86e9450292f76f61276bd0021';
				}
					
				$option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'sender_phone_number')));
				if(!empty($option_setting)){
					$senderPhoneNumber = $option_setting['Option']['value'];
				}
				else {
					$senderPhoneNumber = '+91999999999';
				}
					
				$timesheet = $this->Timesheet->find('first',array(
						'conditions'=>array('Timesheet.user_id'=>$uid),
						'order'=>array('Timesheet.end_time'=>'desc')
				));
					
				if((!empty($timesheet)) && isset($timesheet['Timesheet']['end_time'])){
					// if we got timesheet
					$start = strtotime($timesheet['Timesheet']['start_time']);
					$end = strtotime(date('Y-m-d')); // today
				
					$days_between = ceil(abs($end - $start) / 86400);
				
					$startTimeDuration = $days_between;
				
					$start = strtotime($timesheet['Timesheet']['end_time']);
					$days_between = ceil(abs($end - $start) / 86400);
				
					$endTimeDuration = $days_between;
				
					//notify user thru email
					$sinceDays = 0;
					if ($startTimeDuration > $endTimeDuration){
						$sinceDays = $endTimeDuration;
					} else {
						$sinceDays = $startTimeDuration;
					}
				
					$option_email_content = $this->Option->find('first',array('conditions'=>array('name'=>'email_template_notify')));
					
					if($option_email_content){
						$email_content = $option_email_content['Option']['value'];
					} else {
						$email_content = "You have not filled out timesheet for ".$sinceDays." days.";
					}
					
					$emailVars = array(
							'fullname'=>$timesheet['User']['full_name'], //user Full Name as of now
							'sincedays'=>$sinceDays,
							'firstname'=>$timesheet['User']['first_name'], // prasun modified.
					);
					
					foreach($emailVars as $key=>$value){
						$email_content = str_replace('{{'.$key.'}}',$value,$email_content);
					}
					
					$state = 1;
					if (filter_var($timesheet['User']['email'], FILTER_VALIDATE_EMAIL)) { // check if email is valid
						$email = new CakeEmail('default');
                                                $email->emailFormat('both');
						$state = 2;
						if ($this->from_email){
							$email->from(array($this->from_email=>$this->from_email_title));
						}
						$email->to($timesheet['User']['email']);
						$email->subject('Timesheet Notification');
						if($this->use_smtp){ 
							$email->transport('Smtp');
							$email->config(array('host'=>$this->smtp_host,'port'=>$this->smtp_port,'username'=>$this->smtp_user,'password'=>$this->smtp_password));
							$smtpError = false;
							try {
								if ($email->send($email_content)) {
									// email sent
								}
								else {
									$smtpError = true;
								}
							}
							catch(Exception $e) {
								$smtpError = true;
							}
				
							if($smtpError) {
								$email->transport('Mail');
								try {
									if ($email->send($email_content)) {
										// email sent
									}
								}
								catch(Exception $e) {
									// do notthing
									$emailError = true;
									
									$emailErrorMessage = 'Email could not be sent. ';
									
								}
							}
						} else {
							$email->transport('Mail'); 
							try {
								$email->send($email_content);
									// sent 
							}
							catch(Exception $e) {
								//do notthing
								$error = true;
								$emailError = true;
								//debug($emailError); exit;
								$emailErrorMessage = 'Email could not be sent. ';
							}
						}
					} else {
						// invalid email address
						$error = true;
						$emailError = true;
						$emailErrorMessage = 'User Email address invalid. ';
					}
				
					//now send SMS if we need to
					if($alertUsingSMS == true){
						if(!empty($timesheet['User']['phone'])){
							// set your AccountSid and AuthToken from www.twilio.com/user/account
							//$AccountSid = "ACa1d745f86e9450292f76f61276bd0021";
							//$AuthToken = "6ec001d68e7f2f3862e6dc732fb10d3e";
				
							$client = new Services_Twilio($AccountSid, $twilioApiKey);
							// send sms
							$message = '';
							try{
								$message = $client->account->messages->sendMessage(
										$senderPhoneNumber, // From this number
										$timesheet['User']['phone'], // To this number
										strip_tags($email_content) //message - HTML tags free
								);
							} catch (Services_Twilio_RestException $e) {
								$smsError = true;
								$smsErrorMessage = $e->getMessage(); // do not echo
							}
								
						}
					}
					
					// message
					if($error == true){
						echo json_encode(array('status'=>'Error','message'=>'Cannot send notification. '.$emailErrorMessage.$smsErrorMessage));
						exit;
					} else {
						//Success!! but sms error possible
						echo json_encode(array('status'=>'Ok','message'=>'Email notification sent. '.$state.$smsErrorMessage));
						exit;
					}
					
				} else {
					//last timesheet not found ?? wiered
					echo json_encode(array('status'=>'Error','message'=>'Timesheet not found for this user. '));
					exit;
				}
			} else {
				// no user id 
				$error = true;
				echo json_encode(array('status'=>'Error','message'=>'No user ID. '));
				exit;
			}
			
		}
		echo json_encode(array('status'=>'Error','message'=>'Some error occured. '));
		exit;
	}
	private function isTimesheetEditAllowed($id=null){
                //get timesheets owner and the owners manager
		$user_id = $this->Timesheet->read(array('Timesheet.user_id','User.parent_id'), $id);
		
		if($this->Auth->user('group_id') == 1) return true; // admin can always edit 
		
		if(($user_id['Timesheet']['user_id'] != $this->Auth->user('id')) && ($user_id['User']['parent_id'] != $this->Auth->user('id'))) {
			//not the owner and not the manager // so not allowed to edit
			return false;
		} 
		// we came here so current user is either owner of timesheet or is manager of the owner
		
		if ($user_id['User']['parent_id'] == $this->Auth->user('id')) { //may be manager??
			//current user is manager of the user who created timesheet
			// check if manager is allowed to edit staff's timesheet
			$option_manager_edit_staff = $this->Option->find('first',array('conditions'=>array('name'=>'manager_edit_staff_timesheet')));
			if(!empty($option_manager_edit_staff)){
				$edit_staff = $option_manager_edit_staff['Option']['value'];
			} else {
				$edit_staff = false;
			}
				
			if($edit_staff){
				// ok fine
				return true;
			} else {
				return false; // manager is not allowed to edit
			}
		}
		
		// if its not a manager or admin than its the owner // allow editing according to global setting is user setting
		if($this->edit_timesheet == false){
			return false;
		}
		
		return true; // we came up to here so definately allowed to edit
	}
	
	//--------------patch
	/*
	public function patchtime(){
		$AccountSid = "ACa1d745f86e9450292f76f61276bd0021";
		$AuthToken = "6ec001d68e7f2f3862e6dc732fb10d3e";
			
		$client = new Services_Twilio($AccountSid, $AuthToken);
		// send sms
		$message = '';
		try{
		$message = $client->account->messages->sendMessage(
				"+19208439637", // From this number
				"+918158935511", // To this number
				"Test message!"
		);
		} catch (Services_Twilio_RestException $e) {
			echo $e->getMessage();
		}
		debug($message);
		die;
		/*
		if($this->request->is('post')){
			if(isset($this->request->data['Timesheet']['timezone'])){
				$toTimezone = $this->request->data['Timesheet']['timezone'];
				$allTimesheets = $this->Timesheet->find('all');
				foreach ($allTimesheets as $timesheet){
					$new_start_time = CakeTime::format('Y-m-d H:i',$timesheet['Timesheet']['start_time'],null,$toTimezone);
					$new_end_time = CakeTime::format('Y-m-d H:i',$timesheet['Timesheet']['end_time'],null,$toTimezone);
					$new_times = array(
							'Timesheet'=>array(
									'id'=>$timesheet['Timesheet']['id'],
									'start_time'=>$new_start_time,
									'end_time'=>$new_end_time
							)
					);
					$this->Timesheet->save($new_times);
				}
				$this->Session->setFlash('Done!');
			}
			
		}		
		$this->set('listTimezone',$this->Timesheet->timezone_list());
	
	}*/
        
        
        private function isWeekend($date) {
		$weekDay = date('w', strtotime($date));
                return ($weekDay == 0 || $weekDay == 6);
	}
        
        public function announcementpopup() {
            $this->loadModel('Announcement');
            $announcement_description = $this->Announcement->find('all', array(
                'fields' => array('Announcement.description'),
                'conditions' => array('Announcement.id' => $this->request->data['id'])
            ));
            echo $announcement_description[0]['Announcement']['description'];
            exit;                          
        }
        
        public function checkLogin() {
            if (!$this->Auth->loggedIn()) {
                echo 'logout';
                exit;
            } else {
                echo 'go';
                exit;
            }       
        }
}