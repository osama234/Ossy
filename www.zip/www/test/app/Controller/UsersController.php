<?php

App::uses('CakeEmail', 'Network/Email');

class UsersController extends AppController {
    var $from_email;
    var $from_email_title;
    var $smtp_host;
    var $smtp_port;
    var $smtp_user;
    var $smtp_password;
    var $use_smtp;
    //public $components = array('RequestHandler');   
    

    public function beforeFilter() {
        parent::beforeFilter();
        parent::checkLanguage();
                
        $this->Auth->allow('activeInactive', 'inactive_users', 'clear_directory_organization_cache', 'forgot', 'reset', 'logout', 'login', 'import', 'announcements', 'announcement_add', 'announcement_edit', 'announcement_delete', 'directory', 'language', 'names', 'setPhotoAndName', 'previousEmployees', 'index', 'edit', 'add', 'view');
        //$this->Auth->allow();

        $option_email = $this->Option->find('first', array('conditions' => array('name'=>'email')));
        if (!empty($option_email)) {
            $this->from_email = $option_email['Option']['value'];
        } else {/*
          $euser = $this->User->find('first',array('conditions'=>array('active'=>1)));
          if(isset($euser[0]['User']['email'])){
          $this->from_email = $euser[0]['User']['email'];
          } else {
          $this->from_email = '';
          }
         */
            $first_admin = $this->first_active_admin();
            if ($first_admin) {
                $this->from_email = $first_admin['User']['email'];
                $this->from_email_title = $first_admin['User']['name'];
            } else {
                $this->from_email_title = $this->appTitle;
            }
        }

        $option_email_title = $this->Option->find('first', array('conditions' => array('name' => 'email_title')));
        if (!empty($option_email)) {
            $this->from_email_title = $option_email_title['Option']['value'];
        } else {
            $this->from_email_title = $this->appTitle;
        }

        $option_smtp_host = $this->Option->find('first', array('conditions' => array('name' => 'email_host')));
        if (!empty($option_smtp_host)) {
            $this->smtp_host = $option_smtp_host['Option']['value'];
        } else {
            $this->smtp_host = '';
        }

        $option_smtp_port = $this->Option->find('first', array('conditions' => array('name' => 'email_port')));
        if (!empty($option_smtp_port)) {
            $this->smtp_port = $option_smtp_port['Option']['value'];
        } else {
            $this->smtp_port = '';
        }

        $option_smtp_user = $this->Option->find('first', array('conditions' => array('name' => 'email_user')));
        if (!empty($option_smtp_user)) {
            $this->smtp_user = $option_smtp_user['Option']['value'];
        } else {
            $this->smtp_user = '';
        }

        $option_smtp_password = $this->Option->find('first', array('conditions' => array('name' => 'email_password')));
        if (!empty($option_smtp_password)) {
            $this->smtp_password = $option_smtp_password['Option']['value'];
        } else {
            $this->smtp_password = '';
        }

        if (!empty($this->smtp_host) && !empty($this->smtp_port) && !empty($this->smtp_user) && !empty($this->smtp_password)) {
            $this->use_smtp = true;
        } else {
            $this->use_smtp = false;
        }
    }
    
    public function login() {
        //for Language handling
        $this->loadModel('Language');
        $languages = $this->Language->find('all');
        $this->set('languages', $languages);

        $option_ip_restriction = $this->Option->find('first', array('conditions' => array('name' => 'ip_restriction_status')));
        $option_ip_restriction = $option_ip_restriction['Option']['value'];

        $option_allowed_ip_addresses = $this->Option->find('first', array('conditions' => array('name' => 'allowed_ip_addresses')));
        $option_allowed_ip_addresses = $option_allowed_ip_addresses['Option']['value'];
        $allowed_ip_addresses = array_map('trim', explode(',', $option_allowed_ip_addresses));

        $option_access_outside = $this->Option->find('first', array('conditions' => array('name' => 'access_outside')));
        $option_access_outside = $option_access_outside['Option']['value'];
        $access_outside = explode(',', $option_access_outside);

        $ip_address = $this->User->client_ip(); //debug($ip_address); exit;
        
        if ($this->request->is('post')) :
            $user_active = $this->User->find('first', array(
                'fields' => array('id', 'username', 'active', 'photo', 'photo_dir', 'first_name', 'last_name'),
                'conditions' => array(
                    'User.active' => 1,
                    'User.username' => $this->request->data['User']['username'],
                    'User.password' => $this->Auth->password($this->request->data['User']['password'])
                )
            ));
            
            if (!empty($user_active)) :
                if ($user_active['User']['active']) :
                    if ($user_active['User']['photo'] == NULL) :
                        $userPhoto = '../img/noimage.png';
                    else :
                        $userPhoto = '../files/user/photo/' . $user_active['User']['photo_dir'] . '/default_' . $user_active['User']['photo'];
                    endif;
                    $this->Cookie->write('userphoto',$userPhoto, false, '365 days');
                    
                    $user_full_name = ucfirst($user_active['User']['first_name']) . ' ' . ucfirst($user_active['User']['last_name']);
                    $this->Cookie->write('name',$user_full_name, false, '365 days');
                    
                    $this->Cookie->write('username',$user_active['User']['username'], false, '365 days');
                    if ($this->request->data['User']['remember'] == 1) : 
                        $tmp['User']['username'] = $user_active['User']['username'];
                        $tmp['User']['password'] = $this->request->data['User']['password'];
                        $tmp['User']['photo'] = $user_active['User']['photo'];
                        $tmp['User']['photo_dir'] = $user_active['User']['photo_dir'];
                        $this->Cookie->write('remember', $tmp['User'], true, '365 days');
                    endif;

                    $this->User->id = $user_active['User']['id'];
                    $curUser = array('User' => array(
                        'id' => $user_active['User']['id'],
                        'last_login' => date(DATE_ATOM)
                    ));
                    $this->User->save($curUser, false); // alternate code coz code below gave error on production
                    
                    if ($option_ip_restriction == true) : 
                        if (in_array($ip_address, $allowed_ip_addresses) || ($this->Auth->user('group_id') == 1) || in_array($this->User->id, $access_outside)) :
                            if ($this->Auth->login()) :
                                $this->redirect(array('plugin' => '', 'controller' => 'timesheets', 'action' => 'dashboard'));
                            else :
                                $this->Session->setFlash(__('Invalid username or password, try again'), 'alert', array('class' => 'alert-error'));
                            endif;
                        else :
                            $this->Cookie->delete('remember');
                            $this->Session->setFlash(__('Sorry, you are not allowed to access the system from the network you are on. To change this, please contact the admin.'), 'alert', array('class' => 'alert-error'));
                            $this->redirect($this->Auth->logout());
                        endif;
                    else :
                        if ($this->Auth->login()) :
                            $this->redirect(array('plugin' => '', 'controller' => 'timesheets', 'action' => 'dashboard'));
                        else :
                            $this->Session->setFlash(__('Invalid username or password, try again'), 'alert', array('class' => 'alert-error'));
                        endif;
                    endif;
                else :
                    $this->Session->setFlash(__('User not active'), 'alert', array('class' => 'alert-error'));
                endif;
            else :
                if ($this->Cookie->read('userphoto')) : 
                    $this->set('userPhoto', $this->Cookie->read('userphoto'));
                else :
                    $this->set('userPhoto', '../img/noimage.png');                    
                endif;
                $this->Session->setFlash(__('Invalid username or password, try again'), 'alert', array('class' => 'alert-error'));
            endif;
        else :
            if ($this->Cookie->read('remember')) :
                $lastUser = $this->Cookie->read('remember');
                $user_active = $this->User->find('first', array(
                    'conditions' => array(
                        'User.username' => $lastUser['username'],
                        'User.password' => $this->Auth->password($lastUser['password'])
                    )
                ));
                if (empty($user_active)) :
                    $this->redirect('/users/logout');                    
                else :                
                    if (!$this->params->query) :
                        if (!empty($user_active)) :
                            if ($this->Auth->login($user_active['User'])) :
                                if ($this->Auth->login()) :
                                    if(empty($this->passedArgs)):
                                        $this->redirect(array('plugin' => '', 'controller' => 'timesheets', 'action' => 'dashboard'));
                                    endif;
                                endif;
                            endif;
                        endif;
                    endif;
                endif;
            else : 
                if ($this->Cookie->read('username')) :
                    $foundUser = $this->Cookie->read('username');
                    $user_found = $this->User->find('first', array(
                        'conditions' => array(
                            'User.username' => $foundUser
                        )
                    ));
                    if (!empty($user_found)) :
                        $tmp['username'] = $user_found['User']['username'];
                        $this->set('rememberMe', $tmp);
                    endif;                        
                endif;
                //debug($this->Cookie->read('userphoto')); exit;
                if ($this->Cookie->read('userphoto')) : 
                    $this->set('userPhoto', $this->Cookie->read('userphoto'));
                else :
                    $this->set('userPhoto', '../img/noimage.png');                    
                endif;
                if ($this->Cookie->read('name')) :
                    $this->set('name', $this->Cookie->read('name'));
                endif;
            endif;
        endif;
    }

    public function logout() {
        $this->Cookie->delete('remember');
        $this->redirect($this->Auth->logout());
    }

    public function index($csvFile = null) {
        $searched = false;
        $active = true;
        $search_user_full_name = '';
        if ($this->passedArgs) { 
            $args = $this->passedArgs;
            if (isset($args['search_name'])) {
                $searched = true;
                if ($args['search_inactive'] == '1') {
                     $active = false;                    
                }
            }
            if (isset($args['search_user_id'])) {
                $temp = $this->User->findById($args['search_user_id']);
                if ($temp) {
                    $search_user_full_name = $temp['User']['full_name'];
                }
            }
        }

        $this->set('search_user_full_name', $search_user_full_name);
        $this->set('searched', $searched);

        $this->Prg->commonProcess();
        
        $this->User->unbindModel(array(
            'hasMany' => array('Timesheet','Vacation')
        ));
        
        if ($this->Auth->user('group_id') == 2) { //Manager should see himself and his children
            $below_usrs = $this->User->find('all', array(
                'fields' => array('User.id'),
                'conditions' => array(
                    'User.parent_id' => $this->Auth->user('id'),
                    'User.active' => 1
                ),
                'recursive' => -1
            ));
            $user_ids = array();
            $user_ids[] = $this->Auth->user('id');
            foreach ($below_usrs as $userid) :
                $user_ids[] = $userid['User']['id'];
            endforeach;
        }
       
        if ($this->Auth->user('group_id') == 1) {
            if ($active) {
                $this->paginate = array(
                    'conditions' => array_merge(
                            $this->User->parseCriteria($this->passedArgs),
                            array('User.active' => 1)
                    ),
                    'limit' => $this->option_row_other,
                    'order' => array('User.id' => 'asc')
                );
            } else {
                $this->paginate = array(
                    'conditions' => array_merge(
                            $this->User->parseCriteria($this->passedArgs),
                            array('User.active' => 0)
                    ),
                    'limit' => $this->option_row_other,
                    'order' => array('User.id' => 'asc')
                );                
            }
        } else {
            if ($this->Auth->user('group_id') == 2) { //Manager should see himself and his children
                $this->paginate = array(
                    'conditions' => array_merge($this->User->parseCriteria($this->passedArgs), array('User.id' => $user_ids)),
                    'limit' => $this->option_row_other,
                    'order' => array('User.id' => 'asc')
                );
            } else {
                $this->paginate = array(
                    'conditions' => array_merge($this->User->parseCriteria($this->passedArgs), array('User.id' => $this->Auth->user('id'))),
                    'limit' => $this->option_row_other,
                    'order' => array('User.id' => 'asc')
                );
            }
        }
        
        $this->set('userList', $this->User->find('list'));
        $this->set('groupList', $this->User->Group->find('list'));
        $this->set('users', $this->paginate());


        if ($csvFile) {
            $users = $this->User->find('all', array('conditions' => array('User.active' => 1)));
            $this->request->params['named']['page'] = null;
            $this->set('users', $users);
        }
    }
    
    public function activeInactive() {
        if($this->request->is('post')) {
            $id = $this->request->data('id');
            $this->User->id = $id;
            $tmp = $this->User->read('active');
            if ($tmp['User']['active']) :
                $trg = 0;  
            else :
                $trg = 1;
            endif;
            
            if ($this->User->saveField('active',$trg)) {
                echo 'Ok';
            } else {
                echo 'Err';
            }
        }
        exit;
    }
    
    public function directory() {
        $this->User->unbindModel(array(
            'hasMany' => array('Timesheet','Vacation')
        ), false);

        if (Cache::read('user_directory_cache')) {
            $this->set('users', Cache::read('user_directory_cache'));
        } else { 
            $this->loadModel('Job');
            $users = $this->Job->find('all', array(
                'conditions' => array(
                    'User.active' => 1
                ),
                'order' => $this->User->virtualFields['name'] . ' ASC',
                'group' => 'Job.user_id'
            ));
            
            Cache::write('user_directory_cache', $users);
            $this->set('users', $users);
        }
        
        if (Cache::read('manager_directory_cache')) {
            $this->set('managers', Cache::read('manager_directory_cache'));
        } else {
            $managers = $this->User->find('all');
            Cache::write('manager_directory_cache',$managers);
            $this->set('managers', $managers);
        }  
    }

    public function organization() {
        $curdate = date('Y-m-d H:i:s');

        $this->set('title_for_layout', 'Organization');
        
        $this->User->unbindModel(array(
            'belongsTo' => array('Department'),
            'hasMany' => array('Timesheet','Vacation')
        ), false);

        if (Cache::read('jobs_organization_cache')) {
            $this->set('jobs', Cache::read('jobs_organization_cache'));
        } else {
            $jobs = $this->User->Job->find('all', array(
                'fields' => array('Job.id', 'Job.name', 'Job.user_id'),
                'conditions' => array(
                    'User.active' => 1
                )
            ));
            Cache::write('jobs_organization_cache',$jobs);
            $this->set('jobs', $jobs);
        }

        if (Cache::read('userjobs_organization_cache')) {
            $this->set('userJobs', Cache::read('userjobs_organization_cache'));
        } else {
            $userJobs = array();
            foreach ($jobs as $job) {
                $userJobs[$job['Job']['user_id']] = $job;
            }
            Cache::write('userjobs_organization_cache',$userJobs);
            $this->set('userJobs', $userJobs);            
        }
        
        if (Cache::read('org_organization_cache')) {
            $this->set('organization', Cache::read('org_organization_cache'));
        } else {
            if ($this->User->verify() != true) {
                $this->User->recover();
            }
            $org = $this->User->find('threaded');
            Cache::write('org_organization_cache',$org);
            $this->set('organization', $org);
        }
    }
    
    public function clear_directory_organization_cache() {
        Cache::delete('user_directory_cache');
        Cache::delete('manager_directory_cache');
        Cache::delete('jobs_organization_cache');
        Cache::delete('userjobs_organization_cache');
        Cache::delete('org_organization_cache');
        echo 'OK';
        exit;
    }

    public function view($id = null) {
        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }

        $this->set('user', $this->User->read(null, $id));

        $jobs = $this->User->Job->find('all', array(
            'limit' => 5,
            'conditions' => array(
                'Job.user_id' => $id
            )
        ));

        $this->set('jobs', $jobs);

        $timesheets = $this->User->Timesheet->find('all', array(
            'limit' => 5,
            'conditions' => array(
                'Timesheet.user_id' => $id
            )
        ));

        $this->set('timesheets', $timesheets);
    }

    public function add() {
        $extraMessage = '';
        if ($this->Auth->user('group_id') != 1) {
            $this->Session->setFlash(__('Only Administrator can add new user'), 'alert', array('class' => 'alert-error'));
            $this->redirect(array('action' => 'index'));
        }

        if ($this->Auth->user('group_id') == 1) {

            $admin = $this->User->find('all', array('conditions' => array('User.id' => 1), 'limit' => 1));
            $this->set('admin_timezone', $admin[0]['User']['user_timezone']);
        }

        $option_default_start_time = $this->Option->find('first', array('conditions' => array('name' => 'default_start_time')));
        if (!empty($option_default_start_time)) {
            $default_start_time = $option_default_start_time['Option']['value'];
        } else {
            $default_start_time = '09:00';
        }

        $option_default_end_time = $this->Option->find('first', array('conditions' => array('name' => 'default_end_time')));
        if (!empty($option_default_end_time)) {
            $default_end_time = $option_default_end_time['Option']['value'];
        } else {
            $default_end_time = '18:00';
        }
        //add vacation_days default value
        $option_default_vacation_days = $this->Option->find('first', array('conditions' => array('name' => 'vacation_per_year')));
        if (!empty($option_default_vacation_days)) {
            $default_vacation_days = $option_default_vacation_days['Option']['value'];
        } else {
            $default_vacation_days = '10';
        }
        $option_setting = $this->Option->find('first', array('conditions' => array('name' => 'user_timezone')));
        if (!empty($option_setting)) {
            $user_timezone = $option_setting['Option']['value'];
            //debug($server_timezone);exit;
        } else {
            $user_timezone = 'UTC';
        }
        $this->set('user_timezone', $user_timezone);

        if ($this->request->is('post')) { 
            $user_with_this_username = $this->User->findByUsername($this->request->data['User']['username']);
            $user_with_this_email = $this->User->findByEmail($this->request->data['User']['email']);
            if (!empty($user_with_this_username)) {
                $this->Session->setFlash(__('Username already exists. Please chose another one.'), 'alert', array('class' => 'alert-error'));
            } elseif (!empty($user_with_this_email)) {
                $this->Session->setFlash(__('Email is already registered by another user. Please chose another one.'), 'alert', array('class' => 'alert-error'));
            } else {
                $this->User->create();
                $this->loadModel('Option');

                $option_title = $this->Option->find('first', array('conditions' => array('name' => 'title')));
                if (!empty($option_title)) {
                    $this->request->data['Option']['title'] = $option_title['Option']['value'];
                } else {
                    $this->request->data['Option']['title'] = '';
                }


                if ($this->request->data['Job'][0]['name']) { 
                    // failsafe
                    if (isset($this->request->data['Job'][0]['start_time']) && empty($this->request->data['Job'][0]['start_time'])) {
                        $this->request->data['Job'][0]['start_time'] = $default_start_time;
                    }
                    //failsafe
                    if (isset($this->request->data['Job'][0]['end_time']) && empty($this->request->data['Job'][0]['end_time'])) {
                        $this->request->data['Job'][0]['end_time'] = $default_end_time;
                    }
                    if (isset($this->request->data['User']['user_timezone']) && empty($this->request->data['User']['user_timezone'])) {
                        $this->request->data['User']['user_timezone'] = $server_timezone;
                    }
                    
                    if (empty($this->request->data['Job'][0]['start_date'])) :
                        $this->request->data['Job'][0]['start_date'] = date('Y-m-d');                        
                    endif;
                    
                    if (empty($this->request->data['Job'][0]['end_date'])) :
                        $this->request->data['Job'][0]['end_date'] = '9999-12-31';                        
                    endif;
                    
                    $isSaved = $this->User->saveAssociated($this->request->data);
                } else {
                    $isSaved = $this->User->save($this->request->data);
                }

                if ($isSaved) {
                    if ($this->request->data['User']['notify']) {
                        $option_email_content = $this->Option->find('first', array('conditions' => array('name' => 'email_template_newuser')));

                        $email_content = $option_email_content['Option']['value'];

                        $emailVars = array(
                            'username' => $this->request->data['User']['username'],
                            'password' => $this->request->data['User']['password'],
                            'firstname' => $this->request->data['User']['first_name'],
                            'lastname' => $this->request->data['User']['last_name'],
                            'useremail' => $this->request->data['User']['email'],
                        );

                        foreach ($emailVars as $key => $value) {
                            $email_content = str_replace('{{' . $key . '}}', $value, $email_content);
                        }

                        $email = new CakeEmail('default');

                        if ($this->from_email) {
                            //$email->from(array($this->from_email => $this->from_email_title));
                            $email->from($this->from_email,$this->appTitle); //E-mail from name when creating new users #52
                        }
                        $email->to($this->request->data['User']['email']);
                        $email->subject('Welcome to ' . $option_title['Option']['value']);
                        //$email->template('newuser');
                        $email->template(null);
                        $email->theme('Default');
                        $email->emailFormat('both');
                        $email->viewVars(array('title' => $this->appTitle, 'appUrl' => $this->appUrl, 'username' => $this->request->data['User']['username'], 'password' => $this->request->data['User']['password']));
                        if ($this->use_smtp) {
                            $email->transport('Smtp');
                            $email->config(array('host' => $this->smtp_host, 'port' => $this->smtp_port, 'username' => $this->smtp_user, 'password' => $this->smtp_password));
                            $smtpError = false;
                            try {
                                $email->send($email_content);
                            } catch (Exception $e) {
                                $smtpError = true;
                            }

                            if ($smtpError) {
                                $email->transport('Mail');
                                try {
                                    $email->send($email_content);
                                } catch (Exception $e) {
                                    //
                                    $extraMessage = ' Email sending failed.';
                                }
                            }
                        } else {
                            $email->transport('Mail');
                            try {
                                $email->send($email_content);
                            } catch (Exception $e) {
                                $extraMessage = ' Email sending failed.';
                            }
                        }
                    }
                    $this->Session->setFlash(__('The user has been saved') . $extraMessage);
                    $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__('The user could not be saved. Please, try again.'));
                }
            }
        }
        unset($this->User->Job->validate['name']);
        $grouplist = $this->User->Group->find('list');
        $this->set('grouplist', $grouplist);
        $departmentlist = $this->User->Department->find('list');
        $this->set('departmentlist', $departmentlist);
        $managerList = $this->User->find('list');
        $this->set('managerList', $managerList);
        $this->set('default_start_time', $default_start_time);
        $this->set('default_end_time', $default_end_time);
        $this->set('default_vacation_days', $default_vacation_days);
        $this->set('listTimezone', $this->User->timezone_list());
    }

    public function edit($id = null) {
    	if(!isset($id)) {
    		$id = $this->Auth->user('id');
    	}
        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        if (($this->Auth->user('group_id') != 1) and ($id != $this->Auth->user('id'))) {
            $this->Session->setFlash(__('You do not have permission to edit other users detail'), 'alert', array('class' => 'alert-error'));
            $this->redirect(array('action' => 'edit', $this->Auth->user('id')));
        }
        if ($this->request->is('post') || $this->request->is('put')) {

            $other_user_with_this_email = $this->User->findByEmail($this->request->data['User']['email']);
            if (!empty($other_user_with_this_email) and ($other_user_with_this_email['User']['id'] != $id)) {
                $this->Session->setFlash(__('User with this email already exists, please chose another email'), 'alert', array('class' => 'alert-error'));
            } else {
                if ($this->request->data['User']['new_password']) {
                    if ($this->request->data['User']['new_password'] === $this->request->data['User']['confirm']) {
                        $this->request->data['User']['password'] = $this->request->data['User']['new_password'];
                    } else {
                        $this->Session->setFlash(__('Password not updated'), 'alert', array('class' => 'alert-info'));
                    }
                }
                if (($this->Auth->user('group_id') != 1) or ($id == $this->Auth->user('id'))) {
                    unset($this->request->data['User']['group_id']);
                }
                if ($this->request->data['User']['photo']['name'] == '') {
                    unset($this->request->data['User']['photo_dir']);
                    unset($this->request->data['User']['photo']);
                }
                if ($this->User->save($this->request->data)) {
                    if ($this->Auth->user('id') == $id) {
                        if ($this->Cookie->read('remember')) {
                            $data = $this->Cookie->read('remember');
                            $data['password'] = $this->request->data['User']['password'];
                            $this->Cookie->write('remember', $data, true, '365 days');
                        }
                    }
                    $this->Session->setFlash('User details has been saved', 'alert', array('class' => 'alert-success'));
                    //$this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__('The user could not be saved. Please, try again.'));
                }
            }
        }
        $this->request->data = $this->User->read(null, $id);
        unset($this->request->data['User']['password']);
        $grouplist = $this->User->Group->find('list');
        $this->set('grouplist', $grouplist);
        $departmentlist = $this->User->Department->find('list');
        $this->set('departmentlist', $departmentlist);
        
        $managerList = $this->User->find('list');
        $this->set('managerList', $managerList);
        $this->set('listTimezone', $this->Option->timezone_list());
        
        $this->set('user', $this->User->read(null, $id));
    }

    public function delete($id = null) {
        if (!$this->request->is('post')) {
            throw new MethodNotAllowedException();
        }
        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        if ($id == 1) {
            $this->Session->setFlash(__('Cannot delete supperuser'), 'alert', array('class' => 'alert-error'));
            $this->redirect(array('action' => 'index'));
        }
        if ($this->User->deleteOnlyThis($id)) {
            $this->Session->setFlash(__('User deleted'));
            $this->redirect(array('action' => 'index'));
        }
        $this->Session->setFlash(__('User was not deleted'));
        $this->redirect(array('action' => 'index'));
    }

    public function forgot() {
        if ($this->request->is('post')) {
            $user_data = $this->User->find('first', array('fields' => array('id', 'email', 'first_name', 'last_name'), 'conditions' => array('User.username' => $this->request->data['User']['username'])));
            if (!empty($user_data)) {
                $key = Security::generateAuthKey();
                $this->User->id = $user_data['User']['id'];
                if ($this->User->saveField('token', $key)) {
                    $url = Router::url(array('plugin' => '', 'controller' => 'users', 'action' => 'reset'), true) . '/' . $key . '#' . substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$'), 0, 20);

                    $option_email_content = $this->Option->find('first', array('conditions' => array('name' => 'email_template_reset')));

                    $email_content = $option_email_content['Option']['value'];

                    $emailVars = array(
                        'username' => $this->request->data['User']['username'],
                        'useremail' => $user_data['User']['email'],
                        'firstname' => $user_data['User']['first_name'],
                        'lastname' => $user_data['User']['last_name'],
                        'resetlink' => '<a href="' . $url . '">' . $url . '</a>',
                    );

                    foreach ($emailVars as $key => $value) {
                        $email_content = str_replace('{{' . $key . '}}', $value, $email_content);
                    }

                    $email = new CakeEmail('default');
                    if ($this->from_email) {
                        //$email->from(array($this->from_email => $this->from_email_title));
                        $email->from($this->from_email,$this->appTitle); //E-mail from name when creating new users #52
                    }
                    $email->to($user_data['User']['email']);
                    $email->subject('Password reset link');
                    $email->template('resetlink');
                    $email->theme('Default');
                    $email->emailFormat('both');
                    $email->viewVars(array('url' => $url, 'title' => $this->appTitle, 'appUrl' => $this->appUrl));
                    if ($this->use_smtp) {
                        $email->transport('Smtp');
                        $email->config(array('host' => $this->smtp_host, 'port' => $this->smtp_port, 'username' => $this->smtp_user, 'password' => $this->smtp_password));
                        $smtpError = false;
                        try {
                            if ($email->send($email_content)) {
                                $this->Session->setFlash(__('Password reset link has been sent to your email. Please check your mail.'), 'alert', array('class' => 'alert-success'));
                            } else {
                                $smtpError = true;
                                $this->Session->setFlash(__('Mail cannot be sent'), 'alert', array('class' => 'alert-error'));
                            }
                        } catch (Exception $e) {
                            $smtpError = true;
                        }

                        if ($smtpError) {
                            $email->transport('Mail');
                            try {
                                if ($email->send($email_content)) {
                                    $this->Session->setFlash(__('Password reset link has been sent to your email. Please check your mail.'), 'alert', array('class' => 'alert-success'));
                                } else {
                                    $this->Session->setFlash(__('Mail cannot be sent'), 'alert', array('class' => 'alert-error'));
                                }
                            } catch (Exception $e) {
                                //
                            }
                        }
                    } else {
                        $email->transport('Mail');
                        try {
                            if ($email->send($email_content)) {
                                $this->Session->setFlash(__('Password reset link has been sent to your email. Please check your mail.'), 'alert', array('class' => 'alert-success'));
                            } else {
                                $this->Session->setFlash(__('Mail cannot be sent'), 'alert', array('class' => 'alert-error'));
                            }
                        } catch (Exception $e) {
                            
                        }
                    }
                } else {
                    $this->Session->setFlash(__('Cannot save token key'), 'alert', array('class' => 'alert-error'));
                }
            } else {
                $this->Session->setFlash(__('Username not found'), 'alert', array('class' => 'alert-error'));
            }
        }
    }

    public function reset($token = null) {
        if ($token) {
            $user_data = $this->User->findByToken($token);
            if (!empty($user_data)) {
                $new_password = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$'), 0, 8);
                $new_token = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$'), 0, 39);
                $new_token .= '#';
                $new_token = str_shuffle($new_token);
                $this->User->id = $user_data['User']['id'];

                $curUser = array('User' => array(
                        'id' => $user_data['User']['id'],
                        'token' => $new_token,
                        'password' => $new_password
                ));
                $this->User->save($curUser, false); //alternate code coz code below didn't worked on production
                //$this->User->saveField('token',$new_token);
                //$this->User->saveField('password',$new_password);

                $option_email_content = $this->Option->find('first', array('conditions' => array('name' => 'email_template_newpassword')));

                $email_content = $option_email_content['Option']['value'];

                $emailVars = array(
                    'username' => $user_data['User']['username'],
                    'password' => $new_password,
                    'firstname' => $user_data['User']['first_name'],
                    'lastname' => $user_data['User']['last_name'],
                    'useremail' => $user_data['User']['email']
                );

                foreach ($emailVars as $key => $value) {
                    $email_content = str_replace('{{' . $key . '}}', $value, $email_content);
                }

                $email = new CakeEmail('default');
                if ($this->from_email) {
                    //$email->from(array($this->from_email => $this->from_email_title));
                    $email->from($this->from_email,$this->appTitle); //E-mail from name when creating new users #52
                }
                $email->to($user_data['User']['email']);
                $email->subject('New password');
                //$email->template('newpassword');
                $email->template(null);
                $email->theme('Default');
                $email->emailFormat('both');
                $email->viewVars(array('title' => $this->appTitle, 'appUrl' => $this->appUrl, 'username' => $user_data['User']['username'], 'password' => $new_password));
                if ($this->use_smtp) {
                    $email->transport('Smtp');
                    $email->config(array('host' => $this->smtp_host, 'port' => $this->smtp_port, 'username' => $this->smtp_user, 'password' => $this->smtp_password));
                    $smtpError = false;
                    try {
                        if ($email->send($email_content)) {
                            $this->set('success', true);
                            $this->Session->setFlash(__('A new password has been sent to your email. Please login and change it.'), 'alert', array('class' => 'alert-success'));
                        } else {
                            $smtpError = true;
                        }
                    } catch (Exception $e) {
                        $smtpError = true;
                    }

                    if ($smtpError) {
                        $email->transport('Mail');
                        try {
                            if ($email->send($email_content)) {
                                $this->set('success', true);
                                $this->Session->setFlash(__('A new password has been sent to your email. Please login and change it.'), 'alert', array('class' => 'alert-success'));
                            }
                        } catch (Exception $e) {
                            //
                            $this->set('success', false);
                            $this->Session->setFlash(__('Email could not be sent'), 'alert', array('class' => 'alert-error'));
                        }
                    }
                } else {
                    $email->transport('Mail');
                    try {
                        if ($email->send($email_content)) {
                            $this->set('success', true);
                            $this->Session->setFlash(__('A new password has been sent to your email. Please login and change it.'), 'alert', array('class' => 'alert-success'));
                        }
                    } catch (Exception $e) {
                        $this->set('success', false);
                        $this->Session->setFlash(__('Email could not be sent'), 'alert', array('class' => 'alert-error'));
                    }
                }
            } else {
                $this->set('success', false);
                $this->Session->setFlash(__('Invalid token or link has expired'), 'alert', array('class' => 'alert-error'));
            }
        }
    }

    /* public function overview() {

      $searched = false;
      $search_user_full_name = '';
      if ($this->passedArgs) {
      $args = $this->passedArgs;
      if(isset($args['search_name'])){
      $searched = true;
      }
      if(isset($args['search_user_id'])){
      $temp = $this->User->findById($args['search_user_id']);
      if ($temp){
      $search_user_full_name = $temp['User']['full_name'];
      }

      }
      }

      $this->set('search_user_full_name',$search_user_full_name);
      $this->set('searched',$searched);

      $this->Prg->commonProcess();
      //$this->User->recursive = 0;
      if ($this->Auth->user('group_id')==1){
      $this->paginate = array(
      'conditions' => $this->User->parseCriteria($this->passedArgs),
      'limit' => $this->option_row_other,
      'order' => array(
      'User.id' => 'asc'
      )
      );
      }
      else {
      $this->paginate = array(
      'conditions' => array_merge($this->User->parseCriteria($this->passedArgs),array('User.id'=>$this->Auth->user('id'))),
      'limit' => $this->option_row_other,
      'order' => array(
      'User.id' => 'asc'
      )
      );
      }
      $this->set('userList',$this->User->find('list'));

      $users = $this->paginate();

      $i = 0;
      foreach($users as $user){

      $users[$i]['Timesheet']['total'] = $this->User->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'])));
      $users[$i]['Timesheet']['submitted'] = $this->User->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'],'Timesheet.approval_status_id'=>1)));
      $users[$i]['Timesheet']['approved'] = $this->User->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'],'Timesheet.approval_status_id'=>2)));
      $users[$i]['Timesheet']['rejected'] = $this->User->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'],'Timesheet.approval_status_id'=>3)));
      $users[$i]['Timesheet']['revision'] = $this->User->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'],'Timesheet.approval_status_id'=>4)));
      $users[$i]['Vacation']['total'] = $this->User->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'])));
      $users[$i]['Vacation']['submitted'] = $this->User->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'],'Vacation.approval_status_id'=>1)));
      $users[$i]['Vacation']['approved'] = $this->User->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'],'Vacation.approval_status_id'=>2)));
      $users[$i]['Vacation']['rejected'] = $this->User->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'],'Vacation.approval_status_id'=>3)));
      $users[$i]['Vacation']['revision'] = $this->User->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'],'Vacation.approval_status_id'=>4)));
      $i = $i + 1;
      }
      $this->set('users',$users);
      //$this->set('users',$this->User->getOverview());
      } */           // Dated-02.09.2014 commentedout as overview no more required.  
    //required only initially
    public function initacl() {
        $group = $this->User->Group; 
        //Allow admins to everything
        $group->id = 1;
        $this->Acl->allow($group, 'controllers');
        
        //for  managers 
        $group->id = 2;
        $this->Acl->allow($group, 'controllers');
        $this->Acl->deny($group, 'controllers/Groups');
        $this->Acl->deny($group, 'controllers/Options');
        
        //users default
        $group->id = 3; //users
        $this->Acl->deny($group, 'controllers');
        $this->Acl->allow($group, 'controllers/Users');
        $this->Acl->allow($group, 'controllers/Jobs');
        $this->Acl->allow($group, 'controllers/Timesheets');
        $this->Acl->allow($group, 'controllers/Vacations');
        echo 'TTTTTTTTT';
    }
    
    public function import() {
        $data = $this->request->data;
        $dir = new Folder('tmp', true);
        move_uploaded_file($data['User']['csv_file']['tmp_name'], $dir->path . DS . $data['User']['csv_file']['name']);

        $filename = $dir->path . DS . $data['User']['csv_file']['name'];
        $message = '';
        $handle = fopen($filename, "r");
        $header = fgetcsv($handle);
        $ready = false;
        if ($header[0] == 'username' && $header[1] == 'first_name' && $header[2] == 'last_name' && $header[3] == 'email' && $header[4] == 'active') {
            $ready = true;
        } else {
            $message = 'Error! Header mismatched.';
        }

        $filedata = array();
        $i = 0;
        $j = 0;
        $k = 0;
        $l = 0;
        if ($ready) {
            while (($row = fgetcsv($handle)) !== FALSE) {
                if ($row[0] == '') {
                    $j ++;
                } else {
                    if ($this->User->find('first', array('conditions' => array('User.username' => $row[0])))) {
                        $k ++;
                    } else {
                        foreach ($header as $key => $value) {
                            if ($row[0] != '') {
                                $filedata['User'][$value] = (isset($row[$key])) ? $row[$key] : '';
                                $filedata['User']['password'] = 'password';
                            }
                        }
                        $this->User->saveAll($filedata);
                        $l ++;
                    }
                }
                $i ++;
            }
            //$message = $l . ' New records, ' . $j . ' Failed records, ' . $j . ' Duplicate records out of ' . $i . ' Total records.';
            $message = 'Imported a total of ' . $l . ' user(s), with ' . $k . ' duplicate(s), ' . $j . ' invalid user(s), from ' . $i . ' record(s)';
        }
        fclose($handle);
        $this->Session->setFlash(__($message));
        $this->redirect(array('action' => 'index'));
    }

    public function announcements() {
        
        $this->loadModel('Announcement');

        $this->set('announce', $this->Announcement->find('all', array('order' => array(
                        'Announcement.created' => 'desc'))));
        //pr(announce);exit;
        /* $this->paginate = array(
          'conditions' => $this->Announcement->parseCriteria($this->passedArgs),
          'limit' => $this->option_row_other,
          'order' => array(
          'Announcement.created' => 'desc'
          )
          ); */
    }

    public function announcement_add() {
        $this->loadModel('Announcement');

        if ($this->Auth->user('group_id') != 1) {
            $this->Session->setFlash(__('Only Administrator can add new announcement'), 'alert', array('class' => 'alert-error'));
            $this->redirect(array('action' => 'announcements'));
        }
        if ($this->request->is('post')) {
//debug($this->request->data); exit;
            $this->Announcement->create();
            if ($this->Announcement->save($this->request->data)) {
                $this->Session->setFlash(__('Your announcement has been saved.'));
                return $this->redirect(array('action' => 'announcements'));
            }
            $this->Session->setFlash(__('Unable to add your announcement.'));
        }
    }

    public function announcement_edit($id = null) {
        $this->loadModel('Announcement');
        if ($this->Auth->user('group_id') != 1) {
            $this->Session->setFlash(__('Only Administrator can update announcement'), 'alert', array('class' => 'alert-error'));
            $this->redirect(array('action' => 'announcements'));
        }
        /* if (!$id) {
          throw new NotFoundException(__('Invalid post'));
          } */

        $post = $this->Announcement->findById($id); 
        /* if (!$post) {
          throw new NotFoundException(__('Invalid post'));
          } */

        if ($this->request->is('post')) {
            $this->Announcement->id = $id;
            if ($this->Announcement->save($this->request->data)) {
                $this->Session->setFlash(__('Your announcement has been updated.'));
                return $this->redirect(array('action' => 'announcements'));
            }
            $this->Session->setFlash(__('Unable to update your announcement.'));
        }

        if (!$this->request->data) {
            $post['Announcement']['created'] = date('Y-m-d H:i', strtotime($post['Announcement']['created']));
            $this->request->data = $post;
        }
    }
    
    public function language() {
        if (isset($this->request->data['qstr'])) { 
            $this->Cookie->delete('lang');
            $this->Cookie->write('lang', "".$this->request->data['qstr'], false, '20 days');
            Configure::write('Config.language', $this->request->data['qstr']);
            $this->redirect(array('controller' => 'users', 'action' => 'login', 'lang'));
            exit;
        }         
    }
    
    public function announcement_delete () {
        if ($this->passedArgs) :
            $this->loadModel('Announcement');
            $this->Announcement->delete($this->passedArgs[0]);
            $this->redirect(array('action' => 'announcements'));
        endif;        
    }
    
    public function names() { 
        if ($this->passedArgs[0] == 'user') :
            $data = $this->User->find('all', array(
                'fields' => array('User.username'),
                'conditions' => array('User.username LIKE' =>'%' . $this->request->data['arg'] . '%'),
                'order' => array('User.username ASC')
            ));
        else :
            $data = $this->User->find('all', array(
                'fields' => array('User.name'),
                'conditions' => array(
                    'OR' => array(
                        'User.first_name LIKE' => '%' . $this->request->data['arg'] . '%',
                        $this->User->virtualFields['full_name'] . ' LIKE' => '%' . $this->request->data['arg'] . '%'
                    )
                ),
                'order' => array('User.first_name ASC')
            ));
        endif;
        
        if (empty($data)) :
            echo 'No';
            exit;
        else :
            $tmp_arr = array();
            foreach ($data as $rec) :
                if ($this->passedArgs[0] == 'user') :
                    $firstLetter = strtolower(substr($rec['User']['username'], 0, 1));
                    if ($firstLetter == strtolower($this->request->data['arg'])) :
                        $tmp_arr[] = $rec['User']['username'];
                    endif; 
                else :
                    $firstLetter = strtolower(substr($rec['User']['name'], 0, 1));
                    if ($firstLetter == strtolower($this->request->data['arg'])) :
                        $tmp_arr[] = $rec['User']['name'];
                    endif;
                endif;
            endforeach;
            foreach ($data as $rec) :
                if ($this->passedArgs[0] == 'user') :
                    $firstLetter = strtolower(substr($rec['User']['username'], 0, 1));
                    if ($firstLetter != strtolower($this->request->data['arg'])) :
                        $tmp_arr[] = $rec['User']['username'];
                    endif; 
                else :
                    $firstLetter = strtolower(substr($rec['User']['name'], 0, 1));
                    if ($firstLetter != strtolower($this->request->data['arg'])) :
                        $tmp_arr[] = $rec['User']['name'];
                    endif;
                endif;
            endforeach;
            $temp = '';
            $i = 0;
            for ($i = 0; $i < count($tmp_arr); $i ++) {
                if ($temp == '') :
                    $temp = $tmp_arr[$i];
                else :
                    $temp .= ',' . $tmp_arr[$i];
                endif; 
            }
            echo $temp;
            exit;
        endif;
    } 

    public function setPhotoAndName(){
        if ($this->request->is('post')) :
            if (isset($this->request->data['uname'])) :
                $uData = $this->User->find('first', array(
                    'fields' => array('first_name', 'last_name', 'photo', 'photo_dir'),
                    'conditions' => array('User.username' => $this->request->data['uname'])
                ));
                if (!empty($uData)) :
                    if ($uData['User']['photo'] != NULL && $uData['User']['photo_dir'] != NULL) :
                        $image = '<img src="../files/user/photo/' . $uData['User']['photo_dir'] . '/view_' . $uData['User']['photo'] . '" class="profile-img" />';
                        if ($uData['User']['first_name'] != NULL) :
                            $name = ucfirst($uData['User']['first_name']) . ' ' . ucfirst($uData['User']['last_name']);
                        else :
                            $name = '';
                        endif;
                    else :
                        $image = '<img src="../img/noimage.png" class="profile-img" />'; 
                        if ($uData['User']['first_name'] != NULL) :
                            $name = ucfirst($uData['User']['first_name']) . ' ' . ucfirst($uData['User']['last_name']);
                        else :
                            $name = '';
                        endif;
                    endif;
                else :
                    $image = '<img src="../img/noimage.png" class="profile-img" />';
                    $name = '';
                endif;
                $tmp = array();
                $tmp[0] = $image;
                $tmp[1] = $name;
                echo  json_encode($tmp);
                exit;
            endif;                        
        endif;
    }
}
