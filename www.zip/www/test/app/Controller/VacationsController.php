<?php
App::uses('CakeEmail', 'Network/Email');
class VacationsController extends AppController {

    var $from_email;
    var $from_email_title;
    var $smtp_host;
    var $smtp_port;
    var $smtp_user;
    var $smtp_password;
    var $use_smtp;
    var $vacation_emails;

    public $components = array('RequestHandler');

    public $uses = array('Vacation', 'SickDay');

    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('add', 'reports','addsick', 'readyTip');

        $option_email = $this->Option->find('first',array('conditions'=>array('name'=>'email')));
        if(!empty($option_email)){
            $this->from_email = $option_email['Option']['value'];
        }
        else {
            //$this->from_email = '';
            $first_admin = $this->first_active_admin();
            if($first_admin){
                $this->from_email = $first_admin['User']['email'];
                $this->from_email_title = $first_admin['User']['name'];
            } else {
                $this->from_email_title = $this->appTitle;
            }
        }

        $option_email_title = $this->Option->find('first',array('conditions'=>array('name'=>'email_title')));
        if(!empty($option_email)){
            $this->from_email_title = $option_email_title['Option']['value'];
        }
        else {
            $this->from_email_title = '';
        }

        $option_smtp_host = $this->Option->find('first',array('conditions'=>array('name'=>'email_host')));
        if(!empty($option_smtp_host)){
            $this->smtp_host = $option_smtp_host['Option']['value'];
        }
        else {
            $this->smtp_host = '';
        }

        $option_smtp_port = $this->Option->find('first',array('conditions'=>array('name'=>'email_port')));
        if(!empty($option_smtp_port)){
            $this->smtp_port = $option_smtp_port['Option']['value'];
        }
        else {
            $this->smtp_port = '';
        }

        $option_smtp_user = $this->Option->find('first',array('conditions'=>array('name'=>'email_user')));
        if(!empty($option_smtp_user)){
            $this->smtp_user = $option_smtp_user['Option']['value'];
        }
        else {
            $this->smtp_user = '';
        }

        $option_smtp_password = $this->Option->find('first',array('conditions'=>array('name'=>'email_password')));
        if(!empty($option_smtp_password)){
            $this->smtp_password = $option_smtp_password['Option']['value'];
        }
        else {
            $this->smtp_password = '';
        }

        if(!empty($this->smtp_host) && !empty($this->smtp_port) && !empty($this->smtp_user) && !empty($this->smtp_password)) {
            $this->use_smtp = true;
        } else {
            $this->use_smtp = false;
        }

        $option_vacation_emails = $this->Option->find('first',array('conditions'=>array('name'=>'vacation_email')));
        if(!empty($option_vacation_emails)){
            $this->vacation_emails = $option_vacation_emails['Option']['value'];
        }
        else {
            $this->vacation_emails = '';
        }

    }

    public function index($csvFile = null) {
        $searched = false;
        $search_user_full_name = '';
        if ($this->passedArgs) {
            $args = $this->passedArgs;

            if(isset($args['search_user_id'])){
                $searched = true;
                $temp = $this->User->findById($args['search_user_id']);
                if ($temp){
                    $search_user_full_name = $temp['User']['full_name'];
                }
            }
            if(isset($args['search_status'])){
                $searched = true;
            }
        }

        $this->set('search_user_full_name',$search_user_full_name);

        $this->set('searched',$searched);

        $this->Prg->commonProcess();
        //$this->Vacation->recursive = 1;

        if ($csvFile) {
            $this->paginate = array(
                'conditions' => $this->Vacation->parseCriteria($this->passedArgs),
                'order' => array(
                    'Vacation.modified' => 'desc'
                )
            );
            $this->request->params['named']['page'] = null;
        }
        else {
            if($this->Auth->user('group_id') == 1) {
                $this->paginate = array(
                    'conditions' => $this->Vacation->parseCriteria($this->passedArgs),
                    'limit' => $this->option_row_other,
                    'order' => array(
                        'Vacation.modified' => 'desc'
                    )
                );

                $conditions = $this->Vacation->parseCriteria($this->passedArgs);

            } else {
                ////user children
                $directChildren = $this->User->children($this->Auth->user('id'));
                foreach($directChildren as $directChildren){
                    $b[] = $directChildren['User']['id'];
                }
                $b[] = $this->Auth->user('id');
                $a = $this->User->find('all',array('conditions'=>array(
                        'OR'=>array('User.id'=>$b,
                            'User.parent_id'=>$this->Auth->user('id'))
                    )
                    )
                );
                foreach($a as $val){
                    $child[] = $val['User']['id'];
                }
                if($this->manager_see_multi_lavels == 1){
                    $this->paginate = array(
                        'conditions' => array_merge($this->Vacation->parseCriteria($this->passedArgs),
                            array(
                                'OR' =>array(
                                    'Vacation.user_id'=>$child,
                                    'User.parent_id'=>$this->Auth->user('id'))
                            )),
                        'limit' => $this->option_row_other,
                        'order' => array(
                            'Vacation.modified' => 'desc'
                        )
                    );

                    $conditions = array_merge($this->Vacation->parseCriteria($this->passedArgs),
                        array(
                            'OR' =>array(
                                'Vacation.user_id'=>$child,
                                'User.parent_id'=>$this->Auth->user('id'))
                        ));
                }
                else{
                    $this->paginate = array(
                        'conditions' => array_merge($this->Vacation->parseCriteria($this->passedArgs),
                            array(
                                'OR' =>array(
                                    'Vacation.user_id'=>$this->Auth->user('id'),
                                    'User.parent_id'=>$this->Auth->user('id'))
                            )),
                        'limit' => $this->option_row_other,
                        'order' => array(
                            'Vacation.modified' => 'desc'
                        )
                    );

                    $conditions = array_merge($this->Vacation->parseCriteria($this->passedArgs),
                        array(
                            'OR' =>array(
                                'Vacation.user_id'=>$this->Auth->user('id'),
                                'User.parent_id'=>$this->Auth->user('id'))
                        ));
                }
            }
        }

        if ($this->Auth->user('group_id') == 1){
            $userList = $this->User->find('list');
        } else {
            //user children
            $directChildren = $this->User->children($this->Auth->user('id'));
            foreach($directChildren as $directChildren){
                $b[] = $directChildren['User']['id'];
            }
            $b[] = $this->Auth->user('id');
            $a = $this->User->find('all',array('conditions'=>array(
                    'OR'=>array('User.id'=>$b,
                        'User.parent_id'=>$this->Auth->user('id'))
                )
                )
            );
            foreach($a as $val){
                $child[] = $val['User']['id'];
            }
            if($this->manager_see_multi_lavels == 1){
                $userList = $this->User->find('list',array(
                    'conditions'=>array('OR'=>array(
                        'User.id'=>$child,
                        'User.parent_id'=>$this->Auth->user('id')
                    ))
                ));
            }
            else{
                $userList = $this->User->find('list',array(
                    'conditions'=>array('OR'=>array(
                        'User.id'=>$this->Auth->user('id'),
                        'User.parent_id'=>$this->Auth->user('id')
                    ))
                ));
            }
        }

        $this->set('userList',$userList);
        $this->set('listApprovalStatus',$this->Vacation->ApprovalStatus->find('list'));
        $vacations = $this->Paginate();
        $this->set('vacations', $vacations);
        $this->set('vacationCounts',$this->Vacation->vacationCounts($conditions));
        $this->set('vacationCountsCurrentPage',$this->Vacation->vacationCountsCurrentPage($vacations));
    }

    public function calendar(){
        //for Vacation Calendar
        $calendarData = array();
        if($this->Auth->user('group_id')==1){
            $calendarVacations = $this->Vacation->find('all', array('conditions' => array('Vacation.type_id' => 0)));
            //debug($calendarVacations); exit;
        } else {
            //user children
            $directChildren = $this->User->children($this->Auth->user('id'));
            foreach($directChildren as $directChildren){
                $b[] = $directChildren['User']['id'];
            }
            $b[] = $this->Auth->user('id');
            $a = $this->User->find('all', array(
                    'conditions'=>array(
                        'OR'=>array(
                            'User.id'=>$b,
                            'User.parent_id'=>$this->Auth->user('id')
                        )
                    )
                )
            );
            foreach($a as $val){
                $child[] = $val['User']['id'];
            }

            if($this->manager_see_multi_lavels == 1){
                $calendarVacations = $this->Vacation->find('all',array('conditions'=>array(
                    'AND' => array('Vacation.type_id' => 0),
                    'OR' => array(
                        'User.parent_id'=>$this->Auth->user('id'),
                        'User.id'=>$child
                    )
                )));

            }
            else{
                $calendarVacations = $this->Vacation->find('all',array('conditions'=>array(
                    'AND' => array('Vacation.type_id' => 0),
                    'OR' => array(
                        'User.parent_id'=>$this->Auth->user('id'),
                        'User.id'=>$this->Auth->user('id')
                    )
                )));
            }
        }

        foreach ($calendarVacations as $calendarVacation){
            if (($this->Auth->user('group_id')==1) || ($calendarVacation['User']['parent_id'] == $this->Auth->user('id'))){

                $statusUpdate = '<div class="status-icons">';
                //submitted
                $statusUpdate .= '<a href="javascript:changeToSubmitted('.$calendarVacation['Vacation']['id'].')" class="change-status submitted ';

                if($calendarVacation['ApprovalStatus']['id']=='1'){
                    $statusUpdate .= 'status-active ';
                }
                $statusUpdate .= ' row-submitted-';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= ' row-';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= '"  title="Submitted" alt="Submitted" vacationid="';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= '" statusid="1" ><i class="icon-question"></i></a>';

                //approved
                $statusUpdate .= '<a href="javascript:changeToApproved('.$calendarVacation['Vacation']['id'].')" class="change-status approved ';
                if($calendarVacation['ApprovalStatus']['id']=='2'){
                    $statusUpdate .= 'status-active ';
                }
                $statusUpdate .= ' row-approved-';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= ' row-';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= '"  title="Submitted" alt="Rejected" vacationid="';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= '" statusid="2" ><i class="icon-ok"></i></a>';

                //rejected
                $statusUpdate .= '<a href="javascript:changeToRejected('.$calendarVacation['Vacation']['id'].')" class="change-status rejected ';
                if($calendarVacation['ApprovalStatus']['id']=='3'){
                    $statusUpdate .= 'status-active ';
                }
                $statusUpdate .= ' row-rejected-';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= ' row-';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= '"  title="Submitted" alt="Submitted" vacationid="';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= '" statusid="3" ><i class="icon-ban-circle"></i></a>';

                //revision
                $statusUpdate .= '<a href="javascript:changeToRevision('.$calendarVacation['Vacation']['id'].')" class="change-status revision ';
                if($calendarVacation['ApprovalStatus']['id']=='4'){
                    $statusUpdate .= 'status-active ';
                }
                $statusUpdate .= ' row-revision-';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= ' row-';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= '"  title="Needs Review" alt="Needs Review" vacationid="';
                $statusUpdate .= $calendarVacation['Vacation']['id'];
                $statusUpdate .= '" statusid="4" ><i class="icon-refresh"></i></a>';

                $statusUpdate .= '<span class="spinner row-'. $calendarVacation['Vacation']['id'] .'"></i></span>';
                $statusUpdate .= '</div>';
            } else {
                $statusUpdate = '';
            }

            $calendarData[] = array(
                'id' => $calendarVacation['Vacation']['id'],
                'title'=>$calendarVacation['User']['full_name'].' - '. $calendarVacation['Vacation']['description'],

                'start'=> CakeTime::format('Y-m-d', strtotime($calendarVacation['Vacation']['start_date'])),
                'end' => CakeTime::format('Y-m-d', strtotime($calendarVacation['Vacation']['end_date'])),
                'allDay' => true,
                'url' => Router::url('/',true) . 'vacations/view/'.$calendarVacation['Vacation']['id'],
                'details' => $calendarVacation['User']['username'].':'. $calendarVacation['Vacation']['description'],
                'className' => 'status'.$calendarVacation['ApprovalStatus']['id']. ' ts-'.$calendarVacation['Vacation']['id'],
                'toolTip' => '',
                'statusUpdate' => $statusUpdate
            );
        }


        //for Sickdays Calendar
        $calendarSickdaysData = array();
        if($this->Auth->user('group_id') == 1) {
            $calendarSickdays = $this->Vacation->find('all', array('conditions' => array('Vacation.type_id' => 1)));
        } else {
            //user children
            $directChildren = $this->User->children($this->Auth->user('id'));
            foreach($directChildren as $directChildren){
                $b[] = $directChildren['User']['id'];
            }

            $b[] = $this->Auth->user('id');
            $a = $this->User->find('all', array(
                    'conditions'=>array(
                        'OR'=>array(
                            'User.id'=>$b,
                            'User.parent_id'=>$this->Auth->user('id')
                        )
                    )
                )
            );
            foreach($a as $val){
                $child[] = $val['User']['id'];
            }

            if($this->manager_see_multi_lavels == 1){
                $calendarSickdays = $this->Vacation->find('all',array('conditions'=>array(
                    'AND' => array('Vacation.type_id' => 1),
                    'OR' => array(
                        'User.parent_id'=>$this->Auth->user('id'),
                        'User.id'=>$child
                    )
                )));

            }
            else{
                $calendarSickdays = $this->Vacation->find('all',array('conditions'=>array(
                    'AND' => array('Vacation.type_id' => 1),
                    'OR' => array(
                        'User.parent_id'=>$this->Auth->user('id'),
                        'User.id'=>$this->Auth->user('id')
                    )
                )));
            }
        }

        foreach ($calendarSickdays as $calendarSickday){
            if (($this->Auth->user('group_id')==1) || ($calendarSickday['User']['parent_id'] == $this->Auth->user('id'))){

                $statusUpdate = '<div class="status-icons">';
                //submitted
                $statusUpdate .= '<a href="javascript:changeToSubmitted('.$calendarSickday['Vacation']['id'].')" class="change-status submitted ';

                if($calendarSickday['ApprovalStatus']['id']=='1'){
                    $statusUpdate .= 'status-active ';
                }
                $statusUpdate .= ' row-submitted-';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= ' row-';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= '"  title="Submitted" alt="Submitted" vacationid="';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= '" statusid="1" ><i class="icon-question"></i></a>';

                //approved
                $statusUpdate .= '<a href="javascript:changeToApproved('.$calendarSickday['Vacation']['id'].')" class="change-status approved ';
                if($calendarSickday['ApprovalStatus']['id']=='2'){
                    $statusUpdate .= 'status-active ';
                }
                $statusUpdate .= ' row-approved-';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= ' row-';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= '"  title="Submitted" alt="Rejected" vacationid="';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= '" statusid="2" ><i class="icon-ok"></i></a>';

                //rejected
                $statusUpdate .= '<a href="javascript:changeToRejected('.$calendarSickday['Vacation']['id'].')" class="change-status rejected ';
                if($calendarSickday['ApprovalStatus']['id']=='3'){
                    $statusUpdate .= 'status-active ';
                }
                $statusUpdate .= ' row-rejected-';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= ' row-';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= '"  title="Submitted" alt="Submitted" vacationid="';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= '" statusid="3" ><i class="icon-ban-circle"></i></a>';

                //revision
                $statusUpdate .= '<a href="javascript:changeToRevision('.$calendarSickday['Vacation']['id'].')" class="change-status revision ';
                if($calendarSickday['ApprovalStatus']['id']=='4'){
                    $statusUpdate .= 'status-active ';
                }
                $statusUpdate .= ' row-revision-';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= ' row-';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= '"  title="Needs Review" alt="Needs Review" vacationid="';
                $statusUpdate .= $calendarSickday['Vacation']['id'];
                $statusUpdate .= '" statusid="4" ><i class="icon-refresh"></i></a>';

                $statusUpdate .= '<span class="spinner row-'. $calendarSickday['Vacation']['id'] .'"></i></span>';
                $statusUpdate .= '</div>';
            } else {
                $statusUpdate = '';
            }
            $calendarData[] = array(
                'id' => $calendarSickday['Vacation']['id'],
                'title'=>'[Sick day] ' . $calendarSickday['User']['full_name'].' - '. $calendarSickday['Vacation']['description'],
                'start'=> CakeTime::format('Y-m-d', strtotime($calendarSickday['Vacation']['start_date'])),
                'end' => CakeTime::format('Y-m-d', strtotime($calendarSickday['Vacation']['end_date'])),
                'allDay' => true,
                'url' => Router::url('/',true) . 'vacations/view/'.$calendarSickday['Vacation']['id'],
                'details' => $calendarSickday['User']['username'].':'. $calendarSickday['Vacation']['description'],
                'className' => 'status'.$calendarSickday['ApprovalStatus']['id']. ' ts-'.$calendarSickday['Vacation']['id'],
                'toolTip' => '',
                'statusUpdate' => $statusUpdate
            );
        }

        //user
        if ($this->Auth->user('group_id') == 1){
            $userList = $this->User->find('list');
        } else {
            $userList = $this->User->find('list',array(
                'conditions'=>array('OR'=>array(
                    'User.id'=>$this->Auth->user('id'),
                    'User.parent_id'=>$this->Auth->user('id')
                ))

            ));
        }

        $this->set('userList',$userList);
        $this->set('approvalStatusList',$this->Vacation->ApprovalStatus->find('list'));
        $this->set('calendarData',$calendarData);
    }

    public function reports($csvFile = NULL){
        if (!$this->Auth->user('id')) {
            $this->redirect('/users/logout');
        }
        Controller::disableCache();
        if(!isset($user)) {
            $user = $this->Auth->user('id');
        }
        if ($this->passedArgs) {
            $args = $this->passedArgs;
            if(isset($args['search_report_from'])){
                if(empty($args['search_report_from'])){
                    $start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
                    $args['search_report_from'] = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
                } else {
                    $start = $args['search_report_from'];
                }
            } else {
                $start = date("Y-m-d", strtotime('first day of January this year'));
                //$start = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1, date("Y")));
            }
            if(isset($args['search_report_to'])){
                if(empty($args['search_report_to'])){
                    $end = date('Y-m-d');
                    $args['search_report_to'] = date('Y-m-d');
                } else {
                    $end = $args['search_report_to'];
                }
            } else {
                $end = date("Y-m-d", strtotime('last day of December this year'));
                //$end = date('Y-m-d');
            }
            if(isset($args['search_user_id'])){
                if(empty($args['search_user_id'])){
                    $args['search_user_id'] = $user;
                } else {
                    $user = $args['search_user_id'];
                }
            }
        } else {
            $start = date("Y-m-d", strtotime('first day of January this year'));
            $end = date("Y-m-d", strtotime('last day of December this year'));
        }


        $start = CakeTime::format('Y-m-d', strtotime($start), null, $this->serverTimezone);
        $end = CakeTime::format('Y-m-d', strtotime($end), null, $this->serverTimezone);
        $this->set('userTimezone', $this->userTimezone);

        $this->Prg->commonProcess();

        if ($csvFile) {
            /*
            $this->paginate = array(
                    'conditions' => $this->Vacation->parseCriteria($this->passedArgs),
                    'order' => array(
                            'Vacation.modified' => 'desc'
                    )
            );*/
            $this->request->params['named']['page'] = null;
        }
        else {
            if($this->Auth->user('group_id') == 1) {

                $this->paginate = array(
                    'conditions' => array_merge($this->Vacation->parseCriteria($this->passedArgs),array(

                    )),
                    'limit' => $this->option_row_other,
                    'group' => array('Vacation.user_id')

                );

            } else {

                //user children
                $directChildren = $this->User->children($this->Auth->user('id'));
                foreach($directChildren as $directChildren){
                    $b[] = $directChildren['User']['id'];
                }
                $b[] = $this->Auth->user('id');
                $a = $this->User->find('all',array('conditions'=>array(
                        'OR'=>array('User.id'=>$b,
                            'User.parent_id'=>$this->Auth->user('id'))
                    )
                    )
                );
                foreach($a as $val){
                    $child[] = $val['User']['id'];
                }

                if($this->manager_see_multi_lavels == 1){
                    $this->paginate = array(
                        'conditions' => array_merge($this->Vacation->parseCriteria($this->passedArgs),
                            array(
                                'OR' =>array(
                                    'User.id'=>$child,
                                    'User.parent_id'=>$this->Auth->user('id'))
                            )),
                        'limit' => $this->option_row_other,
                        'group' => array('Vacation.user_id')
                    );
                }
                else{
                    $this->paginate = array(
                        'conditions' => array_merge($this->Vacation->parseCriteria($this->passedArgs),
                            array(
                                'OR' =>array(
                                    'User.id'=>$this->Auth->user('id'),
                                    'User.parent_id'=>$this->Auth->user('id'))
                            )),
                        'limit' => $this->option_row_other,
                        'group' => array('Vacation.user_id')
                    );
                }
            }
        }

        if ($this->Auth->user('group_id') == 1){
            $userList = $this->User->find('list');
        } else {

            // user children
            $directChildren = $this->User->children($this->Auth->user('id'));
            foreach($directChildren as $directChildren){
                $b[] = $directChildren['User']['id'];
            }
            $b[] = $this->Auth->user('id');
            $a = $this->User->find('all',array('conditions'=>array(
                    'OR'=>array('User.id'=>$b,
                        'User.parent_id'=>$this->Auth->user('id'))
                )
                )
            );
            foreach($a as $val){
                $child[] = $val['User']['id'];
            }
            if($this->manager_see_multi_lavels == 1){
                $userList = $this->User->find('list',array(
                    'conditions'=>array('OR'=>array(
                        'User.id'=>$child,
                        'User.parent_id'=>$this->Auth->user('id')
                    ))
                ));

            }
            else{
                $userList = $this->User->find('list',array(
                    'conditions'=>array('OR'=>array(
                        'User.id'=>$this->Auth->user('id'),
                        'User.parent_id'=>$this->Auth->user('id')
                    ))
                ));
            }
        }

        $vacations = $this->Paginate('Vacation');

        $vacations_final_data = array();
        $approved_by_ids = array();
        foreach($vacations as $key=>$vacation){
            if(isset($vacations[$key]['Vacation'])){
                unset($vacations[$key]['Vacation']);
            }
            if(isset($vacations[$key]['Sick'])){
                unset($vacations[$key]['Sick']);
            }
            if(isset($vacations[$key]['TotalVacations'])){
                unset($vacations[$key]['TotalVacations']);
            }


            $vl = $this->Vacation->find('all',array('conditions'=>array(
                'Vacation.type_id' => '0',
                'Vacation.start_date >=' => $start,
                'Vacation.end_date <=' => $end,
                //'Vacation.approval_status_id' => 2,
                'Vacation.user_id' => $vacations[$key]['User']['id']
            )));

            if(isset($vl)){
                foreach ($vl as $each) {
                    if ($each['Vacation']['approved_by_id'] != null) {
                        $approved_by_ids[] = $each['Vacation']['approved_by_id'];
                    }
                }

                $vacations[$key]['Vacation'] = $vl;
                $vdays = 0;
                foreach($vl as $vc){
                    $temp_dates = $this->_dateRange($vc['Vacation']['start_date'], $vc['Vacation']['end_date']);

                    $temp_count = 0;
                    foreach($temp_dates as $vdate){
                        if(!$this->isWeekend($vdate)){
                            $temp_count++;
                        }
                    }
                    $vdays = $vdays + $temp_count;
                }
                $vacations[$key]['Days'] = $vdays;
            } else {
                $vacations[$key]['Vacation'] = array();
            }

            //debug($vacations[$key]['Vacation']);// exit;

            $sl = $this->Vacation->find('all',array('conditions'=>array(
                'Vacation.type_id' => '1',
                'Vacation.start_date >=' => $start,
                'Vacation.start_date <=' => $end,
                //'Vacation.approval_status_id' => 2,
                'Vacation.user_id' => $vacations[$key]['User']['id']
            )));
            if(isset($sl)){
                foreach ($sl as $each) {
                    if ($each['Vacation']['approved_by_id'] != null) {
                        $approved_by_ids[] = $each['Vacation']['approved_by_id'];
                    }
                }

                $vacations[$key]['Sick'] = $sl;
                $sdays = 0;
                foreach($sl as $sc){
                    $temp_dates = $this->_dateRange($sc['Vacation']['start_date'], $sc['Vacation']['end_date']);
                    $temp_count = 0;
                    foreach($temp_dates as $sdate){
                        if(!$this->isWeekend($sdate)){
                            $temp_count++;
                        }
                    }
                    $sdays = $sdays + $temp_count;
                }
                $vacations[$key]['SDays'] = $sdays;
            } else {
                $vacations[$key]['Sick'] = array();
            }

            $this->loadModel('Job');
            $job = $this->Job->find('all', array(
                    'conditions' => array('Job.user_id' => $vacations[$key]['User']['id']),
                    'order' => array('Job.modified'=>'desc'),
                    'limit' => 1
                )
            );
            if ($job[0]['Job']['vacation_days'] > 0) {
                $vacations[$key]['TotalVacations'] = $job[0]['Job']['vacation_days'];
            } else {
                $option_vacation_per_year = $this->Option->find('first',array('conditions'=>array('name'=>'vacation_per_year')));
                if(!empty($option_vacation_per_year)) {
                    $vacations[$key]['TotalVacations'] = $option_vacation_per_year['Option']['value'];
                } else {
                    $vacations[$key]['TotalVacations'] = array();
                }
            }
        }

        if (!empty($approved_by_ids)) {
            $approved_by_users = $this->User->find('all', array(
                'fields' => array('User.id', 'User.full_name'),
                'conditions' => array(
                    'User.id' => array_unique($approved_by_ids)
                ),
                'recursive' => -1
            ));
        } else {
            $approved_by_users = array();
        }

        foreach($vacations as $each) {
            if (!empty($each['Vacation']) || !empty($each['Sick'])) {
                $vacations_final_data[] =  $each;
            }
        }

        //unset($vacations_final_data[array_search(array_unique($vacations_final_data),$vacations_final_data)]);


        $start = CakeTime::format('Y-m-d', strtotime($start), null, $this->userTimezone);
        $end = CakeTime::format('Y-m-d', strtotime($end), null, $this->userTimezone);
        $this->request->data['Vacation']['search_user_id'] = $user;
        $this->request->data['Vacation']['search_report_from'] = $start;
        $this->request->data['Vacation']['search_report_to'] = $end;

        $this->set('userList',$userList);
        $this->set('vacations', $vacations_final_data);
        $this->set('approved_by_users', $approved_by_users);
    }

    public function update() {

    }

    public function view($id = null){
        $this->Vacation->id = $id;
        if(!$this->Vacation->exists()){
            throw new NotFoundException('Record not found');
        }

        $user_id = $this->Vacation->read(array('Vacation.user_id','User.parent_id'), $id);

        //general user and its not own. and not its manager
        if($this->Auth->user('group_id') == 3 && (($user_id['Vacation']['user_id'] != $this->Auth->user('id')) && ($user_id['User']['parent_id'] != $this->Auth->user('id')))) {
            $this->Session->setFlash(__('Oops! Looks like you are not the owner of Vacation. Only the user corresponding to the Vacation can view it.'),'alert',array('class'=>'alert-error'));
            $this->redirect(array('action'=>'calendar'));
        } elseif($this->Auth->user('group_id') == 3 && ($user_id['User']['parent_id'] == $this->Auth->user('id'))) {
            //its manager
        }

        $vacation = $this->Vacation->read();

        $this->set('vacation',$vacation);

    }



    public function add(){
        if($this->request->is('post')){

            if($this->request->data['Vacation']['is_ajax'] == true){
                $this->layout = false;
            }

            if($this->Auth->user('group_id') != 1) {
                $this->request->data['Vacation']['user_id'] = $this->Auth->user('id');

                $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'auto_approve_vacation')));
                if(!empty($option_setting)){
                    $autoApprove = $option_setting['Option']['value'];
                }
                else {
                    $autoApprove = false;
                }

                if($autoApprove == true){
                    $this->request->data['Vacation']['approval_status_id'] = 2; //approved
                } else {
                    $this->request->data['Vacation']['approval_status_id'] = 1; //submitted
                }
            }



            /*new vacation calculation*/

            $curdate = CakeTime::format('Y-m-d H:i:s', date('Y-m-d H:i:s'), null, $this->userTimezone);
            $curdate = CakeTime::format('Y-m-d H:i:s', strtotime($curdate), null, $this->serverTimezone);


            if ($this->Auth->user('group_id') == 1 || $this->Auth->user('group_id') == 2) {
                $this->request->data['Vacation']['approved_by_id'] = $this->Auth->user('id');
                $this->request->data['Vacation']['approved_at'] = $curdate;
            }



            $uid = $this->Auth->user('id');
            $jobList = $this->User->Job->find('all',array(
                'conditions'=> array(
                    'AND' => array(
                        'Job.user_id' => $uid,
                        'OR' => array('Job.end_date '=> null,'Job.end_date >= '=>$curdate)
                    )
                ),
                'order' => array('Job.modified'=>'desc')
            ));

            foreach ($jobList as $theJob){
                $current_job = $theJob['Job']['vacation_days']; // get the first job vacancy and exit
                break;
            }

            $vacationLimitPerYear = $current_job;
            /*end*/


            $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'can_request_vacation_above_limit')));
            if(!empty($option_setting)){
                $canRequestAboveVacationLimit = $option_setting['Option']['value'];
            }
            else {
                $canRequestAboveVacationLimit = true;
            }

            //check vacation in current year
            $thisYear = date('Y'); //currnet year
            $yearStartDate = $thisYear.'-01-01';
            $yearEndDate = $thisYear.'-12-31';
            $yearStartDate = CakeTime::format('Y-m-d', strtotime($yearStartDate), null, $this->userTimezone);
            $yearStartDate = CakeTime::format('Y-m-d', strtotime($yearStartDate), null, $this->serverTimezone);
            $yearEndDate = CakeTime::format('Y-m-d', strtotime($yearEndDate), null, $this->userTimezone);
            $yearEndDate = CakeTime::format('Y-m-d', strtotime($yearEndDate), null, $this->serverTimezone);
            $vacationsCurrentYear = $this->Vacation->find('all',array('conditions'=>array(
                'OR' => array(
                    'AND' => array( // startdate is in between current year
                        'Vacation.start_date >='=>$yearStartDate,
                        'Vacation.start_date <='=>$yearEndDate
                    ),
                    'AND' => array( // enddate is in between current year
                        'Vacation.end_date >='=>$yearStartDate,
                        'Vacation.end_date <='=>$yearEndDate
                    )
                ),
                'AND' => array('Vacation.user_id'=>$this->Auth->user('id'))
            )));
            // now count total days
            $totalVacationDaysThisYear = 0;
            foreach($vacationsCurrentYear as $vacationCurrentYear){
                // the indirect way
                $tempDates = $this->_dateRange(date('Y-m-d',strtotime($vacationCurrentYear['Vacation']['start_date'])), date('Y-m-d',strtotime($vacationCurrentYear['Vacation']['end_date'])));
                $dcount = 0;
                foreach($tempDates as $vdate){
                    if($this->isWeekend($vdate)){

                    } else {
                        $dcount++;
                    }

                }
                $totalVacationDaysThisYear = $totalVacationDaysThisYear + $dcount;
            }
            //debug($totalVacationDaysThisYear);
            //exit;

            $isSaved = false;
            $message = '';

            //if over limit then ...
            if($totalVacationDaysThisYear > $vacationLimitPerYear){
                if($canRequestAboveVacationLimit == true){
                    //Vacation added. Note that you have used [vacations taken - limit] days more than the limit. Subject to approval.
                    $vacationDates = $this->_dateRange(date('Y-m-d',strtotime($this->request->data['Vacation']['start_date'])), date('Y-m-d',strtotime($this->request->data['Vacation']['end_date'])));
                    $dcount = 0;
                    foreach($vacationDates as $vdate){
                        if($this->isWeekend($vdate)){

                        } else {
                            $dcount++;
                        }

                    }

                    $extraDays = ($totalVacationDaysThisYear + $dcount) - $vacationLimitPerYear;
                    $message = "Vacation added. Note that you have used ".$extraDays." days more than the limit. Subject to approval.";
                    $isSaved = $this->Vacation->save($this->request->data);
                } else {
                    //Vacation could not be added. You've already used your vacation days for this year.
                    $message = "Vacation could not be added. You've already used your vacation days for this year.";
                }
            } else {
                //Vacation added. You have [limit - vacations taken so far] vacation days left.
                $vacationDates = $this->_dateRange(date('Y-m-d',strtotime($this->request->data['Vacation']['start_date'])), date('Y-m-d',strtotime($this->request->data['Vacation']['end_date'])));
                $dcount = 0;
                foreach($vacationDates as $vdate){
                    if($this->isWeekend($vdate)){

                    } else {
                        $dcount++;
                    }

                }

                $leftDays = ($vacationLimitPerYear - ($totalVacationDaysThisYear + $dcount));
                $message = "Vacation added. You have ".$leftDays." vacation days left.";
                $isSaved = $this->Vacation->save($this->request->data);
            }

            if($isSaved){
                //send mail
                $this->User->id = $this->request->data['Vacation']['user_id'];
                $user = $this->User->read();
                $this->User->id = $user['User']['parent_id'];
                $manager = $this->User->read();
                /*
                $vacationDates = $dates; //this is already in client timezone

                if(sizeof($vacationDates) > 2) {
                    if($this->vacation_emails){
                        $emails = $this->_csvstring_to_array($this->vacation_emails);

                        $this->_sendVacationMail($emails[0],$user['User']['full_name'],$vacationDates);
                    }
                }
                else {
                    $this->_sendVacationMail($manager['User']['email'],$user['User']['full_name'],$vacationDates);
                }
                */
                if($this->request->data['Vacation']['start_date'] != $this->request->data['Vacation']['end_date']){

                    // if start date is not eaqaul to end date means its more than a day
                    // so send email to manager
                    $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'manager_vacation_notification')));
                    if(!empty($option_setting)){
                        $notify_manager = $option_setting['Option']['value'];
                    }
                    else {
                        $notify_manager = false;
                    }

                    $option_setting = $this->Option->find('first',array('conditions'=>array('name'=>'admin_vacation_notification')));
                    if(!empty($option_setting)){
                        $notify_admin = $option_setting['Option']['value'];
                    }
                    else {
                        $notify_admin = false;
                    }

                    $vacationDates = $this->_dateRange(date('Y-m-d',strtotime($this->request->data['Vacation']['start_date'])), date('Y-m-d',strtotime($this->request->data['Vacation']['end_date'])));

                    if($notify_manager){
                        if($manager){//if has manager
                            $this->_sendVacationMail($manager['User']['email'],$user['User']['full_name'],$vacationDates);
                        }
                    }

                    if($notify_admin){
                        //$admin = $this->first_active_admin();
                        /*if(isset($admin['User']['email'])){
                            $this->_sendVacationMail($admin['User']['email'],$user['User']['full_name'],$vacationDates);
                        }*/
                        //all active admin
                        $active_admin = $this->User->find('all',array('conditions'=>array('User.group_id' => 1,'User.active' => 1)));
                        $active_admin_count = count($active_admin);
                        if(isset($active_admin)){
                            for($i=0;$i<$active_admin_count;$i++){
                                $this->_sendVacationMail($active_admin[$i]['User']['email'],$user['User']['full_name'],$vacationDates);
                            }
                        }
                    }


                }
                if($this->request->data['Vacation']['is_ajax'] == true){
                    $this->layout = false;
                    echo "Ok"; exit;
                }
                else{
                    $this->Session->setFlash(__($message),'alert');
                    $this->redirect(array('action'=>'calendar'));
                }
            }
            else
            {
                if($this->request->data['Vacation']['is_ajax'] == true){
                    $this->layout = false;
                    echo "Vacation is not saved";
                    exit;
                }
                else{
                    if($message){
                        $this->Session->setFlash(__($message),'alert', array('class'=>'alert-error'));
                    } else {
                        $this->Session->setFlash(__('Unable to add'),'alert', array('class'=>'alert-error'));
                    }
                }
            }

        }

        if ($this->Auth->user('group_id') == 1){
            $userList = $this->User->find('list',array('order'=>array('User.first_name ASC','User.last_name ASC')));
            //debug($userList);exit;
        } else {
            $userList = $this->User->find('list',array(
                'conditions'=>array('OR'=>array(
                    'User.id'=>$this->Auth->user('id'),
                    'User.parent_id'=>$this->Auth->user('id')
                ))

            ));
        }

        $this->set('userList',$userList);
        $this->set('approvalStatusList',$this->Vacation->ApprovalStatus->find('list'));

    }

    public function edit($id = null){
        $this->Vacation->id = $id;
        if(!$this->Vacation->exists()){
            throw new NotFoundException('Record not found');
        }

        $user_id = $this->Vacation->read(array('Vacation.user_id','User.parent_id'), $id);
        $restricted = false;
        $is_manager = false;
        //general user and its not own. and not its manager
        if($this->Auth->user('group_id') == 3 && (($user_id['Vacation']['user_id'] != $this->Auth->user('id')) && ($user_id['User']['parent_id'] != $this->Auth->user('id')))) {
            $this->Session->setFlash(__('Oops! Looks like you are not the owner of Vacation. Only the user corresponding to the Vacation can edit it.'),'alert',array('class'=>'alert-error'));
            $this->redirect(array('action'=>'calendar'));
        } elseif($this->Auth->user('group_id') == 3 && ($user_id['User']['parent_id'] == $this->Auth->user('id'))) {
            //its manager
            $is_manager = true;
        }

        if($this->Auth->user('group_id') == 3) {
            $restricted = true;
        }

        if($this->request->is('post')){
            // only date field need no conversion thruout
            $curdate = CakeTime::format('Y-m-d H:i:s', date('Y-m-d H:i:s'), null, $this->userTimezone);
            $curdate = CakeTime::format('Y-m-d H:i:s', strtotime($curdate), null, $this->serverTimezone);
            if ($this->Auth->user('group_id') == 1 || $this->Auth->user('group_id') == 2) {
                $this->request->data['Vacation']['approved_by_id'] = $this->Auth->user('id');
                $this->request->data['Vacation']['approved_at'] = $curdate;
            }
            if($this->Vacation->save($this->request->data)){
                $this->Session->setFlash('Vacation data saved ','alert');
                $this->redirect(array('action'=>'calendar'));
            }
            else
            {
                $this->Session->setFlash(__('Unable to save changes'),'alert', array('class'=>'alert-error'));
            }
        }

        if ($this->Auth->user('group_id') == 1){
            $userList = $this->User->find('list');
        } else {
            $userList = $this->User->find('list',array(
                'conditions'=>array('OR'=>array(
                    'User.id'=>$this->Auth->user('id'),
                    'User.parent_id'=>$this->Auth->user('id')
                ))

            ));
        }

        $this->set('userList',$userList);
        $this->set('approvalStatusList',$this->Vacation->ApprovalStatus->find('list'));
        $this->request->data = $this->Vacation->read();
        $this->set('restricted',$restricted);
        $this->set('is_manager',$is_manager);

    }

    public function changeStatus($id = null) {
        $this->Vacation->id = $id;
        if(!$this->Vacation->exists()){
            throw new NotFoundException('Record not found');
        }

        if($this->request->is('post')){
            $status_id = $this->request->data('statusid');
            //print_r($status_id);
            //exit;
            if($this->Vacation->saveField('approval_status_id',$status_id)){
                $this->Vacation->saveField('approved_by_id',$this->Auth->user('id'));
                $curdate = CakeTime::format('Y-m-d H:i:s', date('Y-m-d H:i:s'), null, $this->userTimezone);
                $curdate = CakeTime::format('Y-m-d H:i:s', strtotime($curdate), null, $this->serverTimezone);
                $this->Vacation->saveField('approved_at',$curdate);

                echo 'Ok';
            }
            else {
                echo 'Err';
            }
        }
        exit;
    }

    public function readyTip($id = null) {
        $this->Vacation->id = $id;
        if(!$this->Vacation->exists()){
            throw new NotFoundException('Record not found');
        }

        if($this->request->is('post')){
            $status_id = $this->request->data('statusid');
            if($this->Vacation->saveField('approval_status_id',$status_id)){
                $this->Vacation->saveField('approved_by_id',$this->Auth->user('id'));
                $curdate = CakeTime::format('Y-m-d H:i:s', date('Y-m-d H:i:s'), null, $this->userTimezone);
                $curdate = CakeTime::format('Y-m-d H:i:s', strtotime($curdate), null, $this->serverTimezone);
                $this->Vacation->saveField('approved_at',$curdate);

                $this->loadModel('Vacation');
                $data = $this->Vacation->find('all', array(
                    'conditions' => array(
                        'Vacation.id' => $id
                    )
                ));
                $approvedBy = $this->User->find('all', array(
                    'fields' => array('User.name'),
                    'conditions' => array(
                        'User.id' => $data[0]['Vacation']['approved_by_id']
                    )
                ));

                foreach($data as $each) {
                    $each['Vacation']['start_date'] = CakeTime::format('Y-m-d', strtotime($each['Vacation']['start_date']));
                    $each['Vacation']['end_date'] = CakeTime::format('Y-m-d', strtotime($each['Vacation']['end_date']));
                    if ($each['Vacation']['approval_status_id'] == 1) {
                        $status = 'warning';
                        $lbl = '';
                        $approved_by = '';
                        $approved_time = '';
                    } elseif ($each['Vacation']['approval_status_id'] == 2) {
                        $status = 'success';
                        $lbl = 'Approved by: ';
                        $approved_by = $approvedBy[0]['User']['name'];
                        $approved_time = $each['Vacation']['approved_at'];
                    } elseif ($each['Vacation']['approval_status_id'] == 3) {
                        $status = 'danger';
                        $lbl = 'Rejected by: ';
                        $approved_by = $approvedBy[0]['User']['name'];
                        $approved_time = $each['Vacation']['approved_at'];
                    } elseif ($each['Vacation']['approval_status_id'] == 4) {
                        $status = 'info';
                        $lbl = '';
                        $approved_by = '';
                        $approved_time = '';
                    }
                }

                if ($lbl != '') {
                    $newTipData .= $lbl . $approved_by . ' at ' . date('M', strtotime($approved_time)) . ' ' . date('d', strtotime($approved_time)) . ', ' . date('Y', strtotime($approved_time)) . '<br />';
                } else {
                    $newTipData .= '<br />';
                }
                echo $newTipData;
            } else {
                echo '';
            }
        }
        exit;
    }

    public function delete($id = null){
        if (!$this->request->is('post')) {
            throw new MethodNotAllowedException();
        }

        $user_id = $this->Vacation->read(array('Vacation.user_id','User.parent_id'), $id);

        //general user and its not own. and not its manager
        if($this->Auth->user('group_id') == 3 && (($user_id['Vacation']['user_id'] != $this->Auth->user('id')) && ($user_id['User']['parent_id'] != $this->Auth->user('id')))) {
            $this->Session->setFlash(__('Oops! Looks like you are not the owner of Vacation. Only the user corresponding to the Vacation can delete it.'),'alert',array('class'=>'alert-error'));
            $this->redirect(array('action'=>'calendar'));
        } elseif($this->Auth->user('group_id') == 3 && ($user_id['User']['parent_id'] == $this->Auth->user('id'))) {
            //its manager
        }

        $this->Vacation->id = $this->request->data['id']; //--
        if(!$this->Vacation->exists()){
            throw new NotFoundException('Record not found');
        }

        if($this->Vacation->delete($id)){
            $this->Session->setFlash(__('Vacation deleted'),'alert');
            $this->redirect(array('action'=>'calendar'));
        }
        else
        {
            $this->Session->setFlash(__('Unable to delete'),'alert', array('class'=>'alert-error'));
            $this->redirect(array('action'=>'calendar'));
        }
    }

    protected function _sendVacationMail($emails,$user,$vacationDates) {
        $email = new CakeEmail('default');
        //email send from who apply for vacation
        $v = $this->Vacation->read();
        $creator_email = $v['User']['email'];
        $creator_name = $v['User']['name'];
        if (filter_var($creator_email, FILTER_VALIDATE_EMAIL)){
            $email->from($creator_email,$creator_name);
        }
        else if ($this->from_email){
            $email->from(array($this->from_email=>$this->from_email_title));
        }

        $option_email_content = $this->Option->find('first',array('conditions'=>array('name'=>'email_template_vacation')));
        $option_settings_date_format = $this->Option->find('first',array('conditions'=>array('name'=>'date_format')));
        $dformat = '';
        if($option_settings_date_format){
            $dformat = $option_settings_date_format['Option']['value'];
        } else {
            $dformat = 'Y-m-d';
        }

        $email_content = $option_email_content['Option']['value'];
        $vacationList = '<ul>';
        foreach($vacationDates  as $vacationDate){
            $vacationList .= '<li>'. CakeTime::format($dformat,$vacationDate) .'</li>';
        }
        $vacationList .= '</ul>';

        $emailVars = array(
            'fullname'=>$user, //user Full Name as of now
            'vacationlist'=>$vacationList,
        );

        foreach($emailVars as $key=>$value){
            $email_content = str_replace('{{'.$key.'}}',$value,$email_content);
        }

        $email->to($emails);

        $email->subject('Vacation notification for	'.$user);
        $email->template(null); //
        $email->theme('Default');
        $email->message($email_content);
        $email->emailFormat('html');
        $email->viewVars(array(
            'title'=>$this->appTitle,
            'appUrl'=>$this->appUrl,
            'user'=>$user,
            'vacationDates'=>$vacationDates
        ));
        if($this->use_smtp){
            $email->transport('Smtp');
            $email->config(array('host'=>$this->smtp_host,'port'=>$this->smtp_port,'username'=>$this->smtp_user,'password'=>$this->smtp_password));
            $smtpError = false;
            try {
                $email->send($email_content);
            }
            catch(Exception $e) {
                $smtpError = true;
            }

            if($smtpError) {
                $email->transport('Mail');
                try {
                    $email->send($email_content);
                }
                catch(Exception $e) {
                    //
                }
            }
        } else {
            $email->transport('Mail');
            try {
                $email->send($email_content);
            }
            catch(Exception $e) {

            }
        }

    }

    protected function _csvstring_to_array($string, $separatorChar = ',', $enclosureChar = '"', $newlineChar = "\n") {
        // @author: Klemen Nagode
        $array = array();
        $size = strlen($string);
        $columnIndex = 0;
        $rowIndex = 0;
        $fieldValue="";
        $isEnclosured = false;
        for($i=0; $i<$size;$i++) {

            $char = $string{$i};
            $addChar = "";

            if($isEnclosured) {
                if($char==$enclosureChar) {

                    if($i+1<$size && $string{$i+1}==$enclosureChar){
                        // escaped char
                        $addChar=$char;
                        $i++; // dont check next char
                    }else{
                        $isEnclosured = false;
                    }
                }else {
                    $addChar=$char;
                }
            }else {
                if($char==$enclosureChar) {
                    $isEnclosured = true;
                }else {

                    if($char==$separatorChar) {

                        $array[$rowIndex][$columnIndex] = $fieldValue;
                        $fieldValue="";

                        $columnIndex++;
                    }elseif($char==$newlineChar) {
                        echo $char;
                        $array[$rowIndex][$columnIndex] = $fieldValue;
                        $fieldValue="";
                        $columnIndex=0;
                        $rowIndex++;
                    }else {
                        $addChar=$char;
                    }
                }
            }
            if($addChar!=""){
                $fieldValue.=$addChar;

            }
        }

        if($fieldValue) { // save last field
            $array[$rowIndex][$columnIndex] = $fieldValue;
        }
        return $array;
    }

    private function isWeekend($date) {
        $weekDay = date('w', strtotime($date));
        return ($weekDay == 0 || $weekDay == 6);
    }
    private function _dateRange($first, $last, $step = '+1 day', $format = 'Y-m-d' ) {

        $dates = array();
        $current = strtotime($first);
        $last = strtotime($last);

        while( $current <= $last ) {

            $dates[] = date($format, $current);
            $current = strtotime($step, $current);
        }

        return $dates;
    }

    public function super_unique($array)
    {
        $result = array_map("unserialize", array_unique(array_map("serialize", $array)));

        foreach ($result as $key => $value)
        {
            if ( is_array($value) )
            {
                $result[$key] = super_unique($value);
            }
        }

        return $result;
    }

}