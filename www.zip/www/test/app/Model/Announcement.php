<?php
class Announcement extends AppModel {
	
	}