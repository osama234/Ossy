<?php
class ApprovalStatus extends AppModel {
	
	public $actsAs = array('Search.Searchable');
	
	public $filterArgs = array(
			'search_name' => array('type'=>'like','field'=>array('ApprovalStatus.name'))
	);
	
	public function parentNode() {
		return null;
	}
}