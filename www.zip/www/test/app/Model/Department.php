<?php
class Department extends AppModel {
	public $hasMany = 'User';
	
	public $actsAs = array('Acl' => array('type' => 'both'));
	
	public function parentNode() {
		return null;
	}
}