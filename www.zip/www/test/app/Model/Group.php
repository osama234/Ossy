<?php
class Group extends AppModel {
	public $hasMany = array('User');
	
	public $actsAs = array('Acl' => array('type' => 'both'));
	
	public function parentNode() {
		return null;
	}
}