<?php
class Job extends AppModel {
	
	public $belongsTo = 'User';
	
	//public $hasMany = array('Timesheet');
	
	public $actsAs = array('Search.Searchable');
	
	public $virtualFields = array(
			"monthly_salary"=>"Job.hourly_salary*Job.expected_hours*4",
			'yearly_salary'=>'Job.hourly_salary*Job.expected_hours*4*12'
	);
	
	public $filterArgs = array(
			'search_name' => array('type'=>'like','field'=>array('Job.name')),
			'search_user_id' => array('type'=>'value','field'=>'User.id'),
			'search_start' => array('type'=>'query','method'=>'searchStart'),
			'search_end' => array('type'=>'query','method'=>'searchEnd'),
			'search_all' => array('type'=>'query','method'=>'searchDefault')
	);
	
	public function searchDefault($data = array()) {
		$filter = $data['search_all']; 
		$cond = array(
				'OR' => array(
						'User.username LIKE' => '%' . $filter . '%',
						'User.first_name LIKE' => '%' . $filter . '%',
						'User.last_name LIKE' => '%' . $filter . '%',
                                                $this->User->virtualFields['full_name'] . ' LIKE' => '%' . $filter . '%',
						$this->alias . '.name LIKE' => '%' . $filter . '%'
	
				));
                return $cond;
	}
	
	public function searchStart($data = array()) {
		if((!empty($data['search_end']) && (!empty($data['search_start'])))){
			$cond = array(
					'AND' => array(
						$this->alias . '.start_date >= ' => $data['search_start'],
						$this->alias . '.end_date <= ' => $data['search_end'],
					)
			);
		} elseif ((empty($data['search_end']) && (!empty($data['search_start'])))){
			$cond = array('Job.start_date >= '=>$data['search_start']);
		}
		else {
			$cond = array();
		}
		
		return $cond;
	}
	
	public function searchEnd($data = array()) {
		
		if((!empty($data['search_end']) && (!empty($data['search_start'])))){
			$cond = array();
		} elseif((!empty($data['search_end']) && (empty($data['search_start'])))) {
			$cond = array($this->alias . '.end_date <= ' => $data['search_end']);
			
		} else {
			$cond = array();
		}
	
		return $cond;
	}
	
	public $validate = array(
			'name' => array(
					'required' => array(
							'rule' => array('notEmpty'),
							'message' => 'Name is required'
					)
			)
	);
	
	public function parentNode() {
		return null;
	}
}