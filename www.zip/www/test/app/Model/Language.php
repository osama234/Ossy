<?php
class Language extends AppModel {
    //public $actsAs = array('Acl' => array('type' => 'both'));
	
    /*public function parentNode() {
            return null;
    }*/
}