<?php
class Option extends AppModel {
    
	public $actsAs = array(
			'Upload.Upload' => array(
					'logo' => array(
							'fields' => array(
									'dir' => 'logo_dir'
							),
							'mimetypes'=> array (
									'application/pdf',
									'image/bmp',
									'image/gif',
									'image/jpeg',
									'image/pjpeg',
									'image/png',
									'image/vnd.microsoft.icon'
							),
							'extensions' => array(
									'gif', 'jpeg', 'png', 'jpg', 'bmp', 'ico'
							),
							'thumbnailSizes' => array(
                                                                        'logo' => '35x35',
									'l' => '50h'
							),
							'thumbnailMethod' => 'php', //GD library intead of imagick
							'thumbnailQuality' => '100'
					)
			)
	);
	
	
	public $validate = array(
			'row_other' => array(
					'rule1' => array(
							'rule'=> 'numeric',
							'allowEmpty' => false
					)
			),
			'logo' => array(
					'rule' => array('isValidMimeType', array('application/pdf','image/bmp','image/gif', 'image/jpeg','image/pjpeg','image/png','image/vnd.microsoft.icon'), false),
					'message' => 'File type is not supported',
					'required' => false,
					'allowEmpty' =>true
			
			),
			'sender_phone_number' => array(
					
			)
	);
        
	
	public function parentNode() {
		return null;
	}
	
	function timezone_list() {
		static $timezones = null;
	
		if ($timezones === null) {
			$timezones = array();
			$offsets = array();
			$now = new DateTime();
	
			$i = 0;
                        foreach (DateTimeZone::listIdentifiers() as $timezone) {
                                
                                
				$now->setTimezone(new DateTimeZone($timezone));
				$offsets[] = $offset = $now->getOffset();
				$timezones[$timezone] = /*'(' . format_GMT_offset($offset) . ') ' . */$this->format_timezone_name($timezone);
			}
	
			array_multisort($offsets, $timezones);
		}
	//debug(DateTimeZone::listIdentifiers(DateTimeZone::AMERICA));
		return $timezones;
	}
	
	function format_GMT_offset($offset) {
		$hours = intval($offset / 3600);
		$minutes = abs(intval($offset % 3600 / 60));
		return 'GMT' . ($offset ? sprintf('%+03d:%02d', $hours, $minutes) : '');
	}
	
	function format_timezone_name($name) {
		//$name = str_replace('/', ', ', $name);
		$name = str_replace('_', ' ', $name);
		$name = str_replace('St ', 'St. ', $name);
		return $name;
	}
        
        function userlist($userlist){
             
             for($i=0; $i<COUNT($userlist); $i++) :
                 
                 $users[$userlist[$i]['User']['id']] = $userlist[$i]['User']['full_name'];
                 
             endfor;
             
             return $users;
            
        }
}