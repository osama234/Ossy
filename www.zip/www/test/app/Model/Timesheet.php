<?php
class Timesheet extends AppModel {
	
	public $belongsTo = array('User','ApprovalStatus'); //,'Job');
	
	public $actsAs = array('Search.Searchable');
	
	public $virtualFields = array(
			'hours' => 'TIMEDIFF(Timesheet.end_time,Timesheet.start_time)',
			'expense' => '(TIME_TO_SEC(TIMEDIFF(Timesheet.end_time,Timesheet.start_time))/3600)'
	);
	
	public $filterArgs = array(
			'search_name' => array('type'=>'like','field'=>array('Timesheet.note')),
			'search_user_id' => array('type'=>'value','field'=>'User.id'),
			'search_status_id' => array('type'=>'value','field'=>'ApprovalStatus.id'),
			'search_start' => array('type'=>'query','method'=>'searchStart'),
			'search_end' => array('type'=>'query','method'=>'searchEnd'),
			'search_all' => array('type'=>'query','method'=>'searchDefault'),
			'search_report_from' => array('type'=>'query','method'=>'searchReportDate'),
			'search_report_to' => array('type'=>'query','method'=>'dummy'),
	);
	
	public function searchDefault($data = array()) {
		$filter = $data['search_all'];
		$cond = array(
				'OR' => array(
						'User.username LIKE' => '%' . $filter . '%',
						'User.first_name LIKE' => '%' . $filter . '%',
						'User.last_name LIKE' => '%' . $filter . '%',
						$this->alias . '.note LIKE' => '%' . $filter . '%'
						
				));
		return $cond;
	}
	
	public function searchStart($data = array()) {
		if((!empty($data['search_end']) && (!empty($data['search_start'])))){
			$cond = array(
					'AND' => array(
						$this->alias . '.start_time >= ' => $data['search_start'],
						$this->alias . '.end_time <= ' => $data['search_end'],
					)
			);
		} elseif ((empty($data['search_end']) && (!empty($data['search_start'])))){
			$cond = array('Timesheet.start_time >= '=>$data['search_start']);
		}
		else {
			$cond = array();
		}
		
		return $cond;
	}
	
	public function searchEnd($data = array()) {
		
		if((!empty($data['search_end']) && (!empty($data['search_start'])))){
			$cond = array();
		} elseif((!empty($data['search_end']) && (empty($data['search_start'])))) {
			$cond = array('Timesheet.end_time <= ' => $data['search_end']);
		} else {
			$cond = array();
		}
	
		return $cond;
	}
	
	public function searchReportDate($data = array()) {
		$date_from = $data['search_report_from'] . ' 00:00:00';
		if(!empty($data['search_report_to'])){
			$date_to = $data['search_report_to'] . ' 23:59:59';
		} else {
			$date_to = date('Y-m-d H:i:s');
		}
		
		if((!empty($data['search_report_from']) && (!empty($data['search_report_to'])))){
			$cond = array(
					'AND' => array(
							$this->alias . '.start_time >= ' => $date_from,
							$this->alias . '.end_time <= ' => $date_to,
					)
			);
		} else {
			$cond = array();
		}
		//$cond = array($date_from,$date_to);
		return $cond;
	}
	
	public function dummy($data = array()){
		return array();
	}
	
	public $validate = array(
			'start_time' => array(
					'required' => array(
							'rule' => array('notEmpty'),
							'message' => 'Start time is required'
					)
			),
			'end_time' => array(
					'required' => array(
							'rule' => array('notEmpty'),
							'message' => 'End time is required'
					)
			),
			
	);
	
	/*public function getDayHours($start,$end,$user){
                $dates = $this->dateRange($start, $end);
                $dayHours = array();
		foreach ($dates as $key=>$val){
			if(isset($dates[$key+1])){ //if next day exists
				$dayHours[] = array('date'=>$val,'hour'=>$this->getTotalHours($val, $dates[$key+1], $user));
                                
			}
		}
                return $dayHours;
	}*/
        
        public function getDayHours($start,$end,$user){
            $userTimesheets = $this->find('all', array(
                'fields' => array('start_time', 'end_time'),
                'conditions' => array('user_id' => $user,
                    'start_time >=' => $start,
                    'end_time <=' => $end
                    ),
                'order' => array('start_time ASC')));
            $dailyHours = array();
            foreach($userTimesheets as $userTimesheet) :
                if (date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time'])) == date('Y-m-d', strtotime($userTimesheet['Timesheet']['end_time']))) :
                    $seconds = strtotime($userTimesheet['Timesheet']['end_time']) - strtotime($userTimesheet['Timesheet']['start_time']);
                    $hours = floor($seconds / (60 * 60));
                    if (isset($dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time']))])) :
                        $dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time']))] = $dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time']))] + $hours;
                    else :
                        $dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time']))] = $hours;
                    endif;
                else : 
                    $dates = $this->dateRange(date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time'])), date('Y-m-d', strtotime($userTimesheet['Timesheet']['end_time'])));
                    foreach ($dates as $key => $val) :
                        if ($key == 0) : 
                            $seconds = strtotime(date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time'])) . ' 23:59:59') - strtotime($userTimesheet['Timesheet']['start_time']);
                            $hours = floor($seconds / (60 * 60));
                            if (isset($dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time']))])) :
                                $dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time']))] = $dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time']))] + $hours;
                            else :
                                $dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['start_time']))] = $hours;
                            endif;
                        elseif ($key == count($dates) - 1) :
                            $seconds = strtotime($userTimesheet['Timesheet']['end_time']) - strtotime(date('Y-m-d', strtotime($userTimesheet['Timesheet']['end_time']) . ' 00:00:00'));
                            $hours = floor($seconds / (60 * 60));
                            if (isset($dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['end_time']))])) :
                                $dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['end_time']))] = $dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['end_time']))] + $hours;
                            else :
                                $dailyHours[date('Y-m-d', strtotime($userTimesheet['Timesheet']['end_time']))] = $hours;
                            endif;
                        else :
                            $seconds = 24 * 60 * 60;
                            $hours = floor($seconds / (60 * 60));
                            $dailyHours[date('Y-m-d', strtotime($val))] = $hours;
                        endif;
                    endforeach;
                endif;
            endforeach;
            
            $dates = $this->dateRange($start, $end);
            foreach ($dates as $eachdate) :
                if (empty($dailyHours)) :
                    $dailyHours[$eachdate] = intval(0);
                else :
                    foreach ($dailyHours as $date => $hours) :
                        if (strtotime($eachdate) == strtotime($date)) :
                            $dailyHours[$eachdate] = intval($hours);
                        else :
                            if (!isset($dailyHours[$eachdate])) :
                                $dailyHours[$eachdate] = intval(0);
                            endif;
                        endif;                    
                    endforeach;
                endif;
           endforeach;
            ksort($dailyHours);
            $finalDailyHours = array();
            foreach ($dailyHours as $key => $val) :
                $finalDailyHours[] = array('date' => $key, 'hour' => $val);
            endforeach;
            //debug($finalDailyHours);
            return $finalDailyHours;
	}
	
	public function getWeekHours($start,$end,$user){
		if(date('l', strtotime( $start)) == "Sunday"){
			$dates = $this->dateRange($start, $end,'+7 day');
		} else {
			$next_sunday = date('Y-m-d', strtotime('next Sunday', strtotime($start)));
			$dates = $this->dateRange($next_sunday, $end,'+7 day');
		}
		$weekHours = array();
		foreach ($dates as $key=>$val){
			if(isset($dates[$key+1])){ //if next day exists
				$weekHours[] = array('date'=>$val,'hour'=>$this->getHours($val, $dates[$key+1], $user));
			}
		}
		return $weekHours;
	}
	
	public function getMonthHours($start,$end,$user){ //todo
		if(date('j', strtotime( $start)) == "1"){
			$dates = $this->dateRange($start, $end,'+1 month');
		} else {
			$next_month = date('Y-m-d', strtotime('first day next month', strtotime($start)));
			$dates = $this->dateRange($next_month, $end,'+1 month');
		}
		$monthHours = array();
		foreach ($dates as $key=>$val){
			if(isset($dates[$key+1])){ //if next day exists
				$monthHours[] = array('date'=>$val,'hour'=>$this->getHours($val, $dates[$key+1], $user));
			}
		}
		return $monthHours;
	}
	
	public function getHours($start,$end,$user){
            $userTimesheets = $this->find('all',array(
                'conditions'=>array(
                    'User.id'=>$user,
                    'Timesheet.start_time >=' => $start,
                    'Timesheet.end_time <=' => $end,
                    'Timesheet.end_time >' => $start
                )
            ));
            foreach($userTimesheets as $userTimesheet) :
                $seconds = strtotime($userTimesheet['Timesheet']['end_time']) - strtotime($userTimesheet['Timesheet']['start_time']);
                $totalSeconds = $totalSeconds + $seconds;
            endforeach;
            $hours = floor($totalSeconds / (60 * 60));
            return $hours;
        }
        public function getTotalHours($start,$end,$user){
		$totalSeconds = 0;
		// get timesheets -start end is between the dates
		$userTimesheets = $this->find('all',array('conditions'=>array(
				'User.id'=>$user,
				'Timesheet.start_time >=' => $start,
				'Timesheet.end_time <=' => $end
		)));
                
                foreach($userTimesheets as $userTimesheet) {
			$seconds = 0;
			$parts = explode(':', $userTimesheet['Timesheet']['hours']);
				
			$seconds = ($parts[0] * 60 * 60) + ($parts[1] * 60) + $parts[2];
				
			$totalSeconds = $totalSeconds + $seconds;
				
		}

		// get timesheets -starts before the cal-start-date but ends before cal-end-date
		$userTimesheets = $this->find('all',array('fields'=>array('start_time','TIMEDIFF(Timesheet.end_time,\''.$start.'\') as phours'),'conditions'=>array(
				'User.id'=>$user,
				'Timesheet.start_time <' => $start,
				'Timesheet.end_time <=' => $end,
				'Timesheet.end_time >' => $start
		)));

		foreach($userTimesheets as $userTimesheet) {
			if($userTimesheet[0]['phours']){
				$seconds = 0;
				$parts = explode(':', $userTimesheet[0]['phours']);
				
				$seconds = ($parts[0] * 60 * 60) + ($parts[1] * 60) + $parts[2];
	
				$totalSeconds = $totalSeconds + $seconds;
			}
		}

		// get timesheets -starts after cal-start-date but ends after cal-end-date
		$userTimesheets = $this->find('all',array('fields'=>array('TIMEDIFF(\''.$end.'\',Timesheet.start_time) as lhours'),'conditions'=>array(
				'User.id'=>$user,
				'Timesheet.start_time >=' => $start,
				'Timesheet.end_time >' => $end,
				'Timesheet.start_time <' => $end
		)));

		foreach($userTimesheets as $userTimesheet) {
			if($userTimesheet[0]['lhours']){
				$seconds = 0;
				$parts = explode(':', $userTimesheet[0]['lhours']);
	
				$seconds = ($parts[0] * 60 * 60) + ($parts[1] * 60) + $parts[2];
	
				$totalSeconds = $totalSeconds + $seconds;
			}
		}
		$totalHours = '';
		// extract hours
		$hours = floor($totalSeconds / (60 * 60));

		// extract minutes
		$divisor_for_minutes = $totalSeconds % (60 * 60);
		$minutes = floor($divisor_for_minutes / 60);

		// extract the remaining seconds
		$divisor_for_seconds = $divisor_for_minutes % 60;
		$seconds = ceil($divisor_for_seconds);
		if($hours == 0){
			$hours = '00';
		}
		if($minutes == 0){
			$minutes = '00';
		}
		
		$totalHours = $hours .':'.$minutes;
		
		return $hours; //discard minutes for while
	
	}
	/**
	 * creating between two date
	 * @param string since
	 * @param string until
	 * @param string step
	 * @param string date format
	 * @return array
	 * @author Ali OYGUR <alioygur@gmail.com>
	 */
	public function dateRange($first, $last, $step = '+1 day', $format = 'Y-m-d' ) {
	
		$dates = array();
		$current = strtotime($first);
		$last = strtotime($last);
	
		while( $current <= $last ) {
			$dates[] = date($format, $current);
			$current = strtotime($step, $current);
		}
                
                return $dates;
	}
	
	public function parentNode() {
		return null;
	}
	
	function timezone_list() {
		static $timezones = null;
	
		if ($timezones === null) {
			$timezones = array();
			$offsets = array();
			$now = new DateTime();
	
			foreach (DateTimeZone::listIdentifiers() as $timezone) {
				$now->setTimezone(new DateTimeZone($timezone));
				$offsets[] = $offset = $now->getOffset();
				$timezones[$timezone] = /*'(' . format_GMT_offset($offset) . ') ' . */$this->format_timezone_name($timezone);
			}
	
			array_multisort($offsets, $timezones);
		}
	
		return $timezones;
	}
	
	function format_GMT_offset($offset) {
		$hours = intval($offset / 3600);
		$minutes = abs(intval($offset % 3600 / 60));
		return 'GMT' . ($offset ? sprintf('%+03d:%02d', $hours, $minutes) : '');
	}
	
	function format_timezone_name($name) {
		//$name = str_replace('/', ', ', $name);
		$name = str_replace('_', ' ', $name);
		$name = str_replace('St ', 'St. ', $name);
		return $name;
	}
        
        
}