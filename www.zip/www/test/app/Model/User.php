<?php 
class User extends AppModel {
	public $belongsTo = array('Group', 'Department', 'Parent'=>array('className'=>'User','foreign_key'=>'parent_id'));
	
	public $hasMany = array('Job','Timesheet','Vacation');
	
	public $virtualFields = array("full_name"=>"CONCAT(User.first_name, ' ' ,User.last_name)", );
	
	public $displayField = 'full_name';
	
	public function __construct($id = false, $table = null, $ds = null) {
            parent::__construct($id, $table, $ds);
            $this->virtualFields['name'] = sprintf(
                'CONCAT(%s.first_name, " ", %s.last_name)', $this->alias, $this->alias
            );
	}
        
        public function deleteOnlyThis($id = null) {
            $customDelete = $this->query(
                    "delete from users where id = " . $id
            ); 
            
            if (empty($customDelete)) {
                return true;
            } else {
                return false;
            }
        }
        
        public $validate = array(
        'username' => array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'A username is required'
            )
        ),
        'password' => array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'A password is required'
            )
        ),
		'photo' => array(
				'rule' => array('isValidMimeType', array('application/pdf','image/bmp','image/gif', 'image/jpeg','image/pjpeg','image/png','image/vnd.microsoft.icon'), false),
				'message' => 'File type is not supported',
				'required' => false,
				'allowEmpty' =>true
		
		)
    );
	
	public $actsAs = array('Acl' => array('type' => 'both'),
			'Search.Searchable',
			'Tree',
			'Upload.Upload' => array(
					'photo' => array(
							'fields' => array(
									'dir' => 'photo_dir'
							),
							'mimetypes'=> array (
									'application/pdf',
									'image/bmp',
									'image/gif',
									'image/jpeg',
									'image/pjpeg',
									'image/png',
									'image/vnd.microsoft.icon'
							),
							'extensions' => array(
									'gif', 'jpeg', 'png', 'jpg', 'bmp', 'ico'
							),
							'thumbnailSizes' => array(
                                                                        'view' => '128x128'
									//'view' => '100x120',
									//'thumb' => '32x32',
                                                                        //'login' => '92x92'
							),
							'thumbnailMethod' => 'php', //GD library instead of imagick
							'thumbnailQuality' => '100'
					)
			),
			'Containable'
	);
	
	public $filterArgs = array(
			'search_username' => array('type'=>'value','field'=>'User.username'),
			'search_name' => array('type'=>'like','field'=>array('User.first_name','User.last_name')),
                        'search_first_name' => array('type'=>'like','field'=>'User.first_name'),
			'search_last_name' => array('type'=>'like','field'=>'User.last_name'),
                        'search_job_title' => array('type'=>'like','field'=>'Job.name'),
			'search_group' => array('type'=>'value','field'=>'Group.id'),
			'search_email' => array('type'=>'value','field'=>'User.email'),
			'search_phone' => array('type'=>'value','field'=>'User.phone'),
			'search_all' => array('type'=>'query','method'=>'searchDefault'),
			'search_user_id' => array('type'=>'value','field'=>'User.parent_id'),
                        'search_resume' => array('type'=>'value','field'=>'User.resume'),
                        'search_inactive' => array('type'=>'value','field'=>'User.active')
	);
	
	public function searchDefault($data = array()) {
		$filter = $data['search_all'];
		$cond = array(
				'OR' => array(
                                                $this->alias . '.username LIKE' => '%' . $filter . '%',
						$this->alias . '.first_name LIKE' => '%' . $filter . '%',
						$this->alias . '.last_name LIKE' => '%' . $filter . '%',
                                                'Group.name LIKE' => '%' . $filter . '%',
                                                'Department.name LIKE' => '%' . $filter . '%',
                                                $this->alias . '.full_name LIKE' => '%' . $filter . '%',
						$this->alias . '.email LIKE' => '%' . $filter . '%'
				));
                
                return $cond;
	}
	public function parentNode() {
		if (!$this->id && empty($this->data)) {
			return null;
		}
		if (isset($this->data['User']['group_id'])) {
			$groupId = $this->data['User']['group_id'];
		} else {
			$groupId = $this->field('group_id');
		}
		if (!$groupId) {
			return null;
		} else {
			return array('Group' => array('id' => $groupId));
		}
//                
//                if (isset($this->data['Department']['department_id'])) {
//			$departmentId = $this->data['Department']['department_id'];
//		} else {
//			$departmentId = $this->field('department_id');
//		}
//		if (!$departmentId) {
//			return null;
//		} else {
//			return array('Department' => array('id' => $departmentId));
//		}
//                
	}
	
	public function bindNode() { //debug(AuthComponent::user()); exit;
	$data = AuthComponent::user();
	return array('model' => 'Group', 'foreign_key' => $data['group_id']);
	}
	
	public function getOverview() {
		$this->recursive = -1;
		$users = $this->find('all');
		$result = array();
		$i = 0;
		foreach($users as $user){
			$result[$i] = $user;
			$result[$i]['Timesheet']['total'] = $this->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'])));
			$result[$i]['Timesheet']['submitted'] = $this->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'],'Timesheet.approval_status_id'=>1)));
			$result[$i]['Timesheet']['approved'] = $this->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'],'Timesheet.approval_status_id'=>2)));
			$result[$i]['Timesheet']['rejected'] = $this->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'],'Timesheet.approval_status_id'=>3)));
			$result[$i]['Timesheet']['revision'] = $this->Timesheet->find('count',array('conditions'=>array('Timesheet.user_id'=>$user['User']['id'],'Timesheet.approval_status_id'=>4)));
			$result[$i]['Vacation']['total'] = $this->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'])));
			$result[$i]['Vacation']['submitted'] = $this->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'],'Vacation.approval_status_id'=>1)));
			$result[$i]['Vacation']['approved'] = $this->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'],'Vacation.approval_status_id'=>2)));
			$result[$i]['Vacation']['rejected'] = $this->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'],'Vacation.approval_status_id'=>3)));
			$result[$i]['Vacation']['revision'] = $this->Vacation->find('count',array('conditions'=>array('Vacation.user_id'=>$user['User']['id'],'Vacation.approval_status_id'=>4)));
			$i = $i + 1;	
		}
		return $result;
	}
	
	public function beforeSave($options = array()) {
		if (isset($this->data[$this->alias]['password'])) {
	        $this->data[$this->alias]['password'] = AuthComponent::password($this->data[$this->alias]['password']);
	    }
		return true;
	}
        
        function timezone_list() {
		static $timezones = null;
	
		if ($timezones === null) {
			$timezones = array();
			$offsets = array();
			$now = new DateTime();
	
			foreach (DateTimeZone::listIdentifiers() as $timezone) {
				$now->setTimezone(new DateTimeZone($timezone));
				$offsets[] = $offset = $now->getOffset();
				$timezones[$timezone] = /*'(' . format_GMT_offset($offset) . ') ' . */$this->format_timezone_name($timezone);
			}
	
			array_multisort($offsets, $timezones);
		}
	
		return $timezones;
	}
        
        function format_GMT_offset($offset) {
		$hours = intval($offset / 3600);
		$minutes = abs(intval($offset % 3600 / 60));
		return 'GMT' . ($offset ? sprintf('%+03d:%02d', $hours, $minutes) : '');
	}
	
	function format_timezone_name($name) {
		//$name = str_replace('/', ', ', $name);
		$name = str_replace('_', ' ', $name);
		$name = str_replace('St ', 'St. ', $name);
		return $name;
	}
        
        function client_ip(){
            
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                    $ip_address = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip_address = $_SERVER['REMOTE_ADDR'];
            }
                return $ip_address;            
        }
}
