<?php
class Vacation extends AppModel {

	public $belongsTo = array('User','ApprovalStatus');
        
        public $actsAs = array('Search.Searchable');

	public $virtualFields = array();

	public $filterArgs = array(
			'search_user_id' => array('type'=>'value','field'=>'User.id'),
			'search_all' => array('type'=>'query','method'=>'searchDefault'),
			'search_status' => array('type'=>'value','field'=>'Vacation.approval_status_id'),
			'search_start' => array('type'=>'query','method'=>'searchStart'),
			'search_end' => array('type'=>'query','method'=>'searchEnd'),
	);

	public function searchDefault($data = array()) {
		$filter = $data['search_all'];
		$cond = array(
				'OR' => array(
						'User.username LIKE' => '%' . $filter . '%',
						'User.first_name LIKE' => '%' . $filter . '%',
						'User.last_name LIKE' => '%' . $filter . '%'
				));
		return $cond;
	}

	public function searchStart($data = array()) {
		if((!empty($data['search_end']) && (!empty($data['search_start'])))){
			$cond = array(
					'AND' => array(
							//$this->alias . '.date >= ' => $data['search_start'],
							//$this->alias . '.date <= ' => $data['search_end'],
							$this->alias . '.start_date >= ' => $data['search_start'],
							$this->alias . '.end_date <= ' => $data['search_end'],
					)
			);
		} elseif ((empty($data['search_end']) && (!empty($data['search_start'])))){
			//$cond = array('Vacation.date >= '=>$data['search_start']);
			$cond = array('Vacation.start_date >= '=>$data['search_start']);
		}
		else {
			$cond = array();
		}
	
		return $cond;
	}
	
	public function searchEnd($data = array()) {
	
		if((!empty($data['search_end']) && (!empty($data['search_start'])))){
			$cond = array();
		} elseif((!empty($data['search_end']) && (empty($data['search_start'])))) {
			//$cond = array('Vacation.date <= ' => $data['search_end']);
			$cond = array('Vacation.end_date <= ' => $data['search_end']);
		} else {
			$cond = array();
		}
	
		return $cond;
	}
	public $validate = array(
			'start_date' => array(
					'required' => array(
							'rule' => array('notEmpty'),
							'message' => 'Start time is required'
					)
			),
			'end_date' => array(
					'required' => array(
							'rule' => array('notEmpty'),
							'message' => 'End time is required'
					)
			)
	);
	
	public function vacationCounts($conditions = array()) {
		$total = $this->find('count');
		
		$submitted = $this->find('count',array('conditions'=>array_merge(array('Vacation.approval_status_id'=>1),$conditions)));
		$approved = $this->find('count',array('conditions'=>array_merge(array('Vacation.approval_status_id'=>2),$conditions)));
		$rejected = $this->find('count',array('conditions'=>array_merge(array('Vacation.approval_status_id'=>3),$conditions)));
		$revision = $this->find('count',array('conditions'=>array_merge(array('Vacation.approval_status_id'=>4),$conditions)));
		
		$result = array('total'=>$total,'submitted'=>$submitted,'approved'=>$approved,'rejected'=>$rejected,'revision'=>$revision);
		return $result;
	}
	
	public function vacationCountsCurrentPage($vacations = array()) {
		$total = 0;
		$submitted = 0;
		$approved = 0;
		$rejected = 0;
		$revision = 0;
		
		foreach($vacations as $vacation)
		{
			switch($vacation['Vacation']['approval_status_id']){
				case 1:
					$submitted++;
				break;
				case 2:
					$approved++;
				break;
				case 3:
					$rejected++;
				break;
				case 4:
					$revision++;
				break;
			}
			$total++;
		}
		$result = array('total'=>$total,'submitted'=>$submitted,'approved'=>$approved,'rejected'=>$rejected,'revision'=>$revision);
		return $result;
	}
	
	public function parentNode() {
		return null;
	}
        
        
}