-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2014 at 07:50 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--
DROP TABLE IF EXISTS `acos`;
CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT '',
  `foreign_key` int(10) unsigned DEFAULT NULL,
  `alias` varchar(255) DEFAULT '',
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=129 ;

--
-- Dumping data for table `acos`
--

INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, 'Group', 1, '', 1, 4),
(2, NULL, 'Group', 2, '', 5, 8),
(3, NULL, 'Group', 3, '', 9, 16),
(4, 1, 'User', 1, '', 2, 3),
(5, NULL, NULL, NULL, 'controllers', 17, 256),
(6, 5, NULL, NULL, 'ApprovalStatuses', 18, 29),
(7, 6, NULL, NULL, 'index', 19, 20),
(8, 6, NULL, NULL, 'view', 21, 22),
(9, 6, NULL, NULL, 'add', 23, 24),
(10, 6, NULL, NULL, 'edit', 25, 26),
(11, 6, NULL, NULL, 'delete', 27, 28),
(12, 5, NULL, NULL, 'Departments', 30, 41),
(13, 12, NULL, NULL, 'index', 31, 32),
(14, 12, NULL, NULL, 'view', 33, 34),
(15, 12, NULL, NULL, 'add', 35, 36),
(16, 12, NULL, NULL, 'edit', 37, 38),
(17, 12, NULL, NULL, 'delete', 39, 40),
(18, 5, NULL, NULL, 'Groups', 42, 53),
(19, 18, NULL, NULL, 'add', 43, 44),
(20, 18, NULL, NULL, 'edit', 45, 46),
(21, 18, NULL, NULL, 'index', 47, 48),
(22, 18, NULL, NULL, 'view', 49, 50),
(23, 18, NULL, NULL, 'delete', 51, 52),
(24, 5, NULL, NULL, 'Jobs', 54, 69),
(25, 24, NULL, NULL, 'index', 55, 56),
(26, 24, NULL, NULL, 'expired', 57, 58),
(27, 24, NULL, NULL, 'view', 59, 60),
(28, 24, NULL, NULL, 'add', 61, 62),
(29, 24, NULL, NULL, 'edit', 63, 64),
(30, 24, NULL, NULL, 'delete', 65, 66),
(31, 24, NULL, NULL, 'names', 67, 68),
(32, 5, NULL, NULL, 'Options', 70, 81),
(33, 32, NULL, NULL, 'edit', 71, 72),
(34, 32, NULL, NULL, 'add', 73, 74),
(35, 32, NULL, NULL, 'index', 75, 76),
(36, 32, NULL, NULL, 'view', 77, 78),
(37, 32, NULL, NULL, 'delete', 79, 80),
(38, 5, NULL, NULL, 'Pages', 82, 95),
(39, 38, NULL, NULL, 'display', 83, 84),
(40, 38, NULL, NULL, 'add', 85, 86),
(41, 38, NULL, NULL, 'edit', 87, 88),
(42, 38, NULL, NULL, 'index', 89, 90),
(43, 38, NULL, NULL, 'view', 91, 92),
(44, 38, NULL, NULL, 'delete', 93, 94),
(45, 5, NULL, NULL, 'Timesheets', 96, 169),
(46, 45, NULL, NULL, 'index', 97, 98),
(47, 45, NULL, NULL, 'all', 99, 100),
(48, 45, NULL, NULL, 'unapproved', 101, 102),
(49, 45, NULL, NULL, 'approved', 103, 104),
(50, 45, NULL, NULL, 'calendar', 105, 106),
(51, 45, NULL, NULL, 'reports', 107, 108),
(52, 45, NULL, NULL, 'reportsAggregate', 109, 110),
(53, 45, NULL, NULL, 'reportsLast', 111, 112),
(54, 45, NULL, NULL, 'reportsUsersCsv2', 113, 114),
(55, 45, NULL, NULL, 'reportsUsers', 115, 116),
(56, 45, NULL, NULL, 'getManagerUsers', 117, 118),
(57, 45, NULL, NULL, 'getReportsUsers', 119, 120),
(58, 45, NULL, NULL, 'calendarFeedNotEndedEvent', 121, 122),
(59, 45, NULL, NULL, 'calendarFeed', 123, 124),
(60, 45, NULL, NULL, 'getTotalHours', 125, 126),
(61, 45, NULL, NULL, 'userTimesheet', 127, 128),
(62, 45, NULL, NULL, 'dashboard', 129, 130),
(63, 45, NULL, NULL, 'timer_edit', 131, 132),
(64, 45, NULL, NULL, 'timer_table', 133, 134),
(65, 45, NULL, NULL, 'timer_start', 135, 136),
(66, 45, NULL, NULL, 'timer_end', 137, 138),
(67, 45, NULL, NULL, 'timer_delete', 139, 140),
(68, 45, NULL, NULL, 'updateStatus', 141, 142),
(69, 45, NULL, NULL, 'update', 143, 144),
(70, 45, NULL, NULL, 'view', 145, 146),
(71, 45, NULL, NULL, 'ajax_joblist', 147, 148),
(72, 45, NULL, NULL, 'add', 149, 150),
(73, 45, NULL, NULL, 'edit', 151, 152),
(74, 45, NULL, NULL, 'ajax_edit', 153, 154),
(75, 45, NULL, NULL, 'ajax_delete', 155, 156),
(76, 45, NULL, NULL, 'changeStatus', 157, 158),
(77, 45, NULL, NULL, 'delete', 159, 160),
(78, 45, NULL, NULL, 'checktimesheet', 161, 162),
(79, 45, NULL, NULL, 'ajax_notify_user', 163, 164),
(80, 45, NULL, NULL, 'announcementpopup', 165, 166),
(81, 45, NULL, NULL, 'checkLogin', 167, 168),
(82, 5, NULL, NULL, 'Users', 170, 217),
(83, 82, NULL, NULL, 'login', 171, 172),
(84, 82, NULL, NULL, 'logout', 173, 174),
(85, 82, NULL, NULL, 'index', 175, 176),
(86, 82, NULL, NULL, 'inactive_users', 177, 178),
(87, 82, NULL, NULL, 'directory', 179, 180),
(88, 82, NULL, NULL, 'organization', 181, 182),
(89, 82, NULL, NULL, 'clear_directory_organization_cache', 183, 184),
(90, 82, NULL, NULL, 'view', 185, 186),
(91, 82, NULL, NULL, 'add', 187, 188),
(92, 82, NULL, NULL, 'edit', 189, 190),
(93, 82, NULL, NULL, 'delete', 191, 192),
(94, 82, NULL, NULL, 'forgot', 193, 194),
(95, 82, NULL, NULL, 'reset', 195, 196),
(96, 82, NULL, NULL, 'initacl', 197, 198),
(97, 82, NULL, NULL, 'rebuildACL', 199, 200),
(98, 82, NULL, NULL, 'import', 201, 202),
(99, 82, NULL, NULL, 'announcements', 203, 204),
(100, 82, NULL, NULL, 'announcement_add', 205, 206),
(101, 82, NULL, NULL, 'announcement_edit', 207, 208),
(102, 82, NULL, NULL, 'language', 209, 210),
(103, 82, NULL, NULL, 'announcement_delete', 211, 212),
(104, 82, NULL, NULL, 'names', 213, 214),
(105, 82, NULL, NULL, 'setPhotoAndName', 215, 216),
(106, 5, NULL, NULL, 'Vacations', 218, 241),
(107, 106, NULL, NULL, 'index', 219, 220),
(108, 106, NULL, NULL, 'calendar', 221, 222),
(109, 106, NULL, NULL, 'reports', 223, 224),
(110, 106, NULL, NULL, 'update', 225, 226),
(111, 106, NULL, NULL, 'view', 227, 228),
(112, 106, NULL, NULL, 'add', 229, 230),
(113, 106, NULL, NULL, 'edit', 231, 232),
(114, 106, NULL, NULL, 'changeStatus', 233, 234),
(115, 106, NULL, NULL, 'readyTip', 235, 236),
(116, 106, NULL, NULL, 'delete', 237, 238),
(117, 106, NULL, NULL, 'super_unique', 239, 240),
(118, 5, NULL, NULL, 'TwitterBootstrap', 242, 255),
(119, 118, NULL, NULL, '', 243, 254),
(120, 119, NULL, NULL, 'add', 244, 245),
(121, 119, NULL, NULL, 'edit', 246, 247),
(122, 119, NULL, NULL, 'index', 248, 249),
(123, 119, NULL, NULL, 'view', 250, 251),
(124, 119, NULL, NULL, 'delete', 252, 253),
(125, 2, 'User', 2, '', 6, 7),
(126, 3, 'User', 3, '', 10, 11),
(127, 3, 'User', 4, '', 12, 13),
(128, 3, 'User', 5, '', 14, 15);

-- --------------------------------------------------------

--
-- Table structure for table `approval_statuses`
--
DROP TABLE IF EXISTS `approval_statuses`;
CREATE TABLE IF NOT EXISTS `approval_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `approval_statuses`
--

INSERT INTO `approval_statuses` (`id`, `name`, `created`, `modified`) VALUES
(1, 'Submitted', '2013-08-09 07:52:12', '2013-08-09 07:52:12'),
(2, 'Approved', '2013-08-09 07:52:28', '2013-08-09 07:52:28'),
(3, 'Rejected', '2013-08-09 07:52:40', '2013-08-09 07:52:40'),
(4, 'Needs revision', '2013-08-09 07:52:53', '2013-08-09 07:52:53');

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--
DROP TABLE IF EXISTS `aros`;
CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT '',
  `foreign_key` int(10) unsigned DEFAULT NULL,
  `alias` varchar(255) DEFAULT '',
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `aros`
--

INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, 'Group', 1, '', 1, 4),
(2, NULL, 'Group', 2, '', 5, 8),
(3, NULL, 'Group', 3, '', 9, 16),
(4, 1, 'User', 1, '', 2, 3),
(5, 2, 'User', 2, '', 6, 7),
(6, 3, 'User', 3, '', 10, 11),
(7, 3, 'User', 4, '', 12, 13),
(8, 3, 'User', 5, '', 14, 15);

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--
DROP TABLE IF EXISTS `aros_acos`;
CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aro_id` int(10) unsigned NOT NULL,
  `aco_id` int(10) unsigned NOT NULL,
  `_create` char(2) NOT NULL DEFAULT '0',
  `_read` char(2) NOT NULL DEFAULT '0',
  `_update` char(2) NOT NULL DEFAULT '0',
  `_delete` char(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `aros_acos`
--

INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
(1, 1, 5, '1', '1', '1', '1'),
(2, 2, 5, '1', '1', '1', '1'),
(3, 2, 18, '-1', '-1', '-1', '-1'),
(4, 3, 5, '1', '1', '1', '1'),
(5, 3, 6, '-1', '-1', '-1', '-1'),
(6, 3, 18, '-1', '-1', '-1', '-1'),
(7, 3, 35, '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--
DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `created`, `modified`) VALUES
(1, 'Administrator', '2013-08-08 08:35:16', '2013-08-08 08:35:16'),
(2, 'User Manager', '2013-08-08 08:36:12', '2013-08-08 08:36:12'),
(3, 'Users', '2013-08-08 08:36:12', '2013-08-08 08:36:12');

-- --------------------------------------------------------

--
-- Table structure for table `i18n`
--
DROP TABLE IF EXISTS `i18n`;
CREATE TABLE IF NOT EXISTS `i18n` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `locale` varchar(6) NOT NULL,
  `model` varchar(255) NOT NULL,
  `foreign_key` int(10) NOT NULL,
  `field` varchar(255) NOT NULL,
  `content` mediumtext,
  PRIMARY KEY (`id`),
  KEY `locale` (`locale`),
  KEY `model` (`model`),
  KEY `row_id` (`foreign_key`),
  KEY `field` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `hourly_salary` float DEFAULT NULL,
  `expected_hours` int(11) DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `vacation_days` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `options`
--
DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `value` longtext,
  `logo` varchar(255) DEFAULT NULL,
  `logo_dir` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `name`, `value`, `logo`, `logo_dir`) VALUES
(1, 'title', 'Zhen HRM', NULL, NULL),
(2, 'copyright', 'Copyright &copy; 2014 Telerim', '', ''),
(3, 'row_other', '30', NULL, NULL),
(4, 'email', 'admin@zhen-hrm.com', NULL, NULL),
(5, 'email_title', 'Zhen HRM', NULL, NULL),
(6, 'currency', '$', NULL, NULL),
(7, 'date_format', 'M j, Y', NULL, NULL),
(8, 'datetime_format', 'D, M j, Y g:i A', NULL, NULL),
(9, 'email_host', '', NULL, NULL),
(10, 'email_port', '', NULL, NULL),
(11, 'email_user', '', NULL, NULL),
(12, 'email_password', '', NULL, NULL),
(13, 'vacation_email', 'admin@zhen-hrm.com', NULL, NULL),
(14, 'edit_timesheet', 'true', NULL, NULL),
(15, 'server_timezone', 'UTC', NULL, NULL),
(17, 'show_copyright', 'true', NULL, NULL),
(18, 'user_timezone', 'UTC', NULL, NULL),
(19, 'email_template_vacation', '<p>Vacation notification for {{fullname}}.</p><p>Vacation Dates:</p><p>{{vacationlist}}</p><p>&nbsp;</p>', NULL, NULL),
(20, 'email_template_newuser', '<p>Following are the new credential</p><p>Username: {{username}}</p><p>Password: {{password}}</p><p>Don''t forget to change it for security reasons.</p>', NULL, NULL),
(21, 'email_template_reset', '<p>Please click on the link below to reset your password.</p><p>{{resetlink}}</p><p>In case the above link dosen''t work, you can also copy the URL in the browser address bar.</p><p>&nbsp;</p>', NULL, NULL),
(22, 'timer_endtime', 'true', NULL, NULL),
(24, 'timer_notification', '1', NULL, NULL),
(27, 'manager_edit_staff_timesheet', 'true', NULL, NULL),
(33, 'default_start_time', '09:00', NULL, NULL),
(34, 'default_end_time', '18:00', NULL, NULL),
(37, 'default_homepage', '0', NULL, NULL),
(40, 'email_template_newpassword', '<p>Following are the new credential</p><p>Username: {{username}}</p><p>Password: {{password}}</p><p>Don''t forget to change it for security reasons.</p><p>&nbsp;</p>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `timesheets`
--
DROP TABLE IF EXISTS `timesheets`;
CREATE TABLE IF NOT EXISTS `timesheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `note` text,
  `user_id` int(11) NOT NULL,
  `approval_status_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `approved_by_id` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36;


-- --------------------------------------------------------

--
-- Table structure for table `users`
--
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` char(50) NOT NULL,
  `group_id` int(11) NOT NULL,
  `last_login` datetime NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `photo_dir` varchar(255) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone` text,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `token` char(50) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `department_id` int(11) NOT NULL,
  `user_timezone` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `vacations`
--
DROP TABLE IF EXISTS `vacations`;
CREATE TABLE IF NOT EXISTS `vacations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `approval_status_id` int(11) NOT NULL,
  `description` text,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `approved_by_id` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

-- --------------------------------------------------------
--
-- Table structure for table `announcements`
--
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE IF NOT EXISTS `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text CHARACTER SET utf8,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;
-- ----------------------------------------------------------
--
-- Table structure for table `departments`
--
DROP TABLE IF EXISTS `departments`;
CREATE TABLE IF NOT EXISTS `departments` (
`id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL,
   PRIMARY KEY (`id`)
 	
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Table structure for table `languages`
--
DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
`id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `display` varchar(255) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Admin user
-- 
INSERT INTO `users` (`id`, `username`, `password`, `group_id`, `last_login`, `created`, `modified`, `first_name`, `last_name`, `photo`, `photo_dir`, `email`, `phone`, `parent_id`, `lft`, `rght`, `token`, `active`, `department_id`, `user_timezone`) VALUES
(1, 'admin', 'ba6fe00d412b5a8803c2c8a0c5f9f987ad9432ab', 1, '2014-09-02 05:38:17', '2013-08-08 08:37:28', '2014-09-02 05:38:17', 'John', 'Carter', 'telerim-icon.png', '1', 'support@telerim.com', NULL, NULL, 1, 10, NULL, 1, 0, 'UTC');
