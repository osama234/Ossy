-- Jobs table
ALTER TABLE jobs ADD INDEX start_date ( start_date );
ALTER TABLE jobs ADD INDEX end_date ( end_date );
ALTER TABLE jobs ADD INDEX user_id ( user_id );

-- Timesheets table
ALTER TABLE timesheets ADD INDEX start_time ( start_time );
ALTER TABLE timesheets ADD INDEX end_time ( end_time );
ALTER TABLE timesheets ADD INDEX user_id ( user_id );

-- Vacations table
ALTER TABLE vacations ADD INDEX start_date ( start_date );
ALTER TABLE vacations ADD INDEX end_date ( end_date );
ALTER TABLE vacations ADD INDEX user_id ( user_id );

