// JavaScript Document
var calendar;
var d = new Date;
        var t = d.getHours();
$(document).ready(function() {
    // page is now ready, initialize the calendar...
    calendar = $('#calendar').fullCalendar({
		theme: true,
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month,agendaWeek,agendaDay'
		},
		allDaySlot: false,
		defaultView: 'agendaWeek',
		firstHour: t,
		weekMode: 'variable',
		aspectRatio: 2,
		selectable: true,
		selectHelper: true,
		select: function(start, end, allDay) {
			var st = new Date(start);
			var et = new Date(end);
			var usr = $('#user-filter').val();
			var startTime = $.fullCalendar.formatDate(st,'yyyy-MM-dd HH:mm');
			var endTime = $.fullCalendar.formatDate(et,'yyyy-MM-dd HH:mm');
			//var addUrl = encodeURI(plgFcRoot + 'timesheets/add?start='+startTime+'&end='+endTime+'&usr='+usr);
                        showAddForm(startTime,endTime,usr);
		},
		editable: false,
		events: function (start, end, callback) {
            var st = start.getFullYear() + '-' + (start.getMonth() + 1) + '-' + start.getDate() + ' 00:00:00';
            var en = end.getFullYear() + '-' + (end.getMonth() + 1) + '-' + end.getDate() + ' 00:00:00';

            //console.log(Math.round(start.getTime() / 1000));
            $.ajax({
                url: plgFcRoot + "/timesheets/calendarFeed?c=" + Math.random(),
                type: "POST",
                cache: false,
                dataType: 'json',
                data: {
                    // feed requires UNIX timestamps
                    start: st, //Math.round(start.getTime() / 1000),
                    end: en, //Math.round(end.getTime() / 1000),
                    user: FcUser, // the user
                    nc: Math.random()
                },
                success: function (events) {
                    console.log(events);
                    calendar.fullCalendar('removeEvents');
                    callback(events);
                }
            });
        },
	    eventClick: function(calEvent, jsEvent, view) {
                var xend = null;
                if (calEvent['end'] == null) {
                    $.ajax({
                        url: plgFcRoot + "/timesheets/calendarFeedNotEndedEvent",
                        type: "POST",
                        cache: false,
                        dataType: 'json',
                        data: { id:calEvent['id'] },
                        success: function(response) {
                            xend = response;
                            if(calEvent.editAllowed == true) {
                                showEditForm(calEvent, xend);
                            }
                        }
                    });
                } else {
                    if(calEvent.editAllowed == true) {
                        showEditForm(calEvent, xend);
                    }
                }
	    	
	    	return false;
	    },
	    loading: function( isLoading, view ) {
    		if(isLoading){
    			$('#event-loading').show();
    		} else {
    			$('#event-loading').hide();
    			var cStart = $.fullCalendar.formatDate(view.visStart,'yyyy-MM-dd HH:mm');
        		var cEnd = $.fullCalendar.formatDate(view.visEnd,'yyyy-MM-dd HH:mm');
        		showTotalHours(cStart, cEnd);
    		}
    	},
		eventRender: function(event, element) { 
			//console.log(event);
        	/*element.qtip({
				content: event.toolTip,
				position: { 
					target: 'mouse',
					adjust: {
						x: 10,
						y: -5
					}
				},
				style: {
					name: 'light',
					tip: 'leftTop'
				},
				hide: {
		             fixed: true // Make it fixed so it can be hovered over
		          }
        	});*/
        	
        	element.qtip(
        		      {
        		          content: event.statusUpdate, // Give it some content
        		          position: 'topRight', // Set its position
        		          hide: {
        		             fixed: true // Make it fixed so it can be hovered over
        		          },
        		          style: {
        		             padding: '2px 3px', // Give it some extra padding
        		             //name: 'dark' // And style it with the preset dark theme
        		          }
        		       });
        	
    	},
    	viewRender: function(view, element) {
    		//code is placed in loading so that it works just after add/edit
    		//var cStart = $.fullCalendar.formatDate(view.visStart,'yyyy-MM-dd HH:mm');
    		//var cEnd = $.fullCalendar.formatDate(view.visEnd,'yyyy-MM-dd HH:mm');
    		//showTotalHours(cStart, cEnd);
    	},
		eventDragStart: function(event) {
			$(this).qtip("destroy");
		},
		eventDrop: function(event) {
			var startdate = new Date(event.start);
			var startyear = startdate.getFullYear();
			var startday = startdate.getDate();
			var startmonth = startdate.getMonth()+1;
			var starthour = startdate.getHours();
			var startminute = startdate.getMinutes();
			var enddate = new Date(event.end);
			var endyear = enddate.getFullYear();
			var endday = enddate.getDate();
			var endmonth = enddate.getMonth()+1;
			var endhour = enddate.getHours();
			var endminute = enddate.getMinutes();
			if(event.allDay == true) {
				var allday = 1;
			} else {
				var allday = 0;
			}
			var url = plgFcRoot + "/timesheets/update?id="+event.id+"&start="+startyear+"-"+startmonth+"-"+startday+" "+starthour+":"+startminute+":00&end="+endyear+"-"+endmonth+"-"+endday+" "+endhour+":"+endminute+":00&allday="+allday;
			$.post(url, function(data){});
		},
		eventResizeStart: function(event) {
			$(this).qtip("destroy");
		},
		eventResize: function(event) {
			var startdate = new Date(event.start);
			var startyear = startdate.getFullYear();
			var startday = startdate.getDate();
			var startmonth = startdate.getMonth()+1;
			var starthour = startdate.getHours();
			var startminute = startdate.getMinutes();
			var enddate = new Date(event.end);
			var endyear = enddate.getFullYear();
			var endday = enddate.getDate();
			var endmonth = enddate.getMonth()+1;
			var endhour = enddate.getHours();
			var endminute = enddate.getMinutes();
			var url = plgFcRoot + "/timesheets/update?id="+event.id+"&start="+startyear+"-"+startmonth+"-"+startday+" "+starthour+":"+startminute+":00&end="+endyear+"-"+endmonth+"-"+endday+" "+endhour+":"+endminute+":00";
			$.post(url, function(data){});
		}
    });

    
});