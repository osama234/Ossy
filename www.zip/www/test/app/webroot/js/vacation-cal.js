// JavaScript Document
var calendar;
$(document).ready(function() {

    // page is now ready, initialize the calendar...
    calendar = $('#calendar').fullCalendar({
		theme: true,
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month,agendaWeek,agendaDay'
		},
		allDaySlot: true,
		defaultView: 'month',
		firstHour: 8,
		weekMode: 'variable',
		aspectRatio: 2,
		selectable: true,
		selectHelper: true,
		select: function(start, end, allDay) {
				var st = new Date(start);
				var et = new Date(end);
				var usr = $('#user-filter').val();
				var startTime = $.fullCalendar.formatDate(st,'yyyy-MM-dd HH:mm');
				var endTime = $.fullCalendar.formatDate(et,'yyyy-MM-dd HH:mm');
				//var addUrl = encodeURI(plgFcRoot + 'timesheets/add?start='+startTime+'&end='+endTime+'&usr='+usr);

				showAddForm(startTime,endTime,usr);
		},
		editable: false,
		events: FcEvents,
		/*events: function(start, end, callback) {
			//console.log(start);
	        $.ajax({
	            url: plgFcRoot + "vacations/calendar?c=" + Math.random(),
	            type: "POST",
	            cache: false,
	            dataType: 'json',
	            data: {
	                // feed requires UNIX timestamps
	                start: Math.round(start.getTime() / 1000),
	                end: Math.round(end.getTime() / 1000),
	                ///user:FcUser, // the user
					nc: Math.random()
	            },
	            success: function(events) {
	            	console.log(events);
	            	calendar.fullCalendar('removeEvents');
	            	callback(events);
	            },
				error:function(events){
					alert('fail');
				}
	        });
	    },*/
		eventRender: function(event, element) {
			//console.log(event);
        	
        	
			
        	element.qtip({
                    content: event.statusUpdate, // Give it some content
                    position: {
                        target: 'mouse',
                        adjust: {
                            screen: true,
                            mouse: false,
                            scroll: false,
                            x: 10,
                            y: -5
                        },
                        corner: {
                            target: 'bottomRight',
                            tooltip: 'bottomLeft'
                        }
                    },
                    hide: {
                        fixed: true // Make it fixed so it can be hovered over
                    },
                    style: {
                        padding: '2px 3px', // Give it some extra padding
                        //name: 'dark' // And style it with the preset dark theme
                    }
                });
        	
    	},
    	eventAfterRender: function(event, element, view) {
    		
    	},
		eventDragStart: function(event) {
			$(this).qtip("destroy");
		},
		eventDrop: function(event) {
			var startdate = new Date(event.start);
			var startyear = startdate.getFullYear();
			var startday = startdate.getDate();
			var startmonth = startdate.getMonth()+1;
			var starthour = startdate.getHours();
			var startminute = startdate.getMinutes();
			var enddate = new Date(event.end);
			var endyear = enddate.getFullYear();
			var endday = enddate.getDate();
			var endmonth = enddate.getMonth()+1;
			var endhour = enddate.getHours();
			var endminute = enddate.getMinutes();
			if(event.allDay == true) {
				var allday = 1;
			} else {
				var allday = 0;
			}
			var url = plgFcRoot + "/vacations/update?id="+event.id+"&start="+startyear+"-"+startmonth+"-"+startday+" "+starthour+":"+startminute+":00&end="+endyear+"-"+endmonth+"-"+endday+" "+endhour+":"+endminute+":00&allday="+allday;
			$.post(url, function(data){});
		},
		eventResizeStart: function(event) {
			$(this).qtip("destroy");
		},
		eventResize: function(event) {
			var startdate = new Date(event.start);
			var startyear = startdate.getFullYear();
			var startday = startdate.getDate();
			var startmonth = startdate.getMonth()+1;
			var starthour = startdate.getHours();
			var startminute = startdate.getMinutes();
			var enddate = new Date(event.end);
			var endyear = enddate.getFullYear();
			var endday = enddate.getDate();
			var endmonth = enddate.getMonth()+1;
			var endhour = enddate.getHours();
			var endminute = enddate.getMinutes();
			var url = plgFcRoot + "/vacations/update?id="+event.id+"&start="+startyear+"-"+startmonth+"-"+startday+" "+starthour+":"+startminute+":00&end="+endyear+"-"+endmonth+"-"+endday+" "+endhour+":"+endminute+":00";
			$.post(url, function(data){});
		}
    });

    
});