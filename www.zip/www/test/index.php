<?php

@mysql_connect('localhost','root','');
mysql_select_db('mcw_data');


$e = [];
$q = mysql_query('select * from users');
while($a = mysql_fetch_array($q)){
	$e[$a['user_id']] = $a;
	$e[$a['user_id']]['newpassword'] = rand(1111,9999);
	$e[$a['user_id']]['mdfnewpassword'] = md5($e[$a['user_id']]['newpassword']);
	echo 'update users set user_password = "'.$e[$a['user_id']]['newpassword'].'" where user_id='.$a['user_id'].'<br/>';
	mysql_query('update users set user_password = "'.$e[$a['user_id']]['mdfnewpassword'].'" where user_id='.$a['user_id']);
}
foreach($e as $a)
print("{$a['newpassword']} {$a['user_mail']} <br/>");
?>